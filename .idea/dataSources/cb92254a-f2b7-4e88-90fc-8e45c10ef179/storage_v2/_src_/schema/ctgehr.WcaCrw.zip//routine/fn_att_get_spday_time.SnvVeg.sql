create procedure FN_ATT_GET_SPDAY_TIME(IN  MY_EMPID      bigint unsigned, IN MY_SPDAYID bigint unsigned,
                                       IN  MY_DATE       date, OUT MY_SPDAY_BGTM datetime, OUT MY_SPDAY_EDTM datetime,
                                       OUT MY_SPDAY_FLAG int)
  comment '算出某个员工某个特殊节假日在某天的开始结束时间'
  BEGIN
DECLARE ATTID,MY_DEPTID BIGINT UNSIGNED;
DECLARE SP_BGPT,SP_EDPT,IS_HAVE_EMP,IS_HAVE_SPDAY INT;
DECLARE SP_BGDT,SP_EDDT DATE;
DECLARE MST,MET,AST,AET TIME;
DECLARE ATTID_STR TEXT;
	IF MY_EMPID IS NOT NULL AND MY_SPDAYID IS NOT NULL AND MY_DATE IS NOT NULL THEN
		SELECT COUNT(*) INTO IS_HAVE_EMP 
		FROM emp_base_info A 
			LEFT JOIN emp_post B ON A.emp_id=B.emp_id
		WHERE A.emp_id=MY_EMPID AND A.is_delete=0 AND A.emp_state IS NOT NULL
			AND B.entry_date IS NOT NULL AND B.entry_date<=MY_DATE AND (B.leave_date IS NULL OR B.leave_date >= MY_DATE);
	
		SELECT COUNT(*) INTO IS_HAVE_SPDAY
		FROM att_set_special_day A
		WHERE A.sp_day_id=MY_SPDAYID AND A.begin_date <= MY_DATE AND A.end_date >= MY_DATE;
		
		IF IS_HAVE_EMP > 0  AND IS_HAVE_SPDAY > 0 THEN
			SELECT A.begin_date,A.begin_point,A.end_date,A.end_point
				INTO SP_BGDT,SP_BGPT,SP_EDDT,SP_EDPT
			FROM att_set_special_day A 
			WHERE A.sp_day_id=MY_SPDAYID;
			
			CALL SP_DPT_GET_SETTINGID(MY_EMPID,MY_DATE,1,ATTID_STR);

			SET ATTID = CAST(ATTID_STR AS UNSIGNED);

			SELECT B.morn_start_time,B.morn_end_time,B.aftn_start_time,B.aftn_end_time
				INTO MST,MET,AST,AET
			FROM att_set_schema_new B
			WHERE B.att_id=ATTID;

			#如果特殊节假日不跨天
			IF SP_BGDT=SP_EDDT THEN
				#上午
				IF SP_BGPT = 1 AND SP_EDPT = 1 THEN
					SET MY_SPDAY_BGTM = CONCAT(MY_DATE,' ',MST);
					SET MY_SPDAY_EDTM = CONCAT(MY_DATE,' ',MET);
					SET MY_SPDAY_FLAG = 1;
				#下午
				ELSEIF SP_BGPT = 2 AND SP_EDPT = 2 THEN
					SET MY_SPDAY_BGTM = CONCAT(MY_DATE,' ',AST);
					SET MY_SPDAY_EDTM = CONCAT(MY_DATE,' ',AET);
					SET MY_SPDAY_FLAG = 2;
				#全天
				ELSEIF SP_BGPT = 1 AND SP_EDPT = 2 THEN
					SET MY_SPDAY_BGTM = CONCAT(MY_DATE,' ',MST);
					SET MY_SPDAY_EDTM = CONCAT(MY_DATE,' ',AET);
					SET MY_SPDAY_FLAG = 3;
				END IF;
			#特殊节假日跨天，要看它处于哪一天
			ELSE
				#第一天
				IF MY_DATE = SP_BGDT THEN
					SET MY_SPDAY_EDTM = CONCAT(MY_DATE,' ',AET);
					IF SP_BGPT = 1 THEN
						SET MY_SPDAY_BGTM = CONCAT(MY_DATE,' ',MST);
						SET MY_SPDAY_FLAG = 3;
					ELSEIF SP_BGPT = 2 THEN
						SET MY_SPDAY_BGTM = CONCAT(MY_DATE,' ',AST);
						SET MY_SPDAY_FLAG = 2;
					END IF;
				#最后一天
				ELSEIF MY_DATE = SP_EDDT THEN
					SET MY_SPDAY_BGTM = CONCAT(MY_DATE,' ',MST);
					IF SP_EDPT = 1 THEN
						SET MY_SPDAY_EDTM = CONCAT(MY_DATE,' ',MET);
						SET MY_SPDAY_FLAG = 1;
					ELSEIF SP_EDPT = 2 THEN
						SET MY_SPDAY_EDTM = CONCAT(MY_DATE,' ',AET);
						SET MY_SPDAY_FLAG = 3;
					END IF;
				ELSE
					SET MY_SPDAY_BGTM = CONCAT(MY_DATE,' ',MST);
					SET MY_SPDAY_EDTM = CONCAT(MY_DATE,' ',AET);
					SET MY_SPDAY_FLAG = 3;
				END IF;
			END IF;
		END IF;
	END IF;
#	SET MY_SPDAY_BGTM = FN_SYS_DTTMFMT_PURGE_SECOND(MY_SPDAY_BGTM);
#	SET MY_SPDAY_EDTM = FN_SYS_DTTMFMT_PURGE_SECOND(MY_SPDAY_EDTM);
END;

