create procedure SP_ATT_SYS_SPECIAL(IN SYS_SPDATE date, IN CUSTID bigint unsigned, IN DEPTID bigint unsigned,
                                    IN EMPID      bigint unsigned, IN DTTYPE int)
  comment '系统预留的特殊节假日日报追加'
  BEGIN
DECLARE MY_SPDAYNAME,I_VERSION_CODE VARCHAR(50);
DECLARE IS_GET_SPDAY,STAT,SP_CT,SP_MXCT,MY_SPDAY_FLAG BIGINT;
DECLARE MY_EMPID,MY_SPDAYID,MY_DEPTID,MY_CUSTID BIGINT UNSIGNED;
DECLARE MY_SPDAY_BGTM,MY_SPDAY_EDTM DATETIME;
DECLARE MY_SP_HOUR DECIMAL(12,2);
DECLARE SPDAY_STR TEXT;


	SET I_VERSION_CODE = UUID();
	
	if (CUSTID is null and DEPTID is null AND DTTYPE IS NULL and EMPID is null) then
		set STAT=4;
	elseif (CUSTID is not null and DEPTID is null AND DTTYPE IS NULL and EMPID is null) then
		set STAT=3;
	elseif (DEPTID is not null AND DTTYPE IS NOT NULL and EMPID is null) then
		set STAT=2;
	elseif (EMPID is not null) then
		set STAT=1;
	end if;

	#38妇女节
	IF MONTH(SYS_SPDATE)=3 AND DAY(SYS_SPDATE)=8 THEN
		CASE STAT
		WHEN 4 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dept_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=1 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.prgm_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=2 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.jrdc_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=3 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id4=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=4 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id5=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=5 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id6=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=6 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id7=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=7 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id8=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=8 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id9=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=9 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id10=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=10 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
		WHEN 3 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dept_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=1 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.prgm_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=2 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.jrdc_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=3 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id4=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=4 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id5=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=5 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id6=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=6 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id7=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=7 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id8=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=8 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id9=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=9 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id10=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.sp_type=1 AND D.dept_type=10 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
		WHEN 2 THEN
			CASE DTTYPE
			WHEN 1 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dept_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=1 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 2 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.prgm_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=2 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 3 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.jrdc_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=3 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 4 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id4=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=4 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 5 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id5=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=5 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 6 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id6=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=6 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 7 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id7=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=7 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 8 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id8=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=8 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 9 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id9=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=9 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			WHEN 10 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id10=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.dept_id=DEPTID AND D.sp_type=1 AND D.dept_type=10 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
			END CASE;
		WHEN 1 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id) 
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dept_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=1 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.prgm_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=2 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.jrdc_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=3 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id4=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=4 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id5=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=5 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id6=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=6 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id7=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=7 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id8=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=8 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id9=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=9 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE)
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id 
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN att_rel_special_dept C ON A.dms_id10=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.sp_type=1 AND D.dept_type=10 AND MONTH(D.begin_date)=3 AND DAY(D.begin_date=8) AND D.is_enable=1 AND D.is_delete=0 AND A.gender = 2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE);
		END CASE;
	#54青年节
	ELSEIF MONTH(SYS_SPDATE)=5 AND DAY(SYS_SPDATE)=4 THEN
		CASE STAT
		WHEN 4 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A 
					LEFT JOIN emp_post B ON A.emp_id=B.emp_id 
					LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dept_id=E.dept_id 
					LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=1 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.prgm_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=2 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.jrdc_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=3 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id4=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=4 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id5=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=5 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id6=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=6 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id7=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=7 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id8=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=8 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id9=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=9 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id10=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND D.dept_type=10 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;				
		WHEN 3 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dept_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=1 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.prgm_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=2 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.jrdc_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=3 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id4=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=4 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id5=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=5 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id6=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=6 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id7=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=7 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id8=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=8 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id9=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=9 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id10=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.cust_id = CUSTID AND D.dept_type=10 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;				
		WHEN 2 THEN
			CASE DTTYPE
			WHEN 1 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dept_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=1 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 2 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.prgm_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=2 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 3 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.jrdc_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=3 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 4 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id4=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=4 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 5 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id5=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=5 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 6 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id6=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=6 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 7 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id7=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=7 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 8 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id8=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=8 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 9 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id9=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=9 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;
			WHEN 10 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id10=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.dept_id = DEPTID AND D.dept_type=10 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;	
			END CASE;
		WHEN 1 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dept_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=1 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.prgm_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=2 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.jrdc_id=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=3 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id4=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=4 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id5=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=5 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id6=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=6 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id7=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=7 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id8=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=8 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id9=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=9 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.EMP_ID,D.sp_day_id
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id LEFT JOIN emp_detail C ON B.emp_id=C.EMP_ID
					LEFT JOIN att_rel_special_dept E ON A.dms_id10=E.dept_id LEFT JOIN att_set_special_day D ON D.sp_day_id=E.sp_day_id
				WHERE D.sp_type=1 AND A.emp_id = EMPID AND D.dept_type=10 AND MONTH(D.begin_date)=5 AND DAY(D.begin_date=4) AND D.is_enable=1 AND D.is_delete=0 AND B.entry_date IS NOT NULL AND B.entry_date <= SYS_SPDATE AND (B.leave_date IS NULL OR B.leave_date <= SYS_SPDATE) AND C.birthday IS NOT NULL AND C.birthday > DATE_ADD(SYS_SPDATE,INTERVAL -29 YEAR) AND A.is_delete=0 AND A.emp_state IS NOT NULL;				
		END CASE;
	END IF;
	
		#循环每个人的每个特殊节假日
	SET SP_CT=0,SP_MXCT=0;
	SELECT MIN(ID),MAX(ID) INTO SP_CT,SP_MXCT FROM tmp_att_specialday_list A WHERE A.version_code=I_VERSION_CODE;
	WHILE SP_CT <= SP_MXCT AND SP_CT > 0 DO
		SET MY_EMPID=NULL,MY_SPDAYID=NULL,MY_SPDAY_BGTM=NULL,MY_SPDAY_EDTM=NULL,MY_SPDAY_FLAG=NULL;
		SELECT A.emp_id,A.sp_day_id INTO MY_EMPID,MY_SPDAYID FROM tmp_att_specialday_list A WHERE A.version_code=I_VERSION_CODE AND A.id=SP_CT;
		DELETE FROM att_hol_apply_day WHERE emp_id=MY_EMPID AND hol_date=SYS_SPDATE AND sp_day_id=MY_SPDAYID;
		CALL SP_DPT_GET_SETTINGID(MY_EMPID,SYS_SPDATE,4,SPDAY_STR);
		SET IS_GET_SPDAY = LOCATE(CONCAT(MY_SPDAYID,','),CONCAT(SPDAY_STR,','));
		
		IF MY_EMPID IS NOT NULL AND IS_GET_SPDAY > 0 THEN
			SET MY_DEPTID=NULL,MY_CUSTID=NULL,MY_SPDAYNAME=NULL,MY_SPDAY_BGTM=NULL,MY_SPDAY_EDTM=NULL,MY_SP_HOUR=NULL;
			#计算出该员工在当天的特殊节假日起止时间点和时长，然后替换掉原有的特殊假期日报数据
			SELECT A.sp_day_name INTO MY_SPDAYNAME FROM att_set_special_day A WHERE A.sp_day_id=MY_SPDAYID;
			CALL FN_ATT_GET_SPDAY_TIME(MY_EMPID,MY_SPDAYID,SYS_SPDATE,MY_SPDAY_BGTM,MY_SPDAY_EDTM,MY_SPDAY_FLAG);
			SET MY_SP_HOUR = FN_ATT_GET_SPHOLDAYS(MY_SPDAY_BGTM,MY_SPDAY_EDTM,MY_EMPID,2);
			REPLACE INTO att_hol_apply_day (hol_id,hol_name,emp_id,hol_date,sp_day_id,cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,start_time,end_time,hol_hours,half_day_flag) 
				SELECT MY_SPDAYID,MY_SPDAYNAME,a.emp_id,SYS_SPDATE,MY_SPDAYID,a.cust_id,a.dept_id,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,TIME(MY_SPDAY_BGTM),TIME(MY_SPDAY_EDTM),MY_SP_HOUR,MY_SPDAY_FLAG
				FROM emp_base_info a
				WHERE a.emp_id=MY_EMPID;
			DELETE FROM tmp_att_specialday_list WHERE version_code=I_VERSION_CODE AND id=SP_CT;
		END IF;
		SET SP_CT = SP_CT + 1;
	END WHILE;


END;

