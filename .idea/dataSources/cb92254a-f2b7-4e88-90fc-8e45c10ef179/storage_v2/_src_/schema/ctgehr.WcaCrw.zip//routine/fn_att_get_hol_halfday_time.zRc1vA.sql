create procedure FN_ATT_GET_HOL_HALFDAY_TIME(IN  MY_BG_TIME   time, IN MY_ED_TIME time, IN MY_ATTID bigint unsigned,
                                             OUT REAL_BG_TIME time, OUT REAL_ED_TIME time, OUT MY_HALF_FLAG int)
  comment '通过给到的起始结束时间和部门id，得到按照半天计算的起止时间点和半天标记状态。'
  BEGIN

/*
参数说明
MY_BG_TIME、MY_ED_TIME 请假申请的起止时间点（同一天内）
MY_DEPT_ID 部门id
REAL_BG_TIME、REAL_ED_TIME 按照半天转化而成的考勤设置时间点，只有坐班考勤返回该值，否则返回原值
*/
DECLARE IS_HAVE_ATT,MY_ATT_RULE INT;
DECLARE MST,MET,AST,AET TIME;
DECLARE MY_FLEX DECIMAL(12,2);
	#查看是否有部门
	SELECT COUNT(*) INTO IS_HAVE_ATT FROM att_set_schema_new A WHERE A.att_id=MY_ATTID;
	#参数验证有部门，且给的两个时间段没有问题
	IF IS_HAVE_ATT > 0 AND MY_BG_TIME<=MY_ED_TIME THEN
		SELECT B.att_rule INTO MY_ATT_RULE
		FROM att_set_schema_new B 
		WHERE B.att_id=MY_ATTID;
		#只有坐班的时候才走半天的时间定位
		IF MY_ATT_RULE = 1 THEN
			SELECT B.morn_start_time,B.morn_end_time,B.aftn_start_time,B.aftn_end_time,B.flex_hour
				INTO MST,MET,AST,AET,MY_FLEX
			FROM att_set_schema_new B 
			WHERE B.att_id=MY_ATTID;
			
			IF MY_FLEX IS NULL OR MY_FLEX < 0 THEN
				SET MY_FLEX = 0;
			END IF;
			
			SET AET = TIME(DATE_ADD(CONCAT(DATE(NOW()),' ',AET),INTERVAL MY_FLEX MINUTE));
			#上午半天
			IF MY_BG_TIME <= MET AND MY_ED_TIME <= MET AND MY_ED_TIME >= MST THEN
				SET REAL_BG_TIME = MST;
				SET REAL_ED_TIME = MET;
				SET MY_HALF_FLAG = 1;
			#无效的上午
			ELSEIF MY_BG_TIME <= MET AND MY_ED_TIME <= MET AND MY_ED_TIME < MST THEN
				SET REAL_BG_TIME = MY_BG_TIME;
				SET REAL_ED_TIME = MY_ED_TIME;
				SET MY_HALF_FLAG = 0;
			#下午半天
			ELSEIF MY_BG_TIME > MET AND MY_ED_TIME > AST AND MY_BG_TIME <= AET THEN
				SET REAL_BG_TIME = AST;
				SET REAL_ED_TIME = AET;
				SET MY_HALF_FLAG = 2;
			#无效的下午
			ELSEIF MY_BG_TIME > MET AND MY_ED_TIME > AST AND MY_BG_TIME > AET THEN
				SET REAL_BG_TIME = MY_BG_TIME;
				SET REAL_ED_TIME = MY_ED_TIME;
				SET MY_HALF_FLAG = 0;
			#全天
			ELSEIF MY_BG_TIME <= MET AND MY_ED_TIME >= AST THEN
				SET REAL_BG_TIME = MST;
				SET REAL_ED_TIME = AET;
				SET MY_HALF_FLAG = 3;
			#无效时间，返回原值
			ELSE
				SET REAL_BG_TIME = MY_BG_TIME;
				SET REAL_ED_TIME = MY_ED_TIME;
				SET MY_HALF_FLAG = 0;
			END IF;
		#否则返回原值
		ELSE
			SET REAL_BG_TIME = MY_BG_TIME;
			SET REAL_ED_TIME = MY_ED_TIME;
			SET MY_HALF_FLAG = 0;
		END IF;
	#参数验证不合格，把原值返回
	ELSE
		SET REAL_BG_TIME = MY_BG_TIME;
		SET REAL_ED_TIME = MY_ED_TIME;
		SET MY_HALF_FLAG = 0;
	END IF;
	
END;

