create procedure SP_ATT_OVER_REPAY_REVERSE(IN MY_APPLY_ID bigint, OUT THIS_STAT int)
  comment '加班置换方式改变之后的各种逆转操作'
  BEGIN
/*
THIS_STAT 
1	代表操作成功
2	代表参数验证没有通过
*/
DECLARE IS_HAVE_APPLY,IS_HAVE_DAILY_REPORT,MY_REPAY_TYPE,MY_YEAR INT;
DECLARE IS_HAVE_REST,IS_GET_PAYED,MY_OVER_HOURS DECIMAL(12,2);
DECLARE MY_EMP BIGINT;
	#校验是否存在有效的加班申请、加班时长是否已经被调休占用
	SELECT COUNT(*),A.rest_hours,A.sala_hours INTO IS_HAVE_APPLY,IS_HAVE_REST,IS_GET_PAYED FROM att_over_apply A WHERE A.apply_id = MY_APPLY_ID AND A.state=1 ;
	#校验是否已经产生了日报
	SELECT COUNT(*) INTO IS_HAVE_DAILY_REPORT FROM att_over_apply_day B WHERE B.apply_id = MY_APPLY_ID;
	
	#校验通过后，开始计算
	IF MY_APPLY_ID IS NOT NULL AND IS_HAVE_APPLY>0 AND IS_HAVE_DAILY_REPORT>0 AND IS_HAVE_REST=0 AND IS_GET_PAYED=0 THEN
		#读出目前的置换方式和加班时长
		SELECT A.repay_type,A.over_hours,A.emp_id,YEAR(A.start_time)
			INTO MY_REPAY_TYPE,MY_OVER_HOURS,MY_EMP,MY_YEAR
		FROM att_over_apply A
		WHERE A.apply_id = MY_APPLY_ID AND A.state=1 ;
	
		#如果是从调休改加班费，需要从调休池撤销相应的数据
		IF MY_REPAY_TYPE = 1 THEN
			CALL SP_ATT_ICSS_POOL_MODIFY_LOG(MY_EMP,MY_APPLY_ID,2,1,0); 
			SET THIS_STAT = 1;

		#如果是从加班费改调休，需要往调休池追加相应的数据
		ELSEIF MY_REPAY_TYPE = 2 THEN
			CALL SP_ATT_ICSS_POOL_MODIFY_LOG(MY_EMP,MY_APPLY_ID,2,1,MY_OVER_HOURS); 
			SET THIS_STAT = 1;
			
		END IF;
	ELSE
		SET THIS_STAT = 2;
	END IF;
END;

