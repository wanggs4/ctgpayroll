create procedure SP_EMP_MONTH_SOIN(IN MAINID bigint unsigned)
  comment '花名册-社保'
  BEGIN
DECLARE DICT_ORITABLE,DICT_PRODUCTNAME,I_VERSION_CODE,MY_PRODUCTID,THIS_COLNAME VARCHAR(50);
DECLARE DICT_PRODUCTID,MY_EMPID,MY_DEPTID,MY_CUSTID BIGINT UNSIGNED;
DECLARE DICT_COL_NUM,DICT_CT,DICT_MXCT,COL_NUM,MY_SERVICETYPE,IS_HAVE_DATA,MY_PVERSION,EMP_CT,EMP_MXCT,COL_CT,COL_MXCT BIGINT;
DECLARE SQL_UPDATE_1,SQL_UPDATE_2,SQL_UPDATE_3,SQL_SET,SQL_INSERT,SQL_SELECT,SQL_FROM,SQL_WHERE,SQL_GROUP TEXT;

	SET I_VERSION_CODE = UUID();
	
	SELECT COUNT(*) INTO IS_HAVE_DATA FROM cust_period_emp_detail A WHERE A.main_id = MAINID;
	
	
	IF MAINID IS NOT NULL AND IS_HAVE_DATA > 0 THEN
		SELECT A.cust_id,A.emp_period_version INTO MY_CUSTID,MY_PVERSION FROM cust_period_emp_main A WHERE A.main_id = MAINID;
		DELETE FROM cust_period_emp_dict WHERE main_id=MAINID AND ori_table_name in ('soin','soin_total') ;

		

		INSERT INTO tmp_period_empsoin_collumn_list (VERSION_CODE,ori_table,product_id,product_name)
			SELECT DISTINCT I_VERSION_CODE,'soin',product_id,product_name
			FROM (
				SELECT DISTINCT B.product_id,B.product_name
				FROM soin_emp A LEFT JOIN soin_receivable_detail B ON A.ehr_emp_id=B.ehr_emp_id
				WHERE A.ehr_cust_id=MY_CUSTID AND A.service_type=100 AND B.service_mon = MY_PVERSION
				UNION ALL
				SELECT DISTINCT D.product_id,D.product_name
				FROM soin_emp C LEFT JOIN soin_bill_detail D ON C.ehr_emp_id=D.ehr_emp_id
				WHERE C.ehr_cust_id=MY_CUSTID AND C.service_type<>100 AND D.service_mon = MY_PVERSION
				) ABCD;
		INSERT INTO tmp_period_empsoin_collumn_list (VERSION_CODE,ori_table,product_id,product_name) values
			(I_VERSION_CODE,'soin_total','p_amount','社保应收金额合计'),
			(I_VERSION_CODE,'soin_total','sb_p_amt','社保个人金额合计'),
			(I_VERSION_CODE,'soin_total','gjj_p_amt','公积金个人金额合计(公积金、补充公积金)');
			
		SET DICT_CT=NULL,DICT_MXCT=NULL,DICT_COL_NUM=1;
		SELECT MIN(A.id),MAX(A.id) INTO DICT_CT,DICT_MXCT FROM tmp_period_empsoin_collumn_list A WHERE A.version_code=I_VERSION_CODE;
		WHILE DICT_CT <= DICT_MXCT DO
			SET DICT_ORITABLE=NULL,DICT_PRODUCTID=NULL,DICT_PRODUCTNAME=NULL;
			SELECT A.ori_table,A.product_id,A.product_name
				INTO DICT_ORITABLE,DICT_PRODUCTID,DICT_PRODUCTNAME
			FROM tmp_period_empsoin_collumn_list A 
			WHERE A.version_code=I_VERSION_CODE AND A.id=DICT_CT;
 			
 			IF DICT_ORITABLE IS NOT NULL THEN
				REPLACE INTO cust_period_emp_dict (main_id,cust_id,emp_period_version,ori_table_name,ori_col_name,show_name,des_tb_name,des_col_name)
					VALUES (MAINID,MY_CUSTID,MY_PVERSION,DICT_ORITABLE,DICT_PRODUCTID,DICT_PRODUCTNAME,'cust_period_emp_soin_detail',IF(DICT_COL_NUM<99,IF(DICT_COL_NUM<10,CONCAT('COL_00',DICT_COL_NUM),CONCAT('COL_0',DICT_COL_NUM)),CONCAT('COL_',DICT_COL_NUM)));
 				SET DICT_COL_NUM = DICT_COL_NUM + 1;
 			END IF;
			SET DICT_CT = DICT_CT + 1;
		END WHILE;
		
		
		INSERT INTO tmp_period_emp_caculation (version_code,emp_id,emp_period_version,cust_id,dept_id)
			SELECT DISTINCT I_VERSION_CODE,emp_id,emp_period_version,cust_id,dept_id 
			FROM cust_period_emp_detail A 
			WHERE A.main_id = MAINID;
		
		SELECT MIN(ID),MAX(ID) INTO EMP_CT,EMP_MXCT FROM tmp_period_emp_caculation WHERE VERSION_CODE=I_VERSION_CODE;
		
		WHILE EMP_CT<=EMP_MXCT AND EMP_CT>0 DO

			SET SQL_INSERT=NULL,SQL_SELECT=NULL,SQL_FROM=NULL,SQL_WHERE=NULL,SQL_GROUP=NULL,SQL_UPDATE_1=NULL,SQL_SET=NULL;
			
			
			SELECT emp_id,dept_id
				INTO MY_EMPID,MY_DEPTID
			FROM tmp_period_emp_caculation 
			WHERE ID = EMP_CT AND VERSION_CODE = I_VERSION_CODE;
			
			IF MY_EMPID IS NOT NULL THEN
				DELETE FROM cust_period_emp_soin_detail WHERE MAIN_ID = MAINID AND EMP_ID=MY_EMPID;
				SET MY_SERVICETYPE = NULL;
				SELECT A.service_type INTO MY_SERVICETYPE FROM soin_emp A WHERE A.ehr_emp_id=MY_EMPID ORDER BY A.create_dt DESC LIMIT 1;
				
				SET SQL_INSERT = 'REPLACE INTO cust_period_emp_soin_detail (main_id,emp_id,emp_period_version,cust_id,dept_id';
				SET SQL_SELECT = CONCAT('SELECT ',MAINID,',',MY_EMPID,',',MY_PVERSION,',',MY_CUSTID,',',MY_DEPTID);
				SET SQL_GROUP = ' GROUP BY B.ehr_emp_id,B.service_mon;';
				
				IF MY_SERVICETYPE = 100 AND MY_SERVICETYPE IS NOT NULL THEN 
					SET SQL_FROM = ' FROM soin_emp A LEFT JOIN soin_receivable_detail B ON A.ehr_emp_id=B.ehr_emp_id';
					SET SQL_WHERE = CONCAT(' WHERE A.ehr_emp_id=',MY_EMPID,' AND A.service_type=100 AND B.service_mon = ''',MY_PVERSION,'''');
				ELSEIF MY_SERVICETYPE<>100 AND MY_SERVICETYPE IS NOT NULL THEN
					SET SQL_FROM = ' FROM soin_emp A LEFT JOIN soin_bill_detail B ON A.ehr_emp_id=B.ehr_emp_id';
					SET SQL_WHERE = CONCAT(' WHERE A.ehr_emp_id=',MY_EMPID,' AND A.service_type<>100 AND B.service_mon = ''',MY_PVERSION,'''');
				END IF;
				

				IF MY_SERVICETYPE IS NOT NULL THEN
					SET COL_CT=0,COL_MXCT=0,COL_NUM=1;
					SELECT MIN(ID),MAX(ID) INTO COL_CT,COL_MXCT FROM tmp_period_empsoin_collumn_list A WHERE VERSION_CODE=I_VERSION_CODE AND A.ori_table='soin';
					WHILE COL_CT <= COL_MXCT DO
						SET MY_PRODUCTID = NULL;
						SELECT A.product_id INTO MY_PRODUCTID FROM tmp_period_empsoin_collumn_list A WHERE A.id=COL_CT AND A.version_code=I_VERSION_CODE;
						
						IF MY_PRODUCTID IS NOT NULL THEN
							
							SET THIS_COLNAME=NULL;
							IF COL_NUM < 10 THEN
								SET THIS_COLNAME = CONCAT('COL_00',COL_NUM);
							ELSEIF COL_NUM > 9 AND COL_CT < 100 THEN
								SET THIS_COLNAME = CONCAT('COL_0',COL_NUM);
							ELSEIF COL_NUM > 99 THEN
								SET THIS_COLNAME = CONCAT('COL_',COL_NUM);
							END IF;
							SET COL_NUM = COL_NUM + 1;
	
							
							SET SQL_SELECT = CONCAT(SQL_SELECT,',SUM(CASE WHEN B.product_id = ''',MY_PRODUCTID,''' THEN IFNULL(B.p_amt,0) ELSE 0 END)');
							IF COL_CT = COL_MXCT THEN
								SET SQL_INSERT = CONCAT(SQL_INSERT,',',THIS_COLNAME,') ');
							ELSE
								SET SQL_INSERT = CONCAT(SQL_INSERT,',',THIS_COLNAME);
							END IF;
						END IF;
						SET COL_CT = COL_CT + 1;
					END WHILE;
					
					IF COL_CT > 0 THEN
						SET @SQL_SOIN = CONCAT(SQL_INSERT,SQL_SELECT,SQL_FROM,SQL_WHERE,SQL_GROUP);



						IF @SQL_SOIN  IS NOT NULL THEN
							PREPARE stmt1 FROM @SQL_SOIN;
							EXECUTE stmt1;
							DEALLOCATE PREPARE stmt1;
						END IF;
						
						
						SET SQL_SET = ' SET ';
						SET SQL_WHERE =CONCAT(' WHERE A.emp_id=B.EMP_ID AND A.emp_period_version=B.emp_period_version AND A.EMP_ID=',MY_EMPID,';');
						SET SQL_UPDATE_1 = CONCAT('UPDATE cust_period_emp_soin_detail A,(SELECT BA.emp_id,BA.emp_period_version,');
						SET SQL_UPDATE_2 = '';
						IF MY_SERVICETYPE = 100 AND MY_SERVICETYPE IS NOT NULL THEN 
							SET SQL_UPDATE_3 = CONCAT(' FROM cust_period_emp_soin_detail BA , soin_receivable_total BB WHERE BA.emp_id=BB.ehr_emp_id AND BA.main_id=',MAINID,' AND BA.emp_id = ',MY_EMPID,' AND BA.emp_period_version=BB.service_mon GROUP BY BA.emp_id) B');
						ELSEIF MY_SERVICETYPE <> 100 AND MY_SERVICETYPE IS NOT NULL THEN 
							SET SQL_UPDATE_3 = CONCAT(' FROM cust_period_emp_soin_detail BA , soin_bill_total BB WHERE BA.emp_id=BB.ehr_emp_id AND BA.main_id=',MAINID,' AND BA.emp_id = ',MY_EMPID,' AND BA.emp_period_version=BB.service_mon GROUP BY BA.emp_id) B');
						END IF;
						
						SET COL_CT=0,COL_MXCT=0 ;
						SELECT MIN(ID),MAX(ID) INTO COL_CT,COL_MXCT FROM tmp_period_empsoin_collumn_list A WHERE VERSION_CODE=I_VERSION_CODE AND A.ori_table='soin_total';
						WHILE COL_CT <= COL_MXCT DO
							SET MY_PRODUCTID = NULL;
							SELECT A.product_id INTO MY_PRODUCTID FROM tmp_period_empsoin_collumn_list A WHERE A.id=COL_CT AND A.version_code=I_VERSION_CODE;
							
							IF MY_PRODUCTID IS NOT NULL THEN
								
								SET THIS_COLNAME=NULL;
								IF COL_NUM < 10 THEN
									SET THIS_COLNAME = CONCAT('COL_00',COL_NUM);
								ELSEIF COL_NUM > 9 AND COL_NUM < 100 THEN
									SET THIS_COLNAME = CONCAT('COL_0',COL_NUM);
								ELSEIF COL_NUM > 99 THEN
									SET THIS_COLNAME = CONCAT('COL_',COL_NUM);
								END IF;
								SET COL_NUM = COL_NUM + 1;
								
								
								IF COL_CT = COL_MXCT THEN
									SET SQL_UPDATE_2 = CONCAT(SQL_UPDATE_2,'SUM(IFNULL(BB.',MY_PRODUCTID,',0)) ',MY_PRODUCTID);
									SET SQL_SET = CONCAT(SQL_SET,THIS_COLNAME,'=B.',MY_PRODUCTID);
								ELSE
									SET SQL_UPDATE_2 = CONCAT(SQL_UPDATE_2,'SUM(IFNULL(BB.',MY_PRODUCTID,',0)) ',MY_PRODUCTID,',');
									SET SQL_SET = CONCAT(SQL_SET,THIS_COLNAME,'=B.',MY_PRODUCTID,',');
								END IF;
							END IF;
							SET COL_CT = COL_CT + 1;
						END WHILE;
						IF COL_CT > 0 THEN
							SET @SQL_SOINTOTAL = CONCAT(SQL_UPDATE_1,SQL_UPDATE_2,SQL_UPDATE_3,SQL_SET,SQL_WHERE);



							IF @SQL_SOINTOTAL IS NOT NULL THEN
								PREPARE stmt1 FROM @SQL_SOINTOTAL;
								EXECUTE stmt1;
								DEALLOCATE PREPARE stmt1;
							END IF;
						END IF;
					END IF;
					DELETE FROM tmp_period_emp_caculation WHERE ID=EMP_CT;
				END IF;
			END IF;
			SET EMP_CT = EMP_CT + 1;
		END WHILE;
	END IF;
	
END;

