create function FN_ATT_GET_HOL_HOURS(bgdt datetime, eddt datetime, holid bigint unsigned, sonver bigint unsigned,
                                     emp  bigint unsigned, minunit int)
  returns decimal(12, 2)
  comment '根据给出的时间段、假期设置id得到请假的小时数'
  BEGIN
DECLARE hol_numbers,daily_hol_numbers DECIMAL(12,2);
DECLARE i_bgtm,i_edtm,mst,met,ast,aet time;
DECLARE init_bgdt,i_bgdt,i_eddt date;
DECLARE MY_ATT_RULE,is_hol_year,i_hol_rule,ieh INT;
DECLARE ATTID_STR TEXT;
DECLARE ATTID BIGINT UNSIGNED;
#mod_log_20190709	deptid 已经无实际用途，仅做保留以避免过多的修改工作量

/*		返回值说明
		-1 参数输入有误 deptid 和 emp 至少有一个不能为null
		-2 不存在输入的假期设置id
*/
/*		计算说明
	拿起止时间和假期设置中的4个时间做对比，再根据请假的最小单位，得到首尾两天的请假时数。
		参数说明
	minunit 当最小单位为4的时候，请假按照上午半天和下午半天计算。
	
*/
	#IF000 先判断输入的参数，如果deptid和emp都是null 或者 hol_id是null 那么返回值是-1.代表参数输入有误
	IF emp is null OR holid IS NULL OR sonver IS NULL AND DATEDIFF(DATE(eddt),DATE(bgdt)) > 61 THEN					#IF000
		SET hol_numbers = -1;
	ELSE																								#IF000
		#通过hol_id获得假期设置
		#首先判断假期类型，是否年假，如果是年假就要去另一个表去取数据
		SELECT count(*) into is_hol_year FROM att_set_holiday_MAIN WHERE hol_id=holid;
		
		if is_hol_year = 0 then			#没有结果								#IF001
			set hol_numbers = -2;						
		else
			select is_year_hol,hol_rule into is_hol_year,i_hol_rule FROM att_set_holiday_main WHERE hol_id=holid;
			
			#初始化hol_numbers
			SET hol_numbers = 0;
			SET daily_hol_numbers = 0;

			SET hol_numbers = 0;
			SET init_bgdt = date(bgdt);
			SET i_bgdt = date(bgdt);
			SET i_eddt = date(eddt);
			#轮询请假每天 
			WHILE (i_bgdt<=i_eddt) DO												#LOOP000
				SET ATTID_STR=NULL,ATTID=NULL,mst=NULL,met=NULL,ast=NULL,aet=NULL;
				SET daily_hol_numbers = 0,i_bgtm=NULL,i_edtm=NULL;
				
				CALL SP_DPT_GET_SETTINGID(emp,i_bgdt,1,ATTID_STR);
				SET ATTID = CAST(ATTID_STR AS UNSIGNED);

				IF ATTID IS NOT NULL THEN
					#得到考勤规则
					SELECT B.att_rule,B.morn_start_time,B.morn_end_time,B.aftn_start_time,B.aftn_end_time
						INTO MY_ATT_RULE,mst,met,ast,aet
					FROM att_set_schema_new B 
					WHERE B.att_id=ATTID;
					
					
					#判断是否假期的首尾两天,根据情况确定起止时间
					IF DATE(bgdt) = DATE(eddt) THEN
						SET i_bgtm = TIME(bgdt);
						SET i_edtm = TIME(eddt);
						IF minunit = 4 AND MY_ATT_RULE = 1 THEN
							#上午半天
							IF TIME(bgdt) <= met AND TIME(eddt) <= met AND TIME(eddt) >= mst THEN
								SET i_bgtm = mst;
								SET i_edtm = met;
							ELSEIF TIME(bgdt) <= met AND TIME(eddt) <= met AND TIME(eddt) < mst THEN
								SET i_bgtm = null;
								SET i_edtm = null;
							#下午半天
							ELSEIF TIME(bgdt) > met AND TIME(eddt) >= ast AND TIME(bgdt) <= aet THEN
								SET i_bgtm = ast;
								SET i_edtm = aet;
							#下午半天
							ELSEIF TIME(bgdt) > met AND TIME(eddt) >= ast AND TIME(bgdt) > aet THEN
								SET i_bgtm = null;
								SET i_edtm = null;
							#全天
							ELSEIF TIME(bgdt) <= met AND TIME(eddt) >= ast THEN
								SET i_bgtm = mst;
								SET i_edtm = aet;
							END IF;
						END IF;						
					ELSEIF (i_bgdt=init_bgdt) THEN			#第一天
						IF MY_ATT_RULE = 1 THEN
							IF minunit <> 4 THEN
								set i_bgtm = time(bgdt);
								set i_edtm = aet;
							ELSE
								#全天
								IF TIME(bgdt) <= met  THEN
									SET i_bgtm = mst;
									SET i_edtm = aet;
								#下午半天
								ELSEIF TIME(bgdt) > met AND TIME(bgdt) <= aet  THEN
									SET i_bgtm = ast;
									SET i_edtm = aet;
								ELSE
									SET i_bgtm = NULL;
									SET i_edtm = NULL;
								END IF;
							END IF;
						ELSE
							set i_bgtm = time(bgdt);
							set i_edtm = '23:59:59';
						END IF;
					ELSEIF (i_bgdt=i_eddt) THEN		#最后一天
						IF MY_ATT_RULE = 1 THEN
							IF minunit <> 4 THEN
								set i_bgtm = mst;
								set i_edtm = time(eddt);
							ELSE
								#上午半天
								IF TIME(eddt) <= met AND TIME(eddt) >= mst THEN
									SET i_bgtm = mst;
									SET i_edtm = met;
								#全天
								ELSEIF TIME(eddt) > met  THEN
									SET i_bgtm = mst;
									SET i_edtm = aet;
								ELSE
									SET i_bgtm = NULL;
									SET i_edtm = NULL;
								END IF;
							END IF;
						ELSE
							set i_bgtm = '00:00:00';
							set i_edtm = time(eddt);
						END IF;
					ELSE										#其余
						IF MY_ATT_RULE = 1 THEN
							set i_bgtm = mst;
							set i_edtm = aet;
						ELSE
							set i_bgtm = '00:00:00';
							set i_edtm = '23:59:59';
						END IF;
					END IF;
					IF i_bgtm IS NOT NULL AND i_edtm IS NOT NULL THEN
						IF DATE(bgdt) = DATE(eddt) THEN
							SET daily_hol_numbers = FN_ATT_GET_REAL_HOLIDAY_HOURS(i_bgtm,i_edtm,holid, sonver,emp,ATTID,i_bgdt,minunit);
						ELSE
							SET daily_hol_numbers = FN_ATT_GET_REAL_HOLIDAY_HOURS_WITHOUT_FLEX(i_bgtm,i_edtm,holid, sonver,emp,ATTID,i_bgdt,minunit);
						END IF;
					ELSE
						SET daily_hol_numbers = 0;
					END IF;
#SELECT i_bgdt,i_bgtm,i_edtm,daily_hol_numbers;
					
					IF daily_hol_numbers IS NULL OR daily_hol_numbers < 0 THEN SET daily_hol_numbers=0; END IF;
				ELSE
					SET daily_hol_numbers = 0;
				END IF;

				SET hol_numbers = ROUND(hol_numbers + daily_hol_numbers,2); #累计请假时数
				
				SET i_bgdt = date_add(i_bgdt,interval 1 day);
			END WHILE;    																#LOOP000
		end if;																				#IF001
	END IF;																							#IF000
	
	RETURN hol_numbers;
END;

