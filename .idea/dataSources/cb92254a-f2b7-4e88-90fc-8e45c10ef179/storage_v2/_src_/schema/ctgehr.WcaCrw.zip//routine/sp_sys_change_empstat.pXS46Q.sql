create procedure SP_SYS_CHANGE_EMPSTAT(IN EMPNAME varchar(50), IN EMPCODE varchar(50), IN CUSTID bigint unsigned,
                                       IN OPTYPE  int)
  BEGIN
#OPTYPE 1 emp_state从2变1
#OPTYPE 2 emp_state从1变2
	
	IF EMPNAME IS NOT NULL AND EMPCODE IS NOT NULL AND CUSTID IS NOT NULL AND OPTYPE IN (1,2) THEN
		IF OPTYPE = 1 THEN
			UPDATE emp_base_info a left join emp_post b on a.emp_id=b.emp_id 
			SET a.emp_state=1
			WHERE a.emp_name=EMPNAME and b.emp_code=EMPCODE and a.cust_id=CUSTID and a.emp_state=2 and a.is_delete=0;
		ELSEIF OPTYPE = 2 THEN
			UPDATE emp_base_info a left join emp_post b on a.emp_id=b.emp_id 
			SET a.emp_state=2
			WHERE a.emp_name=EMPNAME and b.emp_code=EMPCODE and a.cust_id=CUSTID and a.emp_state=1 and a.is_delete=0;
		END IF;
	END IF;
END;

