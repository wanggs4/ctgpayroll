create procedure SP_SYS_GEN_DEPT_LOGIC_CODE(IN CUSTID bigint)
  comment '生成部门逻辑编码'
  BEGIN
DECLARE MY_VALUE,MY_POSITION,PARENT_CT,PARENT_MXCT,CUST_CT,CUST_MXCT,DEPT_CT,DEPT_MXCT,MY_LEVEL,MY_CUSTID,MY_DEPTID,MY_PARENTDEPTID BIGINT;
DECLARE MY_MIDVALUE,MY_BFVALUE,MY_AFTVALUE,MY_PARENT_LOGICCODE,MY_THIS_BASE,MY_BASE,MY_LOGICCODE VARCHAR(20);

	TRUNCATE TABLE tmp_sys_gen_dlc_custlist;
	
	#首先循环企业
	IF CUSTID IS NULL THEN
		INSERT INTO tmp_sys_gen_dlc_custlist (CUST_ID) 
			SELECT DISTINCT A.cust_id FROM dept_info A WHERE A.logic_code IS NULL AND A.dept_type=1;
	ELSE
		INSERT INTO tmp_sys_gen_dlc_custlist (CUST_ID) VALUES (CUSTID);
	END IF;
	
	SET CUST_CT=0,CUST_MXCT=0;
	SELECT MIN(ID),MAX(ID) INTO CUST_CT,CUST_MXCT FROM tmp_sys_gen_dlc_custlist;
	#循环公司
	WHILE CUST_CT <= CUST_MXCT AND CUST_CT > 0 DO
		SELECT CUST_ID INTO MY_CUSTID FROM tmp_sys_gen_dlc_custlist WHERE ID = CUST_CT;
		IF MY_CUSTID IS NOT NULL THEN
			UPDATE dept_info A SET A.logic_code=0 WHERE A.dept_lv_code='0' AND A.dept_type=1;
			SET MY_LEVEL=1;
			SET MY_BASE='10000000000000000000';
			SET MY_POSITION=NULL;

			#从最高级别的 部门开始循环
			WHILE MY_LEVEL <= 10 DO
				IF MY_LEVEL = 1 THEN
					SET MY_POSITION=MY_LEVEL;
				ELSE
					SET MY_POSITION=MY_LEVEL*2 -1;
				END IF;
				
				TRUNCATE TABLE tmp_sys_gen_dlc_parentlist;
				INSERT INTO tmp_sys_gen_dlc_parentlist (parent_dept_id) 
					SELECT DISTINCT A.parent_dept_id
					FROM dept_info A 
					WHERE A.CUST_ID = MY_CUSTID AND A.dept_lv_code=MY_LEVEL AND A.parent_dept_id IS NOT NULL AND A.dept_type=1;

#select *,MY_LEVEL from tmp_sys_gen_dlc_parentlist;

				SET PARENT_CT=NULL,PARENT_MXCT=NULL;
				SELECT MIN(ID),MAX(ID) INTO PARENT_CT,PARENT_MXCT FROM tmp_sys_gen_dlc_parentlist;
				
				WHILE PARENT_CT<=PARENT_MXCT AND PARENT_CT>0 DO
					SET MY_PARENTDEPTID=NULL;
					SELECT A.parent_dept_id INTO MY_PARENTDEPTID FROM tmp_sys_gen_dlc_parentlist A WHERE ID = PARENT_CT;
					
					TRUNCATE TABLE tmp_sys_gen_dlc_sl_deptlist;
					INSERT INTO tmp_sys_gen_dlc_sl_deptlist (dept_id,logic_code) 
						SELECT A.dept_id,A.logic_code 
						FROM dept_info A 
						WHERE A.CUST_ID = MY_CUSTID AND A.dept_lv_code=MY_LEVEL AND A.parent_dept_id=MY_PARENTDEPTID AND A.dept_type=1;
					
					SET DEPT_CT=0,DEPT_MXCT=0,MY_THIS_BASE=NULL;
					SELECT MIN(ID),MAX(ID) INTO DEPT_CT,DEPT_MXCT FROM tmp_sys_gen_dlc_sl_deptlist A ;
					
					WHILE DEPT_CT <= DEPT_MXCT AND DEPT_CT > 0 DO
						SET MY_DEPTID=NULL,MY_LOGICCODE=NULL,MY_VALUE=NULL,MY_MIDVALUE=NULL,MY_BFVALUE=NULL,MY_AFTVALUE=NULL;
						
						SELECT A.dept_id,A.logic_code INTO MY_DEPTID,MY_LOGICCODE 
						FROM tmp_sys_gen_dlc_sl_deptlist A 
						WHERE A.id = DEPT_CT;
						
						IF MY_LOGICCODE IS NULL THEN
							
							SET MY_THIS_BASE = NULL;
							SELECT MAX(A.logic_code) INTO MY_THIS_BASE FROM dept_info A 
								WHERE A.CUST_ID = MY_CUSTID AND A.dept_lv_code=MY_LEVEL AND A.parent_dept_id=MY_PARENTDEPTID AND A.dept_type=1;
							
							#当前处理dept_lv_code为1的一级部门
							IF MY_LEVEL = 1 THEN							
								#当父节点为MY_PARENTDEPTID的部门中
								#1.没有逻辑代码且部门序列处于第一个时
								IF MY_THIS_BASE IS NULL AND DEPT_CT=1 THEN
									SET MY_THIS_BASE = MY_BASE;
									SET MY_LOGICCODE = MY_THIS_BASE;
									SET MY_MIDVALUE=MID(MY_THIS_BASE,MY_POSITION,2);
									SET MY_VALUE = CAST(MY_MIDVALUE AS UNSIGNED);
								#2.没有逻辑代码，但部门不是第一个的时候
								ELSEIF MY_THIS_BASE IS NULL AND DEPT_CT<>1 THEN
									SET MY_THIS_BASE = MY_BASE;
									
									SET MY_MIDVALUE=MID(MY_THIS_BASE,MY_POSITION,2);
									SET MY_BFVALUE='';
									SET MY_AFTVALUE=RIGHT(MY_THIS_BASE,18);
									
									SET MY_VALUE = CAST(MY_MIDVALUE AS UNSIGNED) + 1;
									IF MY_VALUE <10 THEN
										SET MY_MIDVALUE = CONCAT('0',MY_VALUE);
									ELSE
										SET MY_MIDVALUE = MY_VALUE;
									END IF;
								
									SET MY_LOGICCODE = CONCAT(MY_MIDVALUE,MY_AFTVALUE);
								#3.有逻辑代码，且不管部门是否是序列中的第一个
								ELSE									
									SET MY_MIDVALUE=MID(MY_THIS_BASE,MY_POSITION,2);
									SET MY_BFVALUE=LEFT(MY_THIS_BASE,MY_POSITION-1);
									SET MY_AFTVALUE=RIGHT(MY_THIS_BASE,20-MY_POSITION-1);
									
									SET MY_VALUE = CAST(MY_MIDVALUE AS UNSIGNED) + 1;
									IF MY_VALUE <10 THEN
										SET MY_MIDVALUE = CONCAT('0',MY_VALUE);
									ELSE
										SET MY_MIDVALUE = MY_VALUE;
									END IF;
									
									SET MY_LOGICCODE = CONCAT(MY_BFVALUE,MY_MIDVALUE,MY_AFTVALUE);
								END IF;
							#当前处理dept_lv_code不为1的其他级别部门
							ELSE	
								SELECT A.logic_code INTO MY_PARENT_LOGICCODE FROM dept_info A WHERE A.dept_id = MY_PARENTDEPTID AND A.dept_type=1;
								IF MY_PARENT_LOGICCODE > MY_THIS_BASE OR MY_THIS_BASE IS NULL THEN
									SET MY_THIS_BASE = MY_PARENT_LOGICCODE;
								END IF;

								SET MY_MIDVALUE=MID(MY_THIS_BASE,MY_POSITION,2);
								SET MY_BFVALUE=LEFT(MY_THIS_BASE,MY_POSITION-1);
								SET MY_AFTVALUE=RIGHT(MY_THIS_BASE,20-MY_POSITION-1);
								
								SET MY_VALUE = CAST(MY_MIDVALUE AS UNSIGNED) + 1;
								IF MY_VALUE <10 THEN
									SET MY_MIDVALUE = CONCAT('0',MY_VALUE);
								ELSE
									SET MY_MIDVALUE = MY_VALUE;
								END IF;
								
								SET MY_LOGICCODE = CONCAT(MY_BFVALUE,MY_MIDVALUE,MY_AFTVALUE);
#IF MY_LEVEL=2 THEN
#	SELECT MY_THIS_BASE,MY_BASE,MY_BFVALUE,MY_MIDVALUE,MY_AFTVALUE,MY_DEPTID,MY_LOGICCODE;
#END IF;

							END IF;
#IF MY_LEVEL=2 THEN
#	SELECT MY_THIS_BASE,MY_VALUE,MY_MIDVALUE,MY_BFVALUE,MY_AFTVALUE,MY_LOGICCODE,MY_DEPTID;
#END IF;
							#保证数据合法性
							IF MY_VALUE <= 99 THEN
								UPDATE tmp_sys_gen_dlc_sl_deptlist A SET A.logic_code = MY_LOGICCODE WHERE A.dept_id=MY_DEPTID;
								UPDATE dept_info A SET A.logic_code = MY_LOGICCODE WHERE A.dept_id=MY_DEPTID AND A.dept_type=1;
							END IF;
#SELECT MY_DEPTID,MY_PARENTID,MY_LEVEL,MY_THIS_BASE,MY_STEP;
						END IF;
						SET DEPT_CT = DEPT_CT + 1;
					END WHILE;
					SET PARENT_CT = PARENT_CT + 1;
				END WHILE;
				SET MY_LEVEL = MY_LEVEL + 1;
			END WHILE;
		END IF;
		SET CUST_CT = CUST_CT + 1;
	END WHILE;
	TRUNCATE TABLE tmp_sys_gen_dlc_custlist;
	TRUNCATE TABLE tmp_sys_gen_dlc_sl_deptlist;
	TRUNCATE TABLE tmp_sys_gen_dlc_parentlist;
END;

