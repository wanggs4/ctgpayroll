create procedure SP_ATT_REST_OVER_OPERATE(IN MY_REST_APID  bigint, IN MY_OVER_APID bigint,
                                          IN THIS_DO_VALUE decimal(10, 5), OUT THIS_OVER_FLOW_VALUE decimal(10, 5),
                                          IN SEQ_NUM       int)
  comment '调休对于加班时长的占用情况操作,REST_HOUR字段的修改记录'
  BEGIN
/*
参数说明：
MY_REST_APID	调休申请id
MY_OVER_APID	加班申请id
THIS_DO_VALUE	本次操作要在rest_hour上加的值
THIS_OVER_FLOW_VALUE	溢出值，也就是说如果THIS_DO_VALUE的值高于了可供扣除的加班时数，那么多出来的部分返还给调用者，用以下次调用
*/
DECLARE IS_HAVE_REST_APID,IS_HAVE_OVER_APID,IS_SAME_EMP,IS_REAL_REST,IS_HAVE_LOG BIGINT;
DECLARE MY_LEFT_REST_HOUR,MY_OVER_HOUR,THIS_ORI_VALUE,LAST_DO_VALUE,THIS_MOD_VALUE DECIMAL(10,5);
	#验证参数有效性：
	#MY_REST_APID是否存在且生效
	SELECT COUNT(*) INTO IS_HAVE_REST_APID FROM att_hol_apply A WHERE A.apply_id = MY_REST_APID;
	#MY_REST_APID是否调休
	SELECT COUNT(*) INTO IS_REAL_REST 
	FROM att_hol_apply A LEFT JOIN att_set_holiday_rest B ON A.hol_id=B.hol_id 
	WHERE A.apply_id=MY_REST_APID AND B.`status`=1;
	#MY_OVER_APID是否存在且生效
	SELECT COUNT(*) INTO IS_HAVE_OVER_APID FROM att_over_apply A WHERE A.apply_id = MY_OVER_APID AND A.state=1 AND A.repay_type=2 AND A.is_clear=0;
	#两个有效的申请是否属于同一个人
	SELECT COUNT(*) INTO IS_SAME_EMP FROM att_hol_apply A ,att_over_apply B WHERE A.emp_id=B.emp_id AND A.apply_id=MY_REST_APID AND B.apply_id=MY_OVER_APID  AND B.state=1 AND B.is_clear=0;

#SELECT IS_HAVE_REST_APID,IS_REAL_REST,IS_HAVE_OVER_APID,IS_SAME_EMP;
	#通过以上的验证后才开始计算
	IF IS_HAVE_REST_APID > 0 AND IS_REAL_REST > 0 AND IS_HAVE_OVER_APID > 0 AND IS_SAME_EMP > 0 THEN
		#读出剩下的可供调休时数
		SELECT IF(A.over_hours IS NULL,0,A.over_hours) ,
				IF(A.rest_hours IS NULL,0,A.rest_hours)
			INTO MY_OVER_HOUR,THIS_ORI_VALUE
		FROM att_over_apply A 
		WHERE A.apply_id = MY_OVER_APID AND A.state=1 AND A.repay_type=2;
		
		#看看是否已经有log记录
		SELECT COUNT(*) INTO IS_HAVE_LOG FROM att_over_apply_log A WHERE A.rest_apply_id = MY_REST_APID AND A.over_apply_id = MY_OVER_APID;
		IF IS_HAVE_LOG IS NULL THEN SET IS_HAVE_LOG = 0 ; END IF;
		#当有log时
		IF IS_HAVE_LOG > 0 THEN
			#读出上一次修改值
			SELECT A.do_value INTO LAST_DO_VALUE FROM att_over_apply_log A WHERE A.rest_apply_id = MY_REST_APID AND A.over_apply_id = MY_OVER_APID;
			#当修改值大于0时
			IF THIS_DO_VALUE > 0 THEN
				#剩余可供调休时数
				SET MY_LEFT_REST_HOUR = MY_OVER_HOUR - (THIS_ORI_VALUE - LAST_DO_VALUE);
				#本次溢出值
				SET THIS_OVER_FLOW_VALUE = THIS_DO_VALUE - MY_LEFT_REST_HOUR;
				#如果溢出了，本次修改值就等于剩余可供调休时数
				IF THIS_OVER_FLOW_VALUE > 0 THEN
					SET THIS_DO_VALUE = MY_LEFT_REST_HOUR;
				END IF;
				#修改后的rest_hour
				SET THIS_MOD_VALUE = THIS_ORI_VALUE - LAST_DO_VALUE + THIS_DO_VALUE;
			#当修改值为0时
			ELSEIF THIS_DO_VALUE = 0 THEN
				SET THIS_OVER_FLOW_VALUE = 0;
				SET THIS_MOD_VALUE = THIS_ORI_VALUE - LAST_DO_VALUE;
			END IF;
			
			#只有本次修改值跟上一次的不同时，才进行修改。
			IF THIS_DO_VALUE <> LAST_DO_VALUE THEN
				#更新log
				UPDATE att_over_apply_log A 
				SET A.opt_num=A.opt_num+1,A.ori_value = IFNULL(THIS_ORI_VALUE,0),A.do_value = IFNULL(THIS_DO_VALUE,0),A.mod_value = IFNULL(THIS_MOD_VALUE,0),A.op_time=NOW()
				WHERE A.rest_apply_id = MY_REST_APID AND A.over_apply_id=MY_OVER_APID;
				
				#更新加班表
				UPDATE att_over_apply A 
				SET A.rest_hours = IFNULL(THIS_MOD_VALUE,0)
				WHERE A.apply_id = MY_OVER_APID;
			END IF;
		#当没有log时
		ELSEIF IS_HAVE_LOG = 0 THEN
			#当修改值不为0时
			IF THIS_DO_VALUE > 0 THEN
				#剩余可供调休时数
				SET MY_LEFT_REST_HOUR = MY_OVER_HOUR - THIS_ORI_VALUE ;
				#本次溢出值
				SET THIS_OVER_FLOW_VALUE = THIS_DO_VALUE - MY_LEFT_REST_HOUR;
				#如果溢出了，本次修改值就等于剩余可供调休时数
				IF THIS_OVER_FLOW_VALUE > 0 THEN
					SET THIS_DO_VALUE = MY_LEFT_REST_HOUR;
				END IF;
				#修改后的rest_hour
				SET THIS_MOD_VALUE = THIS_ORI_VALUE + THIS_DO_VALUE;
				
				#更新log
				INSERT INTO att_over_apply_log (rest_apply_id,over_apply_id,ori_value,do_value,mod_value,op_time,op_seq) VALUES 
					(MY_REST_APID,MY_OVER_APID,THIS_ORI_VALUE,THIS_DO_VALUE,THIS_MOD_VALUE,now(),SEQ_NUM);
				
				#更新加班表
				UPDATE att_over_apply A 
				SET A.rest_hours = IFNULL(THIS_MOD_VALUE,0)
				WHERE A.apply_id = MY_OVER_APID;

			END IF;
		END IF;
		
	END IF;
END;

