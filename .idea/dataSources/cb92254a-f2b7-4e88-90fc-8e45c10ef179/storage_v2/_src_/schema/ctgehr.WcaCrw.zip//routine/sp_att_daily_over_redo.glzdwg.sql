create procedure SP_ATT_DAILY_OVER_REDO()
  comment '通过给出的日期得到当天加班日报里的列表，然后通过apply_id重跑相关的加班日报'
  BEGIN
DECLARE CT,MXCT,MY_EMPID BIGINT UNSIGNED;
DECLARE THIS_BGDT DATE;
	
	TRUNCATE TABLE tmp_att_daily_over_redo;
	INSERT INTO tmp_att_daily_over_redo (bgdt,emp_id) 
		select distinct if(time(b.start_time) < '05:00:00',date_add(date(b.start_time),interval -1 day),date(b.start_time)),b.emp_id
		from att_over_apply_day a 
			left join att_over_apply b on a.apply_id=b.apply_id
			left join emp_base_info c on a.emp_id=c.emp_id
		where a.work_day=date_add(date(now()),interval -2 day) 
			and ((c.boss_level not in (1,3) and c.boss_level is not null) or c.boss_level is null);


	SET CT = 0, MXCT = 0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_att_daily_over_redo;
	WHILE CT <= MXCT DO
		SET THIS_BGDT = NULL, MY_EMPID = NULL;
		SELECT bgdt,emp_id INTO THIS_BGDT,MY_EMPID
		FROM tmp_att_daily_over_redo A 
		WHERE A.id=CT ;
		IF MY_EMPID IS NOT NULL THEN
			CALL SP_ATT_DAILY_OVER(THIS_BGDT,THIS_BGDT,NULL,NULL,MY_EMPID,NULL);
		END IF;
		SET CT = CT + 1;
	END WHILE;
END;

