create function FN_DPT_GET_UPLMTPRT_DPTID(MY_PRT_DPTID bigint unsigned, MY_DPTID bigint unsigned, MY_UPLMT bigint)
  returns bigint unsigned
  BEGIN
DECLARE THIS_UPLMTPER,THIS_PRTDEPTID,MY_UPLMTPRT_DPTID,THIS_DEPTID BIGINT UNSIGNED;
DECLARE MY_PRT_LVCODE,MY_PRT_UPLMT,LVCT BIGINT;
#有设置人数的距离最近的父级节点(0代表当前层级有人数限制，null代表整条树都没有限制)
	IF MY_PRT_DPTID IS NOT NULL AND MY_DPTID IS NOT NULL THEN
		IF MY_UPLMT > 0 AND MY_UPLMT IS NOT NULL THEN
			SET MY_UPLMTPRT_DPTID = 0;
		ELSE
			SELECT A.dept_lv_code,A.upper_limit_of_personnel ,A.parent_dept_id
				INTO MY_PRT_LVCODE,MY_PRT_UPLMT,THIS_DEPTID
			FROM dept_info A 
			WHERE A.dept_id = MY_PRT_DPTID AND A.is_enable=1 AND A.dept_type=1;
			
			IF MY_PRT_UPLMT IS NOT NULL AND MY_PRT_UPLMT > 0 THEN
				SET MY_UPLMTPRT_DPTID = MY_PRT_DPTID;
			ELSE
				SET LVCT = MY_PRT_LVCODE;
				WHILE LVCT >= 0 DO
					SET THIS_PRTDEPTID=NULL,THIS_UPLMTPER=NULL;
					SELECT A.parent_dept_id,A.upper_limit_of_personnel
						INTO THIS_PRTDEPTID,THIS_UPLMTPER
					FROM dept_info A
					WHERE A.dept_id=THIS_DEPTID AND IS_ENABLE=1 AND A.dept_type=1;
					
					#如果当前部门有设置，那么得到当前的部门id且跳出循环
					IF THIS_UPLMTPER > 0 THEN
						SET LVCT = -1;
						SET MY_UPLMTPRT_DPTID = THIS_DEPTID;
					#否则继续向上找
					ELSE
						SET THIS_DEPTID = THIS_PRTDEPTID;
						SET LVCT = LVCT - 1;
					END IF;
					#如果找到头都没有上限设置，那么设置为空，代表了全公司都不限制人数
					IF LVCT = -1 AND THIS_UPLMTPER IS NULL THEN
						SET MY_UPLMTPRT_DPTID = NULL;
					END IF;
				END WHILE;
			END IF;
		END IF;
	END IF;
RETURN MY_UPLMTPRT_DPTID;
END;

