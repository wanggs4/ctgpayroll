create procedure SP_CUST_PERIOD_EMP(IN BGDT date, IN CUSTID bigint unsigned)
  comment '人事周期数据定期生成'
  BEGIN
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE MON_BGDT,MON_EDDT DATE;
DECLARE MY_PERIOD_VERSION,MY_MAINID,MY_CUSTID,MY_STID,CT,MXCT,MY_p_item_id BIGINT;

SET I_VERSION_CODE = UUID();
	
	IF CUSTID IS NULL THEN
		INSERT INTO tmp_cpm_cust_list (version_code,p_item_id,cust_id,begin_date,end_date)
			SELECT distinct I_VERSION_CODE,p_item_id,cust_id,begin_date,end_date
			FROM cust_period_schedule A
			WHERE A.begin_date <= bgdt AND A.end_date >= bgdt AND A.period_type=3;
	ELSE 
		INSERT INTO tmp_cpm_cust_list (version_code,p_item_id,cust_id,begin_date,end_date)
			SELECT distinct I_VERSION_CODE,p_item_id,cust_id,begin_date,end_date
			FROM cust_period_schedule A
			WHERE CUST_ID=CUSTID AND A.begin_date <= bgdt AND A.end_date >= bgdt AND A.period_type=3;
	END IF;

	
	
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_cpm_cust_list WHERE VERSION_CODE = I_VERSION_CODE;

	WHILE (CT <= MXCT AND CT > 0) DO
		SET MY_CUSTID = NULL;
		SET MON_BGDT = NULL;
		SET MON_EDDT = NULL;
		
		
		SELECT cust_id,begin_date,end_date,p_item_id
			INTO MY_CUSTID,MON_BGDT,MON_EDDT,MY_p_item_id
		FROM tmp_cpm_cust_list
		WHERE VERSION_CODE = I_VERSION_CODE AND ID = CT;
		
		IF MY_CUSTID IS NOT NULL THEN
			SELECT A.year_mon INTO MY_PERIOD_VERSION
			FROM cust_period_schedule A
			WHERE A.p_item_id = MY_p_item_id;
			CALL SP_EMP_MONTH_LIST(MON_BGDT,MON_EDDT,MY_CUSTID,MY_PERIOD_VERSION,NULL);
			DELETE FROM tmp_cpm_cust_list WHERE VERSION_CODE = i_version_code AND ID = CT;
			
		END IF;
		SET CT = CT + 1 ;
	END WHILE;

END;

