create procedure SP_ICSS_AUDIT_POOL_REST(IN MY_STID bigint unsigned)
  comment '调休池审核程序'
  BEGIN
DECLARE BGDT,EDDT DATE;
DECLARE MY_LAST_STID,MY_NEXT_STID,IS_HAVE_INCREMENT,CT,MXCT,THIS_EMPID BIGINT UNSIGNED;
DECLARE VRBS_BEGIN,VRBS_ST_LAST_REST_LEFT,VRBS_THIS_MON_REST_HPD,VRBS_THIS_MON_TO_FUTURE_POOL_REST_USD,VRBS_THIS_MON_OMP_REST_HPD DECIMAL(12,2);
DECLARE VRBS_OFF_LINE_REST_HPD,VRBS_THIS_MON_REST_NEW_GET,VRBS_ST_ALL_REST_LEFT,VRBS_STD_ALL_REST_LEFT,VRBS_DIFF_ST_ALL_REST_LEFT DECIMAL(12,2);
DECLARE VRBS_POOL_REST_LEFT,VRBS_STD_POOL_REST_LEFT,VRBS_DIFF_POOL_REST_LEFT,TMP_VRB1,TMP_VRB2,VRBS_THIS_MON_TO_FUTRUE_REST_NEW_GET DECIMAL(12,2);

	IF MY_STID IS NOT NULL THEN
		#得到计算周期
		SELECT A.comp_start_time,A.comp_end_time INTO BGDT,EDDT FROM att_st_month A WHERE A.st_id = MY_STID;
		
		SELECT A.st_id INTO MY_LAST_STID 
		FROM att_st_month A 
		WHERE A.comp_start_time <= DATE_ADD(BGDT,INTERVAL -1 MONTH) AND A.comp_end_time >= DATE_ADD(BGDT,INTERVAL -1 MONTH) AND A.cust_id=2162554862743552;
		
		SELECT A.st_id INTO MY_NEXT_STID 
		FROM att_st_month A 
		WHERE A.comp_start_time <= DATE_ADD(BGDT,INTERVAL 1 MONTH) AND A.comp_end_time >= DATE_ADD(BGDT,INTERVAL 1 MONTH) AND A.cust_id=2162554862743552;
		
		#如果增量列表有数据，就跑增量，否则就跑所有
		SELECT COUNT(*) INTO IS_HAVE_INCREMENT FROM icss_audit_pool_rest_emplist;
		IF IS_HAVE_INCREMENT IS NULL OR IS_HAVE_INCREMENT = 0 THEN
			INSERT INTO icss_audit_pool_rest_emplist (emp_id,st_id) 
				SELECT EMP_ID,ST_ID FROM icss_audit_pool_rest A WHERE A.st_id=MY_STID;
		END IF;
		
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM icss_audit_pool_rest_emplist;
		
		WHILE CT <= MXCT DO
			SET THIS_EMPID = NULL;
			SELECT EMP_ID INTO THIS_EMPID FROM icss_audit_pool_rest_emplist A WHERE A.id=CT;
			IF THIS_EMPID IS NOT NULL THEN
				SET VRBS_BEGIN= 0, VRBS_ST_LAST_REST_LEFT= 0, VRBS_THIS_MON_REST_HPD= 0, VRBS_THIS_MON_TO_FUTURE_POOL_REST_USD= 0, 
					VRBS_THIS_MON_OMP_REST_HPD= 0, VRBS_OFF_LINE_REST_HPD= 0, VRBS_THIS_MON_REST_NEW_GET= 0, VRBS_ST_ALL_REST_LEFT= 0, 
					VRBS_STD_ALL_REST_LEFT= 0, VRBS_DIFF_ST_ALL_REST_LEFT= 0, VRBS_POOL_REST_LEFT= 0, VRBS_STD_POOL_REST_LEFT= 0, 
					VRBS_DIFF_POOL_REST_LEFT=0, VRBS_THIS_MON_TO_FUTRUE_REST_NEW_GET = 0;
				#VRBS_BEGIN	上月定稿结余：上月补休定稿数据
				#VRBS_OFF_LINE_REST_HPD	线下刷新补休时长：线下特殊处理的补休数据（增减时长）需单独做一张表单独存储
				SELECT IFNULL(A.`begin`,0),IFNULL(A.off_line_rest_hpd,0) INTO VRBS_BEGIN,VRBS_OFF_LINE_REST_HPD 
				FROM icss_audit_pool_rest A 
				WHERE A.emp_id=THIS_EMPID AND A.st_id=MY_STID;
				
				#VRBS_ST_LAST_REST_LEFT	上周期内结余补休小时（系统）：取当月期池报表内容
				SELECT IFNULL(A.last_rest_left,0) INTO VRBS_ST_LAST_REST_LEFT 
				FROM att_st_month_quick_view_st_pool A 
				WHERE A.emp_id=THIS_EMPID AND A.st_id=MY_STID;
				
				#VRBS_THIS_MON_REST_HPD	本月已休已通过：本月已审批通过补休请假时长
				SELECT IFNULL(SUM(A.hol_hours),0) INTO VRBS_THIS_MON_REST_HPD 
				FROM att_hol_apply_day A 
				WHERE A.emp_id = THIS_EMPID AND A.hol_date BETWEEN BGDT AND EDDT AND A.hol_hours > 0 AND A.is_year_hol = 2 AND A.hol_hours IS NOT NULL;
				
				#VRBS_THIS_MON_TO_FUTURE_POOL_REST_USD	补休已使用：本月及往后补休请假总时长（包含：审批中，已通过，待选审批人）
				SET TMP_VRB1 = 0,TMP_VRB2 = 0;
					#未来的已通过
				SELECT IFNULL(SUM(A.hol_hours),0) INTO VRBS_THIS_MON_TO_FUTURE_POOL_REST_USD 
				FROM att_hol_apply_day A 
				WHERE A.emp_id = THIS_EMPID AND A.hol_date > EDDT AND A.hol_hours > 0 AND A.is_year_hol = 2 AND A.hol_hours IS NOT NULL;
					#有扣减顺序
				SELECT IFNULL(SUM(IFNULL(MID(A.credit_detail,LOCATE('补休',A.credit_detail)+3,4),0)),0) 
					INTO TMP_VRB1
				FROM att_hol_apply A
				WHERE A.credit_detail IS NOT NULL AND A.credit_detail LIKE '%补休%'
					AND A.state IN (2,5) AND A.end_time >= CONCAT(BGDT,' 05:00:00') AND A.emp_id = THIS_EMPID;
					#无扣减顺序
				SELECT IFNULL(SUM(IFNULL(A.hol_min_num,0)/60),0)
					INTO TMP_VRB2
				FROM att_hol_apply A
				WHERE A.credit_detail IS NULL AND A.hol_name='补休'
					AND A.state IN (2,5) AND A.end_time >= CONCAT(BGDT,' 05:00:00') AND A.emp_id = THIS_EMPID;
					
				SET VRBS_THIS_MON_TO_FUTURE_POOL_REST_USD = VRBS_THIS_MON_REST_HPD + TMP_VRB1 + TMP_VRB2 + VRBS_THIS_MON_TO_FUTURE_POOL_REST_USD;

				#VRBS_THIS_MON_OMP_REST_HPD	本月已付费抵扣加班小时：本月已通过OMP抵扣的补休总时长，按照create_time+1月取本月数据
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO VRBS_THIS_MON_OMP_REST_HPD
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id=4 AND A.pool_type=2 AND A.create_time >= CONCAT(DATE_ADD(BGDT,INTERVAL 1 MONTH),' 00:00:00') 
					AND A.emp_id=THIS_EMPID;
				
				IF VRBS_ST_LAST_REST_LEFT < 0 THEN
					SET VRBS_ST_LAST_REST_LEFT = VRBS_ST_LAST_REST_LEFT + VRBS_THIS_MON_OMP_REST_HPD;
				END IF;
				
				#VRBS_THIS_MON_REST_NEW_GET	本月新增加班时长：本月新增的加班转补休时长
				SELECT IFNULL(SUM(A.work_hour),0) INTO VRBS_THIS_MON_REST_NEW_GET 
				FROM att_over_apply_day A 
				WHERE A.emp_id = THIS_EMPID AND A.work_day BETWEEN BGDT AND EDDT 
					AND A.work_hour > 0 AND A.date_repay_type = 2 AND A.work_hour IS NOT NULL AND A.is_over_with_rest <> 1;
					
				#VRBS_THIS_MON_TO_FUTRUE_REST_NEW_GET	本月及往后新增加班
				SELECT IFNULL(SUM(A.work_hour),0) INTO VRBS_THIS_MON_TO_FUTRUE_REST_NEW_GET 
				FROM att_over_apply_day A 
				WHERE A.emp_id = THIS_EMPID AND A.work_day >= BGDT 
					AND A.work_hour > 0 AND A.date_repay_type = 2 AND A.work_hour IS NOT NULL AND A.is_over_with_rest <> 1;
				
				#VRBS_ST_ALL_REST_LEFT	本月报表结余(系统)：本月系统内假期池报表补休结余
				SELECT IFNULL(A.all_rest_left,0) INTO VRBS_ST_ALL_REST_LEFT 
				FROM att_st_month_quick_view_st_pool A 
				WHERE A.emp_id=THIS_EMPID AND A.st_id=MY_STID;

				#VRBS_STD_ALL_REST_LEFT	本月报表结余(正确)：本月假期池报表补休应结余时长，
																	#公式为：上月定稿结余+本月新增加班-本月已付费抵扣-本月已休已通过+线下刷新补休时长
				SET VRBS_STD_ALL_REST_LEFT = VRBS_BEGIN + VRBS_THIS_MON_REST_NEW_GET - VRBS_THIS_MON_OMP_REST_HPD - VRBS_THIS_MON_REST_HPD + VRBS_OFF_LINE_REST_HPD;
				
				#VRBS_DIFF_ST_ALL_REST_LEFT	本月报表结余差额：std_all_rest_left - std_all_rest_left
				SET VRBS_DIFF_ST_ALL_REST_LEFT = VRBS_STD_ALL_REST_LEFT - VRBS_ST_ALL_REST_LEFT;
				
				#VRBS_POOL_REST_LEFT	调休池剩余合计：当前池子总剩余
				SELECT IFNULL(SUM(IFNULL(A.this_year_left,0)),0) INTO VRBS_POOL_REST_LEFT
				FROM att_hol_rest A
				WHERE A.emp_id = THIS_EMPID AND A.is_delete = 0;
				
				#VRBS_STD_POOL_REST_LEFT	调休池正确剩余：截至到本月调休池应剩余调休时长。
																	#公式：上月定稿结余+本月及往后新增加班+线下刷新补休时长-本月已付费抵扣-补休已使用
				SET VRBS_STD_POOL_REST_LEFT = VRBS_BEGIN + VRBS_THIS_MON_TO_FUTRUE_REST_NEW_GET + VRBS_OFF_LINE_REST_HPD - VRBS_THIS_MON_OMP_REST_HPD - VRBS_THIS_MON_TO_FUTURE_POOL_REST_USD;
				
				#VRBS_DIFF_POOL_REST_LEFT	调休池底数差额：std_pool_rest_left - pool_rest_left
				SET VRBS_DIFF_POOL_REST_LEFT = VRBS_STD_POOL_REST_LEFT - VRBS_POOL_REST_LEFT;
				
				UPDATE icss_audit_pool_rest A
				SET st_last_rest_left = VRBS_ST_LAST_REST_LEFT,this_mon_rest_hpd = VRBS_THIS_MON_REST_HPD,
					this_mon_to_future_pool_rest_usd = VRBS_THIS_MON_TO_FUTURE_POOL_REST_USD,
					this_mon_omp_rest_hpd = VRBS_THIS_MON_OMP_REST_HPD,this_mon_rest_new_get = VRBS_THIS_MON_REST_NEW_GET,
					st_all_rest_left = VRBS_ST_ALL_REST_LEFT,std_all_rest_left = VRBS_STD_ALL_REST_LEFT,
					diff_st_all_rest_left = VRBS_DIFF_ST_ALL_REST_LEFT,pool_rest_left = VRBS_POOL_REST_LEFT,
					std_pool_rest_left = VRBS_STD_POOL_REST_LEFT,diff_pool_rest_left = VRBS_DIFF_POOL_REST_LEFT					
				WHERE A.emp_id = THIS_EMPID AND A.st_id = MY_STID;
			END IF;
			
			SET CT = CT + 1;
		END WHILE;
		TRUNCATE TABLE icss_audit_pool_rest_emplist;
	END IF;
END;

