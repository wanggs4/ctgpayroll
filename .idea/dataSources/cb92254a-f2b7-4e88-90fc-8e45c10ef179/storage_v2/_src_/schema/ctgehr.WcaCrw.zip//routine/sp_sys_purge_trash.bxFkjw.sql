create procedure SP_SYS_PURGE_TRASH()
  comment '清除业务表中垃圾数据'
  BEGIN
	
	delete from att_emp_log where emp_id not in (select emp_id from emp_base_info);
	delete from att_check_apply where emp_id not in (select emp_id from emp_base_info);
	delete from att_hol_apply where emp_id not in (select emp_id from emp_base_info);
	delete from att_over_apply where emp_id not in (select emp_id from emp_base_info);
	delete from att_exam_step where emp_id not in (select emp_id from emp_base_info);
	delete from att_emp_detail where emp_id not in (select emp_id from emp_base_info);
	delete from att_emp_log where emp_id not in (select emp_id from emp_base_info);
	delete from att_hol_apply_day where emp_id not in (select emp_id from emp_base_info);
	delete from att_over_apply_day where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_bz_gz where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_bz_lwf where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_bz_lzf where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_bz_nzj where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_gz_base where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_lwf_base where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_lzf_base where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_nzj_base where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_tol where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_gz where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_lwf where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_lzf where emp_id not in (select emp_id from emp_base_info);
	delete from payroll_nzj where emp_id not in (select emp_id from emp_base_info);

	delete a.*
	from att_emp_detail a left join  emp_post b on a.emp_id=b.emp_id
	where a.dt > b.leave_date and b.leave_date is not null;
	
	delete a.*
	from att_arrange_schedual a left join  emp_post b on a.emp_id=b.emp_id
	where a.dt > b.leave_date and b.leave_date is not null;

	delete a.*
	from att_rel_exam_step_man a left join att_exam_step b on a.exam_id=b.exam_id
	where b.state<>2 ;
	
	#删除过期月报快照	
#	delete a.*
#	from att_st_month_quick_view a left join att_st_month b on a.st_id=b.st_id
#	where b.comp_start_time < date_add(b.comp_start_time,interval -3 month);

END;

