create procedure SP_DPT_GET_SETTINGID_NEW(IN  EMPID     bigint unsigned, IN BGDT date, IN SETTINGTYPE int,
                                          OUT SETTINGID text)
  comment '得到单独时间段内某个人某个设定的id'
  BEGIN
/*
SETTINGTYPE
1	考勤		att_rel_schema_dept
2	加班		att_rel_overtime_dept
4	特殊假日	att_rel_special_dept
5	特殊工作日	att_rel_special_workday_dept
301-310 各种固定假期
*/
DECLARE IS_HAVE_EMP,CT,MXCT,MY_ATTRULE INT;
DECLARE THIS_ATTRULE,THIS_ATTID BIGINT UNSIGNED;
SET SETTINGID = NULL;
	SELECT COUNT(*) INTO IS_HAVE_EMP FROM emp_base_info A WHERE A.emp_id=EMPID;
	IF IS_HAVE_EMP > 0 AND BGDT IS NOT NULL AND SETTINGTYPE IN (1,2,4,5,301,302,303,304,305,306,307,308,309,310) THEN
		CASE SETTINGTYPE
		WHEN 1 THEN
			SELECT A.att_id INTO SETTINGID FROM att_daily_emp_attid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 7 THEN
			SELECT A.att_id INTO SETTINGID FROM att_daily_emp_attid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
			SELECT a.att_rule INTO MY_ATTRULE FROM att_set_schema_new a where a.att_id=SETTINGID;
			SET SETTINGID = CONCAT(SETTINGID,':',MY_ATTRULE);
		WHEN 2 THEN
			SELECT A.ot_id INTO SETTINGID FROM att_daily_emp_otid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 4 THEN
			SELECT A.sp_day_id INTO SETTINGID FROM att_daily_emp_spdayid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
			SET SETTINGID = CONCAT(SETTINGID,',');
		WHEN 5 THEN
			SELECT A.sp_workday_id INTO SETTINGID FROM att_daily_emp_spworkdayid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 301 THEN
			SELECT A.hol_flag_1 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 302 THEN
			SELECT A.hol_flag_2 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 303 THEN
			SELECT A.hol_flag_3 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 304 THEN
			SELECT A.hol_flag_4 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 305 THEN
			SELECT A.hol_flag_5 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 306 THEN
			SELECT A.hol_flag_6 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 307 THEN
			SELECT A.hol_flag_7 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 308 THEN
			SELECT A.hol_flag_8 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 309 THEN
			SELECT A.hol_flag_9 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		WHEN 310 THEN
			SELECT A.hol_flag_10 INTO SETTINGID FROM att_daily_emp_holid A WHERE A.emp_id=EMPID AND A.dt=BGDT;
		END CASE;
	END IF;
END;

