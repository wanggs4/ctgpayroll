create procedure SP_ATT_MONTH_REPORT_ICSS_ORIGIN(IN MY_STID  bigint unsigned, INOUT MY_STATE int,
                                                 IN MY_EMPID bigint unsigned)
  comment '用于计算手工月报中的截止至部分'
  BEGIN
DECLARE IS_HAVE_STID,YEAR_CT,YEAR_MXCT INT;
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE BGDT,EDDT DATE;
DECLARE CT,MXCT BIGINT UNSIGNED;
DECLARE THIS_sd_szqnjybx,THIS_sd_jzsybzqzjybx,THIS_RESTHAVE,THIS_RESTUSE,THIS_RESTLEFT,ORI_RESTHAVE,ORI_RESTUSE,ORI_RESTLEFT,DO_RESTHAVE,DO_RESTUSE DECIMAL(12,2);
DECLARE THIS_sd_jzdnkxnj,THIS_sd_jzdykxnj,THIS_sd_fdnwxnj,THIS_sd_jzbydkxnj,THIS_YEARHAVE,THIS_YEARUSE,THIS_YEARLEFT,ORI_YEARHAVE,ORI_YEARUSE,ORI_YEARLEFT,DO_YEARHAVE,DO_YEARUSE,ORI_CREDITUSE DECIMAL(10,5);
	SELECT COUNT(*),A.comp_start_time,A.comp_end_time 
		INTO IS_HAVE_STID,BGDT,EDDT
	FROM att_st_month A 
	WHERE A.st_id=MY_STID ;
	
	IF IS_HAVE_STID = 1 THEN
	
		SET I_VERSION_CODE = UUID();
		IF MY_EMPID IS NOT NULL THEN
			INSERT INTO tmp_att_manual_origin_list (VERSION_CODE,EMP_ID)
				SELECT I_VERSION_CODE,EMP_ID FROM att_st_month_quick_view_icss_manual_origin A WHERE A.st_id=MY_STID AND A.emp_id=MY_EMPID;
		ELSE
			INSERT INTO tmp_att_manual_origin_list (VERSION_CODE,EMP_ID)
				SELECT I_VERSION_CODE,EMP_ID FROM att_st_month_quick_view_icss_manual_origin A WHERE A.st_id=MY_STID;
		END IF;
		SET CT = 0, MXCT = 0 ;
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_att_manual_origin_list A WHERE A.version_code=I_VERSION_CODE;
		WHILE CT <= MXCT AND CT > 0 DO
			SET MY_EMPID = NULL;
			SELECT EMP_ID INTO MY_EMPID FROM tmp_att_manual_origin_list A WHERE A.id=CT AND A.version_code=I_VERSION_CODE;
			IF MY_EMPID IS NOT NULL THEN
				SET THIS_sd_szqnjybx=0,THIS_sd_jzsybzqzjybx=0,THIS_RESTHAVE=0,THIS_RESTUSE=0,THIS_RESTLEFT=0;
				SET THIS_sd_jzdykxnj=0,THIS_sd_fdnwxnj=0,THIS_sd_jzbydkxnj=0,THIS_YEARHAVE=0,THIS_YEARUSE=0,THIS_YEARLEFT=0;

			#PART 1 调休相关
			#sd_szqnjybx	上周期内结余补休小时（截至上月）	非当年，刨除3月及以后的所有改动
				SET DO_RESTHAVE=0, DO_RESTUSE=0, ORI_RESTLEFT=0;
				#先得到往年的总值
				SELECT IFNULL(SUM(IFNULL(A.this_year_left,0)),0) INTO ORI_RESTLEFT
				FROM att_hol_rest A 
				WHERE A.emp_id=MY_EMPID AND A.this_year<YEAR(BGDT) AND A.is_delete=0;
				
				#得到3月及以后的 对于往年的 HAVE 改动值
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_RESTHAVE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >=BGDT AND A.pool_type=2 AND A.op_type=1 AND A.which_year < YEAR(BGDT) AND A.is_erase=0;
				#得到3月及以后的 对于往年的 USE 改动值
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_RESTUSE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >=BGDT AND A.pool_type=2 AND A.op_type=2 AND A.which_year < YEAR(BGDT) AND A.is_erase=0;
				#计算结果
				SET THIS_sd_szqnjybx = ORI_RESTLEFT + DO_RESTUSE - DO_RESTHAVE;
				
			#sd_jzsybzqzjybx	截至上月，本周期内总结余补休(小时)	当年，刨除3月及以后的所有改动
				SET DO_RESTHAVE=0, DO_RESTUSE=0, ORI_RESTLEFT=0;
				#先得到当年的总值
				SELECT IFNULL(SUM(IFNULL(A.this_year_left,0)),0) INTO ORI_RESTLEFT
				FROM att_hol_rest A 
				WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR(BGDT) AND A.is_delete=0;
				
				#得到3月及以后的 对于往年的 HAVE 改动值
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_RESTHAVE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >=BGDT AND A.pool_type=2 AND A.op_type=1 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;

				#得到3月及以后的 对于往年的 USE 改动值
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_RESTUSE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >=BGDT AND A.pool_type=2 AND A.op_type=2 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;

				#计算结果
				SET THIS_sd_jzsybzqzjybx = ORI_RESTLEFT + DO_RESTUSE - DO_RESTHAVE;
			
			#PART 2 年假相关
			#sd_fdnwxnj	非当年未休年假（小时）（截至上月）	非当年，刨去3月之后所有改动的值
				SET ORI_YEARHAVE=0,ORI_YEARUSE=0,ORI_YEARLEFT=0,DO_YEARHAVE=0,DO_YEARUSE=0;
				#得到往年当前值
				SELECT IFNULL(SUM(IFNULL(A.this_year_have,0)),0),
						IFNULL(SUM(IFNULL(A.this_year_use,0)),0),
						IFNULL(SUM(IFNULL(A.this_year_left,0)),0)
					INTO ORI_YEARHAVE,ORI_YEARUSE,ORI_YEARLEFT
				FROM att_hol_year A 
				WHERE A.emp_id=MY_EMPID AND A.this_year < YEAR(BGDT) AND A.is_delete=0;
				
				#计算当前月及以后发放
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARHAVE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=1 AND A.op_type=1 AND A.which_year < YEAR(BGDT) AND A.is_erase=0;
				#计算当前月及以后电子流使用
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARUSE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=1 AND A.op_type=2 AND A.which_year < YEAR(BGDT) AND A.is_erase=0;

				SET THIS_sd_fdnwxnj = (ORI_YEARLEFT - DO_YEARHAVE + DO_YEARUSE) * 8 ;

			#当年相关
				SET ORI_YEARHAVE=0,ORI_YEARUSE=0,ORI_YEARLEFT=0,DO_YEARHAVE=0,DO_YEARUSE=0;
				#得到当年当前值
				SELECT IFNULL(SUM(IFNULL(A.this_year_have,0)),0),
						IFNULL(SUM(IFNULL(A.this_year_use,0)),0),
						IFNULL(SUM(IFNULL(A.this_year_left,0)),0)
					INTO ORI_YEARHAVE,ORI_YEARUSE,ORI_YEARLEFT
				FROM att_hol_year A 
				WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR(BGDT) AND A.is_delete=0;
			#sd_jzdykxnj	截止到当月可休年假(小时)	刨去了次月发放的this_year_have
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARHAVE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >EDDT AND A.pool_type=1 AND A.op_type=1 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;
#select ORI_YEARHAVE,DO_YEARHAVE,EDDT, YEAR(BGDT);
				SET THIS_sd_jzdykxnj = (ORI_YEARHAVE - DO_YEARHAVE) * 8;
			#sd_jzdnkxnj	截止到当年可休年假(小时)	年假+预支this_year_have
				SET DO_YEARHAVE = 0;
				SELECT IFNULL(SUM(IFNULL(A.this_year_have,0)),0) 
					INTO DO_YEARHAVE
				FROM att_hol_credit_year A 
				WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR(BGDT) AND A.is_delete=0;
				
				SET THIS_sd_jzdnkxnj = (ORI_YEARHAVE + DO_YEARHAVE) * 8;
#select ORI_YEARHAVE,DO_YEARHAVE;
			#sd_jzbydkxnj	截至本月底可休年假	当年，刨除所有3月及以后电子流，但不刨除3月发放，再刨去3月初的预支已用
				SET DO_YEARHAVE=0,DO_YEARUSE=0;
				#计算之后月发放
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARHAVE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt > EDDT AND A.pool_type=1 AND A.op_type=1 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;
				#计算当前月及以后电子流使用
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARUSE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=1 AND A.op_type=2 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;

				SET THIS_sd_jzbydkxnj = (ORI_YEARLEFT - DO_YEARHAVE + DO_YEARUSE) * 8 ;
				
				SET ORI_CREDITUSE = 0;
				SELECT IFNULL(SUM(IFNULL(A.this_year_use,0)),0)
					INTO ORI_CREDITUSE
				FROM att_hol_credit_year A 
				WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR(BGDT) AND A.is_delete=0;
 				
 				SET DO_YEARUSE = 0;
				#计算当前月及以后电子流使用
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARUSE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=3 AND A.op_type=2 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;
				
				SET THIS_sd_jzbydkxnj = THIS_sd_jzbydkxnj - ((ORI_CREDITUSE - DO_YEARUSE) * 8);
				
			#PART 3 计算当年调休池年假池当月初始状态的值
				DELETE FROM att_st_month_quick_view_icss_manual_pool WHERE ST_ID=MY_STID AND EMP_ID=MY_EMPID;
			#调休
				#得到有几个年份的调休池
				SET YEAR_CT=NULL,YEAR_MXCT=NULL;
				SELECT MIN(A.this_year),MAX(A.this_year) INTO YEAR_CT,YEAR_MXCT
				FROM att_hol_rest A 
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;

				WHILE YEAR_CT <= YEAR_MXCT AND YEAR_CT IS NOT NULL DO
					#得到当前值
					SET ORI_RESTHAVE=0,ORI_RESTUSE=0,ORI_RESTLEFT=0;
					SELECT A.this_year_have,A.this_year_use,A.this_year_left
						INTO ORI_RESTHAVE,ORI_RESTUSE,ORI_RESTLEFT
					FROM att_hol_rest A 
					WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR_CT AND A.is_delete=0;

					IF ORI_RESTLEFT IS NOT NULL THEN
						SET  ORI_RESTHAVE=IFNULL(ORI_RESTHAVE,0),ORI_RESTUSE=IFNULL(ORI_RESTUSE,0),ORI_RESTLEFT=IFNULL(ORI_RESTLEFT,0);
						#得到修改值
						SET DO_RESTHAVE=0, DO_RESTUSE=0;
						#计算当月（含）之后发放
						SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_RESTHAVE
						FROM att_st_icss_pool_log A 
						WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=2 AND A.op_type=1 AND A.which_YEAR = YEAR_CT AND A.is_erase=0;
		
						#回溯过的log标记为已做
						UPDATE att_st_icss_pool_log A 
						SET A.is_erase=1
						WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=2 AND A.op_type=1 AND A.which_YEAR = YEAR_CT AND A.is_erase=0;
		
						#计算当前月及以后电子流使用
						SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_RESTUSE
						FROM att_st_icss_pool_log A 
						WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=2 AND A.op_type=2 AND A.which_YEAR = YEAR_CT AND A.is_erase=0;
						
						#回溯过的log标记为已做
						UPDATE att_st_icss_pool_log A 
						SET A.is_erase=1
						WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=2 AND A.op_type=2 AND A.which_YEAR = YEAR_CT AND A.is_erase=0;

						#计算结果
						SET THIS_RESTHAVE = 0, THIS_RESTUSE = 0, THIS_RESTLEFT= 0;
						SET THIS_RESTHAVE = ORI_RESTHAVE - DO_RESTHAVE;
						SET THIS_RESTUSE = ORI_RESTUSE - DO_RESTUSE;
						SET THIS_RESTLEFT = ORI_RESTLEFT - DO_RESTHAVE + DO_RESTUSE;
						
						REPLACE INTO att_st_month_quick_view_icss_manual_pool (st_id,emp_id,pool_type,this_year,this_year_have,this_year_use,this_year_left)
							VALUES (MY_STID,MY_EMPID,2,YEAR_CT,THIS_RESTHAVE,THIS_RESTUSE,THIS_RESTLEFT);
#select MY_STID,MY_EMPID,2,YEAR_CT,THIS_RESTHAVE,THIS_RESTUSE,THIS_RESTLEFT;
					END IF;
					SET YEAR_CT = YEAR_CT + 1;
				END WHILE;	
			
			#年假
				#得到有几个年份的年假池
				SET YEAR_CT=NULL,YEAR_MXCT=NULL;
				SELECT MIN(A.this_year),MAX(A.this_year) INTO YEAR_CT,YEAR_MXCT
				FROM att_hol_year A 
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;
				
				WHILE YEAR_CT <= YEAR_MXCT AND YEAR_CT IS NOT NULL DO
					#得到当前值
					SET ORI_YEARHAVE=0,ORI_YEARUSE=0,ORI_YEARLEFT=0;
					SELECT A.this_year_have,A.this_year_use,A.this_year_left
						INTO ORI_YEARHAVE,ORI_YEARUSE,ORI_YEARLEFT
					FROM att_hol_YEAR A 
					WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR_CT AND A.is_delete=0;
					
					IF ORI_YEARLEFT IS NOT NULL THEN
						SET  ORI_RESTHAVE=IFNULL(ORI_RESTHAVE,0),ORI_RESTUSE=IFNULL(ORI_RESTUSE,0),ORI_RESTLEFT=IFNULL(ORI_RESTLEFT,0);
						#得到修改值
						SET DO_YEARHAVE=0, DO_YEARUSE=0;
						#计算当月（含）之后发放
						SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARHAVE
						FROM att_st_icss_pool_log A 
						WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt > EDDT AND A.pool_type=1 AND A.op_type=1 AND A.which_YEAR = YEAR_CT AND A.is_erase=0;
		
						#回溯过的log标记为已做
						UPDATE att_st_icss_pool_log A 
						SET A.is_erase=1
						WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt > EDDT AND A.pool_type=1 AND A.op_type=1 AND A.which_YEAR = YEAR_CT AND A.is_erase=0;
		
						#计算当前月及以后电子流使用
						SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARUSE
						FROM att_st_icss_pool_log A 
						WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=1 AND A.op_type=2 AND A.which_YEAR = YEAR_CT AND A.is_erase=0;
						
						#回溯过的log标记为已做
						UPDATE att_st_icss_pool_log A 
						SET A.is_erase=1
						WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=1 AND A.op_type=2 AND A.which_YEAR = YEAR_CT AND A.is_erase=0;
		
						#计算结果
						SET THIS_YEARHAVE = 0, THIS_YEARUSE = 0, THIS_YEARLEFT= 0;
						SET THIS_YEARHAVE = ORI_YEARHAVE - DO_YEARHAVE;
						SET THIS_YEARUSE = ORI_YEARUSE - DO_YEARUSE;
						SET THIS_YEARLEFT = ORI_YEARLEFT - DO_YEARHAVE + DO_YEARUSE;
						
						REPLACE INTO att_st_month_quick_view_icss_manual_pool (st_id,emp_id,pool_type,this_year,this_year_have,this_year_use,this_year_left)
							VALUES (MY_STID,MY_EMPID,1,YEAR_CT,THIS_YEARHAVE,THIS_YEARUSE,THIS_YEARLEFT);
#select MY_STID,MY_EMPID,1,YEAR_CT,THIS_YEARHAVE,THIS_YEARUSE,THIS_YEARLEFT;
					END IF;
					SET YEAR_CT = YEAR_CT + 1;
				END WHILE;	
			
			#当年预支年假
				#得到当前值
				SET ORI_YEARHAVE=0,ORI_YEARUSE=0,ORI_YEARLEFT=0;
				SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_use,0),IFNULL(A.this_year_left,0)
					INTO ORI_YEARHAVE,ORI_YEARUSE,ORI_YEARLEFT
				FROM att_hol_credit_year A 
				WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR(BGDT) AND A.is_delete=0;

				#得到修改值
				SET DO_YEARHAVE=0, DO_YEARUSE=0;
				#计算当月（含）之后发放
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARHAVE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt > EDDT AND A.pool_type=3 AND A.op_type=1 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;
				
				#回溯过的log标记为已做
				UPDATE att_st_icss_pool_log A 
				SET A.is_erase=1
				WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt > EDDT AND A.pool_type=3 AND A.op_type=1 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;

				#计算当前月及以后电子流使用
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) INTO DO_YEARUSE
				FROM att_st_icss_pool_log A 
				WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=3 AND A.op_type=2 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;
				
				#回溯过的log标记为已做
				UPDATE att_st_icss_pool_log A 
				SET A.is_erase=1
				WHERE A.apply_id<>4 AND A.apply_id<>1 AND A.emp_id=MY_EMPID AND A.dt >= BGDT AND A.pool_type=3 AND A.op_type=2 AND A.which_year = YEAR(BGDT) AND A.is_erase=0;

				#计算结果
				SET THIS_YEARHAVE = 0, THIS_YEARUSE = 0, THIS_YEARLEFT= 0;
				SET THIS_YEARHAVE = ORI_YEARHAVE - DO_YEARHAVE;
				SET THIS_YEARUSE = ORI_YEARUSE - DO_YEARUSE;
				SET THIS_YEARLEFT = ORI_YEARLEFT - DO_YEARHAVE + DO_YEARUSE;
	
				REPLACE INTO att_st_month_quick_view_icss_manual_pool (st_id,emp_id,pool_type,this_year,this_year_have,this_year_use,this_year_left)
					VALUES (MY_STID,MY_EMPID,3,YEAR(BGDT),THIS_YEARHAVE,THIS_YEARUSE,THIS_YEARLEFT);
#select MY_STID,MY_EMPID,3,YEAR(BGDT),THIS_YEARHAVE,THIS_YEARUSE,THIS_YEARLEFT;

				#更新计算结果
				UPDATE att_st_month_quick_view_icss_manual_origin A
				SET A.sd_szqnjybx=THIS_sd_szqnjybx, A.sd_jzsybzqzjybx=THIS_sd_jzsybzqzjybx, 
					A.sd_jzdykxnj=THIS_sd_jzdykxnj, A.sd_jzdykxnj=THIS_sd_jzdykxnj, A.sd_fdnwxnj=THIS_sd_fdnwxnj, 
					A.sd_jzbydkxnj=THIS_sd_jzbydkxnj,A.sd_jzdnkxnj = THIS_sd_jzdnkxnj
				WHERE A.st_id=MY_STID AND A.emp_id=MY_EMPID;
			END IF;
			SET CT = CT + 1;
		END WHILE;
	END IF;
	SET MY_STATE = 1;
END;

