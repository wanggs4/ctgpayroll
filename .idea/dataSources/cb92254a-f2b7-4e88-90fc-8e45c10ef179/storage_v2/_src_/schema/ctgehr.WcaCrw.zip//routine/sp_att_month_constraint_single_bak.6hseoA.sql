create procedure SP_ATT_MONTH_CONSTRAINT_SINGLE_BAK(IN bgdt date, IN eddt date, IN emp bigint unsigned)
  comment '针对周期内的日报进行检查和纠错,例如：请假对于考勤的影响'
  BEGIN
DECLARE MY_BOSS_LEVEL,ARR_BGDAY1,ARR_EDDAY1,ARR_BGDAY2,ARR_EDDAY2,ARR_BGDAY3,ARR_EDDAY3,MY_HOLRULE,MY_ATTRULE,THIS_WEEKDAY,MY_ATTGROUPNUMBER,i_have_out,sp_day_half_flag,this_half_day_flag,i_half_day_flag,i_have_half_day_hols,THIS_DAYOFF,ieh,stat,ct,mxct,i_date_type,is_have_att_daily,i_have_hols,h_is_dayoff,app_cnt,app_mxcnt,i_att_rule INT;
DECLARE I_HAVE_SPDAYS,i_act_do_num,i_should_do_num BIGINT;
DECLARE MY_HOLID,i_prgm_id,i_jrdc_id,i_dms_id4,i_dms_id5,i_dms_id6,i_dms_id7,i_dms_id8,i_dms_id9,i_dms_id10,i_position_level_id,i_emp,i_deptid,i_custid,i_holid,i_applyid,MY_ATTID BIGINT UNSIGNED;
DECLARE MONTH_FLEX,MY_MONTH_FLEX_LATE,MY_MONTH_FLEX,ERROR_MINS,THIS_QQ_MINS,i_flex_hour,MY_HOL_DIFF,MY_CK_DIFF,MY_FLEX_DIFF,THIS_WORK_MINS,MY_CNT_HOL_HOUR,MY_ACT_HOUR,i_month_period_hour,MY_WORKMINS,MY_ORI_LATEMINS,MY_ORI_EARLYMINS,MY_ORI_WORKMINS,MY_SPDAY_HOURS,MY_HOLIDAY_HOURS,MY_NA_MINS,THIS_HOL_MINS,THIS_LM,THIS_EM,THIS_MHM,h_work_interval,nl_hour,ne_hour,h_late_mins,h_early_mins,h_hol_hours,i_daily_work_hour,i_hol_hours,MY_MIKLHOL_HOURS DECIMAL(12,2);
DECLARE THIS_HOL_BGTM,THIS_HOL_EDTM,MY_CPT_MST,THIS_ARR_BGTM1,THIS_ARR_EDTM1,THIS_ARR_BGTM2,THIS_ARR_EDTM2,THIS_ARR_BGTM3,THIS_ARR_EDTM3,i_check_in,i_check_out,i_check_osd,THIS_MST,THIS_MET,THIS_AST,THIS_AET,THIS_NA1_BGTM,THIS_NA1_EDTM,THIS_NA2_BGTM,THIS_NA2_EDTM,MY_MONTH_CKIN DATETIME;
DECLARE MY_APPLY_END_TIME,ARR_BGTM1,ARR_EDTM1,ARR_BGTM2,ARR_EDTM2,ARR_BGTM3,ARR_EDTM3,SP_START_TIME,SP_END_TIME,min_start_time,max_end_time,start_time,end_time,MST,MET,AST,AET,i_na_start_time_1,i_na_end_time_1,i_na_start_time_2,i_na_end_time_2 TIME;
DECLARE i_eddt,i_bgdt,i_entry_date,i_leave_date,I_HOL_BGDT,I_HOL_EDDT date;
DECLARE ATTID_STR TEXT;
DECLARE THIS_UID,i_partition_code,i_emp_code,i_emp_name VARCHAR(50);
			

	set sql_mode='';
	SET h_hol_hours = 0,i_hol_hours=0;
	#得到该员工的各项id
	SELECT a.emp_id,a.cust_id,a.dept_id,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,
			b.position_level_id,b.emp_code,a.emp_name,a.boss_level
		INTO 	i_emp,i_custid,i_deptid,i_prgm_id,i_jrdc_id,i_dms_id4,i_dms_id5,i_dms_id6,i_dms_id7,i_dms_id8,i_dms_id9,i_dms_id10,
				i_position_level_id,i_emp_code,i_emp_name,MY_BOSS_LEVEL
	FROM emp_base_info a LEFT JOIN emp_post b ON a.emp_id=b.emp_id 
	WHERE a.emp_id = emp ;
	IF i_emp IS NOT NULL THEN

		select entry_date,leave_date into i_entry_date,i_leave_date from emp_post where emp_id = i_emp;
		#循环2 按给定的日期范围循环
		
		IF i_entry_date > bgdt AND i_entry_date IS NOT NULL THEN 
			SET bgdt = i_entry_date; 
		END IF;
		
		IF i_leave_date < eddt AND i_leave_date IS NOT NULL THEN
			SET eddt = i_leave_date;
		END IF;
		
		SELECT MIN(A.hol_date),MAX(A.hol_date)
			INTO I_HOL_BGDT,I_HOL_EDDT
		FROM att_hol_apply_day A
		WHERE A.emp_id=i_emp AND A.hol_date BETWEEN bgdt AND eddt ;
		
		IF I_HOL_BGDT > bgdt AND I_HOL_BGDT IS NOT NULL THEN 
			SET bgdt = I_HOL_BGDT; 
		END IF;
		
		IF I_HOL_EDDT < eddt AND I_HOL_EDDT IS NOT NULL THEN
			SET eddt = I_HOL_EDDT;
		END IF;

		#按天循环
		WHILE(bgdt <= eddt) DO
			SET h_hol_hours = 0,i_hol_hours=0;
			SET i_date_type=NULL,i_check_in=NULL,i_check_out=NULL,i_check_osd=NULL,is_have_att_daily=0;
			SET i_have_hols=NULL,i_have_half_day_hols=NULL,min_start_time=NULL,max_end_time=NULL,MY_APPLY_END_TIME=NULL;
			SET MY_HOLIDAY_HOURS=0,MY_SPDAY_HOURS=0,MY_MIKLHOL_HOURS=0;
			SET ATTID_STR = NULL,MY_ATTID=NULL;
			#初始化变量
			SET MY_ATTID=NULL,MY_ATTRULE=NULL,MY_ORI_WORKMINS=NULL,MY_ORI_LATEMINS=NULL,MY_ORI_EARLYMINS=NULL;
			#得到日报的信息
			SELECT A.late_mins,A.early_mins,A.work_interval,A.att_id,date_type,
				check_in,check_out,check_osd,count(*)
				INTO MY_ORI_LATEMINS,MY_ORI_EARLYMINS,MY_ORI_WORKMINS,MY_ATTID,i_date_type,i_check_in,i_check_out,i_check_osd,is_have_att_daily
			FROM att_emp_detail A
			WHERE emp_id = i_emp AND dt = bgdt;
			
			IF MY_ATTID IS NULL THEN
				CALL SP_DPT_GET_SETTINGID(i_emp,bgdt,1,ATTID_STR);
				SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);
			END IF;
			
			#得到该员工的出勤设置
			SELECT b.att_rule,b.is_exp_hol,
					b.morn_start_time,b.morn_end_time,b.aftn_start_time,b.aftn_end_time,b.month_period_hour,b.flex_hour,
					b.arrange_bg_day_1,b.arrange_bg_time_1,b.arrange_end_day_1,b.arrange_end_time_1,
					b.arrange_bg_day_2,b.arrange_bg_time_2,b.arrange_end_day_2,b.arrange_end_time_2,
					b.arrange_bg_day_3,b.arrange_bg_time_3,b.arrange_end_day_3,b.arrange_end_time_3,
					b.na_start_time_1,b.na_end_time_1,b.na_start_time_2,b.na_end_time_2
				INTO i_att_rule,ieh,
					MST,MET,AST,AET,i_month_period_hour,i_flex_hour,
					ARR_BGDAY1,ARR_BGTM1,ARR_EDDAY1,ARR_EDTM1,
					ARR_BGDAY2,ARR_BGTM2,ARR_EDDAY2,ARR_EDTM2,
					ARR_BGDAY3,ARR_BGTM3,ARR_EDDAY3,ARR_EDTM3,
					i_na_start_time_1,i_na_end_time_1,i_na_start_time_2,i_na_end_time_2
			FROM att_set_schema_new b
			WHERE b.att_id=MY_ATTID;
			
			#考勤有效时间点转化为datetime
			#坐班
			SET THIS_MST = CONCAT(bgdt,' ',MST);
			SET THIS_MET = CONCAT(bgdt,' ',MET);
			SET THIS_AST = CONCAT(bgdt,' ',AST);
			SET THIS_AET = CONCAT(bgdt,' ',AET);
			SET THIS_NA1_BGTM = CONCAT(bgdt,' ',i_na_start_time_1);
			SET THIS_NA1_EDTM = CONCAT(bgdt,' ',i_na_end_time_1);
			SET THIS_NA2_BGTM = CONCAT(bgdt,' ',i_na_start_time_2);
			SET THIS_NA2_EDTM = CONCAT(bgdt,' ',i_na_end_time_2);			
			
			#排班班段1
			IF ARR_BGDAY1 IS NOT NULL THEN
				SET THIS_ARR_BGTM1 = CONCAT(bgdt,' ',ARR_BGTM1);
				IF ARR_EDDAY1 = 1 THEN
					SET THIS_ARR_EDTM1 = CONCAT(bgdt,' ',ARR_EDTM1);
				ELSEIF ARR_EDDAY1 = 2 THEN
					SET THIS_ARR_EDTM1 = CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' ',ARR_EDTM1);
				END IF;
			ELSE 
				SET THIS_ARR_BGTM1 = NULL;
				SET THIS_ARR_EDTM1 = NULL;
			END IF;
			#排班班段2
			IF ARR_BGDAY2 IS NOT NULL THEN
				SET THIS_ARR_BGTM2 = CONCAT(bgdt,' ',ARR_BGTM2);
				IF ARR_EDDAY2 = 2 THEN
					SET THIS_ARR_EDTM2 = CONCAT(bgdt,' ',ARR_EDTM2);
				ELSEIF ARR_EDDAY2 = 2 THEN
					SET THIS_ARR_EDTM2 = CONCAT(DATE_ADD(bgdt,INTERVAL 2 DAY),' ',ARR_EDTM2);
				END IF;
			ELSE
				SET THIS_ARR_BGTM2 = NULL;
				SET THIS_ARR_EDTM2 = NULL;
			END IF;
			#排班班段3
			IF ARR_BGDAY3 IS NOT NULL THEN
				SET THIS_ARR_BGTM3 = CONCAT(bgdt,' ',ARR_BGTM3);
				IF ARR_EDDAY3 = 3 THEN
					SET THIS_ARR_EDTM3 = CONCAT(bgdt,' ',ARR_EDTM3);
				ELSEIF ARR_EDDAY3 = 3 THEN
					SET THIS_ARR_EDTM3 = CONCAT(DATE_ADD(bgdt,INTERVAL 3 DAY),' ',ARR_EDTM3);
				END IF;
			ELSE
				SET THIS_ARR_BGTM3 = NULL;
				SET THIS_ARR_EDTM3 = NULL;
			END IF;
			
			IF ieh IS NULL OR ieh NOT IN (0,1) THEN SET ieh = 0 ; END IF;
			IF i_month_period_hour IS NULL THEN SET i_month_period_hour=0; END IF;
			
			IF i_flex_hour IS NULL THEN 
				SET i_flex_hour = 0;
			END IF;
			
#1 >>>>>>>>>>>>>>>>>>>		请假校正开始
#1.1 ----------> 	除了每天一小时的哺乳假以外，所有的假期
			#得到请假的信息
			#首先看看当天有几个休假
			SET i_have_hols = 0;
			SELECT count(*) INTO i_have_hols
			FROM att_hol_apply_day A 
				LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
				AND (A.is_year_hol NOT IN (4,9,10) OR (A.is_year_hol=4 AND B.hol_duration=2)) 
				AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL);
				
			SELECT COUNT(*) INTO i_have_out
			FROM att_hol_apply_day A 
				LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			WHERE A.emp_id = i_emp AND A.hol_date = bgdt  AND A.hol_hours > 0
				AND A.is_year_hol = 10 AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL);

			SELECT count(*) INTO i_have_half_day_hols
			FROM att_hol_apply_day A 
				LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			WHERE A.emp_id = i_emp AND A.hol_date = bgdt AND A.min_unit=4
				AND (A.is_year_hol NOT IN (4,9,10) OR (A.is_year_hol=4 AND B.hol_duration=2))
				AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL);
				
			SELECT COUNT(*) INTO I_HAVE_SPDAYS
			FROM att_hol_apply_day A 
				LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
			WHERE A.emp_id=i_emp AND A.hol_date BETWEEN bgdt AND eddt 
				AND A.sp_day_id IS NOT NULL AND A.sp_day_id<>0 AND B.sp_type=2;
			
			SET i_have_half_day_hols = IFNULL(i_have_half_day_hols,0) + IFNULL(I_HAVE_SPDAYS,0);
			SET i_have_hols = IFNULL(i_have_hols,0) + IFNULL(I_HAVE_SPDAYS,0);
			
			SET h_hol_hours = 0;

			#当天有休假且有日报时
			IF i_have_hols > 0 and is_have_att_daily>0 THEN
				#读出当天休假的最早和最晚时间
				SELECT min(A.start_time),max(A.end_time)
					,MAX(APPLY_END_TIME)
					INTO min_start_time,max_end_time,MY_APPLY_END_TIME
				FROM att_hol_apply_day A 
					LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
				AND (A.is_year_hol NOT IN (4,9,10) OR (A.is_year_hol=4 AND B.hol_duration=2));
				
				SELECT min(A.start_time),max(A.end_time)
					INTO SP_START_TIME,SP_END_TIME
				FROM att_hol_apply_day A 
					LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt
					AND A.sp_day_id IS NOT NULL AND A.sp_day_id<>0 AND B.sp_type=2;

				IF min_start_time > SP_START_TIME AND SP_START_TIME IS NOT NULL THEN
				 SET min_start_time = SP_START_TIME;
				END IF;
				IF max_end_time < SP_END_TIME AND SP_END_TIME IS NOT NULL THEN
				 SET max_end_time = SP_END_TIME;
				END IF;
				IF MY_APPLY_END_TIME < SP_END_TIME AND SP_END_TIME IS NOT NULL THEN
				 SET MY_APPLY_END_TIME = SP_END_TIME;
				END IF;
				
				#计算请假时长 
				SELECT SUM(A.hol_hours) INTO MY_HOLIDAY_HOURS
				FROM att_hol_apply_day A 
					LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
					AND (A.is_year_hol NOT IN (4,9,10) OR (A.is_year_hol=4 AND B.hol_duration=2))
					AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL);
				#计算哺乳假时长 
				SELECT SUM(A.hol_hours) INTO MY_MIKLHOL_HOURS
				FROM att_hol_apply_day A 
					LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
					AND A.is_year_hol IN (4,9,10)
					AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL);
				#计算特殊假期时长
				SELECT SUM(A.hol_hours) INTO MY_SPDAY_HOURS
				FROM att_hol_apply_day A 
					LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt AND A.sp_day_id <> 0 AND A.sp_day_id IS NOT NULL AND B.sp_type=2;
				#计算总时长
				SET h_hol_hours = IFNULL(MY_HOLIDAY_HOURS,0) + IFNULL(MY_SPDAY_HOURS,0) + IFNULL(MY_MIKLHOL_HOURS,0);


				SET i_daily_work_hour = FN_ATT_GET_WORKHOURS(MY_ATTID);
				/*
				情况：  有请假的。
				处理：  考勤日报无打卡时间，也没有旷工 不做任何事
						考勤日报如无打卡时间 有旷工
						i_check_in is null and i_check_out is null and i_check_osd is null
							1.工作时长记为0
								h_work_interval
							2.迟到早退分钟数需要根据请假的时间进行计算，
								FN_ATT_GET_MINS_FIXED_NA
							3.再根据迟到计算是否旷工
							4.当日工作时长  =  当天应工作时长 - 迟到 + 早退时间		
				        如有打卡时间
				        一、没有外勤时
							1.有上班打卡，无迟到，迟到不动
							2.有下班打卡，无早退，早退不动
							3.有上班打卡，有迟到，需要根据请假时间进行判断
								如果请假开始时间早于上班打卡时间 替换上班打卡时间重新计算迟到时间
								如果请假开始时间晚于上班打卡时间 不动
							4.有下班打卡，有早退，需要根据请假时间进行判断
								如果请假结束时间早于下班打卡时间，不动
								如果请假结束时间晚于下班打卡时间，替换下班打卡时间重新计算迟到时间
							5.根据迟到和早退时间进行旷工的计算。
							6.工作时长 = 当天应工作时长 - 迟到 + 早退时间
						二、有外勤	不动
						
						如只有上班打卡时间，无下班打卡时间
							
				*/

				#如果当天的请假时长已经超过了当天的应工作时长，那么就应该将当天的旷工、迟到、早退和工作时长归零。
				IF i_daily_work_hour <= h_hol_hours  THEN
					SET h_is_dayoff = 0 ;
					SET h_work_interval = 0 ;
					SET h_late_mins = 0;
					set h_early_mins = 0;
					
#select 1,bgdt,i_daily_work_hour,h_hol_hours,bgdt;

					IF i_have_out > 0 AND i_have_out IS NOT NULL THEN
						IF i_att_rule = 1 THEN
							UPDATE att_emp_detail A
							SET  late_mins = h_late_mins ,
								  early_mins = h_early_mins ,
								  is_dayoff = h_is_dayoff,
								  A.is_have_out = 1,
								  work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID)*60
							WHERE emp_id = i_emp and dt = bgdt;
						ELSEIF i_att_rule = 3 THEN
							UPDATE att_emp_detail A
							SET  late_mins = h_late_mins ,
								  early_mins = h_early_mins ,
								  is_dayoff = h_is_dayoff,
								  A.is_have_out = 1,
								  work_interval = FN_ATT_GET_ARR_WORKHOURS(i_emp,bgdt)
							WHERE emp_id = i_emp and dt = bgdt;
						END IF;
					ELSE
						IF i_att_rule = 1 THEN
							UPDATE att_emp_detail
							SET work_interval = h_work_interval ,
								  late_mins = h_late_mins ,
								  early_mins = h_early_mins ,
								  is_dayoff = h_is_dayoff,
								  is_have_hol = 1,
								  hol_mins = FN_ATT_GET_WORKHOURS(MY_ATTID)*60
							WHERE emp_id = i_emp and dt = bgdt;
						ELSEIF i_att_rule = 3 THEN
							UPDATE att_emp_detail
							SET work_interval = h_work_interval ,
								  late_mins = h_late_mins ,
								  early_mins = h_early_mins ,
								  is_dayoff = h_is_dayoff,
								  is_have_hol = 1,
								  hol_mins = FN_ATT_GET_ARR_WORKHOURS(i_emp,bgdt)
							WHERE emp_id = i_emp and dt = bgdt;
						END IF;
					END IF;
				#坐班考勤，请假时长小于应工作时长，并且有半天假
				ELSEIF i_daily_work_hour > h_hol_hours AND i_have_half_day_hols >= 1 AND i_att_rule = 1 THEN
					SET h_is_dayoff = 0 ;
					SET h_work_interval = 0 ;
					SET h_late_mins = 0;
					set h_early_mins = 0;
					SELECT SUM(IFNULL(A.half_day_flag,0)) INTO i_half_day_flag
					FROM att_hol_apply_day A 
						LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
					WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
						AND (A.is_year_hol NOT IN (4,9,10) OR (A.is_year_hol=4 AND B.hol_duration=2))
						AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL);

					SELECT SUM(IFNULL(A.half_day_flag,0)) INTO sp_day_half_flag
					FROM att_hol_apply_day A
						LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
					WHERE A.emp_id = i_emp AND A.hol_date = bgdt AND A.sp_day_id <> 0 and A.sp_day_id IS NOT NULL AND B.sp_type=2;
					set i_half_day_flag = ifnull(i_half_day_flag,0) + ifnull(sp_day_half_flag,0);
					
					IF i_half_day_flag IS NULL THEN SET i_half_day_flag = 0; END IF;
					#请了上午半天
					IF i_half_day_flag = 1 THEN
						#无外签，有打卡
						IF i_check_osd IS NULL AND i_check_in IS NOT NULL AND i_check_out IS NOT NULL THEN
							SET MY_NA_MINS = (i_daily_work_hour - h_hol_hours) * 60 - FN_ATT_GET_REAL_DAY_HOURS(time(i_check_in),time(i_check_out),i_emp,bgdt);

							IF MY_NA_MINS < 0 OR MY_NA_MINS IS NULL THEN
								SET MY_NA_MINS = 0;
							END IF;

							#最早打卡时间晚于下午开始时间，算为迟到
							IF i_check_in > THIS_AST THEN
								SET h_late_mins = MY_NA_MINS;
								SET h_early_mins = 0;
							#最晚打卡时间小于下午结束时间，算早退
							ELSEIF i_check_out < THIS_AET THEN			
								SET h_late_mins = 0;
								SET h_early_mins = MY_NA_MINS;
							ELSE
								SET h_late_mins = 0;
								SET h_early_mins = 0;
							END IF;
						#无外签，无打卡，算迟到
						ELSEIF i_check_osd IS NULL AND i_check_in IS NULL AND i_check_out IS NULL THEN
							SET MY_NA_MINS = (i_daily_work_hour - h_hol_hours) * 60 ;
							IF MY_NA_MINS < 0 OR MY_NA_MINS IS NULL THEN
								SET MY_NA_MINS = 0;
							END IF;
							SET h_late_mins = MY_NA_MINS;
							SET h_early_mins = 0;
						#有外签，啥都不算
						ELSEIF i_check_osd IS NOT NULL THEN
							SET h_late_mins = 0;
							SET h_early_mins = 0;
						END IF;
					#请了下午半天
					ELSEIF i_half_day_flag = 2 THEN
						#无外签，有打卡
						IF i_check_osd IS NULL AND i_check_in IS NOT NULL AND i_check_out IS NOT NULL THEN
							SET MY_NA_MINS = (i_daily_work_hour - h_hol_hours) * 60 - FN_ATT_GET_REAL_DAY_HOURS(time(i_check_in),time(i_check_out),i_emp,bgdt);
							
							IF MY_NA_MINS < 0 OR MY_NA_MINS IS NULL THEN
								SET MY_NA_MINS = 0;
							END IF;
							
							#最早打卡时间晚于上午开始时间，算为迟到
							IF i_check_in > THIS_MST THEN
								SET h_late_mins = MY_NA_MINS;
								SET h_early_mins = 0;
							#最晚打卡时间小于上午结束时间，算早退
							ELSEIF i_check_out < THIS_MET THEN			
								SET h_late_mins = 0;
								SET h_early_mins = MY_NA_MINS;
							ELSE
								SET h_late_mins = 0;
								SET h_early_mins = 0;
							END IF;
						#无外签，无打卡，算迟到
						ELSEIF i_check_osd IS NULL AND i_check_in IS NULL AND i_check_out IS NULL THEN
							SET MY_NA_MINS = (i_daily_work_hour - h_hol_hours) * 60;
							IF MY_NA_MINS < 0 OR MY_NA_MINS IS NULL THEN
								SET MY_NA_MINS = 0;
							END IF;
							SET h_late_mins = MY_NA_MINS;
							SET h_early_mins = 0;
						#有外签，啥都不算
						ELSEIF i_check_osd IS NOT NULL THEN
							SET h_late_mins = 0;
							SET h_early_mins = 0;
						END IF;
					#请了全天
					ELSEIF i_half_day_flag =3 THEN
						SET h_late_mins = 0;
						SET h_early_mins = 0;
					END IF;

					#计算工作时长
					SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60 - h_late_mins - h_early_mins - h_hol_hours*60;
					#计算旷工

					SET h_is_dayoff = FN_ATT_GET_DAYOFF_STATUS(h_late_mins,h_early_mins,MY_ATTID);
					
					IF MY_BOSS_LEVEL IN (2,3) THEN
						SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60;
						SET h_late_mins = 0,h_early_mins = 0,h_is_dayoff=0,h_hol_hours=0;
					END IF;
#select 2,bgdt,h_work_interval,h_late_mins,h_early_mins,h_is_dayoff, h_hol_hours*60;
					#更新数据
					UPDATE att_emp_detail 
					SET work_interval = h_work_interval ,
					  late_mins = FN_ATT_GET_MINUNIT_MINS(h_late_mins,MY_ATTID) ,
					  early_mins = FN_ATT_GET_MINUNIT_MINS(h_early_mins,MY_ATTID) ,
					  is_dayoff = h_is_dayoff,
					  hol_mins = h_hol_hours*60
					WHERE emp_id = i_emp and dt = bgdt;	

				#如果当天请假时长没有超过应工作时长，那么针对请假的两个时间点进行判断和处理。
				ELSE
					SET h_is_dayoff = 0 ;
					SET h_work_interval = 0 ;
					SET h_late_mins = 0;
					set h_early_mins = 0;
					#case1 无打卡信息或只有一次打卡，有矿工，且工作日，需根据请假时间点重新计算迟到早退和旷工
#/*
					IF (((i_check_in is null and i_check_out is null) OR i_check_in = i_check_out) and i_check_osd is null AND (i_date_type IN (1,6) or ( i_date_type=3 and ieh=0 ))) THEN

						#计算迟到早退时间
						IF i_att_rule = 1 THEN
							CALL FN_ATT_GET_MINS_FIXED_NA(min_start_time,max_end_time,MY_ATTID,h_late_mins,h_early_mins);
						ELSEIF i_att_rule = 3 THEN
							CALL FN_ATT_GET_MINS_ARRANGE_NA(min_start_time,max_end_time,bgdt,i_emp,h_late_mins,h_early_mins);
						END IF;
#20200508 注销 中软不需要补足480分钟
						#请假起点和上班点的时间差 大于零且小于等于设定弹性时间
 
						SET ERROR_MINS = FN_ATT_GET_WORKHOURS(MY_ATTID)*60 - h_work_interval - h_late_mins - h_early_mins -  h_hol_hours*60;
						
						#最早的打卡时间
						SET MY_MONTH_CKIN = CONCAT(bgdt,' ',min_start_time);

						#设置最晚上班时间，月弹
						IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
							SET MY_CPT_MST = DATE_ADD(THIS_MST,INTERVAL (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60 MINUTE);
						#日弹
					
						ELSE
							SET MY_CPT_MST = DATE_ADD(THIS_MST,INTERVAL i_flex_hour MINUTE);
						END IF;
						
						SET MONTH_FLEX = (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60;
						
						IF (i_month_period_hour IS NULL OR i_month_period_hour = 0) OR (i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL AND ( ERROR_MINS > MONTH_FLEX OR ERROR_MINS < 0 )) THEN
							
							IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
								SET ERROR_MINS = ERROR_MINS - MONTH_FLEX;
							END IF;
 
							IF ERROR_MINS > 0 THEN
								IF MY_MONTH_CKIN <= MY_CPT_MST THEN
									SET h_early_mins = h_early_mins + ERROR_MINS;
								ELSE
									SET h_late_mins = h_late_mins + ERROR_MINS;
								END IF;
							ELSEIF ERROR_MINS < 0 AND h_late_mins = 0 AND h_early_mins = 0  THEN
								IF i_check_in <= MY_CPT_MST THEN
									SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID)*60 - h_late_mins - h_early_mins -  h_hol_hours*60;
								ELSE
									SET h_work_interval = h_work_interval + ERROR_MINS;
								END IF;
								
							ELSEIF ERROR_MINS < 0 AND (h_late_mins > 0 OR h_early_mins > 0) THEN
								IF h_early_mins + ERROR_MINS >= 0 THEN
									SET h_early_mins = h_early_mins + ERROR_MINS;
								ELSE
	
									SET ERROR_MINS = ERROR_MINS + h_early_mins;
									SET h_early_mins = 0 ;
									IF h_late_mins + ERROR_MINS >= 0 THEN
										SET h_late_mins = h_late_mins + ERROR_MINS;
									ELSE
										SET ERROR_MINS = ERROR_MINS + h_late_mins;
										SET h_late_mins = 0;
										SET h_work_interval = h_work_interval + ERROR_MINS;
									END IF;
								END IF;
							END IF;

						#月弹，且误差时间在1小时内
						ELSEIF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL AND ( ERROR_MINS < MONTH_FLEX AND ERROR_MINS > 0 ) THEN							
							IF MY_MONTH_CKIN > MY_CPT_MST THEN
								SET h_late_mins = h_late_mins + ERROR_MINS;
							END IF;

						END IF;
					


						#计算旷工
						SET h_is_dayoff = FN_ATT_GET_DAYOFF_STATUS(h_late_mins,h_early_mins,MY_ATTID);
						IF MY_BOSS_LEVEL IN (2,3) THEN
							SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60;
							SET h_late_mins = 0,h_early_mins = 0,h_is_dayoff=0,h_hol_hours=0;
						END IF;
						
						IF h_work_interval < 0 THEN SET h_work_interval = 0 ; END IF;
						IF h_late_mins < 0 THEN SET h_late_mins = 0 ; END IF;

#select 3,ERROR_MINS,bgdt,min_start_time,max_end_time,h_work_interval,h_late_mins,h_early_mins,h_hol_hours,h_is_dayoff,MY_ATTID;
						#更新数据
						UPDATE att_emp_detail 
						SET work_interval = h_work_interval ,
						  late_mins = FN_ATT_GET_MINUNIT_MINS(h_late_mins,MY_ATTID) ,
						  early_mins = FN_ATT_GET_MINUNIT_MINS(h_early_mins,MY_ATTID) ,
						  is_dayoff = h_is_dayoff,
						  hol_mins = h_hol_hours*60
						WHERE emp_id = i_emp and dt = bgdt;	
					#case2 当没有外勤，且上下班打卡都有，且是工作日的时候,			

#*/
					ELSEIF (i_check_osd IS NULL AND i_check_in IS NOT NULL AND i_check_out IS NOT NULL AND (i_date_type IN (1,6) or ( i_date_type=3 and ieh=0 ))) 
#						OR (((i_check_in is null and i_check_out is null) OR i_check_in = i_check_out) and i_check_osd is null AND (i_date_type IN (1,6) or ( i_date_type=3 and ieh=0 ))) 
					THEN
						SET THIS_UID = NULL;
						SET THIS_UID = UUID();
						
						IF i_att_rule = 1 THEN
							SET MY_HOL_DIFF=0,MY_CK_DIFF=0,MY_FLEX_DIFF=0;
							SET MY_HOL_DIFF = ROUND(TIME_TO_SEC(TIMEDIFF(CONCAT(bgdt,' ',min_start_time),THIS_MST))/60,2);
							SET MY_CK_DIFF = ROUND(TIME_TO_SEC(TIMEDIFF(i_check_in,THIS_MST))/60,2);
							#请假起点和上班点的时间差 大于零且小于等于设定弹性时间
							IF MY_HOL_DIFF > 0 AND MY_HOL_DIFF <= i_flex_hour THEN
								IF MY_CK_DIFF > 0 AND MY_CK_DIFF <= i_flex_hour THEN
									IF MY_CK_DIFF < MY_HOL_DIFF THEN
										SET MY_FLEX_DIFF = MY_CK_DIFF ; 
									ELSE
										SET MY_FLEX_DIFF = MY_HOL_DIFF ; 
									END IF;
									SET max_end_time = MY_APPLY_END_TIME;
								ELSEIF MY_CK_DIFF > 0 AND MY_CK_DIFF > i_flex_hour THEN
									SET MY_FLEX_DIFF = MY_HOL_DIFF ; 
									SET max_end_time = MY_APPLY_END_TIME;
								ELSE
									SET MY_FLEX_DIFF = 0 ; 
								END IF;
							#请假起点和上班点的时间差 大于零且大于等于设定弹性时间
							ELSEIF MY_HOL_DIFF > 0 AND MY_HOL_DIFF > i_flex_hour THEN
								IF MY_CK_DIFF > 0 AND MY_CK_DIFF <= i_flex_hour THEN
									SET MY_FLEX_DIFF = MY_CK_DIFF ; 
									SET max_end_time = MY_APPLY_END_TIME;
								ELSE
									SET MY_FLEX_DIFF = 0 ; 
								END IF;
							#请假起点和上班点的时间差 小于0
							ELSE
								SET MY_FLEX_DIFF = 0 ; 
							END IF;
							
							IF MY_FLEX_DIFF IS NULL THEN
								SET MY_FLEX_DIFF = 0;
							END IF;
							
							INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
								(THIS_UID,DATE_ADD(THIS_MST,INTERVAL MY_FLEX_DIFF MINUTE),1,1),
								(THIS_UID,THIS_MET,1,2),
								(THIS_UID,THIS_AST,2,1),
								(THIS_UID,DATE_ADD(THIS_AET,INTERVAL MY_FLEX_DIFF MINUTE),2,2),
								(THIS_UID,THIS_NA1_BGTM,6,1),
								(THIS_UID,THIS_NA1_EDTM,6,2),
								(THIS_UID,THIS_NA2_BGTM,6,1),
								(THIS_UID,THIS_NA2_EDTM,6,2);
						ELSEIF i_att_rule = 3 THEN
							INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
								(THIS_UID,THIS_ARR_BGTM1,1,1),
								(THIS_UID,THIS_ARR_EDTM1,1,2),
								(THIS_UID,THIS_ARR_BGTM2,2,1),
								(THIS_UID,THIS_ARR_EDTM2,2,2),
								(THIS_UID,THIS_ARR_BGTM3,3,1),
								(THIS_UID,THIS_ARR_EDTM3,3,2);
						END IF;
						INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
							(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(CONCAT(bgdt,' ',min_start_time)),5,1),
							(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(CONCAT(bgdt,' ',max_end_time)),5,2),
							(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(i_check_in),4,1),
							(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(i_check_out),4,2);						
						
						INSERT INTO tmp_att_timeframe_compare (version_code,time_point,tp_type,which_pt)
							SELECT A.version_code,A.time_point,A.tp_type,A.which_pt
							FROM tmp_att_timeframe_compare_random A
							WHERE A.version_code=THIS_UID AND A.time_point IS NOT NULL
							ORDER BY A.time_point,A.tp_type,A.which_pt;

						SET h_late_mins=0,h_early_mins=0,THIS_HOL_MINS=0,THIS_WORK_MINS=0,h_work_interval=0;
						CALL FN_ATT_GET_TIMEFRAME_COMPARE(THIS_UID,h_late_mins,h_early_mins,THIS_HOL_MINS,THIS_WORK_MINS);
						
						SET h_work_interval = THIS_WORK_MINS;
						
						#处理月弹处于弹性内的迟到问题
						IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
							SET MY_MONTH_FLEX = NULL, MY_MONTH_CKIN = NULL, MY_MONTH_FLEX_LATE = NULL;
							#得到月弹弹性时长
							SET MY_MONTH_FLEX = (FN_ATT_GET_WORKHOURS(MY_ATTID) - i_month_period_hour) * 60;
							
							SET MY_MONTH_CKIN = CONCAT(bgdt,' ',min_start_time);
							
							#确定请假和打卡哪个是最早的打卡时间
							IF i_check_in < MY_MONTH_CKIN THEN
								SET MY_MONTH_CKIN = i_check_in;
							END IF;
							
							#如果这个打卡介于弹性时间内，迟到时长要减去响应时间
							IF MY_MONTH_CKIN > THIS_MST AND MY_MONTH_CKIN < DATE_ADD(THIS_MST,INTERVAL MY_MONTH_FLEX MINUTE) THEN
								SET MY_MONTH_FLEX_LATE = FN_ATT_GET_MINUNIT_MINS(ROUND(TIME_TO_SEC(TIMEDIFF(MY_MONTH_CKIN,THIS_MST))/60,2),MY_ATTID);
							#如果打卡超出了弹性时间，迟到时长减去总弹性时长
							ELSEIF MY_MONTH_CKIN >= DATE_ADD(THIS_MST,INTERVAL MY_MONTH_FLEX MINUTE) THEN
								SET MY_MONTH_FLEX_LATE = MY_MONTH_FLEX;
							ELSE
								SET MY_MONTH_FLEX_LATE = 0;
							END IF;
#SELECT MY_MONTH_FLEX_LATE,MY_MONTH_CKIN,THIS_MST,DATE_ADD(THIS_MST,INTERVAL MY_MONTH_FLEX MINUTE) ;
							SET h_late_mins = h_late_mins - MY_MONTH_FLEX_LATE;
						#日弹得到最早打卡时间
						ELSE
							SET MY_MONTH_CKIN = CONCAT(bgdt,' ',min_start_time);
							
							#确定请假和打卡哪个是最早的打卡时间
							IF i_check_in < MY_MONTH_CKIN THEN
								SET MY_MONTH_CKIN = i_check_in;
							END IF;
							
						END IF;						
/*
						IF THIS_HOL_MINS > h_hol_hours*60 THEN
							IF h_early_mins > 0 THEN
								SET h_late_mins = h_late_mins + h_early_mins;
								SET h_early_mins = 0;
							ELSE
								SET h_late_mins = h_late_mins + (THIS_HOL_MINS-h_hol_hours*60);
							END IF;
						END IF;
*/

						SET ERROR_MINS = FN_ATT_GET_WORKHOURS(MY_ATTID)*60 - h_work_interval - h_late_mins - h_early_mins -  h_hol_hours*60;
						
						IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
							SET MY_CPT_MST = DATE_ADD(THIS_MST,INTERVAL (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60 MINUTE);
						ELSE
							SET MY_CPT_MST = DATE_ADD(THIS_MST,INTERVAL i_flex_hour MINUTE);
						END IF;
#SELECT MY_CPT_MST;
#

#20200508 注销 中软不需要补足480分钟
#/*
						SET MONTH_FLEX = (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60;


						IF (i_month_period_hour IS NULL OR i_month_period_hour = 0) OR (i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL AND ( ERROR_MINS > MONTH_FLEX OR ERROR_MINS < 0 )) THEN
							IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
								SET ERROR_MINS = ERROR_MINS - MONTH_FLEX;
							END IF;
#select ERROR_MINS,MY_CPT_MST,MY_MONTH_CKIN; 
							IF ERROR_MINS > 0 THEN
								IF MY_MONTH_CKIN <= MY_CPT_MST THEN
									SET h_early_mins = h_early_mins + ERROR_MINS;
								ELSE
									SET h_late_mins = h_late_mins + ERROR_MINS;
								END IF;
							ELSEIF ERROR_MINS < 0 AND h_late_mins = 0 AND h_early_mins = 0  THEN
								IF i_check_in <= MY_CPT_MST THEN
									SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID)*60 - h_late_mins - h_early_mins -  h_hol_hours*60;
								ELSE
									SET h_work_interval = h_work_interval + ERROR_MINS;
								END IF;
								
							ELSEIF ERROR_MINS < 0 AND (h_late_mins > 0 OR h_early_mins > 0) THEN
								IF h_early_mins + ERROR_MINS >= 0 THEN
									SET h_early_mins = h_early_mins + ERROR_MINS;
								ELSE
	
									SET ERROR_MINS = ERROR_MINS + h_early_mins;
									SET h_early_mins = 0 ;
									IF h_late_mins + ERROR_MINS >= 0 THEN
										SET h_late_mins = h_late_mins + ERROR_MINS;
									ELSE
										SET ERROR_MINS = ERROR_MINS + h_late_mins;
										SET h_late_mins = 0;
										SET h_work_interval = h_work_interval + ERROR_MINS;
									END IF;
								END IF;
							END IF;

						#月弹，且误差时间在1小时内
						ELSEIF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL AND ( ERROR_MINS < MONTH_FLEX AND ERROR_MINS > 0 ) THEN							
#select 2; 
							IF MY_MONTH_CKIN > MY_CPT_MST THEN
								SET h_late_mins = h_late_mins + ERROR_MINS;
							END IF;

						END IF;
#*/
						#计算旷工
						SET h_is_dayoff = FN_ATT_GET_DAYOFF_STATUS(h_late_mins,h_early_mins,MY_ATTID);
						IF MY_BOSS_LEVEL IN (2,3) THEN
							SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60;
							SET h_late_mins = 0,h_early_mins = 0,h_is_dayoff=0,h_hol_hours=0;
						END IF;
						
						IF h_work_interval < 0 THEN SET h_work_interval = 0 ; END IF;
						IF h_late_mins < 0 THEN SET h_late_mins = 0 ; END IF;
						
#select 4,bgdt,h_work_interval,h_late_mins,h_early_mins,h_is_dayoff, h_hol_hours*60,ERROR_MINS; 
						#更新数据
						UPDATE att_emp_detail 
						SET work_interval = h_work_interval ,
						  late_mins = FN_ATT_GET_MINUNIT_MINS(h_late_mins,MY_ATTID) ,
						  early_mins = FN_ATT_GET_MINUNIT_MINS(h_early_mins,MY_ATTID) ,
						  is_dayoff = h_is_dayoff,
						  hol_mins = h_hol_hours*60
						WHERE emp_id = i_emp and dt = bgdt;	
					ELSE 
						SET h_work_interval=0;
						SET h_late_mins = 0;
						SET h_early_mins = 0;
						SET h_is_dayoff = 0 ;

#select 5,bgdt,h_work_interval,h_late_mins,h_early_mins,h_is_dayoff, h_hol_hours*60; 
						IF MY_BOSS_LEVEL IN (2,3) THEN
							SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60;
							SET h_late_mins = 0,h_early_mins = 0,h_is_dayoff=0,h_hol_hours=0;
						END IF;
						#更新数据
						UPDATE att_emp_detail
						SET #work_interval = h_work_interval ,
						  late_mins = FN_ATT_GET_MINUNIT_MINS(h_late_mins,MY_ATTID) ,
						  early_mins = FN_ATT_GET_MINUNIT_MINS(h_early_mins,MY_ATTID) ,
						  is_dayoff = h_is_dayoff,
						  hol_mins = h_hol_hours*60
						WHERE emp_id = i_emp and dt = bgdt;	
					
					END IF;		
				END IF;
			END IF;
			
			#有公出
			IF i_have_out > 0 AND i_have_out IS NOT NULL THEN

				SET THIS_UID = NULL,min_start_time=NULL,max_end_time=NULL,MY_APPLY_END_TIME=NULL,h_hol_hours=0;
				
				SET THIS_UID = UUID();
				SELECT min(A.start_time),max(A.end_time)
					,MAX(APPLY_END_TIME),SUM(IFNULL(A.hol_hours,0))*60
						INTO min_start_time,max_end_time,MY_APPLY_END_TIME,h_hol_hours
				FROM att_hol_apply_day A
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt AND A.is_year_hol=10;
				
				IF i_att_rule = 1 THEN
					SET MY_HOL_DIFF=0,MY_CK_DIFF=0,MY_FLEX_DIFF=0;
					SET MY_HOL_DIFF = ROUND(TIME_TO_SEC(TIMEDIFF(CONCAT(bgdt,' ',min_start_time),THIS_MST))/60,2);
					SET MY_CK_DIFF = ROUND(TIME_TO_SEC(TIMEDIFF(i_check_in,THIS_MST))/60,2);
					#请假起点和上班点的时间差 大于零且小于等于设定弹性时间
					IF MY_HOL_DIFF > 0 AND MY_HOL_DIFF <= i_flex_hour THEN
						IF MY_CK_DIFF > 0 AND MY_CK_DIFF <= i_flex_hour THEN
							IF MY_CK_DIFF < MY_HOL_DIFF THEN
								SET MY_FLEX_DIFF = MY_CK_DIFF ; 
							ELSE
								SET MY_FLEX_DIFF = MY_HOL_DIFF ; 
							END IF;
							SET max_end_time = MY_APPLY_END_TIME;
						ELSEIF MY_CK_DIFF > 0 AND MY_CK_DIFF > i_flex_hour THEN
							SET MY_FLEX_DIFF = MY_HOL_DIFF ; 
							SET max_end_time = MY_APPLY_END_TIME;
						ELSE
							SET MY_FLEX_DIFF = 0 ; 
						END IF;
					#请假起点和上班点的时间差 大于零且大于等于设定弹性时间
					ELSEIF MY_HOL_DIFF > 0 AND MY_HOL_DIFF > i_flex_hour THEN
						IF MY_CK_DIFF > 0 AND MY_CK_DIFF <= i_flex_hour THEN
							SET MY_FLEX_DIFF = MY_CK_DIFF ; 
							SET max_end_time = MY_APPLY_END_TIME;
						ELSE
							SET MY_FLEX_DIFF = 0 ; 
						END IF;
					#请假起点和上班点的时间差 小于0
					ELSE
						SET MY_FLEX_DIFF = 0 ; 
					END IF;
					
					IF MY_FLEX_DIFF IS NULL THEN
						SET MY_FLEX_DIFF = 0;
					END IF;
					
					INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
						(THIS_UID,DATE_ADD(THIS_MST,INTERVAL MY_FLEX_DIFF MINUTE),1,1),
						(THIS_UID,THIS_MET,1,2),
						(THIS_UID,THIS_AST,2,1),
						(THIS_UID,DATE_ADD(THIS_AET,INTERVAL MY_FLEX_DIFF MINUTE),2,2),
						(THIS_UID,THIS_NA1_BGTM,6,1),
						(THIS_UID,THIS_NA1_EDTM,6,2),
						(THIS_UID,THIS_NA2_BGTM,6,1),
						(THIS_UID,THIS_NA2_EDTM,6,2);
				ELSEIF i_att_rule = 3 THEN
					INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
						(THIS_UID,THIS_ARR_BGTM1,1,1),
						(THIS_UID,THIS_ARR_EDTM1,1,2),
						(THIS_UID,THIS_ARR_BGTM2,2,1),
						(THIS_UID,THIS_ARR_EDTM2,2,2),
						(THIS_UID,THIS_ARR_BGTM3,3,1),
						(THIS_UID,THIS_ARR_EDTM3,3,2);
				END IF;
				INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
					(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(CONCAT(bgdt,' ',min_start_time)),5,1),
					(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(CONCAT(bgdt,' ',max_end_time)),5,2),
					(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(i_check_in),4,1),
					(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(i_check_out),4,2);						
				
				INSERT INTO tmp_att_timeframe_compare (version_code,time_point,tp_type,which_pt)
					SELECT A.version_code,A.time_point,A.tp_type,A.which_pt
					FROM tmp_att_timeframe_compare_random A
					WHERE A.version_code=THIS_UID AND A.time_point IS NOT NULL
					ORDER BY A.time_point,A.tp_type,A.which_pt;
#select * from tmp_att_timeframe_compare where version_code=THIS_UID;
				SET h_late_mins=0,h_early_mins=0,THIS_HOL_MINS=0,THIS_WORK_MINS=0,h_work_interval=0;
				CALL FN_ATT_GET_TIMEFRAME_COMPARE(THIS_UID,h_late_mins,h_early_mins,THIS_HOL_MINS,THIS_WORK_MINS);

#select h_late_mins,h_early_mins,THIS_HOL_MINS,THIS_WORK_MINS;				

				SET h_work_interval = THIS_WORK_MINS + THIS_HOL_MINS;
#SELECT h_work_interval;			
				#处理月弹处于弹性内的迟到问题
				IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
					SET MY_MONTH_FLEX = NULL, MY_MONTH_CKIN = NULL, MY_MONTH_FLEX_LATE = NULL;
					#得到月弹弹性时长
					SET MY_MONTH_FLEX = (FN_ATT_GET_WORKHOURS(MY_ATTID) - i_month_period_hour) * 60;
#select MY_MONTH_FLEX;					
					SET MY_MONTH_CKIN = CONCAT(bgdt,' ',min_start_time);
					
					#确定请假和打卡哪个是最早的打卡时间
					IF i_check_in < MY_MONTH_CKIN AND i_check_in IS NOT NULL THEN
						SET MY_MONTH_CKIN = i_check_in;
					END IF;
					
					#如果这个打卡介于弹性时间内，迟到时长要减去响应时间
					IF MY_MONTH_CKIN > THIS_MST AND MY_MONTH_CKIN < DATE_ADD(THIS_MST,INTERVAL MY_MONTH_FLEX MINUTE) THEN
						SET MY_MONTH_FLEX_LATE = FN_ATT_GET_MINUNIT_MINS(ROUND(TIME_TO_SEC(TIMEDIFF(MY_MONTH_CKIN,THIS_MST))/60,2),MY_ATTID);
					#如果打卡超出了弹性时间，迟到时长减去总弹性时长
					ELSEIF MY_MONTH_CKIN >= DATE_ADD(THIS_MST,INTERVAL MY_MONTH_FLEX MINUTE) THEN
						SET MY_MONTH_FLEX_LATE = MY_MONTH_FLEX;
					ELSE
						SET MY_MONTH_FLEX_LATE = 0;
					END IF;
#SELECT MY_MONTH_CKIN,THIS_MST,MY_MONTH_FLEX,MY_MONTH_FLEX_LATE;
					SET h_late_mins = h_late_mins - MY_MONTH_FLEX_LATE;
				#日弹得到最早打卡时间
				ELSE
					SET MY_MONTH_CKIN = CONCAT(bgdt,' ',min_start_time);
					
					#确定请假和打卡哪个是最早的打卡时间
					IF i_check_in < MY_MONTH_CKIN AND i_check_in IS NOT NULL THEN
						SET MY_MONTH_CKIN = i_check_in;
					END IF;
					
				END IF;						


				SET ERROR_MINS = FN_ATT_GET_WORKHOURS(MY_ATTID)*60 - h_work_interval - h_late_mins - h_early_mins;
				
				IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
					SET MY_CPT_MST = DATE_ADD(THIS_MST,INTERVAL (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60 MINUTE);
				ELSE
					SET MY_CPT_MST = DATE_ADD(THIS_MST,INTERVAL i_flex_hour MINUTE);
				END IF;

#SELECT MY_MONTH_CKIN,MY_CPT_MST,h_work_interval,h_late_mins,h_early_mins;
				IF MY_MONTH_CKIN <= MY_CPT_MST AND h_late_mins > 0 AND i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
					SET h_early_mins = h_early_mins + h_late_mins;
					SET h_late_mins = 0;
#SELECT 801;
				ELSEIF MY_MONTH_CKIN <= MY_CPT_MST AND MY_MONTH_CKIN > THIS_MST  AND h_late_mins > 0 AND h_late_mins <= i_flex_hour AND i_flex_hour > 0 THEN
					SET h_work_interval = h_work_interval + h_late_mins;
					SET h_late_mins = 0;
#SELECT 802;
				ELSEIF MY_MONTH_CKIN > MY_CPT_MST AND h_late_mins > i_flex_hour AND i_flex_hour > 0 THEN
					IF i_check_in IS NOT NULL AND i_check_out IS NOT NULL AND i_check_in <> i_check_out THEN
						SET h_work_interval = h_work_interval + i_flex_hour;
						SET h_late_mins = h_late_mins - i_flex_hour;
					ELSEIF (i_check_in IS NULL OR i_check_out IS NULL) OR i_check_in <> i_check_out THEN
						IF h_work_interval < h_hol_hours THEN
							SET h_work_interval = h_work_interval + i_flex_hour;
							SET h_late_mins = h_late_mins - i_flex_hour;						
						ELSE
							SET h_early_mins = h_early_mins + i_flex_hour;
							SET h_late_mins = h_late_mins - i_flex_hour;
						END IF;
					END IF;
#SELECT 803;
				ELSEIF MY_MONTH_CKIN <= THIS_MST AND h_late_mins > 0 AND i_flex_hour > 0 THEN
					SET h_early_mins = h_early_mins + h_late_mins; 
					SET h_late_mins = 0;
#SELECT 804;
				END IF;
#SELECT MY_MONTH_CKIN,MY_CPT_MST,h_work_interval,h_late_mins,h_early_mins;
				SET MONTH_FLEX = (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60;

				IF (i_month_period_hour IS NULL OR i_month_period_hour = 0) OR (i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL AND ( ERROR_MINS > MONTH_FLEX OR ERROR_MINS < 0 )) THEN
					IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
						SET ERROR_MINS = ERROR_MINS - MONTH_FLEX;
					END IF;

					IF ERROR_MINS > 0 THEN
						IF MY_MONTH_CKIN <= MY_CPT_MST THEN
							IF max_end_time > '19:00:00' THEN
								SET h_work_interval = h_work_interval + ERROR_MINS;
							ELSE
								SET h_early_mins = h_early_mins + ERROR_MINS;
							END IF;
						ELSE
							SET h_late_mins = h_late_mins + ERROR_MINS;
						END IF;
#select 81,MY_MONTH_CKIN,MY_CPT_MST,h_early_mins,h_late_mins,h_work_interval;
					ELSEIF ERROR_MINS < 0 AND h_late_mins = 0 AND h_early_mins = 0  THEN
						IF i_check_in <= MY_CPT_MST THEN
							SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID)*60 - h_late_mins - h_early_mins -  h_hol_hours*60;
						ELSE
							SET h_work_interval = h_work_interval + ERROR_MINS;
						END IF;
#select 82;
					ELSEIF ERROR_MINS < 0 AND (h_late_mins > 0 OR h_early_mins > 0) THEN
						IF h_early_mins + ERROR_MINS >= 0 THEN
							SET h_early_mins = h_early_mins + ERROR_MINS;
						ELSE

							SET ERROR_MINS = ERROR_MINS + h_early_mins;
							SET h_early_mins = 0 ;
							IF h_late_mins + ERROR_MINS >= 0 THEN
								SET h_late_mins = h_late_mins + ERROR_MINS;
							ELSE
								SET ERROR_MINS = ERROR_MINS + h_late_mins;
								SET h_late_mins = 0;
								SET h_work_interval = h_work_interval + ERROR_MINS;
							END IF;
						END IF;
#select 83;
					END IF;

				#月弹，且误差时间在1小时内
				ELSEIF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL AND ( ERROR_MINS < MONTH_FLEX AND ERROR_MINS > 0 ) THEN							
					IF MY_MONTH_CKIN > MY_CPT_MST THEN
						SET h_late_mins = h_late_mins + ERROR_MINS;
					ELSE
						SET h_work_interval = h_work_interval + ERROR_MINS;
					END IF;
#select 84;

				END IF;
				#计算旷工
				SET h_is_dayoff = FN_ATT_GET_DAYOFF_STATUS(h_late_mins,h_early_mins,MY_ATTID);
				IF MY_BOSS_LEVEL IN (2,3) THEN
					SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60;
					SET h_late_mins = 0,h_early_mins = 0,h_is_dayoff=0,h_hol_hours=0;
				END IF;
				
				IF h_work_interval < 0 THEN SET h_work_interval = 0 ; END IF;
				IF h_late_mins < 0 THEN SET h_late_mins = 0 ; END IF;
				
#select 8,bgdt,h_work_interval ,h_late_mins,h_early_mins,h_is_dayoff, ERROR_MINS; 
				#更新数据
				UPDATE att_emp_detail A
				SET work_interval = h_work_interval,
				  late_mins = FN_ATT_GET_MINUNIT_MINS(h_late_mins,MY_ATTID) ,
				  early_mins = FN_ATT_GET_MINUNIT_MINS(h_early_mins,MY_ATTID) ,
				  is_dayoff = h_is_dayoff,
				  hol_mins = 0,
				  A.is_have_out=1
				WHERE emp_id = i_emp and dt = bgdt;	
			END IF;
			
#1.2 ----------> 	每天N小时的哺乳假
			#首先看看当天有几个休假
			SET i_have_hols = 0;
			SET i_applyid = NULL,i_deptid=null;
			select dept_id into i_deptid from emp_base_info a where a.emp_id=i_emp;
			SELECT count(*),MAX(A.APPLY_ID) INTO i_have_hols,i_applyid
			FROM att_hol_apply_day A 
				LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
				AND ((A.is_year_hol=4 AND B.hol_duration=1) OR A.is_year_hol=9)
				AND (A.sp_day_id=0 OR A.sp_day_id IS NULL);

			#如果当天有减N小时的哺乳假
			IF i_have_hols > 0 AND i_applyid IS NOT NULL THEN
				#读出当天日报内容
				SELECT A.late_mins,A.early_mins,A.milk_hol_mins
					INTO THIS_LM,THIS_EM,THIS_MHM
				FROM att_emp_detail A
				WHERE A.emp_id = i_emp AND A.dt =  bgdt;
				
				SET THIS_HOL_MINS = 0;
				
				SELECT ROUND(IF(A.hol_hours IS NULL,0,A.hol_hours) * 60,2) INTO THIS_HOL_MINS
				FROM att_hol_apply_day A
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt AND A.apply_id = i_applyid;

				#只有当哺乳假小时未被扣除时才进行计算，否则直接跳过
				IF THIS_MHM = 0 OR THIS_MHM IS NULL THEN
					SET THIS_MHM = THIS_HOL_MINS ;
					IF THIS_MHM <= THIS_LM THEN
						SET THIS_LM = THIS_LM - THIS_MHM;
					ELSEIF THIS_MHM > THIS_LM THEN
						SET THIS_EM = THIS_EM - (THIS_MHM - THIS_LM);
						IF THIS_EM < 0 THEN
							SET THIS_MHM = THIS_HOL_MINS + THIS_EM;
						END IF;
						SET THIS_LM = 0;
					END IF;
					IF THIS_LM IS NULL OR THIS_LM < 0 THEN SET THIS_LM = 0; END IF;
					IF THIS_EM IS NULL OR THIS_EM < 0 THEN SET THIS_EM = 0; END IF;

					SET THIS_DAYOFF = FN_ATT_GET_DAYOFF_STATUS(THIS_LM,THIS_EM,MY_ATTID);
					IF MY_BOSS_LEVEL IN (2,3) THEN
						SET THIS_LM = 0,THIS_EM = 0,THIS_DAYOFF=0,THIS_HOL_MINS=0;
					END IF;
					
					IF THIS_LM < 0 THEN SET THIS_LM = 0 ;END IF;
#select 9,bgdt,THIS_LM,THIS_EM,THIS_DAYOFF, THIS_HOL_MINS;
					UPDATE att_emp_detail A
					SET 
						late_mins = FN_ATT_GET_MINUNIT_MINS(THIS_LM,MY_ATTID) ,
						early_mins = FN_ATT_GET_MINUNIT_MINS(THIS_EM,MY_ATTID) ,
						A.milk_hol_mins = THIS_HOL_MINS,
						A.is_dayoff = THIS_DAYOFF
					WHERE A.emp_id = i_emp AND A.dt =  bgdt;
				END IF;
			END IF;
#<<<<<<<<<<<<<<<<<<<		请假校正结束
			#是否请假
			update att_emp_detail a left join att_hol_apply_day b on a.emp_id=b.emp_id and a.dt=b.hol_date
			set a.is_have_hol=1
			where b.hol_hours > 0 AND b.apply_id <> 0 and b.apply_id is not null and a.emp_id=emp and a.dt=bgdt and b.is_year_hol<>10;
			#是否加班
			update att_emp_detail a left join att_over_apply_day b on a.emp_id=b.emp_id and a.dt=b.work_day
			set a.is_have_over=1
			where b.work_hour > 0 and a.emp_id=emp and a.dt=bgdt;
					
			SET bgdt = DATE_ADD(bgdt,INTERVAL 1 DAY);
		END WHILE;
	END IF;
	
	
END;

