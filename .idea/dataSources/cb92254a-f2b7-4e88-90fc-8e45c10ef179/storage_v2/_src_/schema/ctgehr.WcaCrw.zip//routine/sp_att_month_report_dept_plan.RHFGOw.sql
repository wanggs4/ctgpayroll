create procedure SP_ATT_MONTH_REPORT_DEPT_PLAN(IN BGDT date)
  comment '月报部门维度统计分组'
  BEGIN
DECLARE CT,MXCT BIGINT UNSIGNED;
DECLARE MAX_DEPT_IN_GROUP,DEPT_NUM,MAX_EMP_IN_GROUP,THIS_EMP_IN_GROUP,EMP_IN_GROUP,GROUP_CODE BIGINT;
#每组最高人数上限
SET MAX_EMP_IN_GROUP = 20000;
SET MAX_DEPT_IN_GROUP = 2000;
#当前组人数
SET EMP_IN_GROUP = 0;

	TRUNCATE TABLE tmp_month_report_dept_plan;
	INSERT INTO tmp_month_report_dept_plan (CUST_ID,DEPT_ID,CNT)
	SELECT a.cust_id,b.dept_id,count(*) cnt
	FROM cust_info a 
		left join dept_info b on a.cust_id=b.cust_id 
		left join emp_base_info c on b.dept_id=c.dept_id 
		left join emp_post d on c.emp_id=d.emp_id
		left join cust_period_schedule e on a.cust_id=e.cust_id 
	where a.is_enable=1 and b.is_enable=1 and e.period_type=1 and c.is_delete=0 and c.emp_state is not null 
		and d.entry_date is not null and d.entry_date <= e.end_date and (d.leave_date is null or d.leave_date >= e.begin_date)
		and e.begin_date <= BGDT AND e.end_date >= BGDT
	group by b.dept_id ;
	
	SET GROUP_CODE = 1;
	SET DEPT_NUM = 0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_month_report_dept_plan;
	WHILE CT <= MXCT AND CT > 0 DO
		#当前组人数
		SET THIS_EMP_IN_GROUP = 0;
		SELECT A.cnt INTO THIS_EMP_IN_GROUP FROM tmp_month_report_dept_plan A WHERE A.id = CT;
		SET EMP_IN_GROUP = EMP_IN_GROUP + THIS_EMP_IN_GROUP;
		
		SET DEPT_NUM = DEPT_NUM + 1;
		IF DEPT_NUM >= MAX_DEPT_IN_GROUP THEN
			SET DEPT_NUM=0;
			set EMP_IN_GROUP = MAX_EMP_IN_GROUP + 1;
		END IF;
		IF EMP_IN_GROUP >= MAX_EMP_IN_GROUP THEN
			SET GROUP_CODE = GROUP_CODE + 1;
			SET EMP_IN_GROUP = 0;
		END IF;
		
		UPDATE tmp_month_report_dept_plan A SET A.`group`=GROUP_CODE WHERE ID=CT;
		SET CT = CT + 1;
	END WHILE;
END;

