create procedure SP_PAYROLL_GZ_TAX(IN  PAYVAL     decimal(13, 3), IN TAX_VERSION int, OUT NRATE decimal(13, 3),
                                   OUT NDEDUCTION decimal(13, 3), OUT RES decimal(13, 3))
  comment '税档定位'
  BEGIN


    
    IF PAYVAL <= 0 OR PAYVAL IS NULL THEN
      set NRATE = 0;
      set NDEDUCTION = 0;
      set res = 0;
    END IF;
    
    SELECT RATE,DEDUCTION INTO NRATE,NDEDUCTION
     FROM payroll_GZ_TAX 
     WHERE INCOME = (SELECT MAX(INCOME) INCOME
                         FROM payroll_GZ_TAX 
                        WHERE  INCOME < PAYVAL AND `VERSION` = TAX_VERSION)
				AND `VERSION` = TAX_VERSION;

    IF NRATE IS NULL THEN SET NRATE = 0; END IF;
    IF NDEDUCTION IS NULL THEN SET NDEDUCTION = 0; END IF;
    
    
    SET RES= PAYVAL * NRATE - NDEDUCTION;

END;

