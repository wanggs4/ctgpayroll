create procedure SP_EMP_MONTH_LIST_ADDTIONAL(IN MAINID bigint unsigned, IN COL_BG_NUM int)
  comment '为detai表追加新增的两个表内的数据 (emp_subsidy_project，log_emp_post_change)'
  BEGIN
DECLARE IS_HAVE_SUBSIDY,MY_SEQ,IS_HAVE_LIST,CT,MXCT,COL_CT,COL_MXCT,MY_EMPID,MY_CUSTID,MY_PERIOD_VERSION,EP_LOGID,ESP_LOGID BIGINT UNSIGNED;
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE EP_ENABLETIME,EP_CREATETIME DATETIME;
DECLARE BGDT,EDDT,ESP_ENABLETIME DATE;
DECLARE CMSQL_UPDATE,CMSQL_SET,SQL_UPDATE,SQL_SET,SQL_WHERE TEXT;
DECLARE MY_DESCOL,THIS_TBNAME,THIS_COLNAME,THIS_SHOWNAME,MY_DESTAB VARCHAR(50);
DECLARE THIS_VALUE DECIMAL(12,2);

	SELECT COUNT(*) INTO IS_HAVE_LIST FROM cust_period_emp_detail A WHERE A.main_id = MAINID;
	SET I_VERSION_CODE = UUID();
	IF IS_HAVE_LIST > 0 AND COL_BG_NUM IS NOT NULL AND COL_BG_NUM > 0 THEN
		
		SELECT A.cust_id,B.begin_date,B.end_date,A.emp_period_version 
			INTO MY_CUSTID,BGDT,EDDT,MY_PERIOD_VERSION
		FROM cust_period_emp_main A 
			LEFT JOIN cust_period_schedule B ON A.cust_id=B.cust_id AND A.emp_period_version=B.year_mon
		WHERE A.main_id=MAINID AND B.period_type=1;
		

		
		SET SQL_UPDATE = 'UPDATE cust_period_emp_detail LEFT JOIN cust_period_emp_detail_2 ON cust_period_emp_detail.main_id = cust_period_emp_detail_2.main_id AND cust_period_emp_detail.emp_id = cust_period_emp_detail_2.emp_id LEFT JOIN cust_period_emp_detail_3 ON cust_period_emp_detail_2.main_id = cust_period_emp_detail_3.main_id AND cust_period_emp_detail_2.emp_id = cust_period_emp_detail_3.emp_id LEFT JOIN cust_period_emp_detail_4 ON cust_period_emp_detail_3.main_id = cust_period_emp_detail_4.main_id AND cust_period_emp_detail_3.emp_id = cust_period_emp_detail_4.emp_id LEFT JOIN log_emp_post_change ON cust_period_emp_detail.emp_id = log_emp_post_change.emp_id ';
		SET SQL_SET = 'SET ';
		
		
		INSERT INTO tmp_period_emp_collumn_list (version_code,table_name,col_name,show_name)
		SELECT I_VERSION_CODE,a.table_name,a.col_name,a.show_name
		FROM set_show_cols a
		WHERE a.cust_id=MY_CUSTID AND a.is_show=1 
			AND a.table_name = 'emp_post'
			AND a.col_name IS NOT NULL AND a.col_name not in ('PRE_LEAVE_DATE','LEAVE_TYPE','LEAVE_REASON','LEAVE_DATE')
		ORDER BY seq_no ;
		
		INSERT INTO tmp_period_emp_collumn_list (version_code,table_name,col_name,show_name)
		SELECT I_VERSION_CODE,a.table_name,a.col_name,a.show_name
		FROM set_show_cols a
		WHERE a.cust_id=MY_CUSTID 
			AND a.table_name = 'emp_post'
			AND a.col_name = 'leave_type'
		ORDER BY seq_no ;
		
		INSERT INTO tmp_period_emp_collumn_list (version_code,table_name,col_name,show_name)
		SELECT I_VERSION_CODE,a.table_name,a.col_name,a.show_name
		FROM set_show_cols a
		WHERE a.cust_id=MY_CUSTID 
			AND a.table_name = 'emp_post_leave'
			AND a.col_name in ('PRE_LEAVE_DATE','LEAVE_TYPE','LEAVE_REASON','LEAVE_DATE')
		ORDER BY seq_no ;

		SET COL_CT = 0, COL_MXCT = 0;
		SELECT MIN(ID),MAX(ID) INTO COL_CT,COL_MXCT FROM tmp_period_emp_collumn_list WHERE VERSION_CODE=I_VERSION_CODE;
		SET MY_SEQ=COL_BG_NUM;
		WHILE COL_CT <= COL_MXCT AND COL_CT>0 AND MY_SEQ <= 600 DO
			SET THIS_TBNAME=NULL,THIS_COLNAME=NULL,THIS_SHOWNAME=NULL;
			SELECT A.col_name,A.show_name 
				INTO THIS_COLNAME,THIS_SHOWNAME 
			FROM tmp_period_emp_collumn_list A 
			WHERE A.id=COL_CT AND A.version_code=I_VERSION_CODE;
			
			IF THIS_COLNAME IS NOT NULL THEN
				SET THIS_TBNAME = 'log_emp_post_change';
				
				IF MY_SEQ BETWEEN 1 AND 9 THEN
					SET MY_DESCOL = CONCAT('COL_00',MY_SEQ);
				ELSEIF MY_SEQ BETWEEN 10 AND 99 THEN
					SET MY_DESCOL = CONCAT('COL_0',MY_SEQ);
				ELSEIF MY_SEQ >= 100 THEN
					SET MY_DESCOL = CONCAT('COL_',MY_SEQ);
				END IF;
				
				IF MY_SEQ BETWEEN 1 AND 150 THEN
					SET MY_DESTAB = 'cust_period_emp_detail';
				ELSEIF MY_SEQ BETWEEN 151 AND 300 THEN
					SET MY_DESTAB = 'cust_period_emp_detail_2';
				ELSEIF MY_SEQ BETWEEN 301 AND 450 THEN
					SET MY_DESTAB = 'cust_period_emp_detail_3';
				ELSEIF MY_SEQ BETWEEN 451 AND 600 THEN
					SET MY_DESTAB = 'cust_period_emp_detail_4';
				END IF;
				
				
				IF SQL_SET = 'SET ' THEN
					SET SQL_SET = CONCAT(SQL_SET,MY_DESTAB,'.',MY_DESCOL,'=',THIS_TBNAME,'.',THIS_COLNAME,' ');
				ELSE
					SET SQL_SET = CONCAT(SQL_SET,',',MY_DESTAB,'.',MY_DESCOL,'=',THIS_TBNAME,'.',THIS_COLNAME,' ');
				END IF;
				

				
				REPLACE INTO cust_period_emp_dict (main_id,cust_id,emp_period_version,ori_table_name,ori_col_name,show_name,des_tb_name,des_col_name,seq_num) 
					VALUES (MAINID,MY_CUSTID,MY_PERIOD_VERSION,'emp_post',THIS_COLNAME,THIS_SHOWNAME,MY_DESTAB,MY_DESCOL,MY_SEQ);

				SET MY_SEQ = MY_SEQ + 1;
				DELETE FROM tmp_period_emp_collumn_list WHERE id=COL_CT AND version_code=I_VERSION_CODE;
				
			END IF;
			
			SET COL_CT = COL_CT + 1;
		END WHILE;
		
		SET COL_BG_NUM = MY_SEQ;
		
		SET CMSQL_UPDATE = SQL_UPDATE;
		SET CMSQL_SET = SQL_SET;

		INSERT INTO tmp_emp_month_list (VERSION_CODE,EMP_ID)
			SELECT I_VERSION_CODE,EMP_ID FROM cust_period_emp_detail A WHERE A.main_id = MAINID;
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_emp_month_list WHERE VERSION_CODE=I_VERSION_CODE;
		WHILE CT <= MXCT AND CT > 0 DO
			SET SQL_UPDATE = CMSQL_UPDATE;
			SET SQL_SET = CMSQL_SET;
			SELECT EMP_ID INTO MY_EMPID FROM tmp_emp_month_list WHERE VERSION_CODE=I_VERSION_CODE AND ID = CT;
			IF MY_EMPID IS NOT NULL THEN
				
				SET EP_ENABLETIME=NULL,EP_CREATETIME=NULL,EP_LOGID=NULL,SQL_WHERE='',@SQL1='';
				
				SELECT MAX(A.enable_time)
					INTO EP_ENABLETIME
				FROM log_emp_post_change A
				WHERE A.emp_id=MY_EMPID AND A.enable_time <= CONCAT(EDDT,' 23:59:59') AND A.is_delete=0;
				
				SELECT MAX(A.create_time)
					INTO EP_CREATETIME
				FROM log_emp_post_change A 
				WHERE A.emp_id=MY_EMPID AND A.enable_time=EP_ENABLETIME AND A.is_delete=0;
				
				SELECT MAX(A.log_id)
					INTO EP_LOGID
				FROM log_emp_post_change A 
				WHERE A.emp_id=MY_EMPID AND A.enable_time=EP_ENABLETIME AND A.create_time=EP_CREATETIME AND A.is_delete=0;

			 	
			 	IF EP_LOGID IS NOT NULL THEN
			 		SET SQL_WHERE = CONCAT('WHERE cust_period_emp_detail.main_id = ',MAINID,' AND cust_period_emp_detail.EMP_ID = ',MY_EMPID,' AND log_emp_post_change.log_id=',EP_LOGID,';');
				ELSE
			 		SET SQL_WHERE = CONCAT('WHERE cust_period_emp_detail.main_id = ',MAINID,' AND cust_period_emp_detail.EMP_ID = ',MY_EMPID,' ;');
			 		SET SQL_SET = REPLACE(SQL_SET,'log_emp_post_change','emp_post');
			 		SET SQL_UPDATE = REPLACE(SQL_UPDATE,'log_emp_post_change','emp_post');
				END IF;
				SET @SQL1 = CONCAT(SQL_UPDATE,SQL_SET,SQL_WHERE);


			 	IF @SQL1 IS NOT NULL AND SQL_SET <> 'SET ' THEN
	 				PREPARE stmt1 FROM @SQL1;
					EXECUTE stmt1;
					DEALLOCATE PREPARE stmt1;
				END IF;

			END IF;
			SET CT = CT + 1;
		END WHILE;
		


#emp_subsidy_project		
		
		INSERT INTO tmp_period_emp_collumn_list (version_code,table_name,col_name,show_name)
		SELECT I_VERSION_CODE,a.table_name,a.col_name,a.show_name
		FROM set_show_cols a
		WHERE a.cust_id=MY_CUSTID AND a.is_show=1 
			AND a.table_name = 'emp_subsidy_project'
			AND a.col_name IS NOT NULL
		ORDER BY seq_no ;
		
		
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_emp_month_list WHERE VERSION_CODE=I_VERSION_CODE;
		WHILE CT <= MXCT AND CT > 0 DO
			SELECT EMP_ID INTO MY_EMPID FROM tmp_emp_month_list WHERE VERSION_CODE=I_VERSION_CODE AND ID = CT;
			IF MY_EMPID IS NOT NULL THEN
				SET SQL_SET = 'SET ';
				SET SQL_UPDATE = CONCAT('UPDATE cust_period_emp_detail left join cust_period_emp_detail_2 on cust_period_emp_detail.main_id=cust_period_emp_detail_2.main_id and cust_period_emp_detail.emp_id=cust_period_emp_detail_2.emp_id left join cust_period_emp_detail_3 on cust_period_emp_detail_2.main_id=cust_period_emp_detail_3.main_id and cust_period_emp_detail_2.emp_id=cust_period_emp_detail_3.emp_id left join cust_period_emp_detail_4 on cust_period_emp_detail_3.main_id=cust_period_emp_detail_4.main_id and cust_period_emp_detail_3.emp_id=cust_period_emp_detail_4.emp_id ');
				
				SET MY_SEQ = COL_BG_NUM;
				
				SET ESP_ENABLETIME=NULL,ESP_LOGID=NULL,@SQL1='';
				

				
				SET COL_CT = 0, COL_MXCT = 0;
				SELECT MIN(ID),MAX(ID) INTO COL_CT,COL_MXCT FROM tmp_period_emp_collumn_list WHERE VERSION_CODE=I_VERSION_CODE;

				IF COL_CT > 0 THEN 
					WHILE COL_CT <= COL_MXCT AND MY_SEQ <= 600 DO
						SET THIS_TBNAME=NULL,THIS_COLNAME=NULL,THIS_SHOWNAME=NULL,THIS_VALUE = 0;
						SELECT A.table_name,A.col_name,A.show_name 
							INTO THIS_TBNAME,THIS_COLNAME,THIS_SHOWNAME 
						FROM tmp_period_emp_collumn_list A 
						WHERE A.id=COL_CT AND A.version_code=I_VERSION_CODE;
						
						SELECT COUNT(*) INTO IS_HAVE_SUBSIDY 
						FROM emp_subsidy_project A
						WHERE A.EMP_ID=MY_EMPID AND A.ENABLE_START_DATE <= EDDT;
						
						IF THIS_COLNAME IS NOT NULL AND IS_HAVE_SUBSIDY > 0 THEN
							
							SELECT MAX(A.ENABLE_START_DATE)
								INTO ESP_ENABLETIME
							FROM emp_subsidy_project A
							WHERE A.EMP_ID=MY_EMPID AND A.ENABLE_START_DATE <= EDDT  AND A.COL_NAME=THIS_COLNAME AND A.IS_DELETE=0;
							
							SELECT MAX(A.ID)
								INTO ESP_LOGID
							FROM emp_subsidy_project A 
							WHERE A.emp_id=MY_EMPID AND A.ENABLE_START_DATE = ESP_ENABLETIME  AND A.COL_NAME=THIS_COLNAME AND A.IS_DELETE=0;
							
							
							SELECT IFNULL(A.MONEY,0)
								INTO THIS_VALUE
							FROM emp_subsidy_project A
							WHERE A.ID = ESP_LOGID;
							
							
							IF MY_SEQ BETWEEN 1 AND 9 THEN
								SET MY_DESCOL = CONCAT('COL_00',MY_SEQ);
							ELSEIF MY_SEQ BETWEEN 10 AND 99 THEN
								SET MY_DESCOL = CONCAT('COL_0',MY_SEQ);
							ELSEIF MY_SEQ >= 100 THEN
								SET MY_DESCOL = CONCAT('COL_',MY_SEQ);
							END IF;
							
							IF MY_SEQ BETWEEN 1 AND 150 THEN
								SET MY_DESTAB = 'cust_period_emp_detail';
							ELSEIF MY_SEQ BETWEEN 151 AND 300 THEN
								SET MY_DESTAB = 'cust_period_emp_detail_2';
							ELSEIF MY_SEQ BETWEEN 301 AND 450 THEN
								SET MY_DESTAB = 'cust_period_emp_detail_3';
							ELSEIF MY_SEQ BETWEEN 451 AND 600 THEN
								SET MY_DESTAB = 'cust_period_emp_detail_4';
							END IF;
				
							IF ESP_LOGID IS NOT NULL AND THIS_VALUE IS NOT NULL THEN
								
								IF SQL_SET = 'SET ' THEN
									SET SQL_SET = CONCAT(SQL_SET,MY_DESTAB,'.',MY_DESCOL,'=',THIS_VALUE,' ');
								ELSE
									SET SQL_SET = CONCAT(SQL_SET,',',MY_DESTAB,'.',MY_DESCOL,'=',THIS_VALUE,' ');
								END IF;

							END IF;
							
							
							REPLACE INTO cust_period_emp_dict (main_id,cust_id,emp_period_version,ori_table_name,ori_col_name,show_name,des_tb_name,des_col_name,seq_num) 
								VALUES (MAINID,MY_CUSTID,MY_PERIOD_VERSION,THIS_TBNAME,THIS_COLNAME,THIS_SHOWNAME,MY_DESTAB,MY_DESCOL,MY_SEQ);
			
							SET MY_SEQ = MY_SEQ + 1;							
						END IF;
						
						SET COL_CT = COL_CT + 1;
					END WHILE;
	
					SET SQL_WHERE = CONCAT('WHERE cust_period_emp_detail.MAIN_ID=',MAINID,' AND cust_period_emp_detail.EMP_ID = ',MY_EMPID,';');
					SET @SQL1 = CONCAT(SQL_UPDATE,SQL_SET,SQL_WHERE);



				 	IF @SQL1 IS NOT NULL AND SQL_SET <> 'SET ' THEN
		 				PREPARE stmt1 FROM @SQL1;
						EXECUTE stmt1;
						DEALLOCATE PREPARE stmt1;
					END IF;
				END IF;
			END IF;
			SET CT = CT + 1;
		END WHILE;
		

	END IF;
END;

