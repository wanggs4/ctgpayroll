create procedure SP_JAVA_EVENT_EVERYDAY_2059()
  comment '补跑由于中间库延迟导入的打卡相关日报'
  BEGIN
DECLARE TODAY DATE;
DECLARE CT,MXCT,MY_EMPID,MY_DT,IS_ARCHIVE BIGINT UNSIGNED;

	SET TODAY = DATE(NOW());
	
	TRUNCATE TABLE tmp_att_emp_log_left_2_days_tmp;
	REPLACE INTO tmp_att_emp_log_left_2_days_tmp SELECT DISTINCT A.EMP_ID,A.dt FROM tmp_att_emp_log_left_2_days A WHERE A.stat=0;
	
	REPLACE INTO tmp_att_emp_log_left_2_days_tmp (emp_id,dt)
	SELECT DISTINCT a.emp_id,IF(time(a.check_time)>='05:00:00',date(a.check_time),date_add(date(a.check_time),interval -1 day)) dt
	FROM att_emp_log a 
	WHERE date(a.create_time) = TODAY
	   AND if(time(a.check_time)>='05:00:00',date(a.check_time),date_add(date(a.check_time),interval -1 day)) 
	                <= date_add(TODAY,interval -3 day)
		AND a.is_middle_data = 1;
	
	TRUNCATE TABLE tmp_att_emp_log_left_2_days;
	INSERT INTO tmp_att_emp_log_left_2_days (emp_id,dt) SELECT emp_id,dt FROM tmp_att_emp_log_left_2_days_tmp;
	TRUNCATE TABLE tmp_att_emp_log_left_2_days_tmp;

	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_att_emp_log_left_2_days A;
		
	WHILE CT <= MXCT AND CT > 0 AND CT IS NOT NULL AND MXCT IS NOT NULL DO
		SET MY_EMPID=NULL,MY_DT=NULL;
		SELECT A.emp_id,A.dt
			INTO MY_EMPID,MY_DT
		FROM tmp_att_emp_log_left_2_days A
		WHERE A.id=CT ;
		
		SET IS_ARCHIVE = NULL;
		
		SELECT A.archive_state INTO IS_ARCHIVE
		FROM att_st_month A
		WHERE A.cust_id= 2162554862743552 AND A.comp_start_time <= MY_DT AND A.comp_end_time >= MY_DT LIMIT 1;
		
		IF (IS_ARCHIVE IS NULL OR IS_ARCHIVE = 0) AND MY_EMPID IS NOT NULL THEN
			CALL SP_ATT_DAILY_CHECK(MY_DT,MY_DT,NULL,NULL,MY_EMPID,NULL);
			CALL SP_ATT_DAILY_OVER(MY_DT,MY_DT,NULL,NULL,MY_EMPID,NULL);
			CALL SP_ATT_DAILY_OVER_WITH_REST(MY_DT,MY_DT,NULL,MY_EMPID);
			UPDATE tmp_att_emp_log_left_2_days A SET A.stat=1 WHERE A.id=CT;
		END IF;
		SET CT = CT + 1;
	END WHILE;
END;

