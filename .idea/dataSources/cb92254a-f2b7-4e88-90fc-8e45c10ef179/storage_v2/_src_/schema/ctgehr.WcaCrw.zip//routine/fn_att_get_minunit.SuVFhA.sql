create function FN_ATT_GET_MINUNIT(DEPT bigint unsigned)
  returns int
  comment '得到最小单位值'
  BEGIN
DECLARE MY_MINUNIT,IS_HAVE_ATT,IS_HAVE_DEPT INT;
SET MY_MINUNIT = 99;
	SELECT COUNT(*) INTO IS_HAVE_DEPT FROM DEPT_INFO WHERE DEPT_ID=DEPT AND IS_ENABLE=1;
	IF IS_HAVE_DEPT > 0 THEN
		SELECT COUNT(*) INTO IS_HAVE_ATT 
		FROM att_rel_schema_dept a left join  att_set_schema_new b on a.schema_id=b.att_id
		WHERE a.dept_id=DEPT AND b.is_delete=0 and b.`status`=1 ;
		
		IF IS_HAVE_ATT > 0 THEN
			SELECT b.le_fine_compute_unit
				INTO MY_MINUNIT
			FROM att_rel_schema_dept a left join  att_set_schema_new b on a.schema_id=b.att_id
			WHERE a.dept_id=DEPT AND b.is_delete=0 and b.`status`=1 LIMIT 1;
			
			IF MY_MINUNIT IS NULL THEN SET MY_MINUNIT = 99 ; END IF;
		END IF;
	END IF;
RETURN MY_MINUNIT;
END;

