create procedure SP_ATT_MONTH_REPORT_ICSS_IMPORT(IN MY_STID bigint unsigned, IN EMPID bigint unsigned)
  comment '手工考勤月报改动之后的池子修改'
  BEGIN
DECLARE IS_HAVE_STID,YEAR_CT,YEAR_MXCT,ORI_YEAR_MXCT,IS_HAVE_FUTURE,IS_HAVE_CREDIT INT;
DECLARE CT,MXCT,MY_EMPID BIGINT UNSIGNED;
DECLARE BGDT,EDDT DATE;
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE MY_RESTDOHAVE,MY_RESTDOUSE,ORI_THISRESTHAVE,ORI_THISRESTUSE,ORI_THISRESTLEFT DECIMAL(12,2);
DECLARE MY_YEARDOUSE,ORI_THISYEARHAVE,ORI_THISYEARUSE,ORI_THISYEARLEFT,MY_THIS_DOUSE,MY_THIS_DOHAVE,ORI_CREDITHAVE,ORI_CREDITUSE,ORI_CREDITLEFT DECIMAL(15,5);

	SELECT A.comp_start_time,A.comp_end_time
		INTO BGDT,EDDT
	FROM att_st_month A 
	WHERE A.st_id=MY_STID;
	
	SET I_VERSION_CODE = UUID();
	
	IF EMPID IS NOT NULL THEN
		INSERT INTO tmp_att_manual_import_list (version_code,emp_id,resthave,restuse,yearuse)
			SELECT I_VERSION_CODE,A.emp_id,IFNULL(A.byxzbxxs,0),IFNULL(A.TYPE0001,0),IFNULL(A.TYPE0002,0)
			FROM att_st_month_quick_view_icss_manual_import A
			WHERE A.st_id=MY_STID AND A.EMP_ID=EMPID AND A.is_enable=1;
	ELSE
		INSERT INTO tmp_att_manual_import_list (version_code,emp_id,resthave,restuse,yearuse)
			SELECT I_VERSION_CODE,A.emp_id,IFNULL(A.byxzbxxs,0),IFNULL(A.TYPE0001,0),IFNULL(A.TYPE0002,0)
			FROM att_st_month_quick_view_icss_manual_import A
			WHERE A.st_id=MY_STID AND A.is_enable=1;
	END IF;
	
	SET CT = 0, MXCT = 0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_att_manual_import_list A WHERE A.version_code=I_VERSION_CODE;

	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_EMPID=NULL,MY_RESTDOHAVE=0,MY_RESTDOUSE=0,MY_YEARDOUSE=0;

		SELECT A.emp_id,IFNULL(A.resthave,0),IFNULL(A.restuse,0),IFNULL(A.yearuse,0)
			INTO MY_EMPID,MY_RESTDOHAVE,MY_RESTDOUSE,MY_YEARDOUSE
		FROM tmp_att_manual_import_list A
		WHERE A.id=CT AND A.version_code=I_VERSION_CODE;

		IF MY_EMPID IS NOT NULL THEN
			SET ORI_THISYEARHAVE=0,ORI_THISYEARUSE=0,ORI_THISYEARLEFT=0;
		
		#调休部分计算
			#删掉以往的手动考勤标志
			DELETE A.* 
			FROM att_st_icss_pool_log A
			WHERE A.emp_id=MY_EMPID AND A.apply_id=1 AND A.dt BETWEEN EDDT AND DATE(NOW()) AND A.pool_type=2 AND A.op_type IN (1,2);
			
			SET YEAR_CT = 0, YEAR_MXCT = 0;
			SELECT MIN(A.this_year),MAX(A.this_year) 
				INTO YEAR_CT,YEAR_MXCT
			FROM att_st_month_quick_view_icss_manual_pool A 
			WHERE A.st_id=MY_STID AND A.emp_id=MY_EMPID AND A.pool_type=2;


			WHILE YEAR_CT <= YEAR_MXCT AND (MY_RESTDOUSE > 0 OR MY_RESTDOHAVE > 0) DO
				SET ORI_THISRESTHAVE=0,ORI_THISRESTUSE=0,ORI_THISRESTLEFT=0;
				SET MY_THIS_DOUSE = 0,MY_THIS_DOHAVE=0;
				
				SELECT A.this_year_have,A.this_year_use,A.this_year_left
					INTO ORI_THISRESTHAVE,ORI_THISRESTUSE,ORI_THISRESTLEFT
				FROM att_st_month_quick_view_icss_manual_pool A 
				WHERE A.st_id=MY_STID AND A.emp_id=MY_EMPID AND A.pool_type=2 AND A.this_year=YEAR_CT;
				
#SELECT MY_RESTDOUSE;
				IF ORI_THISRESTLEFT IS NOT NULL THEN
					#够扣
					IF ORI_THISRESTLEFT >= MY_RESTDOUSE THEN
						#修改池子表-调休
						#当年
						IF YEAR_CT = YEAR(BGDT) THEN
							SET MY_THIS_DOUSE = MY_RESTDOUSE;
							SET MY_THIS_DOHAVE = MY_RESTDOHAVE;
						#往年 或 最后一年且非当年
						ELSE
							SET MY_THIS_DOUSE = MY_RESTDOUSE;
							SET MY_THIS_DOHAVE = 0;
						END IF;
					#不够扣
					ELSE
		#修改池子表-调休
						#当年且最后一年
						IF YEAR_CT = YEAR(BGDT) AND YEAR_CT = YEAR_MXCT THEN				
							SET MY_THIS_DOUSE = MY_RESTDOUSE;
							SET MY_THIS_DOHAVE = MY_RESTDOHAVE;
						#当年但非最后一年
						ELSEIF YEAR_CT = YEAR(BGDT) AND YEAR_CT = YEAR_MXCT THEN
							SET MY_THIS_DOUSE = ORI_THISRESTLEFT;					
							SET MY_THIS_DOHAVE = MY_RESTDOHAVE;
						#非当年最后一年
						ELSEIF YEAR_CT <> YEAR(BGDT) AND YEAR_CT = YEAR_MXCT THEN
							SET MY_THIS_DOUSE = MY_RESTDOUSE;
							SET MY_THIS_DOHAVE = 0;
						#往年
						ELSE
							SET MY_THIS_DOUSE = ORI_THISRESTLEFT;					
							SET MY_THIS_DOHAVE = 0;
						END IF;	
					END IF;
					
					UPDATE att_hol_rest A 
					SET A.this_year_have = ORI_THISRESTHAVE + MY_THIS_DOHAVE,
						A.this_year_use = ORI_THISRESTUSE + MY_THIS_DOUSE,
						A.this_year_left = ORI_THISRESTLEFT + MY_THIS_DOHAVE - MY_THIS_DOUSE
					WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR_CT AND A.is_delete=0;
					
					#写入本次改动
					INSERT INTO att_st_icss_pool_log (emp_id,apply_id,dt,pool_type,which_year,op_type,do_value)
					VALUES (MY_EMPID,1,EDDT,2,YEAR_CT,1,MY_THIS_DOHAVE);
					
					INSERT INTO att_st_icss_pool_log (emp_id,apply_id,dt,pool_type,which_year,op_type,do_value)
					VALUES (MY_EMPID,1,EDDT,2,YEAR_CT,2,MY_THIS_DOUSE);
				
					#总量归零
					SET MY_RESTDOUSE = MY_RESTDOUSE - MY_THIS_DOUSE;
					SET MY_RESTDOHAVE = MY_RESTDOHAVE - MY_THIS_DOHAVE;
					
				END IF;
				SET YEAR_CT = YEAR_CT + 1 ;
			END WHILE;
		
		
		
			
			
			
		#年假部分计算
			#删掉以往的手动考勤标志
			DELETE A.* 
			FROM att_st_icss_pool_log A
			WHERE A.emp_id=MY_EMPID AND A.apply_id=1 AND A.dt BETWEEN EDDT AND DATE(NOW()) AND A.pool_type=1 AND A.op_type IN (2);

			SET YEAR_CT = 0, YEAR_MXCT = 0;
			SELECT MIN(A.this_year),MAX(A.this_year) 
				INTO YEAR_CT,YEAR_MXCT
			FROM att_st_month_quick_view_icss_manual_pool A 
			WHERE A.st_id=MY_STID AND A.emp_id=MY_EMPID AND A.pool_type=1;
			
			SET ORI_YEAR_MXCT = YEAR_MXCT;
			
			SELECT A.this_year_have,A.this_year_use,A.this_year_left
				INTO ORI_CREDITHAVE,ORI_CREDITUSE,ORI_CREDITLEFT
			FROM att_st_month_quick_view_icss_manual_pool A 
			WHERE A.st_id=MY_STID AND A.emp_id=MY_EMPID AND A.pool_type=3 AND A.this_year=YEAR(BGDT);
			
			#是否有未来
			IF YEAR_MXCT > YEAR(BGDT) THEN
				SET IS_HAVE_FUTURE = 1;
				SET YEAR_MXCT = YEAR(BGDT);
			ELSE
				SET IS_HAVE_FUTURE = 0;
			END IF;
			
			#是否有预支
			IF ORI_CREDITLEFT IS NOT NULL AND ORI_CREDITLEFT > 0 THEN
				SET IS_HAVE_CREDIT = 1;
			ELSE
				SET IS_HAVE_CREDIT = 0;
			END IF;
			
			#第一次循环，最多只循环到当年池
			SET  MY_THIS_DOUSE = MY_YEARDOUSE;

			WHILE YEAR_CT <= YEAR_MXCT AND MY_YEARDOUSE >= 0  DO
				SET ORI_THISYEARHAVE=0,ORI_THISYEARUSE=0,ORI_THISYEARLEFT=0;
				SET MY_THIS_DOUSE = 0,MY_THIS_DOHAVE=0;
				SELECT A.this_year_have,A.this_year_use,A.this_year_left
					INTO ORI_THISYEARHAVE,ORI_THISYEARUSE,ORI_THISYEARLEFT
				FROM att_st_month_quick_view_icss_manual_pool A 
				WHERE A.st_id=MY_STID AND A.emp_id=MY_EMPID AND A.pool_type=1 AND A.this_year = YEAR_CT;
				
				IF ORI_THISYEARLEFT IS NOT NULL THEN
					#够扣
					IF ORI_THISYEARLEFT >= MY_YEARDOUSE THEN
						SET MY_THIS_DOUSE = MY_YEARDOUSE;
					#不够扣
					ELSE
						#当年
						IF YEAR_CT = YEAR_MXCT THEN
							#有预支或有未来池的情况下，不能无脑扣
							IF IS_HAVE_FUTURE = 1 OR IS_HAVE_CREDIT = 1 THEN
								SET MY_THIS_DOUSE = ORI_THISYEARLEFT;
							#无预支和未来池，直接扣
							ELSE
								SET MY_THIS_DOUSE = MY_YEARDOUSE;								
							END IF;
						#往年
						ELSE
							SET MY_THIS_DOUSE = ORI_THISYEARLEFT;	
						END IF;
					END IF;
					
					#修改池子表-年假
					UPDATE att_hol_year A 
					SET A.this_year_have = ORI_THISYEARHAVE,
						A.this_year_use = ORI_THISYEARUSE + MY_THIS_DOUSE,
						A.this_year_left = ORI_THISYEARLEFT - MY_THIS_DOUSE
					WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR_CT AND A.is_delete=0;
		
					#总量递减
					SET MY_YEARDOUSE = MY_YEARDOUSE - MY_THIS_DOUSE;
						
					#写入本次改动
					INSERT INTO att_st_icss_pool_log (emp_id,apply_id,dt,pool_type,which_year,op_type,do_value)
					VALUES (MY_EMPID,1,EDDT,1,YEAR_CT,2,MY_THIS_DOUSE);
					
				END IF;
				SET YEAR_CT = YEAR_CT + 1;
			END WHILE;
			
			#第二轮扣减，看看MY_YEARDOUSE如有剩余，去预支里扣
			IF IS_HAVE_CREDIT = 1 AND MY_YEARDOUSE > 0 THEN
				SET MY_THIS_DOUSE = 0,MY_THIS_DOHAVE=0;
				#够扣
				IF ORI_CREDITLEFT >= MY_YEARDOUSE THEN
					SET MY_THIS_DOUSE = MY_YEARDOUSE;
				#不够扣
				ELSE
					IF IS_HAVE_FUTURE = 1 THEN
						SET MY_THIS_DOUSE = ORI_CREDITLEFT;
					ELSE
						SET MY_THIS_DOUSE = MY_YEARDOUSE;
					END IF;
				END IF;
				
				#修改池子表-年假
				UPDATE att_hol_credit_year A 
				SET A.this_year_have = ORI_CREDITHAVE,
					A.this_year_use = ORI_CREDITUSE + MY_THIS_DOUSE,
					A.this_year_left = ORI_CREDITLEFT - MY_THIS_DOUSE
				WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR(BGDT) AND A.is_delete=0;
	
				#总量递减
				SET MY_YEARDOUSE = MY_YEARDOUSE - MY_THIS_DOUSE;
					
				IF MY_THIS_DOUSE <> 0 THEN
					#写入本次改动
					INSERT INTO att_st_icss_pool_log (emp_id,apply_id,dt,pool_type,which_year,op_type,do_value)
					VALUES (MY_EMPID,1,EDDT,3,YEAR(BGDT),2,MY_THIS_DOUSE);
				END IF;
			END IF;
			
			#第三轮，如有未来池，并且MY_YEARDOUSE还有剩余，去未来池扣减
			IF IS_HAVE_FUTURE = 1 AND MY_YEARDOUSE > 0 THEN
				SET YEAR_MXCT = ORI_YEAR_MXCT;
				WHILE YEAR_CT <= YEAR_MXCT AND MY_YEARDOUSE > 0  DO
					SET ORI_THISYEARHAVE=0,ORI_THISYEARUSE=0,ORI_THISYEARLEFT=0;
					
					SELECT A.this_year_have,A.this_year_use,A.this_year_left
						INTO ORI_THISYEARHAVE,ORI_THISYEARUSE,ORI_THISYEARLEFT
					FROM att_st_month_quick_view_icss_manual_pool A 
					WHERE A.st_id=MY_STID AND A.emp_id=MY_EMPID AND A.pool_type=1 AND A.this_year = YEAR_CT;
					
					IF ORI_THISYEARLEFT IS NOT NULL THEN
						SET MY_THIS_DOUSE = 0,MY_THIS_DOHAVE=0;
					#够扣
						IF ORI_THISYEARLEFT >= MY_YEARDOUSE THEN
							SET MY_THIS_DOUSE = MY_YEARDOUSE;
						#不够扣
						ELSE
							#最后年
							IF YEAR_CT = YEAR_MXCT THEN
								SET MY_THIS_DOUSE = MY_YEARDOUSE;								
							#其余
							ELSE
								SET MY_THIS_DOUSE = ORI_THISYEARLEFT;	
							END IF;
						END IF;
						
						#修改池子表-年假
						UPDATE att_hol_year A 
						SET A.this_year_have = ORI_THISYEARHAVE,
							A.this_year_use = ORI_THISYEARUSE + MY_THIS_DOUSE,
							A.this_year_left = ORI_THISYEARLEFT - MY_THIS_DOUSE
						WHERE A.emp_id=MY_EMPID AND A.this_year=YEAR_CT AND A.is_delete=0;
			
						#总量递减
						SET MY_YEARDOUSE = MY_YEARDOUSE - MY_THIS_DOUSE;
					
						IF MY_THIS_DOUSE <> 0 THEN
							#写入本次改动
							INSERT INTO att_st_icss_pool_log (emp_id,apply_id,dt,pool_type,which_year,op_type,do_value)
							VALUES (MY_EMPID,1,EDDT1,YEAR_CT,2,MY_THIS_DOUSE);
						END IF;
					END IF;
					SET YEAR_CT = YEAR_CT + 1;
				END WHILE;
			END IF;
			CALL SP_ATT_MONTH_REPORT_ST_POOL(MY_STID,MY_EMPID);
		END IF;
		SET CT = CT + 1;
	END WHILE;
END;

