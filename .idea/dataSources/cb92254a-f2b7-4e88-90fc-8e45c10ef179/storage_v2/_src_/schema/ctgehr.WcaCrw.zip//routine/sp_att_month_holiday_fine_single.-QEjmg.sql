create procedure SP_ATT_MONTH_HOLIDAY_FINE_SINGLE(IN bgdt date, IN eddt date, IN emp bigint unsigned)
  comment '日报钱数计算'
  BEGIN
#PART 1  初始化	
DECLARE MY_SONVER,h_is_sala_compute,is_have_hol,stat,ct,mxct,dttype,i_dttype,t_dttype,i_isdoff,is_have_att,app_cnt,app_mxcnt int;
DECLARE ATTID,i_emp,i_deptid,i_custid,i_hol_id, i_applyid bigint UNSIGNED;
DECLARE init_bgdt,i_lvdate,i_entry_date date;
DECLARE i_lm,i_em,MY_SALA_PROG,h_hol_sala,i_hol_hours,hpay,i_daily_hour,i_days DECIMAL(12,2);
DECLARE i_version_code VARCHAR(50);
DECLARE THIS_HOL_TYPE,i_att_rule,a_le_fine,a_le_fine_single_com,a_dayoff_fine,a_dayoff_fine_single_com INT;
DECLARE MY_DAYOFF_FINE,MY_LATE_FINE,MY_EARLY_FINE,a_le_fine_single_money,a_le_fine_compute_factor,a_dayoff_half_fine_single_money,a_dayoff_fine_single_money,a_dayoff_fine_compute_factor	DECIMAL(12,2);
DECLARE ATTID_STR TEXT;
DECLARE MY_HOL_LIST,THIS_HOL VARCHAR(200);
	
	SET i_version_code = UUID();
	SET init_bgdt = bgdt;

		#得到员工和相关的部门、企业id
		select emp_id,dept_id,cust_id into i_emp,i_deptid,i_custid from emp_base_info where emp_id=emp;
		IF i_emp IS NOT NULL THEN
			#开始循环日期
			WHILE (bgdt<=eddt) DO														#LOOP2 bgdt
				#初始化循环变量
				SET is_have_att = NULL;
				SET is_have_hol = NULL;
				#有没有考勤信息
				select count(*) into is_have_att from att_emp_detail where emp_id=i_emp and dt=bgdt;
				#有没有请假信息
				select count(*) into is_have_hol from att_hol_apply_day where emp_id=i_emp and hol_date=bgdt;

	#********3 计算请假
				IF is_have_hol>0 THEN
					CALL SP_DPT_GET_SETTINGID(i_emp,bgdt,1,ATTID_STR);
					SET ATTID = CAST(ATTID_STR AS UNSIGNED);

					
					#把当天所有的apply_id写入临时表
					INSERT INTO TMP_APPLY_ID_DP (version_code,APPLY_ID) SELECT DISTINCT i_version_code,APPLY_ID FROM att_hol_apply_day WHERE emp_id = i_emp and hol_date = bgdt;
					SET app_cnt = 0;
					SET app_mxcnt = 0;
					SELECT MIN(ID),MAX(ID) INTO app_cnt,app_mxcnt FROM TMP_APPLY_ID_DP  where version_code = i_version_code;
					WHILE (app_cnt<=app_mxcnt) DO	#遍历每个apply_id
						#初始化循环变量
						SET i_applyid = NULL;
						SET MY_HOL_LIST =NULL;
						#得到apply_id
						SELECT APPLY_ID INTO i_applyid FROM TMP_APPLY_ID_DP WHERE ID = app_cnt and version_code = i_version_code;

						select group_concat(concat(a.hol_id,':',a.son_ver)) into MY_HOL_LIST
						from att_hol_apply_day a 
						WHERE emp_id = i_emp and hol_date = bgdt AND apply_id=i_applyid;
						
						SET MY_HOL_LIST = CONCAT(MY_HOL_LIST,',');
						
						WHILE LOCATE(',',MY_HOL_LIST) <= LENGTH(MY_HOL_LIST) AND LOCATE(',',MY_HOL_LIST) > 2 DO
							SET i_hol_hours = NULL,THIS_HOL_TYPE=NULL;
							SET h_is_sala_compute = NULL;
							SET h_hol_sala = NULL;
							SET MY_SALA_PROG = NULL;
							SET i_days = NULL;
							SET i_daily_hour = NULL;
							SET i_hol_hours = NULL;
							SET h_hol_sala = NULL;

							SET THIS_HOL =NULL,i_hol_hours=NULL,i_hol_id=NULL,MY_SONVER=NULL,i_dttype=NULL;
							SET THIS_HOL = CONCAT(LEFT(MY_HOL_LIST,LOCATE(',',MY_HOL_LIST)-1),':');
							SET i_hol_id = LEFT(THIS_HOL,LOCATE(':',THIS_HOL)-1);
							SET THIS_HOL = RIGHT(THIS_HOL,LENGTH(THIS_HOL)-LOCATE(':',THIS_HOL));
							SET MY_SONVER = LEFT(THIS_HOL,LOCATE(':',THIS_HOL)-1);
							
							select a.is_year_hol INTO THIS_HOL_TYPE from att_set_holiday_main a where a.hol_id=i_hol_id;
							
							
							IF THIS_HOL_TYPE NOT IN (10,11,12,13) THEN
								#1	得到当天请假信息
								SELECT sum(hol_hours),hol_id,SON_VER,date_type INTO i_hol_hours,i_hol_id,MY_SONVER,i_dttype
								FROM att_hol_apply_day a
								WHERE emp_id = i_emp and hol_date = bgdt AND apply_id=i_applyid AND a.hol_id = i_hol_id and a.son_ver=MY_SONVER;
								
								set h_is_sala_compute=null,h_hol_sala=null;
								#型取得 h_is_sala_compute，hol_sala_rate，h_sala_prog
								SELECT is_sala_compute,
										hol_sala
								INTO	h_is_sala_compute,				#是否计算薪酬（0否 1是）
										h_hol_sala
								FROM att_set_holiday a
								WHERE hol_id= i_hol_id and a.son_ver=MY_SONVER;										
							
								IF h_is_sala_compute=1 THEN     #如果计算薪酬
									/*
									请假扣薪金额计算方法：
										扣薪金额 = 薪酬项目/该月工作日/每日工作时数*请假时数*工资比例
										hpay = MY_SALA_PROG/i_days/i_daily_hour*i_hol_hours*h_hol_sala
									*/
		
									#1 得到薪酬项目值MY_SALA_PROG
									CALL SP_ATT_GET_SALA_PROG(i_emp,bgdt,5,i_hol_id,MY_SONVER,MY_SALA_PROG);
									#2 得到本月工作天数 i_days
									SET i_days = FN_ATT_GET_WORKDAYS(init_bgdt,eddt,i_emp,1);
									#3 得到一天工作时长 
									SELECT ATT_RULE INTO i_att_rule FROM att_emp_detail A WHERE A.emp_id = i_emp AND dt = bgdt;
									IF i_att_rule > 0 AND i_att_rule IS NOT NULL THEN
										IF i_att_rule = 1 THEN
											#计算一天工作时长
											SET i_daily_hour = FN_ATT_GET_WORKHOURS(ATTID);
										ELSEIF i_att_rule = 3 THEN
											SET i_daily_hour = FN_ATT_GET_ARR_WORKHOURS(i_emp,bgdt);
										END IF;
										#计算出结果
										SET hpay = MY_SALA_PROG/i_days/i_daily_hour*i_hol_hours*h_hol_sala/100;
									ELSE
										SET hpay=0;
									END IF;
								ELSE
									SET hpay=0;
								END IF;
		
								UPDATE att_hol_apply_day SET pay_money= hpay WHERE emp_id = i_emp and hol_date = bgdt AND apply_id=i_applyid and hol_id=i_hol_id and is_delete=0;
							END IF;
							SET MY_HOL_LIST = RIGHT(MY_HOL_LIST,LENGTH(MY_HOL_LIST)-LOCATE(',',MY_HOL_LIST));
						END WHILE;
							
						DELETE FROM TMP_APPLY_ID_DP WHERE ID = app_cnt and version_code = i_version_code;

						SET app_cnt = app_cnt + 1;
					END WHILE;
				END IF;
				#如果有离职时间，并且当天是离职日期的话，那么循环到此结束；如果没有离职时间或者当天不是离职那天，bgdt继续递增。
				IF (i_lvdate = bgdt) THEN
					SET bgdt = date_add(eddt,interval 1 day);
				ELSE
					SET bgdt = date_add(bgdt,interval 1 day);
				END IF;	
			END WHILE;																		#LOOP2 bgdt
		END IF;
END;

