create procedure SP_PAYROLL_FML_VIP_XHT(IN key_word varchar(50), IN i_emp bigint unsigned, IN prid bigint unsigned,
                                        IN setid    bigint unsigned, OUT res decimal(12, 2))
  comment '新恒泰薪酬计算'
  BEGIN
DECLARE MY_ATT_RULE,MY_ARCH_ID,TAX_VERSION,MY_DEPT_ID BIGINT;
DECLARE MY_ENTRY_DATE,MY_LEAVE_DATE,MY_BG_TIME,MY_ED_TIME DATE;
DECLARE MY_GZZE,MY_SQTS,MY_SALARY,MY_YCQTS, MY_FDJRTS, MY_BJTS, MY_SJTS, MY_KGTS, MY_SJCQTS DECIMAL(12,2);
	IF key_word IS NOT NULL AND i_emp IS NOT NULL AND prid IS NOT NULL AND setid IS NOT NULL THEN 
		SELECT A.arch_id,left(A.sala_ym,4) INTO MY_ARCH_ID,TAX_VERSION
		FROM payroll_sala_settings A
		WHERE A.set_id = setid;
		#归档id非空时
		IF MY_ARCH_ID IS NOT NULL THEN	
			SELECT B.comp_start_time,B.comp_end_time INTO MY_BG_TIME,MY_ED_TIME
			FROM att_st_month_arch B
			WHERE B.arch_id = MY_ARCH_ID;
			CASE key_word
			#工作日加班时长			XHT_WORKDAY_OV	prjbsc
			WHEN 'XHT_WORKDAY_OVER' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='prjbsc';
			#周末加班时长				XHT_WEEKEND_OVER	gxjbsc
			WHEN 'XHT_WEEKEND_OVER' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='gxjbsc';
			#法定节假日加班时长		XHT_HOLIDAY_OVER	jrjbsc
			WHEN 'XHT_HOLIDAY_OVER' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='jrjbsc';
			#病假天数						XHT_BJTS	type0003
			WHEN 'XHT_BJTS' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='type0003';
			#事假天数					XHT_SJTS	type0008
			WHEN 'XHT_SJTS' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='type0008';
			#旷工天数					XHT_KGTS	kg
			WHEN 'XHT_KGTS' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='kg';
			#迟到/早退（次数）			XHT_CDZT		cdcs+ztcs
			WHEN 'XHT_CDZT' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='cdcs';
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) + res INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='ztcs';
			#带薪假天数				XHT_DXJTS
			WHEN 'XHT_DXJTS' THEN
				#应出勤天数+法定节假日天数-病假天数-事假天数-矿工天数-实际出勤天数（包括出差）
				#应出勤天数
				SELECT IF(BZ19 IS NULL,0,BZ19) INTO MY_YCQTS FROM payroll_bz_gz A WHERE A.id = prid;
				#法定节假日
				SELECT COUNT(*) INTO MY_FDJRTS FROM dict_hol_date A WHERE A.dt  BETWEEN MY_BG_TIME AND MY_ED_TIME AND A.date_type=3;
				#病假天数
				SELECT IF(bz5 IS NULL,0,bz5) INTO MY_BJTS FROM payroll_bz_gz A WHERE A.id = prid;
				#事假天数
				SELECT IF(bz6 IS NULL,0,bz6) INTO MY_SJTS FROM payroll_bz_gz A WHERE A.id = prid;
				#矿工天数
				SELECT IF(bz7 IS NULL,0,bz7) INTO MY_KGTS FROM payroll_bz_gz A WHERE A.id = prid;
				#实际出勤天数
				SELECT IF(bz20 IS NULL,0,bz20) INTO MY_SJCQTS FROM payroll_bz_gz A WHERE A.id = prid;
				#计算结果
				SET res = MY_YCQTS + MY_FDJRTS - MY_BJTS - MY_SJTS - MY_KGTS - MY_SJCQTS;
			
			#扣个税						XHT_KGS
			WHEN 'XHT_KGS' THEN
				SELECT bz13 INTO MY_SALARY FROM payroll_bz_gz A WHERE A.id = prid;
				
				IF MY_SALARY IS NULL THEN 
					SET MY_SALARY = 0 ; 
				END IF;
				
				IF MY_SALARY >= 5000 THEN
					CALL SP_PAYROLL_GZ_TAX(MY_SALARY-5000,TAX_VERSION,@NRATE,@NDEDUCTION,res);
				ELSE
					SET res = 0;
				END IF;
				
			#应出勤天数
			WHEN 'XHT_YCQTS' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='ycqts';
			#实勤天数	sjcqts
			WHEN 'XHT_SJCQTS' THEN
				SELECT ROUND(IF(A.st_value IS NULL,0,A.st_value),2) INTO res FROM att_st_month_arch_items A
				WHERE A.arch_id=MY_ARCH_ID AND A.emp_id=i_emp AND A.st_key ='sjcqts';

#				SELECT ROUND(SUM(IF(A.hol_hours IS NULL,0,A.hol_hours))/FN_ATT_GET_WORKHOURS(MY_DEPT_ID),2) + res INTO res 
#				FROM att_hol_apply_day A WHERE A.hol_id = 1042588420784128 AND A.emp_id=i_emp AND A.hol_date BETWEEN MY_BG_TIME AND MY_ED_TIME;
			#未出勤扣款
			WHEN 'XHT_WCQKK' THEN
				#if(入职日期=当前年and当前月.or.离职日期=当前年and当前月,工资总额/26*(26-实勤天数),0)
				SELECT ENTRY_DATE,LEAVE_DATE INTO MY_ENTRY_DATE,MY_LEAVE_DATE FROM emp_post WHERE EMP_ID=i_emp;
				IF (MY_ENTRY_DATE IS NOT NULL AND MY_ENTRY_DATE >= MY_BG_TIME AND MY_ENTRY_DATE<=MY_ED_TIME) OR (MY_LEAVE_DATE IS NOT NULL AND MY_LEAVE_DATE >= MY_BG_TIME AND MY_LEAVE_DATE<=MY_ED_TIME) THEN
					SELECT IFNULL(bz4,0),IFNULL(bz20,0) INTO MY_GZZE,MY_SQTS
					FROM payroll_bz_gz A
					WHERE A.SET_ID = setid AND A.emp_id=i_emp;
					
					SET res = ROUND(MY_GZZE/26*(26-MY_SQTS),2);
				ELSE
					SET res = 0;
				END IF;
			END CASE;
		END IF;
	END IF;
END;

