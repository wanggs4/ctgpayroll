create procedure SP_PAYROLL_GZ_TAX_NEW(IN  PAYVAL      decimal(13, 3), IN TAX_BASE int, IN TAX_VERSION int,
                                       IN  PAYVAL_TYPE int, OUT NRATE decimal(13, 3), OUT NDEDUCTION decimal(13, 3),
                                       OUT RES         decimal(13, 3))
  comment '税档定位，返回税额.PAYVAL是已经扣除了基数的'
  BEGIN

	
	IF PAYVAL_TYPE = 1 THEN
		SET PAYVAL = (PAYVAL - TAX_BASE) * 12;
	
	ELSEIF PAYVAL_TYPE = 2 THEN
		SET PAYVAL = PAYVAL - TAX_BASE*12;
	END IF;
	
	IF PAYVAL <= 0 OR PAYVAL IS NULL THEN
	   set NRATE = 0;
	   set res = 0;
	ELSE
	 
		SELECT A.RATE,A.DEDUCTION
		 	INTO NRATE,NDEDUCTION
		FROM payroll_gz_tax A
		WHERE INCOME = (SELECT MAX(INCOME) INCOME
		                   FROM payroll_GZ_TAX 
		                  WHERE  INCOME < PAYVAL);
		
		IF NRATE IS NULL THEN SET NRATE = 0; END IF;
		IF NDEDUCTION IS NULL THEN SET NDEDUCTION = 0; END IF;
		
		
		IF PAYVAL_TYPE = 1 THEN
			SET NDEDUCTION = ROUND(NDEDUCTION/12,2);
			SET RES = PAYVAL/12 * NRATE - NDEDUCTION;
		
		ELSEIF PAYVAL_TYPE = 2 THEN
			SET RES = PAYVAL * NRATE - NDEDUCTION;
		END IF;
	END IF;
END;

