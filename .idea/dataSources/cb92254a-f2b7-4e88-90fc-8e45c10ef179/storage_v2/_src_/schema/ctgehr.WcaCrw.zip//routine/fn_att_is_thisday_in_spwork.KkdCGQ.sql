create function FN_ATT_IS_THISDAY_IN_SPWORK(CHECK_DATE   date, TIMEPOINT int, MY_EMPID bigint unsigned, MY_DEPTID int,
                                            UPDT_SPDAYID bigint unsigned)
  returns int
  comment '给一个日期、部门id和时间点标识，用来判断这个是否在特殊工作日内'
  BEGIN
/*	参数说明
	CHECK_DATE 需要检查的日期
	TIMEPOINT	需要检查日期当天所占的时间段 1上午 2下午 3全天
	MY_EMPID	部门id
*/
DECLARE IS_IN_SPWORK,IS_HAVE_ATT,MY_SP_BGPT,MY_SP_EDPT INT;
DECLARE MST,MET,AST,AET TIME;
DECLARE MY_SP_BGDT,MY_SP_EDDT DATE;
DECLARE MY_SP_BGTM,MY_SP_EDTM,MY_CHECK_BGTM,MY_CHECK_EDTM DATETIME;
DECLARE ATTID,THIS_SPWKDAYID BIGINT UNSIGNED;
DECLARE ATTID_STR,SPWKDAYID_STR TEXT;

	#用于个人计算
	IF CHECK_DATE IS NOT NULL AND TIMEPOINT IS NOT NULL AND MY_EMPID IS NOT NULL AND MY_DEPTID IS NULL THEN
		#定位此人出勤方案
		CALL SP_DPT_GET_SETTINGID(MY_EMPID,CHECK_DATE,1,ATTID_STR);
		SET ATTID = CAST(ATTID_STR AS UNSIGNED);

		#有方案再计算
		IF ATTID IS NOT NULL THEN
			#再看看当天是否有特殊工作日
			SET MY_SP_BGDT=NULL,MY_SP_BGPT=NULL,MY_SP_EDDT=NULL,MY_SP_EDPT=NULL;
			CALL SP_DPT_GET_SETTINGID(MY_EMPID,CHECK_DATE,5,SPWKDAYID_STR);
			
			IF SPWKDAYID_STR IS NULL THEN
				SET IS_IN_SPWORK = 0;
			ELSE
				SET IS_IN_SPWORK = 1;
			END IF;
		#没方案说明没覆盖
		ELSE
			SET IS_IN_SPWORK = 0;
		END IF;
	#用于修改设置
	ELSEIF CHECK_DATE IS NOT NULL AND TIMEPOINT IS NOT NULL AND MY_DEPTID IS NOT NULL THEN
		#得到与UPDT_SPDAYID挂钩的所有维度的值，并且找出与这些维度挂钩的除了UPDT_SPDAYID以外的当天有关系的id串
		IF UPDT_SPDAYID IS NOT NULL THEN
			SELECT CONCAT(GROUP_CONCAT(C.sp_workday_id),',')
				INTO SPWKDAYID_STR
			FROM att_rel_special_workday_dept A
				LEFT JOIN att_rel_special_workday_dept B ON A.dept_id=B.dept_id
				LEFT JOIN att_set_special_workday C ON B.sp_workday_id=C.sp_workday_id
			WHERE A.sp_workday_id = UPDT_SPDAYID AND B.sp_workday_id<>UPDT_SPDAYID 
				AND C.is_enable=1 AND C.is_delete=0 AND C.begin_date<=CHECK_DATE AND C.end_date>=CHECK_DATE;
		ELSE
			SELECT CONCAT(GROUP_CONCAT(C.sp_workday_id),',')
				INTO SPWKDAYID_STR
			FROM att_rel_special_workday_dept A
				LEFT JOIN att_rel_special_workday_dept B ON A.dept_id=B.dept_id
				LEFT JOIN att_set_special_workday C ON B.sp_workday_id=C.sp_workday_id
			WHERE A.sp_workday_id = UPDT_SPDAYID 
				AND C.is_enable=1 AND C.is_delete=0 AND C.begin_date<=CHECK_DATE AND C.end_date>=CHECK_DATE;
		END IF;
		IF SPWKDAYID_STR IS NULL THEN
			SET IS_IN_SPWORK = 0;
		ELSE
			SET IS_IN_SPWORK = 1;
		END IF;
	END IF;
RETURN IS_IN_SPWORK;
END;

