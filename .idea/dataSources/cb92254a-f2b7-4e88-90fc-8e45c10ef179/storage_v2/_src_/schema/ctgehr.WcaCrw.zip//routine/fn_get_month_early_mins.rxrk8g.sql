create function FN_GET_MONTH_EARLY_MINS(MY_EMP                  bigint, BGDT date, EDDT date,
                                        MORE_THAN_HOW_MANY_MINS decimal(12, 2), LESS_THAN_HOW_MANY_MINS decimal(12, 2),
                                        OP_TYPE                 int)
  returns float
  comment '通过给到的emp_id和日期区间，根据相应的考勤设置得到这段时间内的（获得减免的）早退分钟数'
  BEGIN
/*	变量说明
	MY_EMP 								emp_id
	BGDT、EDDT						开始结束时间

	LESS_THAN_HOW_MANY_MINS	MORE_THAN_HOW_MANY_MINS
	本次只统计早退分钟数在MORE_THAN_HOW_MANY_MINS和LESS_THAN_HOW_MANY_MINS之间的

	OP_TYPE
	1	返回分钟数
	2	返回次数
*/

DECLARE MY_EARLY_MINS DECIMAL(12,2);
DECLARE zt_jmct,THIS_EM,i_EARLY_credit,i_early_credit_count_switch,i_EARLY_credit_counts,i_EARLY_credit_counts_exception,i_EARLY_credit_mins,i_EARLY_credit_mins_exception,IS_HAVE_EMP,IS_HAVE_ATT INT;
DECLARE MY_ATTID,MY_DEPT BIGINT UNSIGNED;
DECLARE ATTID_STR TEXT;

	SET MY_EARLY_MINS = 0;

	IF MORE_THAN_HOW_MANY_MINS <= 0 OR MORE_THAN_HOW_MANY_MINS IS NULL THEN
		SET MORE_THAN_HOW_MANY_MINS = 0.01;
	END IF;
	
	#1440是24小时的分钟数
	IF LESS_THAN_HOW_MANY_MINS <= 0 OR LESS_THAN_HOW_MANY_MINS IS NULL THEN
		SET LESS_THAN_HOW_MANY_MINS = 99999;
	END IF;
	
	#验证有没有emp_id
	SELECT COUNT(*) INTO IS_HAVE_EMP FROM emp_base_info WHERE EMP_ID=MY_EMP AND IS_DELETE=0 AND EMP_STATE IS NOT NULL AND EMP_STATE<>0;
	#当参数有效时才开始
	IF IS_HAVE_EMP>0 AND BGDT<=EDDT AND LESS_THAN_HOW_MANY_MINS > MORE_THAN_HOW_MANY_MINS THEN
		CALL SP_DPT_GET_SETTINGID(MY_EMP,BGDT,1,ATTID_STR);
		SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);
		#有考勤设置的时候，继续计算
		IF MY_ATTID IS NOT NULL THEN
			SELECT B.early_credit,B.early_credit_count_switch,
					B.EARLY_credit_counts,B.EARLY_credit_counts_exception,
					B.EARLY_credit_mins,B.EARLY_credit_mins_exception
				INTO i_EARLY_credit,i_early_credit_count_switch,						#早退减免(0关 1开),  1减免早退次数 2减免早退时间
					i_EARLY_credit_counts,i_EARLY_credit_counts_exception,	#周期内减免次数,不享受减免的早退分钟数
					i_EARLY_credit_mins,i_EARLY_credit_mins_exception			#周期内减免分钟,不享受减免的早退分钟数
			FROM att_set_schema_new B 
			WHERE B.att_id=MY_ATTID;
			
			
			#有早退减免，且减免次数
			IF i_EARLY_credit = 1 AND i_early_credit_count_switch = 1 THEN
				#早退减免次数
				SET zt_jmct = 1;
				IF i_EARLY_credit_counts IS NULL THEN SET i_EARLY_credit_counts=0; END IF;
				IF i_EARLY_credit_counts_exception IS NULL THEN SET i_EARLY_credit_counts_exception=99999; END IF;
				
				#根据期间内每一天得到的值进行判断和累加
				WHILE ( BGDT <= EDDT ) DO
					#初始化变量
					SET THIS_EM=0;
					#得到本次的早退时长
					SELECT EARLY_mins INTO THIS_EM 
					FROM att_emp_detail 
					WHERE emp_id = MY_EMP and dt = BGDT and is_dayoff=0 
						and EARLY_mins between MORE_THAN_HOW_MANY_MINS and LESS_THAN_HOW_MANY_MINS;
					#首先，有满足条件的早退，才计数
					IF THIS_EM IS NOT NULL AND THIS_EM > 0 THEN
						#当减免次数没有用完时
						IF zt_jmct <= i_EARLY_credit_counts THEN
							#当早退分钟数小于不享受减免的早退分钟数时,就进行减免
							IF THIS_EM < i_EARLY_credit_counts_exception THEN
								SET THIS_EM = 0;
								SET zt_jmct = zt_jmct + 1;
							END IF;
						END IF;
						
						#如果是次数，把THIS_EM 改成次数
						IF OP_TYPE = 2 AND THIS_EM>0 THEN
							SET THIS_EM = 1;
						END IF;
						
						SET MY_EARLY_MINS = MY_EARLY_MINS + THIS_EM;
					END IF;
					
					SET BGDT = DATE_ADD(BGDT,INTERVAL 1 DAY);
					
				END WHILE;
			#有早退减免，且减免时间
			ELSEIF i_EARLY_credit = 1 AND i_early_credit_count_switch = 2 THEN
				#早退减免分钟数
				SET zt_jmct = i_EARLY_credit_mins;
				IF i_EARLY_credit_mins IS NULL THEN SET i_EARLY_credit_mins=0; END IF;
				IF i_EARLY_credit_mins_exception IS NULL THEN SET i_EARLY_credit_mins_exception=99999; END IF;

				#根据期间内每一天得到的值进行判断和累加
				WHILE ( BGDT <= EDDT ) DO
					#初始化变量
					SET THIS_EM=0;
					#得到本次的早退时长
					SELECT EARLY_mins INTO THIS_EM 
					FROM att_emp_detail 
					WHERE emp_id = MY_EMP and dt = BGDT and is_dayoff=0 
						and EARLY_mins between MORE_THAN_HOW_MANY_MINS and LESS_THAN_HOW_MANY_MINS;
					
					#首先，有满足条件的早退，才计数
					IF THIS_EM IS NOT NULL AND THIS_EM > 0 THEN
						#当减免分钟数没有用完时
						IF zt_jmct > 0 THEN
							#当早退分钟数小于不享受减免的早退分钟数时
							IF THIS_EM < i_EARLY_credit_mins_exception THEN
								#够扣的时候，早退时间为0
								IF zt_jmct - THIS_EM > 0 THEN
									SET zt_jmct = zt_jmct - THIS_EM;
									SET THIS_EM = 0;
								#不够扣的时候，早退时间是超出的部分
								ELSE
									SET THIS_EM = THIS_EM - zt_jmct;
									SET zt_jmct = 0;
								END IF;
							END IF;
						END IF;
						
						#如果是次数，把THIS_EM 改成次数
						IF OP_TYPE = 2 AND THIS_EM>0 THEN
							SET THIS_EM = 1;
						END IF;

						SET MY_EARLY_MINS = MY_EARLY_MINS + THIS_EM;
						
					END IF;
					
					SET BGDT = DATE_ADD(BGDT,INTERVAL 1 DAY);
					
				END WHILE;
			#没有早退减免
			ELSE
				IF OP_TYPE = 1 THEN
					SELECT ROUND(SUM(EARLY_mins)/60,2) INTO MY_EARLY_MINS 
					FROM att_emp_detail 
					WHERE emp_id = MY_EMP and dt between BGDT and EDDT and is_dayoff=0 
						and EARLY_mins between MORE_THAN_HOW_MANY_MINS and LESS_THAN_HOW_MANY_MINS;
				ELSEIF OP_TYPE = 2 THEN
					SELECT COUNT(*) INTO MY_EARLY_MINS 
					FROM att_emp_detail 
					WHERE emp_id = MY_EMP and dt between BGDT and EDDT and is_dayoff=0 
						and EARLY_mins between MORE_THAN_HOW_MANY_MINS and LESS_THAN_HOW_MANY_MINS;				END IF;
			END IF;

		
		END IF;
	END IF;
	SET MY_EARLY_MINS = ROUND(MY_EARLY_MINS,2);
	RETURN MY_EARLY_MINS;

END;

