create procedure SP_JAVA_EVENT_EVERYDAY_0130()
  comment '每天凌晨1:30跑的计划任务'
  BEGIN
DECLARE IS_LAST_ARCHIVE INT;
DECLARE BGDT,EDDT DATE;
DECLARE BGDTTM,EDDTTM DATETIME;

	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('审批流数据推送','START',NOW());
		truncate table emp_data_source.att_exam_step_external_ref;
		insert into emp_data_source.att_exam_step_external_ref
		SELECT distinct apply_id 
		from att_exam_step
		where 
			(
				(apply_time between concat(date_add(date(now()),interval -1 day),' 00:00:00') and  concat(date_add(date(now()),interval -1 day),' 23:59:59') and exam_anchor = 1)
				or (approval_time between concat(date_add(date(now()),interval -1 day),' 00:00:00') and  concat(date_add(date(now()),interval -1 day),' 23:59:59'))
			) and
			(
				exam_man not like 'or_%' and exam_man not like 'and_%' and exam_man not like 'no_%'
			);
					
		DELETE a.*
		from emp_data_source.att_exam_step_external a,emp_data_source.att_exam_step_external_ref b
		where a.apply_id=b.apply_id;

		replace INTO emp_data_source.att_exam_step_external
			(
			exam_id,cust_id,apply_id,flow_id,dept_id,prgm_id,jrdc_id,
			dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,dept_name,
			emp_id,emp_name,emp_code,apply_time,exam_source,exam_source_xq,apply_content,
			exam_step,exam_anchor,state,is_over,remark,exam_start_time,approval_time,
			exam_dept_id,exam_man,exam_man_name,exam_man_code,exam_step_id,agent_dept_id,agent_id,agent_name,agent_code,
			cs_examer_emp_id,cs_examer_emp_name,abort_notice_emp_id,abort_notice_emp_name,msg_type,
			from_who_id,from_who_name,from_who_code,update_time
			)
			SELECT exam_id,cust_id,apply_id,flow_id,dept_id,prgm_id,jrdc_id,
			dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,dept_name,
			emp_id,emp_name,emp_code,apply_time,exam_source,exam_source_xq,apply_content,
			exam_step,exam_anchor,state,is_over,remark,exam_start_time,approval_time,
			exam_dept_id,exam_man,exam_man_name,exam_man_code,exam_step_id,agent_dept_id,agent_id,agent_name,agent_code,
			cs_examer_emp_id,cs_examer_emp_name,abort_notice_emp_id,abort_notice_emp_name,msg_type,
			from_who_id,from_who_name,from_who_code, 
			    IF(exam_anchor = 1,apply_time,approval_time) 
			from att_exam_step 
			where 
				(
					(apply_time between concat(date_add(date(now()),interval -1 day),' 00:00:00') and  concat(date_add(date(now()),interval -1 day),' 23:59:59') and exam_anchor = 1)
					or (approval_time between concat(date_add(date(now()),interval -1 day),' 00:00:00') and  concat(date_add(date(now()),interval -1 day),' 23:59:59'))
				) and
				(
					exam_man not like 'or_%' and exam_man not like 'and_%' and exam_man not like 'no_%'
				)
			GROUP BY apply_id,IFNULL(exam_step_id,0),exam_step;
		
		truncate table emp_data_source.att_exam_step_external_max_step;
		insert into emp_data_source.att_exam_step_external_max_step
			select a.apply_id,max(a.exam_step)
			from emp_data_source.att_exam_step_external a
			where a.is_over=1
			group by a.apply_id;
		
		update emp_data_source.att_exam_step_external a,emp_data_source.att_exam_step_external_max_step b
		set a.is_over=0
		where a.apply_id=b.apply_id and a.is_over=1;
		
		update emp_data_source.att_exam_step_external a,emp_data_source.att_exam_step_external_max_step b
		set a.is_over=1
		where a.apply_id=b.apply_id and a.exam_step=b.exam_step;
		
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('审批流数据推送','END',NOW());

	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('考勤日报','START',NOW());
	CALL SP_ATT_DAILY_CHECK(DATE_ADD(DATE(NOW()),INTERVAL -3 DAY),DATE_ADD(DATE(NOW()),INTERVAL -3 DAY),2162554862743552,NULL,NULL,NULL);
	CALL SP_ATT_DAILY_CHECK(DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),2162554862743552,NULL,NULL,NULL);
#	CALL SP_ATT_DAILY_CHECK_TASK(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),2162554862743552,NULL,NULL,NULL);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('考勤日报','END',NOW());
	

	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('补跑n-2当天加班日报','START',NOW());
	call SP_ATT_DAILY_OVER_REDO();
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('补跑n-2当天加班日报','END',NOW());

	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('加班日报','START',NOW());
	CALL SP_ATT_DAILY_OVER(DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),2162554862743552,NULL,NULL,NULL);
#	CALL SP_ATT_DAILY_OVER(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),2162554862743552,NULL,NULL,NULL);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('加班日报','END',NOW());

	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('夜班加补休日报','START',NOW());
	CALL SP_ATT_DAILY_OVER_WITH_REST(DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),NULL,NULL);
#	CALL SP_ATT_DAILY_OVER_WITH_REST(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),NULL,NULL);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('夜班加补休日报','END',NOW());

	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('假期日报','START',NOW());
	CALL SP_ATT_DAILY_HOLIDAY(DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),2162554862743552,NULL,NULL,NULL);
#	CALL SP_ATT_DAILY_HOLIDAY(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),2162554862743552,NULL,NULL,NULL);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('假期日报','END',NOW());

	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('系统通知处理','START',NOW());
	CALL SP_SYS_TRANSACTION_NOTICE_DAILY(DATE(NOW()),DATE(NOW()),NULL);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('系统通知处理','END',NOW());
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('清除当天离职的人所涉及到的推荐审批流','START',NOW());
	CALL SP_PURGE_LEAVE_APPLY_RECO();
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('清除当天离职的人所涉及到的推荐审批流','END',NOW());
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('已审待审分化','START',NOW());
	CALL SP_ATT_SEPERATE_EXAM_MAN(NULL);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('已审待审分化','END',NOW());
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('更新父级节点人数限制','START',NOW());
	call SP_SYS_BULK_UPDT_LMTPRT_DEPTID(NULL,NULL);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('更新父级节点人数限制','END',NOW());
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('司龄','START',NOW());
	UPDATE emp_post A ,emp_base_info B
	SET A.wh_time = IF(FLOOR(DATEDIFF(DATE(NOW()),A.entry_date)/365)<0,0,FLOOR(DATEDIFF(DATE(NOW()),A.entry_date)/365))
	WHERE B.is_delete=0 AND B.emp_state IN (1,3) AND A.entry_date IS NOT NULL AND A.emp_id=B.emp_id;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('司龄','END',NOW());
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('工龄','START',NOW());
	UPDATE emp_post A ,emp_base_info B
	SET A.work_time = IF(FLOOR(DATEDIFF(DATE(NOW()),A.fst_job_time)/365)<0,0,FLOOR(DATEDIFF(DATE(NOW()),A.fst_job_time)/365))
	WHERE B.is_delete=0 AND B.emp_state IN (1,3) AND A.entry_date IS NOT NULL AND A.fst_job_time IS NOT NULL AND A.emp_id=B.emp_id;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('工龄','END',NOW());
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('月报','START',NOW());
	CALL SP_CUST_PERIOD_MONTH(DATE_ADD(DATE(NOW()),INTERVAL -2 DAY),2162554862743552,NULL);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('月报','END',NOW());

	IF DAY(NOW()) <= 10 AND DAY(NOW()) >= 3 THEN

		REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('上个月月报','START',NOW());

		SELECT A.begin_date,A.end_date INTO BGDT,EDDT
		FROM cust_period_schedule A
		WHERE A.cust_id = 2162554862743552 and A.period_type=1 
			AND A.begin_date <= DATE_ADD(DATE(NOW()),INTERVAL -1 MONTH) AND A.end_date >=DATE_ADD(DATE(NOW()),INTERVAL -1 MONTH);
		
		SELECT A.archive_state INTO IS_LAST_ARCHIVE
		FROM att_st_month A
		WHERE A.cust_id=2162554862743552 AND A.comp_start_time=BGDT AND A.comp_end_time=EDDT;
		
		IF IS_LAST_ARCHIVE > 0 AND IS_LAST_ARCHIVE IS NOT NULL THEN
		
			SET BGDTTM = CONCAT(BGDT,' 05:00:00');
			SET EDDTTM = CONCAT(DATE_ADD(EDDT,INTERVAL 1 DAY),' 04:59:59');
			
			#3号特殊处理上月最后一天有请假人的月报
			IF DAY(NOW()) = 3 THEN
				INSERT INTO att_st_last_month_emp (EMP_ID)
				SELECT DISTINCT A.emp_id
				FROM att_hol_apply_day A
				WHERE A.HOL_DATE = DATE_ADD(DATE(NOW()),INTERVAL -3 DAY);
			END IF;
			
			
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct a.emp_id
			from att_exam_step a
				left join att_hol_apply_day b on a.apply_id=b.apply_id
			where a.is_over=1 and a.state=1 and b.hol_date between BGDT and EDDT
				and a.approval_time >= CONCAT(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),' 01:30:00')
			group by a.apply_id;
			
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct a.emp_id
			from att_exam_step a
				left join att_hol_reduce_apply b on a.apply_id=b.apply_id
			where a.is_over=1 and a.state=1 and b.new_end_time between BGDTTM and EDDTTM
				and a.approval_time >=  CONCAT(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),' 01:30:00')
			group by a.apply_id;
			
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct a.emp_id
			from att_exam_step a
				left join att_over_apply_day b on a.apply_id=b.apply_id
			where a.is_over=1 and a.state=1 and b.work_day between BGDT and EDDT
				and a.approval_time >=  CONCAT(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),' 01:30:00')
			group by a.apply_id;
			
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct a.emp_id
			from att_exam_step a
				left join att_check_apply b on a.apply_id=b.apply_id
			where a.is_over=1 and a.state=1 and b.check_time between BGDTTM and EDDTTM
				and a.approval_time >=  CONCAT(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),' 01:30:00')
			group by a.apply_id;
			
			
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct a.emp_id
			from att_exam_step a
				left join att_over_apply_with_rest b on a.apply_id=b.apply_id
			where a.is_over=1 and a.state=1 and b.over_start_time <= EDDTTM and b.over_end_time >= BGDTTM
				and a.approval_time >=  CONCAT(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY),' 01:30:00')
			group by a.apply_id;
	
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct a.emp_id
			from att_emp_detail a
				left join att_st_month_quick_view_icss b on a.emp_id=b.emp_id
				left join att_st_month c on b.st_id=c.st_id
			where a.cust_id = 2162554862743552 AND a.dt between BGDT AND EDDT
				AND (a.create_time > b.create_time or a.mod_time > b.create_time) and b.personal_archive_state=0 and c.archive_state=0
				AND c.comp_start_time=BGDT AND c.comp_end_time=EDDT;
	
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct a.emp_id
			from att_hol_apply_day a
				left join att_st_month_quick_view_icss b on a.emp_id=b.emp_id
				left join att_st_month c on b.st_id=c.st_id
			where a.cust_id = 2162554862743552 AND a.hol_date between BGDT AND EDDT
				AND a.create_time > b.create_time and b.personal_archive_state=0 and c.archive_state=0
				AND c.comp_start_time=BGDT AND c.comp_end_time=EDDT;
	
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct a.emp_id
			from att_over_apply_day a
				left join att_st_month_quick_view_icss b on a.emp_id=b.emp_id
				left join att_st_month c on b.st_id=c.st_id
			where a.cust_id = 2162554862743552 AND a.work_day between BGDT AND EDDT
				AND a.create_time > b.create_time and b.personal_archive_state=0 and c.archive_state=0
				AND c.comp_start_time=BGDT AND c.comp_end_time=EDDT;
	
			INSERT INTO att_st_last_month_emp (EMP_ID)
			select distinct b.emp_id
			from att_st_month a
				left join att_st_month_quick_view_icss b on a.st_id=b.st_id 
				left join emp_post c on b.emp_id=b.emp_id
			where a.cust_id = 2162554862743552 AND a.comp_start_time=BGDT AND a.comp_end_time=EDDT
				AND (b.entry_date <> c.entry_date or b.leave_date <> c.leave_date);
				
			CALL SP_ATT_MONTH_REPORT_LAST_MONTH();
		END IF;
		REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('上个月月报','END',NOW());
	END IF;

END;

