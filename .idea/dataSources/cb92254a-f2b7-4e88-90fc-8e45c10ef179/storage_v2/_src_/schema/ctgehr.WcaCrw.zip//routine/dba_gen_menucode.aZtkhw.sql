create procedure DBA_GEN_MENUCODE(IN ROOTID bigint unsigned)
  comment '创建一个菜单表备份，并且为其创建一个体现层级关系的code系统'
  BEGIN
DECLARE THIS_PRTMNID,I_CT,I_MXCT,LV_CT,LV_MXCT,THIS_ROOTID,CT,MXCT BIGINT UNSIGNED;
DECLARE THIS_CODE VARCHAR(300);

	DROP TABLE IF EXISTS tmp_son_list;
	CREATE TABLE `tmp_son_list` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`menu_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '菜单id',
		PRIMARY KEY (`id`)
		)
	COLLATE='utf8mb4_general_ci'
	ENGINE=memory;

	DROP TABLE IF EXISTS `tmp_menu_list`;
	CREATE TABLE `tmp_menu_list` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`menu_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '菜单id',
		PRIMARY KEY (`id`)
		)
	COLLATE='utf8mb4_general_ci'
	ENGINE=memory;
	
	DROP TABLE IF EXISTS `tmp_menu_list_order`;
	CREATE TABLE `tmp_menu_list_order` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`menu_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '菜单id',
		PRIMARY KEY (`id`)
		)
	COLLATE='utf8mb4_general_ci'
	ENGINE=memory;

	TRUNCATE TABLE au_menus_tree;
	INSERT INTO au_menus_tree (menu_id,parent_menu_id,state) 
		SELECT menu_id,parent_menu_id,state FROM au_menus;
	
	DROP TABLE IF EXISTS tmp_root_list;
	CREATE TABLE `tmp_root_list` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`menu_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '菜单id',
		PRIMARY KEY (`id`)
		)
	COLLATE='utf8mb4_general_ci'
	ENGINE=memory;
	IF ROOTID IS NULL THEN
		INSERT INTO tmp_root_list (MENU_ID) SELECT MENU_ID FROM au_menus_tree WHERE PARENT_MENU_ID=0;
	ELSE
		INSERT INTO tmp_root_list (MENU_ID) VALUES (ROOTID);
	END IF;
	
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_root_list;
	
	WHILE CT <= MXCT AND CT > 0 DO
		SELECT MENU_ID INTO THIS_ROOTID FROM tmp_root_list WHERE ID=CT;
		IF CT < 10 THEN
			SET THIS_CODE = CONCAT('00',CT);
		ELSEIF CT >= 10 AND CT <100 THEN
			SET THIS_CODE = CONCAT('0',CT);
		ELSE
			SET THIS_CODE = CONCAT(CT);
		END IF;
		UPDATE au_menus_tree A SET A.menu_code = THIS_CODE WHERE A.menu_id=THIS_ROOTID;
		
		TRUNCATE TABLE tmp_menu_list ;
		INSERT INTO tmp_menu_list (MENU_ID) VALUES (THIS_ROOTID);
		
		SET LV_CT=1,LV_MXCT=10;
		WHILE LV_CT <= LV_MXCT DO
			INSERT INTO tmp_menu_list (MENU_ID)
				SELECT DISTINCT A.MENU_ID FROM au_menus_tree A LEFT JOIN tmp_menu_list B ON A.parent_menu_id=B.MENU_ID ;
			SET LV_CT = LV_CT + 1;
		END WHILE;
		
		TRUNCATE TABLE tmp_menu_list_order;
		INSERT INTO tmp_menu_list_order (MENU_ID) SELECT DISTINCT MENU_ID FROM tmp_menu_list ORDER BY ID;
		SET I_CT=0,I_MXCT=0;
		SELECT MIN(ID),MAX(ID) INTO I_CT,I_MXCT FROM tmp_menu_list_order;
		WHILE I_CT <= I_MXCT AND I_CT > 0 DO
			SELECT MENU_ID INTO THIS_PRTMNID FROM tmp_menu_list_order WHERE ID=I_CT;
			CALL DBA_GEN_SONMENUCODE(THIS_PRTMNID);
			SET I_CT = I_CT + 1;
		END WHILE;
		SET CT = CT + 1;		
	END WHILE;
	
	DROP TABLE IF EXISTS tmp_son_list;
	DROP TABLE IF EXISTS tmp_menu_list;
	DROP TABLE IF EXISTS tmp_menu_list_order;
	DROP TABLE IF EXISTS tmp_root_list;
END;

