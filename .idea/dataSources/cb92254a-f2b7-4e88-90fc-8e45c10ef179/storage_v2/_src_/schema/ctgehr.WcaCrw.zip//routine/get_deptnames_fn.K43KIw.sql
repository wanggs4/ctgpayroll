create function GET_DEPTNAMES_FN(dept_ids varchar(500))
  returns varchar(500)
  comment '通过id获得一组部门名称'
  BEGIN

DECLARE DEPT_NAMES VARCHAR(500);
DECLARE DPNAME,DPID VARCHAR(50);
DECLARE len,start_pt,part_end INT;
 
set DEPT_NAMES='';
set len = length(dept_ids);

while (len >=2) do
	set start_pt = 1;
	set part_end = locate(',',dept_ids);
	SET DPID = MID(dept_ids,start_pt,part_end-start_pt); 
	select dept_name into DPNAME FROM DEPT_INFO WHERE DEPT_ID=DPID AND DEPT_TYPE=1;
	set DEPT_NAMES=concat(DEPT_NAMES,DPNAME,',');
	set dept_ids = mid(dept_ids,part_end+1);
	set len=len - part_end;
end while;

RETURN DEPT_NAMES;
END;

