create function FN_ATT_GET_REAL_HOL_END_TIME(MY_HOL_START_TIME datetime, MY_HOL_HOUR_POOL decimal(12, 2),
                                             MY_EMPID          bigint unsigned, MY_HOLID bigint unsigned, MY_SONVER int,
                                             IS_SINGLE_DAY_HOL int)
  returns datetime
  comment '根据给出的条件和时间，计算出针对于此人的有效请假结束时间点'
  BEGIN
#MY_HOL_HOUR_POOL 单位分钟
DECLARE BGDT DATE;
DECLARE ATTSET_MST,ATTSET_MET,ATTSET_AST,ATTSET_AET TIME;
DECLARE THIS_ST,THIS_ET,THIS_MST,THIS_MET,THIS_AST,THIS_AET,MY_THIS_START_TIME,MY_THIS_END_TIME DATETIME;
DECLARE ATTID_STR TEXT;
DECLARE THIS_DTTYPE,CT,MXCT,SAFE_COUNT,HOLSET_HOLRULE,ATTSET_ATTRULE,HOLSET_HOLUNIT,HOLSET_STUNIT,IS_HAVE_EMP,IS_HAVE_HOL,HOLSET_ISYEARHOL,IS_HAVE_SONVER INT;
DECLARE MY_ATTID BIGINT UNSIGNED;
DECLARE THIS_BLOCK_HOUR DECIMAL(12,2);

	IF MY_HOL_HOUR_POOL IS NULL THEN SET MY_HOL_HOUR_POOL = 0; END IF;
	
	IF MY_HOL_START_TIME IS NOT NULL AND MY_HOL_HOUR_POOL > 0 AND MY_EMPID IS NOT NULL AND MY_HOLID IS NOT NULL AND MY_SONVER IS NOT NULL THEN

		SELECT COUNT(*) INTO IS_HAVE_EMP FROM emp_base_info A WHERE A.emp_id=MY_EMPID;
		SELECT COUNT(*),A.is_year_hol INTO IS_HAVE_HOL,HOLSET_ISYEARHOL FROM att_set_holiday_main A WHERE A.hol_id=MY_HOLID;
		IF HOLSET_ISYEARHOL = 1 THEN
			SELECT COUNT(*) INTO IS_HAVE_SONVER FROM att_set_holiday_year_new A WHERE A.hol_id=MY_HOLID AND A.son_ver=MY_SONVER;
		ELSEIF HOLSET_ISYEARHOL = 2 THEN
			SELECT COUNT(*) INTO IS_HAVE_SONVER FROM att_set_holiday_rest A WHERE A.hol_id=MY_HOLID AND A.son_ver=MY_SONVER;
		ELSEIF HOLSET_ISYEARHOL IN (11,12,13) THEN
			SET IS_HAVE_SONVER = 1;
		ELSE
			SELECT COUNT(*) INTO IS_HAVE_SONVER FROM att_set_holiday A WHERE A.hol_id=MY_HOLID AND A.son_ver=MY_SONVER;
		END IF;
		#全部条件都满足后开始计算
		IF IS_HAVE_EMP>0 AND IS_HAVE_HOL>0 AND IS_HAVE_SONVER>0 THEN

	########################################################################################################################################################################		
	#	1.前提准备 读取各种设置
	########################################################################################################################################################################		
			#读出最小单位
			IF HOLSET_ISYEARHOL <> 11 THEN
				SELECT A.hol_unit,A.st_unit,A.hol_rule 
					INTO HOLSET_HOLUNIT,HOLSET_STUNIT,HOLSET_HOLRULE 
				FROM att_set_holiday_main A WHERE A.hol_id=MY_HOLID;
			ELSE
				SELECT A.hol_unit,A.st_unit,A.hol_rule
					INTO HOLSET_HOLUNIT,HOLSET_STUNIT,HOLSET_HOLRULE 
				FROM att_set_holiday_main A LEFT JOIN att_set_holiday_main B ON A.cust_id=B.cust_id
				WHERE B.hol_id=MY_HOLID AND A.is_year_hol=1 LIMIT 1;
			END IF;
			#SET MY_THIS_START_TIME = FN_ATT_GET_REAL_HOL_START_TIME(MY_HOL_START_TIME,MY_EMPID,MY_HOLID);
			SET MY_THIS_START_TIME = MY_HOL_START_TIME;
			SET BGDT = DATE(MY_THIS_START_TIME);
			
			#得到出勤方案
			CALL SP_DPT_GET_SETTINGID(MY_EMPID,BGDT,1,ATTID_STR);
			SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);

			IF MY_ATTID IS NOT NULL THEN 

				SELECT A.att_rule,A.morn_start_time,A.morn_end_time,A.aftn_start_time,A.aftn_end_time
					INTO ATTSET_ATTRULE,ATTSET_MST,ATTSET_MET,ATTSET_AST,ATTSET_AET
				FROM att_set_schema_new A WHERE A.att_id=MY_ATTID;

		########################################################################################################################################################################
		#	2.循环扣除给出的假期时数，最后计算出终点的时间点
		########################################################################################################################################################################
				SET SAFE_COUNT = 366;
				#当给出的时间足够扣除，依次扣除和计算截止的时间点
				WHILE MY_HOL_HOUR_POOL > 0 AND SAFE_COUNT > 0 DO
			########################################################################################################################################################################
			#	2.1 根据出勤规则不同设置循环指针
			########################################################################################################################################################################
					SET THIS_MST = CONCAT(BGDT,' ',ATTSET_MST);
					SET THIS_MET = CONCAT(BGDT,' ',ATTSET_MET);
					SET THIS_AST = CONCAT(BGDT,' ',ATTSET_AST);
					SET THIS_AET = CONCAT(BGDT,' ',ATTSET_AET);

					#按工作日
					IF HOLSET_HOLRULE = 1 THEN
						IF ATTSET_ATTRULE = 1  THEN
							SET THIS_DTTYPE = FN_ATT_GET_DTTYPE(BGDT,MY_EMPID);
							#可以被扣减
							IF THIS_DTTYPE IN (1,6) THEN
								SET CT = 1,MXCT = 2 ;
							ELSE
								SET MXCT = 0;
							END IF;
							
						ELSEIF ATTSET_ATTRULE = 3 THEN
							SELECT COUNT(*) INTO MXCT FROM att_arrange_schedual A WHERE A.emp_id=MY_EMPID AND A.dt = BGDT;
							#可以被扣减
							IF MXCT > 0 THEN
								SET CT = 1 ;
							END IF;
						END IF;
					#按自然日
					ELSEIF HOLSET_HOLRULE = 2 THEN
						IF ATTSET_ATTRULE = 1  THEN
							SET CT = 1,MXCT = 2 ;
						ELSEIF ATTSET_ATTRULE = 3 THEN
							SET CT = 1,MXCT = 1 ;
						END IF;
					END IF;
					
					IF MXCT IS NULL THEN SET MXCT = 0; END IF;
			########################################################################################################################################################################
			#	2.2 设置班段的起止时间点
			########################################################################################################################################################################
					WHILE CT <= MXCT AND MXCT > 0 DO 
						#初始化循环变量
						SET THIS_BLOCK_HOUR=0,THIS_ST=NULL,THIS_ET=NULL;
						
						#设置时间段起止点
						IF ATTSET_ATTRULE = 1 THEN
							IF CT = 1 THEN
								SET THIS_ST = THIS_MST,THIS_ET = THIS_MET;
							ELSEIF CT = 2 THEN
								SET THIS_ST = THIS_AST,THIS_ET = THIS_AET;
							END IF;
						ELSEIF ATTSET_ATTRULE = 3 THEN
							IF HOLSET_HOLRULE = 1 THEN
								SELECT B.arr_start_time,B.arr_end_time INTO THIS_ST,THIS_ET FROM att_arrange_schedual B WHERE A.emp_id=MY_EMPID AND B.dt=BGDT AND B.arr_no=CT;
							ELSEIF HOLSET_HOLRULE = 2 THEN
								SET THIS_ST = CONCAT(BGDT,' 00:00:00'),THIS_ET = CONCAT(BGDT,' 23:59:59') ;
							END IF;
						END IF;
			########################################################################################################################################################################
			#	2.3 计算每个段的时长
			########################################################################################################################################################################
						IF IS_SINGLE_DAY_HOL = 0 THEN
							IF MY_THIS_START_TIME < THIS_ST THEN
								SET THIS_BLOCK_HOUR = FN_ATT_GET_REAL_HOLIDAY_HOURS(TIME(THIS_ST),TIME(THIS_ET),MY_HOLID,MY_SONVER,MY_EMPID,MY_ATTID,BGDT,999);
							ELSEIF MY_THIS_START_TIME > THIS_ET THEN
								SET THIS_BLOCK_HOUR = 0;
							ELSEIF MY_THIS_START_TIME >= THIS_ST AND MY_THIS_START_TIME <= THIS_ET THEN
								SET THIS_BLOCK_HOUR = FN_ATT_GET_REAL_HOLIDAY_HOURS(TIME(MY_THIS_START_TIME),TIME(THIS_ET),MY_HOLID,MY_SONVER,MY_EMPID,MY_ATTID,BGDT,999);
								SET THIS_ST = MY_THIS_START_TIME;
							END IF;
						ELSEIF IS_SINGLE_DAY_HOL = 1 THEN
							IF MY_THIS_START_TIME <= THIS_ET THEN
								SET THIS_BLOCK_HOUR = MY_HOL_HOUR_POOL;
								SET THIS_ST = MY_THIS_START_TIME;
							ELSE
								SET THIS_BLOCK_HOUR = 0;
							END IF;
						END IF;
#SELECT THIS_ST,THIS_ET,IS_SINGLE_DAY_HOL;
			########################################################################################################################################################################
			#	2.4 根据扣减情况设置循环和设置最终时间点
			########################################################################################################################################################################
						#够扣，指针递增继续循环，并且设置起始时间
						IF MY_HOL_HOUR_POOL - THIS_BLOCK_HOUR > 0 THEN
							#扣减
							SET MY_HOL_HOUR_POOL = MY_HOL_HOUR_POOL - THIS_BLOCK_HOUR;
							SET CT = CT + 1 ;
						ELSE
							SET THIS_BLOCK_HOUR = MY_HOL_HOUR_POOL;
							SET MY_THIS_END_TIME = DATE_ADD(THIS_ST,INTERVAL THIS_BLOCK_HOUR MINUTE);
							IF MY_THIS_END_TIME > THIS_ET AND CT = 1 THEN
								SET MY_THIS_END_TIME = DATE_ADD(MY_THIS_END_TIME, INTERVAL TIME_TO_SEC(TIMEDIFF(THIS_AST,THIS_MET))/60 MINUTE);
							END IF;
							SET MY_HOL_HOUR_POOL = 0 ;
							SET CT = MXCT + 1 ;
#SELECT CT,THIS_BLOCK_HOUR,MY_THIS_END_TIME,MY_HOL_HOUR_POOL;
						END IF;
					END WHILE;
					
					IF MY_HOL_HOUR_POOL > 0 THEN
						SET BGDT = DATE_ADD(BGDT,INTERVAL 1 DAY);
					END IF;
					SET SAFE_COUNT = SAFE_COUNT - 1;
				END WHILE;
			END IF;
		END IF;
	END IF;
RETURN MY_THIS_END_TIME;
END;

