create procedure SP_ICSS_ST_EXTRA_WORK_DETAIL(IN MONTH_VERSION int unsigned)
  comment '3个月内超时离场详情'
  BEGIN
DECLARE IS_ARCH INT;
DECLARE MY_STID,MY_LAST_STID,MY_LAST2_STID BIGINT UNSIGNED;
DECLARE ARCH_DAY,LAST_ARCH_DAY,LAST2_ARCH_DAY DATE;

	IF MONTH_VERSION IS NOT NULL THEN
		SELECT A.archive_state,A.st_id,A.comp_start_time INTO IS_ARCH,MY_STID,ARCH_DAY
		FROM att_st_month A 
		WHERE A.`version` = MONTH_VERSION AND A.cust_id=2162554862743552;
	ELSE
		SET ARCH_DAY = DATE_ADD(DATE(NOW()),INTERVAL -1 MONTH);
		SELECT A.archive_state,A.st_id INTO IS_ARCH,MY_STID
		FROM att_st_month A 
		WHERE A.comp_start_time <= ARCH_DAY AND A.comp_end_time >= ARCH_DAY AND A.cust_id=2162554862743552;
	END IF;	
	
	
	IF IS_ARCH = 1 AND IS_ARCH IS NOT NULL THEN		
		REPLACE INTO icss_st_3months_extra_work_detail (emp_id,year_mon,this_extra_work_mins,emp_code,emp_name,ownership_place,dept_full_name,dept_id,admin_place_id)
			SELECT A.emp_id,MONTH_VERSION,IFNULL(A.yyxcqgs,0) - IFNULL(A.ybzcqgs,0),A.emp_code,A.emp_name,A.ownership_place,A.dept_full_name,A.dept_id,A.dms_id5
			FROM att_st_month_quick_view_icss A
			WHERE A.st_id=MY_STID AND IFNULL(A.yyxcqgs,0) - IFNULL(A.ybzcqgs,0) > 0;
			
		SET LAST_ARCH_DAY = DATE_ADD(ARCH_DAY,INTERVAL -1 MONTH);
		SELECT A.st_id INTO MY_LAST_STID
		FROM att_st_month A 
		WHERE A.comp_start_time <= LAST_ARCH_DAY AND A.comp_end_time >= LAST_ARCH_DAY AND A.cust_id=2162554862743552;
		UPDATE icss_st_3months_extra_work_detail A , att_st_month_quick_view_icss B
		SET A.last_extra_work_mins = IFNULL(B.yyxcqgs,0) - IFNULL(B.ybzcqgs,0)
		WHERE A.emp_id=B.emp_id AND A.year_mon=MONTH_VERSION AND B.st_id=MY_LAST_STID;
		
		SET LAST2_ARCH_DAY = DATE_ADD(LAST_ARCH_DAY,INTERVAL -1 MONTH);
		SELECT A.st_id INTO MY_LAST2_STID
		FROM att_st_month A 
		WHERE A.comp_start_time <= LAST2_ARCH_DAY AND A.comp_end_time >= LAST2_ARCH_DAY AND A.cust_id=2162554862743552;
		UPDATE icss_st_3months_extra_work_detail A , att_st_month_quick_view_icss B
		SET A.last_2_extra_work_mins = IFNULL(B.yyxcqgs,0) - IFNULL(B.ybzcqgs,0)
		WHERE A.emp_id=B.emp_id AND A.year_mon=MONTH_VERSION AND B.st_id=MY_LAST2_STID;

	END IF;
END;

