create procedure SP_PAYROLL_GZ_TAX_BACK(IN  PAYVAL decimal(13, 3), IN TAXBASEVALUE decimal(13, 3), IN TAX_VERSION int,
                                        OUT NRATE  decimal(13, 3), OUT NDEDUCTION decimal(13, 3),
                                        OUT RES    decimal(13, 3))
  comment '逆向所得税函数'
  BEGIN
 

    
    IF PAYVAL <= 5000 OR PAYVAL IS NULL THEN
      SET NRATE      = 0;
      SET NDEDUCTION = 0;
      SET RES = 0;
   
    END IF;
    
    SELECT RATE,DEDUCTION
      INTO NRATE,NDEDUCTION
      FROM payroll_GZ_TAX F
      WHERE F.INCOME = (SELECT MAX(T.INCOME) INCOME
                         FROM payroll_GZ_TAX T
                         WHERE T.Netpay + TAXBASEVALUE < PAYVAL AND `VERSION` = TAX_VERSION)
				AND `VERSION`=TAX_VERSION;
    IF NRATE IS NULL THEN SET NRATE = 0; END IF;
    IF NDEDUCTION IS NULL THEN SET NDEDUCTION = 0; END IF;
    
	 SET RES = ROUND((PAYVAL - NDEDUCTION - TAXBASEVALUE)/(1-NRATE),2);
	 
END;

