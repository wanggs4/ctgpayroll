create procedure SP_PURGE_LEAVE_APPLY_RECO()
  comment '清除当天离职的人所涉及到的推荐审批流（每天固定后台执行）'
  BEGIN
DECLARE CT,MXCT INT;
DECLARE i_emp,i_custid BIGINT;
	DROP TABLE IF EXISTS TMP_LEAVE_EMP;
	CREATE TABLE TMP_LEAVE_EMP(
		ID bigint unsigned not null AUTO_INCREMENT,
		`emp_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL ,
		`cust_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL ,
		PRIMARY KEY (`ID`)
	)ENGINE = MEMORY;
	
	
	delete from  TMP_LEAVE_EMP;
	INSERT INTO TMP_LEAVE_EMP (emp_id,cust_id) select emp_id,cust_id from emp_post where leave_date= date(now());
	
	
	SET CT = 0;
	SET MXCT = 0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM TMP_LEAVE_EMP;
	IF CT IS NULL THEN SET CT = 0; END IF;
	IF MXCT IS NULL THEN SET MXCT = 0; END IF;
	WHILE (CT<=MXCT AND CT>0) DO
		SELECT emp_id,cust_id INTO i_emp,i_custid FROM TMP_LEAVE_EMP WHERE ID = CT;	
		
		DELETE FROM att_apply_reco WHERE LOCATE(i_emp,CONCAT(',',examers,','))>0 AND CUST_ID = i_custid; 
		SET CT = CT + 1;
	END WHILE;

	DROP TABLE IF EXISTS TMP_LEAVE_EMP;

END;

