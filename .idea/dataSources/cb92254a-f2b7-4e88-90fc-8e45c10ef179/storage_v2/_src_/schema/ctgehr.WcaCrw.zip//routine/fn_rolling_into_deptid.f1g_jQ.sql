create procedure FN_ROLLING_INTO_DEPTID(IN HYPER_DEPT_ID bigint)
  comment '通过给到的部门id，找到它下面的所有子部门（包括自己）'
  BEGIN

END;

