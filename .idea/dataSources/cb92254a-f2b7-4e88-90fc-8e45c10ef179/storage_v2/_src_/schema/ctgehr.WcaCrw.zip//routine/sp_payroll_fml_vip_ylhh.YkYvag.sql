create procedure SP_PAYROLL_FML_VIP_YLHH(IN key_word varchar(50), IN i_emp bigint unsigned, IN prid bigint unsigned,
                                         IN setid    bigint unsigned, OUT res decimal(13, 2))
  comment '易联汇华个性化计算'
  BEGIN
DECLARE i_sala_ymd_begin,i_sala_ymd_end,i_entry_date,i_leave_date DATE;
DECLARE i_nx,i_30_cnt,i_60_cnt,i_30_cnt_early,i_60_cnt_early, i_workdays, i_holdays INT;
DECLARE i_deptid bigint;

	IF key_word IS NOT NULL AND i_emp IS NOT NULL AND prid IS NOT NULL AND setid IS NOT NULL THEN 
		SELECT sala_ymd_begin,sala_ymd_end into i_sala_ymd_begin,i_sala_ymd_end
		FROM payroll_sala_settings WHERE SET_ID = setid;
			
		CASE key_word
		WHEN 'YLHH_BJBL' THEN
		
			SELECT entry_date,leave_date into i_entry_date,i_leave_date
			FROM emp_post WHERE emp_id = i_emp;
			
			IF i_entry_date > i_sala_ymd_end and i_entry_date is not null THEN
				SET i_nx = 0;
			ELSEIF (i_entry_date is not null AND i_leave_date is not null AND ((i_leave_date <= i_sala_ymd_end AND i_leave_date >= i_sala_ymd_begin) OR i_leave_date < i_sala_ymd_begin)) THEN
				SET i_nx = FLOOR(DATEDIFF(i_leave_date,i_entry_date)/365);
			ELSEIF (i_entry_date is not null AND i_leave_date is not null AND i_leave_date > i_sala_ymd_end) THEN
				SET i_nx = FLOOR(DATEDIFF(i_sala_ymd_end,i_entry_date)/365);
			ELSEIF (i_entry_date is not null AND i_leave_date IS null) THEN
				SET i_nx = FLOOR(DATEDIFF(i_sala_ymd_end,i_entry_date)/365);
			ELSE
				SET i_nx = 0;
			END IF;
			
			IF i_nx<2 THEN
				SET res = 0.4;
			ELSEIF i_nx>=2 AND i_nx<4 THEN
				SET res = 0.3;
			ELSEIF i_nx>=2 AND i_nx<4 THEN
				SET res = 0.2;
			END IF;
		WHEN 'YLHH_CDKK' THEN
			
			SELECT COUNT(*) INTO i_30_cnt 
			FROM att_emp_detail 
			WHERE EMP_ID=i_emp AND DT BETWEEN i_sala_ymd_begin AND i_sala_ymd_end AND is_dayoff=0 AND date_type=1 
				AND late_mins BETWEEN 0 AND 30;

			SELECT COUNT(*) INTO i_30_cnt_early
			FROM att_emp_detail 
			WHERE EMP_ID=i_emp AND DT BETWEEN i_sala_ymd_begin AND i_sala_ymd_end AND is_dayoff=0 AND date_type=1 
				AND early_mins BETWEEN 0 AND 30 ;
			
			IF i_30_cnt IS NULL THEN SET i_30_cnt=0; END IF;
			IF i_30_cnt_early IS NULL THEN SET i_30_cnt_early=0; END IF;
			
			SET i_30_cnt = i_30_cnt + i_30_cnt_early;
			
			SELECT COUNT(*) INTO i_60_cnt 
			FROM att_emp_detail 
			WHERE EMP_ID=i_emp AND DT BETWEEN i_sala_ymd_begin AND i_sala_ymd_end AND is_dayoff=0 AND date_type=1 
				AND late_mins BETWEEN 31 AND 60;
				
			SELECT COUNT(*) INTO i_60_cnt_early
			FROM att_emp_detail 
			WHERE EMP_ID=i_emp AND DT BETWEEN i_sala_ymd_begin AND i_sala_ymd_end AND is_dayoff=0 AND date_type=1 
				AND early_mins BETWEEN 31 AND 60;
			
			IF i_60_cnt IS NULL THEN SET i_60_cnt=0; END IF;
			IF i_60_cnt_early IS NULL THEN SET i_60_cnt_early=0; END IF;
			
			SET i_60_cnt = i_60_cnt + i_60_cnt_early;
				
			IF i_30_cnt > 3 THEN
				SET res = (i_30_cnt-3)*20 + i_60_cnt*50;
			ELSE
				SET res = i_60_cnt*50;
			END IF;
		WHEN 'YLHH_YCQTS' THEN
			
			SELECT DEPT_ID INTO i_deptid FROM emp_base_info WHERE EMP_ID = i_emp;
			
			SET i_workdays = FN_ATT_GET_WORKDAYS(i_sala_ymd_begin,i_sala_ymd_end,i_emp,2);
			SELECT COUNT(*) INTO i_holdays FROM dict_hol_date where dt between i_sala_ymd_begin and i_sala_ymd_end and date_type=3;
			
			IF i_workdays IS NULL THEN SET i_workdays = 0 ; END IF;
			IF i_holdays IS NULL THEN SET i_holdays = 0 ; END IF;
			
			SET res = i_workdays + i_holdays;
			
		WHEN 'YLHH_YGCQTS' THEN
			
			SET res = 0;
		END CASE;	
	END IF;
END;

