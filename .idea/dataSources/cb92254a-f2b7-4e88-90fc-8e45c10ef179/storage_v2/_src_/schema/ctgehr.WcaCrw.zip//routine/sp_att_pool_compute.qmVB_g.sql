create procedure SP_ATT_POOL_COMPUTE(IN APPLYID bigint unsigned, IN OPR_TYPE int, OUT RES int)
  comment '看看年假池，调休池够不够扣'
  BEGIN
/*
程序说明
	会根据给出参数去年假池或者调休池找出小于申请日期最早的is_delete=0的数据，并从this_year_have里加或减 发生的天数或小时数


变量说明
APPLYID		申请id
OPR_TYPE	操作类型 1加 2减
RES			返回结果状态 1正常 2无可扣除的剩余量
*/
DECLARE MY_ATTID,i_emp,i_holid,i_dept BIGINT UNSIGNED;
DECLARE MY_ATTRULE,sonver,THIS_DTTYPE,THIS_HFDAY_FLAG,MY_HOLUNIT,MY_STUNIT,i_is_year_hol,year_ct,INIT_CT,IS_HAVE_POOL BIGINT;
DECLARE THIS_BGTM,THIS_EDTM,i_start_time,i_end_time DATETIME;
DECLARE DAILY_HOURS,THIS_OPR_VALUE,year_mxct,OPR_VALUE,this_left_value,i_this_year_left,i_do_value,i_ori_value,i_mod_value,last_left_value,MY_LAST_LEFT,MY_THIS_LEFT DECIMAL(13,3);
DECLARE MST,MET,AST,AET,THIS_REAL_START_TIME,THIS_REAL_END_TIME,THIS_START_TIME,THIS_END_TIME TIME;
DECLARE MY_BGDT,MY_EDDT,MY_ORI_BGDT DATE;
DECLARE ATTID_STR TEXT;
	SET RES = 1;
#从申请表里读出申请的开始和结束时间，并计算出发生时间
	SELECT emp_id,start_time,end_time,hol_id,dept_id,son_ver
		INTO i_emp,i_start_time,i_end_time,i_holid,i_dept,sonver
	FROM att_hol_apply 
	WHERE APPLY_ID = APPLYID;

	SELECT is_year_hol INTO i_is_year_hol FROM att_set_holiday_main WHERE hol_id = i_holid;
	
	
	SET  MY_HOLUNIT=NULL,MY_STUNIT=NULL;
	IF i_is_year_hol = 1 OR i_is_year_hol = 3 THEN		#年假或带薪病假
		IF  OPR_TYPE = 2 THEN
	
			SELECT A.hol_unit,A.st_unit
				INTO MY_HOLUNIT,MY_STUNIT
			FROM att_set_holiday_main A
			WHERE A.hol_id=i_holid;

			
			
			SET MY_BGDT = DATE(i_start_time);
			SET MY_EDDT = DATE(i_end_time);
			
			
			SET OPR_VALUE = 0;
			SET MY_ORI_BGDT = MY_BGDT;
			WHILE MY_BGDT <= MY_EDDT DO
				SET THIS_OPR_VALUE = 0,DAILY_HOURS=0,MY_ATTRULE=NULL,THIS_BGTM=NULL,THIS_EDTM=NULL;
				SET THIS_DTTYPE=NULL,THIS_START_TIME=NULL,THIS_END_TIME=NULL,THIS_HFDAY_FLAG=NULL;

				CALL SP_DPT_GET_SETTINGID(i_emp,MY_BGDT,1,ATTID_STR);
				SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);

				SELECT A.att_rule,A.morn_start_time,A.morn_end_time,A.aftn_start_time,A.aftn_end_time 
					INTO MY_ATTRULE,MST,MET,AST,AET 
				FROM att_set_schema_new A WHERE ATT_ID=MY_ATTID;

				IF MY_ATTID IS NOT NULL THEN
					#最小单位非半天或者半天月报统计单位小时，按照实际时间算
					IF MY_HOLUNIT<>4 OR (MY_HOLUNIT=4 AND MY_STUNIT=2) THEN 			
						#坐班当天应工作时长
						IF MY_ATTRULE = 1 THEN
							SET DAILY_HOURS = FN_ATT_GET_WORKHOURS(MY_ATTID);
						#排班当天应工作时长
						ELSEIF MY_ATTRULE = 3 THEN
							SET DAILY_HOURS = FN_ATT_GET_ARR_WORKHOURS(i_emp,MY_BGDT);
						END IF;
						#单天
						IF MY_ORI_BGDT = MY_EDDT THEN
							SET THIS_BGTM = i_start_time,THIS_EDTM = i_end_time;
						#多天第一天
						ELSEIF MY_ORI_BGDT = MY_BGDT AND MY_ORI_BGDT < MY_EDDT THEN
							SET THIS_BGTM = i_start_time;
							SET THIS_EDTM = CONCAT(MY_BGDT,' 23:59:59');	
						#多天最后一天
						ELSEIF MY_BGDT = MY_EDDT AND MY_ORI_BGDT < MY_EDDT THEN
							SET THIS_BGTM = CONCAT(MY_BGDT,' 00:00:00');
							SET THIS_EDTM = i_end_time;	
						#多天中间
						ELSEIF MY_ORI_BGDT < MY_EDDT THEN
							SET THIS_BGTM = CONCAT(MY_BGDT,' 00:00:00');
							SET THIS_EDTM = CONCAT(MY_BGDT,' 23:59:59');	
						END IF;
						#如果当天工作时长有值，说明当天可以请假，否则计为零
						IF DAILY_HOURS > 0 THEN
							SET THIS_OPR_VALUE = IFNULL(FN_ATT_GET_HOL_HOURS(THIS_BGTM,THIS_EDTM,i_holid,sonver,i_emp,99)/DAILY_HOURS,0);
						ELSE
							SET THIS_OPR_VALUE = 0;
						END IF;
					#请假单位半天且月报单位天，半天按照一半的天数
					ELSEIF MY_HOLUNIT=4 AND MY_STUNIT=1 THEN
						#只有出勤规则是坐班的时候才有半天假
						IF MY_ATTRULE = 1 THEN
							SET THIS_DTTYPE = FN_ATT_GET_DTTYPE(MY_BGDT,i_emp);
							#工作日才进行扣减
							IF THIS_DTTYPE IN (1,6) THEN
								#单天的申请
								IF MY_ORI_BGDT = MY_EDDT THEN
									SET THIS_START_TIME = TIME(i_start_time);
									SET THIS_END_TIME = TIME(i_end_time);
								#多天第一天
								ELSEIF MY_BGDT = MY_ORI_BGDT AND MY_ORI_BGDT < MY_EDDT THEN
										SET THIS_START_TIME = TIME(i_start_time);
										SET THIS_END_TIME = '23:59:59';
								#多天最后一天
								ELSEIF MY_BGDT = MY_EDDT AND MY_ORI_BGDT < MY_EDDT THEN
										SET THIS_START_TIME = '00:00:00';
										SET THIS_END_TIME = TIME(i_end_time);
								#多天其余天
								ELSEIF MY_ORI_BGDT < MY_EDDT THEN
										SET THIS_START_TIME = '00:00:00';
										SET THIS_END_TIME = '23:59:59';
								END IF;
								CALL FN_ATT_GET_HOL_HALFDAY_TIME(THIS_START_TIME,THIS_END_TIME,MY_ATTID,THIS_REAL_START_TIME,THIS_REAL_END_TIME,THIS_HFDAY_FLAG);

								#上下午
								IF THIS_HFDAY_FLAG IN (1,2) THEN
									SET THIS_OPR_VALUE = 0.5;
								#全天
								ELSEIF THIS_HFDAY_FLAG = 3 THEN
									SET THIS_OPR_VALUE = 1;
								END IF;
							ELSE
								SET THIS_OPR_VALUE = 0;
							END IF;
						ELSEIF MY_ATTRULE = 3 THEN
							SET THIS_OPR_VALUE = 0;
						END IF;
					END IF;
				ELSE
					SET THIS_OPR_VALUE = 0 ;
				END IF;
					
				SET OPR_VALUE = OPR_VALUE + THIS_OPR_VALUE;
				SET MY_BGDT = DATE_ADD(MY_BGDT,INTERVAL 1 DAY);
			END WHILE;
			#年假
			IF i_is_year_hol = 1 THEN
				SELECT SUM(IF(THIS_YEAR_LEFT IS NULL OR THIS_YEAR_LEFT < 0,0,THIS_YEAR_LEFT)) INTO year_mxct 
				FROM att_hol_year A WHERE A.emp_id=i_emp AND A.is_delete=0;
				
			#带薪病假
			ELSEIF i_is_year_hol = 3 THEN
				SELECT SUM(IF(THIS_YEAR_LEFT IS NULL OR THIS_YEAR_LEFT < 0,0,THIS_YEAR_LEFT)) INTO year_mxct 
				FROM att_hol_sick A WHERE A.emp_id=i_emp AND A.is_delete=0;
				
			END IF;
			

			IF year_mxct - OPR_VALUE < 0 THEN			#不存在可扣的
				SET RES = 2;
			ELSEIF year_mxct - OPR_VALUE >= 0 THEN	#存在可扣的
				SET RES = 1;
			END IF;
		END IF;

	ELSEIF i_is_year_hol = 2 THEN 	#调休
		#本次请假的天数
		SET OPR_VALUE = IFNULL(FN_ATT_GET_HOL_HOURS(i_start_time,i_end_time,i_holid,sonver,i_emp,99),0);
		IF  OPR_TYPE = 2 THEN
			
			SELECT SUM(IF(THIS_YEAR_LEFT IS NULL OR THIS_YEAR_LEFT < 0,0,THIS_YEAR_LEFT)) INTO year_mxct 
			FROM att_hol_rest A WHERE A.emp_id=i_emp AND A.is_delete=0;
			
			
			IF year_mxct - OPR_VALUE < 0 THEN			#不存在可扣的
				SET RES = 2;
			ELSEIF year_mxct - OPR_VALUE >= 0 THEN	#存在可扣的
				SET RES = 1;
			END IF;
		END IF;
	END IF;
END;

