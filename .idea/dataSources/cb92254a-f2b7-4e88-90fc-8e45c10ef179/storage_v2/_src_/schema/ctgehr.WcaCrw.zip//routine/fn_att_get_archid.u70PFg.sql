create function FN_ATT_GET_ARCHID(CUSTID bigint unsigned, MONVER int unsigned)
  returns bigint unsigned
  BEGIN
DECLARE THIS_ARCHID BIGINT UNSIGNED;
DECLARE BGDT,EDDT DATE;


	IF CUSTID IS NOT NULL AND MONVER IS NOT NULL THEN
		SELECT A.arch_id INTO THIS_ARCHID
		FROM att_st_month_arch A
		WHERE A.cust_id=CUSTID AND A.`version` = MONVER;
		
		IF THIS_ARCHID IS NULL THEN
			SELECT A.begin_date,A.end_date INTO BGDT,EDDT
			FROM cust_period_schedule A
			WHERE A.cust_id=CUSTID AND A.year_mon=MONVER AND A.period_type=1;
			
			SELECT MAX(ARCH_ID) + 1 INTO THIS_ARCHID FROM att_st_month_arch A WHERE A.arch_id < 100000000;
			
			INSERT INTO att_st_month_arch (arch_id,cust_id,`version`,arch_time,comp_start_time,comp_end_time,is_delete,arch_state) 
				VALUES (THIS_ARCHID,CUSTID,MONVER,NOW(),BGDT,EDDT,0,1);
		END IF;
	END IF;
RETURN THIS_ARCHID;
END;

