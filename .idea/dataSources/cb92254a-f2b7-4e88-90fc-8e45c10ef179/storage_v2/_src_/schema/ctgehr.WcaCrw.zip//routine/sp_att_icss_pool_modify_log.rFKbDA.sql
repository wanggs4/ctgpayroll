create procedure SP_ATT_ICSS_POOL_MODIFY_LOG(IN MY_EMPID    bigint unsigned, IN MY_APPLYID bigint unsigned,
                                             IN MY_POOLTYPE int, IN MY_OPTYPE int, IN MY_DOVALUE decimal(10, 5))
  comment '以天为单位记录每个申请对于池子的扣减详情'
  BEGIN
#入参说明：
#	MY_POOLTYPE	1年假池 2调休池 3预支年假池 4带薪病假 5付费调休12 6付费调休13
#	MY_OPTYPE	操作类型 1.have , 2.use
#	MY_DOVALUE	增量值
DECLARE IS_HAVE_EMP,IS_HAVE_APPLY,THIS_DOYEAR,IS_DAILY_OUT,MY_POOL_MAX_YEAR,MY_APPLY_STATE,CT INT;
DECLARE MY_SOURCE,THIS_DOLOG_STR,THIS_POOL_STR,THIS_DAILY_STR VARCHAR(200);
DECLARE MY_DAILY_STR,MY_POOL_STR,MY_DOLOG_STR TEXT;
DECLARE THIS_DOVALUE,THIS_ORIHAVE,THIS_ORIUSE,THIS_ORILEFT,THIS_YEAR_DOVALUE,THIS_YEARLEFT,ALL_DOVALUE,THIS_DOVALUE_UNDONE DECIMAL(10,5);
DECLARE THIS_DODATE,THIS_DT DATE;
	#入参有效性校验
	SELECT COUNT(*) INTO IS_HAVE_EMP FROM emp_base_info A WHERE A.emp_id=MY_EMPID;
	#年假 OR 调休
	IF MY_OPTYPE = 2 AND MY_DOVALUE >= 0 THEN
		SELECT COUNT(*) INTO IS_HAVE_APPLY FROM att_over_apply_with_rest A WHERE A.apply_id=MY_APPLYID;
		SELECT COUNT(*) + IFNULL(IS_HAVE_APPLY,0) INTO IS_HAVE_APPLY FROM att_hol_apply A WHERE A.apply_id=MY_APPLYID;
		SET MY_SOURCE = 'HOL';
	#加班
	ELSEIF MY_OPTYPE = 1 AND MY_DOVALUE >= 0 THEN
		SELECT COUNT(*) INTO IS_HAVE_APPLY FROM att_over_apply A WHERE A.apply_id=MY_APPLYID;
		SET MY_SOURCE = 'OVER';
	END IF;
	
	SET MY_APPLY_STATE = NULL ;
	SET CT =1;
	WHILE MY_APPLY_STATE IS NULL AND CT <= 3 DO
		CASE CT 
		WHEN 1 THEN
			SELECT A.state	
				INTO MY_APPLY_STATE
			FROM att_hol_apply A
			WHERE A.apply_id=MY_APPLYID;
		WHEN 2 THEN
			SELECT A.state	
				INTO MY_APPLY_STATE
			FROM att_over_apply A
			WHERE A.apply_id=MY_APPLYID;
		WHEN 3 THEN
			SELECT A.state	
				INTO MY_APPLY_STATE
			FROM att_over_apply_with_rest A
			WHERE A.apply_id=MY_APPLYID;
		END CASE;
		
		SET CT = CT + 1;
	END WHILE;
#SELECT 	MY_APPLY_STATE;
	#参数有效且合理，进行池子的计算
	IF IS_HAVE_EMP > 0 AND IS_HAVE_APPLY > 0 AND MY_POOLTYPE IN (1,2,3,4,5,6) AND MY_POOLTYPE IS NOT NULL AND MY_OPTYPE IN (1,2) AND MY_OPTYPE IS NOT NULL AND MY_DOVALUE IS NOT NULL THEN
	#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   PART1 回滚操作   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		IF MY_DOVALUE = 0 THEN
#SELECT 1;
		#<----------------------------STEP1.首先删除att_st_icss_pool_log上的相关记录
			DELETE FROM att_st_icss_pool_log WHERE emp_id = MY_EMPID AND apply_id = MY_APPLYID and pool_type=MY_POOLTYPE AND op_type=MY_OPTYPE;
		#-----------------------------STEP1 END --------------------------------------->	
		
		#<----------------------------STEP2.回退池子的操作
			#1.得到曾经操作过的信息
			#格式：年份|操作值,年份|操作值,....,
			#example:2019|2.00000,2020|1.00000,
			IF MY_POOLTYPE = 1 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.which_year,'|',A.do_value),''),',')
					INTO MY_DOLOG_STR
				FROM att_hol_year_log A
				WHERE A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE';
			ELSEIF MY_POOLTYPE = 2 THEN
				IF MY_SOURCE = 'HOL' THEN
					SELECT CONCAT(IFNULL(GROUP_CONCAT(A.which_year,'|',A.do_value),''),',')
						INTO MY_DOLOG_STR
					FROM att_hol_rest_log A
					WHERE A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE';
				ELSEIF MY_SOURCE = 'OVER' THEN
					SELECT CONCAT(IFNULL(GROUP_CONCAT(A.which_year,'|',A.do_value),''),',')
						INTO MY_DOLOG_STR
					FROM att_hol_rest_log A
					WHERE A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_HAVE';
				END IF;
			ELSEIF MY_POOLTYPE = 3 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.which_year,'|',A.do_value),''),',')
					INTO MY_DOLOG_STR
				FROM att_hol_credit_year_log A
				WHERE A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE';
			ELSEIF MY_POOLTYPE = 4 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.which_year,'|',A.do_value),''),',')
					INTO MY_DOLOG_STR
				FROM att_hol_sick_log A
				WHERE A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE';
			ELSEIF MY_POOLTYPE = 5 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.which_year,'|',A.do_value),''),',')
					INTO MY_DOLOG_STR
				FROM att_hol_pay_rest_log A
				WHERE A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE' AND A.pool_type=12;
			ELSEIF MY_POOLTYPE = 6 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.which_year,'|',A.do_value),''),',')
					INTO MY_DOLOG_STR
				FROM att_hol_pay_rest_log A
				WHERE A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE' AND A.pool_type=13;
			END IF;
			
			WHILE LOCATE(',',MY_DOLOG_STR) <= LENGTH(MY_DOLOG_STR) AND LOCATE(',',MY_DOLOG_STR) > 1 AND MY_DOLOG_STR IS NOT NULL DO
				SET THIS_DOLOG_STR = CONCAT(LEFT(MY_DOLOG_STR,LOCATE(',',MY_DOLOG_STR)-1),'|');
#select THIS_DOLOG_STR;
				#得到操作年份
				SET THIS_DOYEAR = CAST(LEFT(THIS_DOLOG_STR,LOCATE('|',THIS_DOLOG_STR)-1) AS UNSIGNED);
				SET THIS_DOLOG_STR = RIGHT(THIS_DOLOG_STR,LENGTH(THIS_DOLOG_STR)-LOCATE('|',THIS_DOLOG_STR));
				#得到操作值
				SET THIS_DOVALUE = CAST(LEFT(THIS_DOLOG_STR,LOCATE('|',THIS_DOLOG_STR)-1) AS DECIMAL(10,5));
				#
				IF THIS_DOYEAR IS NOT NULL AND THIS_DOVALUE IS NOT NULL THEN
					#年假池
					IF MY_POOLTYPE = 1 THEN
						#更新年假池
						UPDATE att_hol_year A 
						SET A.THIS_YEAR_USE=A.THIS_YEAR_USE-THIS_DOVALUE,A.THIS_YEAR_LEFT=A.THIS_YEAR_LEFT+THIS_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
						
						#更新操作LOG
						UPDATE att_hol_year_log A,att_hol_year B
						SET A.do_value = 0,A.mod_value=B.this_year_use
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE' AND A.which_year=THIS_DOYEAR;
						UPDATE att_hol_year_log A,att_hol_year B
						SET A.do_value = 0,A.mod_value=B.this_year_left
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_LEFT' AND A.which_year=THIS_DOYEAR;
					#调休池
					ELSEIF MY_POOLTYPE = 2 THEN
						#回退调休
						IF MY_SOURCE = 'HOL' THEN
							#更新调休池
							UPDATE att_hol_rest A 
							SET A.THIS_YEAR_USE=A.THIS_YEAR_USE-THIS_DOVALUE,A.THIS_YEAR_LEFT=A.THIS_YEAR_LEFT+THIS_DOVALUE
							WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
							
							#更新操作LOG
							UPDATE att_hol_rest_log A,att_hol_rest B
							SET A.do_value = 0,A.mod_value=B.this_year_use
							WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE' AND A.which_year=THIS_DOYEAR;
							UPDATE att_hol_rest_log A,att_hol_rest B
							SET A.do_value = 0,A.mod_value=B.this_year_left
							WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_LEFT' AND A.which_year=THIS_DOYEAR;
						#回退加班
						ELSEIF MY_SOURCE = 'OVER' THEN
							#更新调休池
							UPDATE att_hol_rest A 
							SET A.this_year_have=A.this_year_have-THIS_DOVALUE,A.THIS_YEAR_LEFT=A.THIS_YEAR_LEFT-THIS_DOVALUE
							WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
							
							#更新操作LOG
							UPDATE att_hol_rest_log A,att_hol_rest B
							SET A.do_value = 0,A.mod_value=B.this_year_have
							WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_HAVE' AND A.which_year=THIS_DOYEAR;
							UPDATE att_hol_rest_log A,att_hol_rest B
							SET A.do_value = 0,A.mod_value=B.this_year_left
							WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_LEFT' AND A.which_year=THIS_DOYEAR;
						END IF;
					#预支年假池
					ELSEIF MY_POOLTYPE = 3 THEN
						#更新年假池
						UPDATE att_hol_credit_year A 
						SET A.THIS_YEAR_USE=A.THIS_YEAR_USE-THIS_DOVALUE,A.THIS_YEAR_LEFT=A.THIS_YEAR_LEFT+THIS_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
						
						#更新操作LOG
						UPDATE att_hol_credit_year_log A,att_hol_credit_year B
						SET A.do_value = 0,A.mod_value=B.this_year_use
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE' AND A.which_year=THIS_DOYEAR;
						UPDATE att_hol_credit_year_log A,att_hol_credit_year B
						SET A.do_value = 0,A.mod_value=B.this_year_left
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_LEFT' AND A.which_year=THIS_DOYEAR;
						
					ELSEIF MY_POOLTYPE = 4 THEN
						#更新年假池
						UPDATE att_hol_sick A 
						SET A.THIS_YEAR_USE=A.THIS_YEAR_USE-THIS_DOVALUE,A.THIS_YEAR_LEFT=A.THIS_YEAR_LEFT+THIS_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
						
						#更新操作LOG
						UPDATE att_hol_sick_log A,att_hol_sick B
						SET A.do_value = 0,A.mod_value=B.this_year_use
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE' AND A.which_year=THIS_DOYEAR;
						UPDATE att_hol_sick_log A,att_hol_sick B
						SET A.do_value = 0,A.mod_value=B.this_year_left
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_LEFT' AND A.which_year=THIS_DOYEAR;
						
					ELSEIF MY_POOLTYPE = 5 THEN
						#更新年假池
						UPDATE att_hol_pay_rest A 
						SET A.THIS_YEAR_USE=A.THIS_YEAR_USE-THIS_DOVALUE,A.THIS_YEAR_LEFT=A.THIS_YEAR_LEFT+THIS_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0 AND A.pool_type=12;
						
						#更新操作LOG
						UPDATE att_hol_pay_rest_log A,att_hol_pay_rest B
						SET A.do_value = 0,A.mod_value=B.this_year_use
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE' AND A.which_year=THIS_DOYEAR AND A.pool_type=12;
						UPDATE att_hol_pay_rest_log A,att_hol_pay_rest B
						SET A.do_value = 0,A.mod_value=B.this_year_left
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_LEFT' AND A.which_year=THIS_DOYEAR AND A.pool_type=12;
						
					ELSEIF MY_POOLTYPE = 6 THEN
						#更新年假池
						UPDATE att_hol_pay_rest A 
						SET A.THIS_YEAR_USE=A.THIS_YEAR_USE-THIS_DOVALUE,A.THIS_YEAR_LEFT=A.THIS_YEAR_LEFT+THIS_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0 AND A.pool_type=13;
						
						#更新操作LOG
						UPDATE att_hol_pay_rest_log A,att_hol_pay_rest B
						SET A.do_value = 0,A.mod_value=B.this_year_use
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_USE' AND A.which_year=THIS_DOYEAR AND A.pool_type=13;
						UPDATE att_hol_pay_rest_log A,att_hol_pay_rest B
						SET A.do_value = 0,A.mod_value=B.this_year_left
						WHERE A.emp_id=B.emp_id AND A.which_year=B.this_year AND B.is_delete=0 AND A.apply_id=MY_APPLYID AND A.col_name='THIS_YEAR_LEFT' AND A.which_year=THIS_DOYEAR AND A.pool_type=13;
						
					END IF;
				END IF;
				SET MY_DOLOG_STR = RIGHT(MY_DOLOG_STR,LENGTH(MY_DOLOG_STR)-LOCATE(',',MY_DOLOG_STR));
			END WHILE;
		#-----------------------------STEP2 END --------------------------------------->	
	#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   PART1 回滚操作 END   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	
	
	
	#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   PART2 申请已通过的正常操作   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		ELSEIF MY_DOVALUE > 0 AND MY_APPLY_STATE = 1 AND MY_OPTYPE =2 THEN
#SELECT 2;
			DELETE FROM att_st_icss_pool_log WHERE apply_id = MY_APPLYID and pool_type=MY_POOLTYPE AND op_type=MY_OPTYPE;
			#得到申请的每日信息
			#格式：日期|时长,日期|时长,...,
			#example：2020-05-28|1.00000,2020-05-29|1.00000,
			#年假
			IF MY_POOLTYPE = 1 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.hol_date,'|',A.hol_days),''),',')
					INTO MY_DAILY_STR
				FROM att_hol_apply_day A
				WHERE A.apply_id=MY_APPLYID AND A.is_year_hol=1 AND A.hol_days > 0;
			#调休
			ELSEIF MY_POOLTYPE = 2 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.hol_date,'|',A.hol_hours),''),',')
					INTO MY_DAILY_STR
				FROM att_hol_apply_day A
				WHERE A.apply_id=MY_APPLYID AND A.is_year_hol=2 AND A.hol_hours > 0;
			#预支年假
			ELSEIF MY_POOLTYPE = 3 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.hol_date,'|',A.hol_days),''),',')
					INTO MY_DAILY_STR
				FROM att_hol_apply_day A
				WHERE A.apply_id=MY_APPLYID AND A.is_year_hol=11 AND A.hol_days > 0;				
			#带薪病假
			ELSEIF MY_POOLTYPE = 4 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.hol_date,'|',A.hol_days),''),',')
					INTO MY_DAILY_STR
				FROM att_hol_apply_day A
				WHERE A.apply_id=MY_APPLYID AND A.is_year_hol=3 AND A.hol_days > 0;				
			#付费调休12
			ELSEIF MY_POOLTYPE = 5 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.hol_date,'|',A.hol_hours),''),',')
					INTO MY_DAILY_STR
				FROM att_hol_apply_day A
				WHERE A.apply_id=MY_APPLYID AND A.is_year_hol=12 AND A.hol_hours > 0;				
			#付费调休13
			ELSEIF MY_POOLTYPE = 6 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.hol_date,'|',A.hol_hours),''),',')
					INTO MY_DAILY_STR
				FROM att_hol_apply_day A
				WHERE A.apply_id=MY_APPLYID AND A.is_year_hol=13 AND A.hol_hours > 0;				
			END IF;
			
			#计算一下池子的剩余总量和最早最晚的年份，以后按年份顺序扣减
			#格式：年份|当年有|当年用|当年剩余,年份|当年有|当年用|当年剩余,...,
			#example：2019|2.00000|0.00000|2.00000,2020|4.00000|0.00000|0.00000,
			IF MY_POOLTYPE = 1 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_year A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0 ;
			ELSEIF MY_POOLTYPE = 2 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_rest A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;
			ELSEIF MY_POOLTYPE = 3 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_credit_year A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;
			ELSEIF MY_POOLTYPE = 4 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_sick A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;
			ELSEIF MY_POOLTYPE = 5 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_pay_rest A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0 AND A.pool_type=12;
			ELSEIF MY_POOLTYPE = 6 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_pay_rest A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0 AND A.pool_type=13;
			END IF;
			
#SELECT MY_DAILY_STR,MY_POOL_STR;
			#首先循环可用的年假池信息
			WHILE LOCATE(',',MY_POOL_STR) <= LENGTH(MY_POOL_STR) AND LOCATE(',',MY_POOL_STR) > 1 AND MY_POOL_STR IS NOT NULL AND MY_DOVALUE > 0 DO
			#格式：年份|当年有|当年用|当年剩余,年份|当年有|当年用|当年剩余,...,
			#example：2019|2.00000|0.00000|2.00000,2020|4.00000|0.00000|0.00000,
				SET THIS_POOL_STR=NULL,THIS_DOYEAR=NULL,THIS_ORIHAVE=NULL,THIS_ORIUSE=NULL,THIS_ORILEFT=NULL;
				SET THIS_POOL_STR = CONCAT(LEFT(MY_POOL_STR,LOCATE(',',MY_POOL_STR)-1),'|');
				#得到年份
				SET THIS_DOYEAR = CAST(LEFT(THIS_POOL_STR,LOCATE('|',THIS_POOL_STR)-1) AS UNSIGNED);
				SET THIS_POOL_STR = RIGHT(THIS_POOL_STR,LENGTH(THIS_POOL_STR)-LOCATE('|',THIS_POOL_STR));
				#得到原始当年有
				SET THIS_ORIHAVE = CAST(LEFT(THIS_POOL_STR,LOCATE('|',THIS_POOL_STR)-1) AS DECIMAL(10,5));
				SET THIS_POOL_STR = RIGHT(THIS_POOL_STR,LENGTH(THIS_POOL_STR)-LOCATE('|',THIS_POOL_STR));
				#得到原始当年用
				SET THIS_ORIUSE = CAST(LEFT(THIS_POOL_STR,LOCATE('|',THIS_POOL_STR)-1) AS DECIMAL(10,5));
				SET THIS_POOL_STR = RIGHT(THIS_POOL_STR,LENGTH(THIS_POOL_STR)-LOCATE('|',THIS_POOL_STR));
				#得到原始当年剩
				SET THIS_ORILEFT = CAST(LEFT(THIS_POOL_STR,LOCATE('|',THIS_POOL_STR)-1) AS DECIMAL(10,5));
					
				IF THIS_ORILEFT IS NOT NULL THEN
					#然后循环每天的追加信息，然后从相应的年份里扣除					
					SET THIS_YEAR_DOVALUE = 0, 			#年度操作累计值
						THIS_YEARLEFT = THIS_ORILEFT, 	#当年剩余值(计算用)
						IS_DAILY_OUT=0, 						#循环跳出控制
						THIS_DOVALUE_UNDONE=0; 		#年度扣完，但是每日的操作值还没有累加扣完的量
					WHILE LOCATE(',',MY_DAILY_STR) <= LENGTH(MY_DAILY_STR) AND LOCATE(',',MY_DAILY_STR) > 1 
						AND MY_DAILY_STR IS NOT NULL AND IS_DAILY_OUT = 0 
					DO
					#格式：日期|时长,日期|时长,...,
					#example：2020-05-28|1.00000,2020-05-29|1.00000,
						SET THIS_DAILY_STR=NULL,THIS_DODATE=NULL,THIS_DOVALUE=NULL;
						SET THIS_DAILY_STR = CONCAT(LEFT(MY_DAILY_STR,LOCATE(',',MY_DAILY_STR)-1),'|');
						#得到年份
						SET THIS_DODATE = CAST(LEFT(THIS_DAILY_STR,LOCATE('|',THIS_DAILY_STR)-1) AS DATE);
						SET THIS_DAILY_STR = RIGHT(THIS_DAILY_STR,LENGTH(THIS_DAILY_STR)-LOCATE('|',THIS_DAILY_STR));
						#得到原始当年有
						SET THIS_DOVALUE = CAST(LEFT(THIS_DAILY_STR,LOCATE('|',THIS_DAILY_STR)-1) AS DECIMAL(10,5));
						
						IF THIS_DOVALUE IS NOT NULL THEN
							#剩余够用，不管是哪年，正常计算
							IF THIS_YEARLEFT - THIS_DOVALUE >= 0 THEN
								SET THIS_YEAR_DOVALUE = THIS_YEAR_DOVALUE + THIS_DOVALUE;
								SET THIS_YEARLEFT = THIS_YEARLEFT - THIS_DOVALUE;
								SET THIS_DOVALUE_UNDONE = 0;
								SET MY_DAILY_STR = RIGHT(MY_DAILY_STR,LENGTH(MY_DAILY_STR)-LOCATE(',',MY_DAILY_STR));
								SET IS_DAILY_OUT = 0;

							#剩余不够用 
							ELSEIF THIS_YEARLEFT - THIS_DOVALUE < 0 THEN
								#如果是扣到了池子中的最后一年，那么可以扣成负数
								IF THIS_DOYEAR = MY_POOL_MAX_YEAR THEN
									SET THIS_YEAR_DOVALUE = THIS_YEAR_DOVALUE + THIS_DOVALUE;
									SET THIS_YEARLEFT = THIS_YEARLEFT - THIS_DOVALUE;
									SET THIS_DOVALUE_UNDONE = 0;
#SELECT 1,THIS_DOVALUE_UNDONE;
									SET MY_DAILY_STR = RIGHT(MY_DAILY_STR,LENGTH(MY_DAILY_STR)-LOCATE(',',MY_DAILY_STR));
									SET IS_DAILY_OUT = 0;
								#如果不是最后一年，那么需要把当天没有扣到池子中的数放回每日信息，为下一年循环使用
								ELSE
									SET THIS_YEAR_DOVALUE = THIS_YEAR_DOVALUE + THIS_YEARLEFT;
									SET THIS_DOVALUE_UNDONE = THIS_DOVALUE - THIS_YEARLEFT;
#SELECT 2,THIS_DOVALUE_UNDONE,THIS_DOVALUE,THIS_YEARLEFT;
									SET THIS_YEARLEFT = 0;
									SET MY_DAILY_STR = CONCAT(THIS_DODATE,'|',THIS_DOVALUE_UNDONE,',',IFNULL(RIGHT(MY_DAILY_STR,LENGTH(MY_DAILY_STR)-LOCATE(',',MY_DAILY_STR)),''));
									SET IS_DAILY_OUT = 1;
								END IF;
							END IF;

							#记录当天的修改记录
							INSERT INTO att_st_icss_pool_log (emp_id,apply_id,dt,pool_type,which_year,op_type,do_value) 
								VALUES (MY_EMPID,MY_APPLYID,THIS_DODATE,MY_POOLTYPE,THIS_DOYEAR,MY_OPTYPE,THIS_DOVALUE-THIS_DOVALUE_UNDONE);

						ELSE
							SET MY_DAILY_STR = RIGHT(MY_DAILY_STR,LENGTH(MY_DAILY_STR)-LOCATE(',',MY_DAILY_STR));	
						END IF;
#SELECT THIS_DOYEAR,THIS_DOVALUE,THIS_DOVALUE_UNDONE,MY_POOL_MAX_YEAR;
					END WHILE;
					
					#记录到当年的池子
					#年假池
					IF MY_POOLTYPE = 1 THEN
						#更新操作LOG
						REPLACE INTO att_hol_year_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_year_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_YEARLEFT);

						#更新年假池
						UPDATE att_hol_year A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
					#调休池
					ELSEIF MY_POOLTYPE = 2 THEN
						#调休
						IF MY_OPTYPE = 2 THEN
							#更新操作LOG
							REPLACE INTO att_hol_rest_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
								VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
							REPLACE INTO att_hol_rest_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
								VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_YEARLEFT);
	
							#更新调休池
							UPDATE att_hol_rest A 
							SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
								A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
							WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;

						#加班
						ELSEIF MY_OPTYPE = 1 THEN
							#更新操作LOG
							REPLACE INTO att_hol_rest_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
								VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_HAVE',THIS_ORIHAVE,THIS_YEAR_DOVALUE,THIS_ORIHAVE+THIS_YEAR_DOVALUE);
							REPLACE INTO att_hol_rest_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
								VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,THIS_YEAR_DOVALUE,THIS_YEARLEFT);
	
							#更新调休池
							UPDATE att_hol_rest A 
							SET A.THIS_YEAR_USE = IFNULL(A.this_year_have,0) + THIS_YEAR_DOVALUE,
								A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) + THIS_YEAR_DOVALUE
							WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;

						END IF;
					#预支年假池
					ELSEIF MY_POOLTYPE = 3 THEN
						#更新操作LOG
						REPLACE INTO att_hol_credit_year_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_credit_year_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_YEARLEFT);

						#更新调休池
						UPDATE att_hol_credit_year A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
						
					ELSEIF MY_POOLTYPE = 4 THEN
						#更新操作LOG
						REPLACE INTO att_hol_sick_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_sick_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_YEARLEFT);

						#更新调休池
						UPDATE att_hol_sick A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
						
					ELSEIF MY_POOLTYPE = 5 THEN
						#更新操作LOG
						REPLACE INTO att_hol_pay_rest_log (pool_type,emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (12,MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_pay_rest_log (pool_type,emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (12,MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_YEARLEFT);

						#更新调休池
						UPDATE att_hol_pay_rest A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0 AND A.pool_type=12;
						
					ELSEIF MY_POOLTYPE = 6 THEN
						#更新操作LOG
						REPLACE INTO att_hol_pay_rest_log (pool_type,emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (13,MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_pay_rest_log (pool_type,emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (13,MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_YEARLEFT);

						#更新调休池
						UPDATE att_hol_pay_rest A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0 AND A.pool_type=13;
						
						
					END IF;
					
				END IF;
				SET MY_POOL_STR = RIGHT(MY_POOL_STR,LENGTH(MY_POOL_STR)-LOCATE(',',MY_POOL_STR));
			END WHILE;
			
			
		#为预扣减而做的计算
		ELSEIF MY_DOVALUE > 0 AND MY_APPLY_STATE <> 1 AND MY_OPTYPE = 2 THEN
#SELECT 3;
			DELETE FROM att_st_icss_pool_log WHERE apply_id = MY_APPLYID and pool_type=MY_POOLTYPE AND op_type=MY_OPTYPE;
			#计算一下池子的剩余总量和最早最晚的年份，以后按年份顺序扣减
			#格式：年份|当年有|当年用|当年剩余,年份|当年有|当年用|当年剩余,...,
			#example：2019|2.00000|0.00000|2.00000,2020|4.00000|0.00000|0.00000,
			IF MY_POOLTYPE = 1 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_year A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;
			ELSEIF MY_POOLTYPE = 2 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_rest A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;
			ELSEIF MY_POOLTYPE = 3 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_credit_year A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;
			ELSEIF MY_POOLTYPE = 4 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_sick A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0;
			ELSEIF MY_POOLTYPE = 5 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_pay_rest A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0 AND A.pool_type=12;
			ELSEIF MY_POOLTYPE = 6 THEN
				SELECT CONCAT(IFNULL(GROUP_CONCAT(A.THIS_YEAR,'|',IFNULL(A.THIS_YEAR_HAVE,0),'|',IFNULL(A.THIS_YEAR_USE,0),'|',IFNULL(A.THIS_YEAR_LEFT,0) ORDER BY A.this_year),''),','),MAX(A.this_year)
					INTO MY_POOL_STR,MY_POOL_MAX_YEAR
				FROM att_hol_pay_rest A
				WHERE A.emp_id=MY_EMPID AND A.is_delete=0 AND A.pool_type=13;
			END IF;
			
			#首先循环可用的年假池信息
			SET ALL_DOVALUE = MY_DOVALUE;
			WHILE ALL_DOVALUE > 0 AND LOCATE(',',MY_POOL_STR) <= LENGTH(MY_POOL_STR) AND LOCATE(',',MY_POOL_STR) > 1 AND MY_POOL_STR IS NOT NULL AND MY_DOVALUE > 0 DO
			#格式：年份|当年有|当年用|当年剩余,年份|当年有|当年用|当年剩余,...,
			#example：2019|2.00000|0.00000|2.00000,2020|4.00000|0.00000|0.00000,
				SET THIS_POOL_STR=NULL,THIS_DOYEAR=NULL,THIS_ORIHAVE=NULL,THIS_ORIUSE=NULL,THIS_ORILEFT=NULL;
				SET THIS_POOL_STR = CONCAT(LEFT(MY_POOL_STR,LOCATE(',',MY_POOL_STR)-1),'|');
				#得到年份
				SET THIS_DOYEAR = CAST(LEFT(THIS_POOL_STR,LOCATE('|',THIS_POOL_STR)-1) AS UNSIGNED);
				SET THIS_POOL_STR = RIGHT(THIS_POOL_STR,LENGTH(THIS_POOL_STR)-LOCATE('|',THIS_POOL_STR));
				#得到原始当年有
				SET THIS_ORIHAVE = CAST(LEFT(THIS_POOL_STR,LOCATE('|',THIS_POOL_STR)-1) AS DECIMAL(10,5));
				SET THIS_POOL_STR = RIGHT(THIS_POOL_STR,LENGTH(THIS_POOL_STR)-LOCATE('|',THIS_POOL_STR));
				#得到原始当年用
				SET THIS_ORIUSE = CAST(LEFT(THIS_POOL_STR,LOCATE('|',THIS_POOL_STR)-1) AS DECIMAL(10,5));
				SET THIS_POOL_STR = RIGHT(THIS_POOL_STR,LENGTH(THIS_POOL_STR)-LOCATE('|',THIS_POOL_STR));
				#得到原始当年剩
				SET THIS_ORILEFT = CAST(LEFT(THIS_POOL_STR,LOCATE('|',THIS_POOL_STR)-1) AS DECIMAL(10,5));
					
				IF THIS_ORILEFT IS NOT NULL THEN
					IF THIS_DOYEAR <> MY_POOL_MAX_YEAR THEN
						IF THIS_ORILEFT - ALL_DOVALUE >= 0 THEN
							SET THIS_YEAR_DOVALUE = ALL_DOVALUE;
							SET ALL_DOVALUE = 0;
						ELSE
							SET THIS_YEAR_DOVALUE = THIS_ORILEFT;
							SET ALL_DOVALUE = ALL_DOVALUE - THIS_ORILEFT;
						END IF;
					ELSE
						SET THIS_YEAR_DOVALUE = ALL_DOVALUE;
						SET ALL_DOVALUE = 0;
					END IF;
					#记录到当年的池子
					#年假池
					IF MY_POOLTYPE = 1 THEN
						#更新操作LOG
						REPLACE INTO att_hol_year_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_year_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_ORILEFT - THIS_YEAR_DOVALUE);

						#更新年假池
						UPDATE att_hol_year A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
					#调休池
					ELSEIF MY_POOLTYPE = 2 THEN
						#更新操作LOG
						REPLACE INTO att_hol_rest_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_rest_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_ORILEFT - THIS_YEAR_DOVALUE);

						#更新调休池
						UPDATE att_hol_rest A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;

					#预支年假池
					ELSEIF MY_POOLTYPE = 3 THEN
						#更新操作LOG
						REPLACE INTO att_hol_credit_year_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_credit_year_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_ORILEFT - THIS_YEAR_DOVALUE);

						#更新调休池
						UPDATE att_hol_credit_year A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
						
					ELSEIF MY_POOLTYPE = 4 THEN
						#更新操作LOG
						REPLACE INTO att_hol_sick_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_sick_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_ORILEFT - THIS_YEAR_DOVALUE);

						#更新调休池
						UPDATE att_hol_sick A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;
						
					ELSEIF MY_POOLTYPE = 5 THEN
						#更新操作LOG
						REPLACE INTO att_hol_pay_rest_log (pool_type,emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (12,MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_pay_rest_log (pool_type,emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (12,MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_ORILEFT - THIS_YEAR_DOVALUE);

						#更新调休池
						UPDATE att_hol_pay_rest A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0 AND A.pool_type=12;
						
					ELSEIF MY_POOLTYPE = 6 THEN
						#更新操作LOG
						REPLACE INTO att_hol_pay_rest_log (pool_type,emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (13,MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_USE',THIS_ORIUSE,THIS_YEAR_DOVALUE,THIS_ORIUSE+THIS_YEAR_DOVALUE);
						REPLACE INTO att_hol_pay_rest_log (pool_type,emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
							VALUES (13,MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,-THIS_YEAR_DOVALUE,THIS_ORILEFT - THIS_YEAR_DOVALUE);

						#更新调休池
						UPDATE att_hol_pay_rest A 
						SET A.THIS_YEAR_USE = IFNULL(A.THIS_YEAR_USE,0) + THIS_YEAR_DOVALUE,
							A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) - THIS_YEAR_DOVALUE
						WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0 AND A.pool_type=13;
						
						
					END IF;
				END IF;
				
				SET THIS_DT = NULL;
				SELECT DATE(A.start_time) INTO THIS_DT FROM att_hol_apply A WHERE A.apply_id=MY_APPLYID;
				IF THIS_DT = NULL THEN
					SELECT DATE(A.rest_start_time) INTO THIS_DT FROM att_over_apply_with_rest A WHERE A.apply_id=MY_APPLYID;
				END IF;
				
				#记录当天的修改记录
				INSERT INTO att_st_icss_pool_log (emp_id,apply_id,dt,pool_type,which_year,op_type,do_value) 
					VALUES (MY_EMPID,MY_APPLYID,IFNULL(THIS_DT,DATE(NOW())),MY_POOLTYPE,THIS_DOYEAR,MY_OPTYPE,THIS_YEAR_DOVALUE);
				
				SET MY_POOL_STR = RIGHT(MY_POOL_STR,LENGTH(MY_POOL_STR)-LOCATE(',',MY_POOL_STR));
			END WHILE;
		#加班
		ELSEIF MY_DOVALUE > 0 AND MY_OPTYPE = 1 AND MY_POOLTYPE = 2 THEN
			DELETE FROM att_st_icss_pool_log WHERE apply_id = MY_APPLYID;			
			SET MY_DAILY_STR = NULL,THIS_DOYEAR = NULL;
			SELECT CONCAT(IFNULL(GROUP_CONCAT(A.work_day,'|',A.work_hour),''),',')
				INTO MY_DAILY_STR
			FROM att_over_apply_day A
			WHERE A.apply_id=MY_APPLYID AND A.date_repay_type=2 AND A.work_hour > 0 AND A.is_over_with_rest=0;	
						
			SELECT IF(MONTH(A.start_time) < 3 ,YEAR(A.start_time)-1,IF(MONTH(A.start_time)=3 AND DAY(A.start_time)=1 AND TIME(A.start_time)<'05:00:00',YEAR(A.start_time)-1,YEAR(A.start_time))) INTO THIS_DOYEAR 
			FROM att_over_apply A WHERE A.apply_id=MY_APPLYID;
#select THIS_DOYEAR;			
			SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_left,0)
				INTO THIS_ORIHAVE,THIS_ORILEFT
			FROM att_hol_rest A 
			WHERE A.emp_id=MY_EMPID AND A.this_year=THIS_DOYEAR AND A.is_delete=0;
			
			WHILE LOCATE(',',MY_DAILY_STR) <= LENGTH(MY_DAILY_STR) AND LOCATE(',',MY_DAILY_STR) > 1 AND MY_DAILY_STR IS NOT NULL DO
				SET THIS_DAILY_STR=NULL,THIS_DODATE=NULL,THIS_DOVALUE=NULL;
				SET THIS_DAILY_STR = CONCAT(LEFT(MY_DAILY_STR,LOCATE(',',MY_DAILY_STR)-1),'|');
				#得到年份
				SET THIS_DODATE = CAST(LEFT(THIS_DAILY_STR,LOCATE('|',THIS_DAILY_STR)-1) AS DATE);
				SET THIS_DAILY_STR = RIGHT(THIS_DAILY_STR,LENGTH(THIS_DAILY_STR)-LOCATE('|',THIS_DAILY_STR));
				#得到原始当年有
				SET THIS_DOVALUE = CAST(LEFT(THIS_DAILY_STR,LOCATE('|',THIS_DAILY_STR)-1) AS DECIMAL(10,5));

				IF THIS_DOVALUE > 0 AND THIS_DOVALUE IS NOT NULL THEN
					#记录当天的修改记录
					INSERT INTO att_st_icss_pool_log (emp_id,apply_id,dt,pool_type,which_year,op_type,do_value) 
						VALUES (MY_EMPID,MY_APPLYID,THIS_DODATE,MY_POOLTYPE,THIS_DOYEAR,MY_OPTYPE,THIS_DOVALUE);
				END IF;
				SET MY_DAILY_STR = RIGHT(MY_DAILY_STR,LENGTH(MY_DAILY_STR)-LOCATE(',',MY_DAILY_STR));	
			END WHILE;
			
			#更新操作LOG
			REPLACE INTO att_hol_rest_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
				VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_HAVE',THIS_ORIHAVE,MY_DOVALUE,THIS_ORIHAVE+MY_DOVALUE);
			REPLACE INTO att_hol_rest_log (emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value)
				VALUES (MY_EMPID,MY_APPLYID,THIS_DOYEAR,'THIS_YEAR_LEFT',THIS_ORILEFT,MY_DOVALUE,THIS_ORILEFT+MY_DOVALUE);

			#更新调休池
			UPDATE att_hol_rest A 
			SET A.this_year_have = IFNULL(A.this_year_have,0) + MY_DOVALUE,
				A.THIS_YEAR_LEFT = IFNULL(A.THIS_YEAR_LEFT,0) + MY_DOVALUE
			WHERE A.emp_id=MY_EMPID AND A.THIS_YEAR=THIS_DOYEAR AND A.is_delete=0;

		END IF;
	#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   PART2 正常操作 END   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		
	END IF;
END;

