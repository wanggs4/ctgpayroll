create function FN_ATT_GET_STID(CUSTID bigint unsigned, MONVER bigint)
  returns bigint unsigned
  BEGIN
DECLARE THIS_STID BIGINT UNSIGNED;
DECLARE BGDT,EDDT DATE;


	IF CUSTID IS NOT NULL AND MONVER IS NOT NULL THEN
		SELECT A.st_id INTO THIS_STID
		FROM att_st_month A
		WHERE A.cust_id=CUSTID AND A.`version` = MONVER;
		
		IF THIS_STID IS NULL THEN
			SELECT A.begin_date,A.end_date INTO BGDT,EDDT
			FROM cust_period_schedule A
			WHERE A.cust_id=CUSTID AND A.year_mon=MONVER AND A.period_type=1;
			
			SELECT IFNULL(MAX(st_id),0) + 1 INTO THIS_STID FROM att_st_month A WHERE A.st_id < 1000000000;
			
			INSERT INTO att_st_month   (st_id,cust_id,comp_start_time,comp_end_time,creator_id,create_time,`version`) 
				VALUES (THIS_STID,CUSTID,BGDT,EDDT,1,now(),MONVER);
		END IF;
	END IF;
RETURN THIS_STID;
END;

