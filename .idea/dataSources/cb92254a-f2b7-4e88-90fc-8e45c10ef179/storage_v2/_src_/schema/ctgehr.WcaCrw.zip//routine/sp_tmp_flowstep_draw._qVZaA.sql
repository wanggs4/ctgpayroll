create procedure SP_TMP_FLOWSTEP_DRAW()
  BEGIN
DECLARE THIS_STPID,THIS_FLID,COL_COUNTER,X_PT,Y_PT,CT,MXCT,STP_CT,STP_MXCT BIGINT UNSIGNED;

	drop table if exists tmp_flow_list;
	CREATE TABLE `tmp_flow_list` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`flow_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '审批流id',
		PRIMARY KEY (`id`)
	)ENGINE=InnoDB;
	
	drop table if exists tmp_flow_step_list;
	CREATE TABLE `tmp_flow_step_list` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`step_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '节点id',
		`flow_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '审批流id',
		PRIMARY KEY (`id`)
	)ENGINE=InnoDB;

	INSERT INTO tmp_flow_list (flow_id) select distinct flow_id from flow_set_step;
	INSERT INTO tmp_flow_step_list (step_id,flow_id) Select a.step_id,a.flow_id from flow_set_step a order by a.flow_id,a.step_point,a.step_id;
	
	SET CT = 0,MXCT = 0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_flow_list;
	WHILE CT <= MXCT AND CT > 0 DO
		SELECT FLOW_ID INTO THIS_FLID FROM tmp_flow_list WHERE ID = CT;
		IF THIS_FLID IS NOT NULL THEN
			SET STP_CT=0,STP_MXCT=0;
			SELECT MIN(ID),MAX(ID) INTO STP_CT,STP_MXCT FROM tmp_flow_step_list A WHERE A.flow_id=THIS_FLID;
			SET COL_COUNTER=1,X_PT=100,Y_PT=100;
			WHILE STP_CT <= STP_MXCT AND STP_CT > 0 DO
				SELECT A.step_id INTO THIS_STPID FROM tmp_flow_step_list A WHERE A.id=STP_CT;
				IF THIS_STPID IS NOT NULL THEN
					IF COL_COUNTER IN (2,3) THEN
						SET X_PT = X_PT + 300;
					ELSEIF COL_COUNTER > 3 THEN
						SET COL_COUNTER = 1;
						SET Y_PT = Y_PT + 300;
						SET X_PT = 100;
					END IF;
					
					UPDATE flow_set_step A SET A.top_px=Y_PT,A.left_px=X_PT WHERE A.step_id=THIS_STPID;
				END IF;
				SET COL_COUNTER = COL_COUNTER + 1;
				SET STP_CT = STP_CT + 1;
			END WHILE;
		END IF;
		SET CT = CT + 1;
	END WHILE;
	drop table if exists tmp_flow_list;
	drop table if exists tmp_flow_step_list;
END;

