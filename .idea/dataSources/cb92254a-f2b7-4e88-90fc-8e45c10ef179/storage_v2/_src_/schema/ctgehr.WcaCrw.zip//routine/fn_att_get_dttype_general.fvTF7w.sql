create function FN_ATT_GET_DTTYPE_GENERAL(bgdt date)
  returns int
  comment '得到某一天的类型（1工作日 2周末 3法定节假日 4法定节假日调整的周末 5特殊节假日 6特殊工作日）'
  BEGIN
DECLARE dttype,do_have_att,is_have_emp,ieh INT;
DECLARE workday VARCHAR(20);
DECLARE ATTID_STR,IS_TODAY_SPECIAL_WORKDAY TEXT;
	
	#日期判定 是否为涉及到节假日的日期,如果不是，则根据出勤设置的工作日判断工作日还是周末
	SET workday = '1,2,3,4,5,';	
	SET ieh = 1;	
	#日期判定 首先看法定节假日是否生效，如果生效，先从节假日表读出节假日的类型，剩下的再从工作日中辨别
	#判断是否工作日，weekday 周一起点 依次0-6
	#先判断法定节假日
	IF dttype IS NULL THEN
		select date_type into dttype from dict_hol_date where dt=bgdt;
	END IF;
	
	IF dttype IS NULL THEN
		if (locate(concat(weekday(bgdt)+1,','),workday)>0) then 	#if2
			set dttype=1;
		else
			set dttype=2;
		end if;																	#if2	
	END IF;
	
	RETURN dttype;
END;

