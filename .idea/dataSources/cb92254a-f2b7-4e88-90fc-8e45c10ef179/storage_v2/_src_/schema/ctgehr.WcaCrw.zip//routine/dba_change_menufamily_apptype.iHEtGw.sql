create procedure DBA_CHANGE_MENUFAMILY_APPTYPE(IN PARENTID bigint unsigned, IN TYPEVALUE int)
  comment '批量更改au_menus某个节点下所有子节点的apptype'
  BEGIN
DECLARE MY_ROOTCODE VARCHAR(300);
	SELECT A.menu_code INTO MY_ROOTCODE FROM au_menus_tree A WHERE A.menu_id=PARENTID;
	
	SET @SQL_UPDT = CONCAT('UPDATE au_menus A,au_menus_tree B SET A.app_type = ',TYPEVALUE,' WHERE A.menu_id=B.menu_id AND B.menu_code LIKE ''',MY_ROOTCODE,'%'';');
	PREPARE stmt1 FROM @SQL_UPDT;
	EXECUTE stmt1;
	DEALLOCATE PREPARE stmt1;

END;

