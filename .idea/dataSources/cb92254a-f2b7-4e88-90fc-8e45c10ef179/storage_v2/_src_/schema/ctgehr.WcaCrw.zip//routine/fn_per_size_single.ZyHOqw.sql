create function FN_PER_SIZE_SINGLE(op_type int, cdid bigint unsigned, value int)
  returns int
  comment '为部门或公司的限制值加减，并返回是否超出限额'
  BEGIN

DECLARE THIS_CUSTID,THIS_NOW_VALUE,THIS_MAX_VALUE,THIS_DEPTID,LVCT,MAX_VALUE,NOW_VALUE,NOW_VALUE_2,RES,THIS_DEPTLVCODE,MY_DEPTLVCODE  BIGINT;
DECLARE THIS_LOGICCODE VARCHAR(20);
                
	IF op_type IS NOT NULL AND cdid IS NOT NULL AND value IS NOT NULL  THEN
		#按照给的value值进行判断，如果有值且不等于0，那么需要验证是否超出限制并且在现有人数中增加
		IF value <> 0 THEN
			#当操作类型为1，对公司进行操作，也就是部门表中的顶级部门
			IF op_type = 1 THEN
				SELECT upper_limit_of_personnel INTO MAX_VALUE FROM dept_info a WHERE cust_id = cdid and a.dept_type=1 and a.dept_lv_code=0 and a.is_enable=1;
				IF MAX_VALUE > 0 AND MAX_VALUE IS NOT NULL THEN
					SELECT COUNT(*) INTO NOW_VALUE 
					FROM emp_base_info a left join emp_post b on a.emp_id=b.emp_id 
					WHERE a.cust_id=cdid AND a.is_delete=0 
						AND (a.emp_state in (1,3) and b.entry_date is not null) or (a.emp_state is null and b.entry_date>date(now()));
						
					select count(*) INTO NOW_VALUE_2
					from att_exam_step a 
					where exam_source = 4 and exam_anchor = 1 and is_over = 0 and state = 2 and a.cust_id = cdid;
					
					IF NOW_VALUE IS NULL THEN SET NOW_VALUE = 0; END IF;
					IF NOW_VALUE_2 IS NULL THEN SET NOW_VALUE_2 = 0; END IF;
					
					SET NOW_VALUE = NOW_VALUE + NOW_VALUE_2;
				END IF;
			#操作类型为2，对部门进行操作
			ELSEIF op_type = 2 THEN
				#读取部门的上限设置和有上限设置的父级id
				SELECT a.upper_limit_of_personnel
				       INTO MAX_VALUE 
				FROM dept_info a 
				WHERE a.dept_id=cdid and a.dept_type=1 and a.is_enable=1;
				
				#如果目标部门没有上限设置，那么需要按照有上限设置的父级id去找相应的数据
				IF MAX_VALUE IS NOT NULL AND MAX_VALUE > 0 THEN
					SELECT count(*) into NOW_VALUE
					FROM emp_base_info a left join emp_post b on a.emp_id=b.emp_id
					WHERE a.is_delete=0 and a.dept_id = cdid 
						AND ((a.emp_state in (1,3) and b.entry_date is not null) or (a.emp_state is null and b.entry_date>date(now())));
						
					select count(*) INTO NOW_VALUE_2
					from att_exam_step a 
					where exam_source = 4 and exam_anchor = 1 and is_over = 0 and state = 2 and a.dept_id = cdid;
				
				END IF;
			        
			END IF;
			
			#合理性校验
			IF NOW_VALUE IS NULL THEN SET NOW_VALUE = 0; END IF;
			IF NOW_VALUE_2 IS NULL THEN SET NOW_VALUE_2 = 0; END IF;
			SET NOW_VALUE = NOW_VALUE + NOW_VALUE_2;
			
			#当上限设置有值且现有人数加上value的人数后还够，或者上限设置是0或null时，就可以往里插人。
			IF ((MAX_VALUE IS NOT NULL AND MAX_VALUE<>0) AND (NOW_VALUE + value <= MAX_VALUE AND NOW_VALUE + value >= 0)) THEN
				#公司
				IF op_type = 1 THEN
					UPDATE cust_info SET perso_size = NOW_VALUE + value WHERE cust_id = cdid;
					UPDATE dept_info a SET a.per_size = NOW_VALUE + value WHERE cust_id = cdid and a.dept_type=1 and a.dept_lv_code=0 and a.is_enable=1;
				#部门
				ELSEIF op_type = 2 THEN
					#再更新
					UPDATE dept_info A 
					SET A.per_size = NOW_VALUE + value
					WHERE A.dept_id=cdid and dept_type=1 AND A.is_enable=1;
				END IF;
				SET RES = 1;
			#否则不可以插人
			ELSEIF MAX_VALUE IS NULL OR MAX_VALUE=0 AND NOW_VALUE IS NULL THEN
				SET RES = 1;
			ELSE
				SET RES = 0;
			END IF;
		#如果value为零，代表不插入人
		ELSEIF value = 0 THEN
			
			IF op_type = 1 THEN
				SELECT upper_limit_of_personnel INTO MAX_VALUE FROM dept_info a WHERE cust_id = cdid and dept_type=1 and a.dept_lv_code=0 and a.is_enable=1;
				IF MAX_VALUE IS NOT NULL THEN
					SELECT COUNT(*) INTO NOW_VALUE 
					FROM emp_base_info a left join emp_post b on a.emp_id=b.emp_id 
					WHERE a.cust_id=cdid AND a.is_delete=0 
						AND (a.emp_state in (1,3) and b.entry_date is not null) or (a.emp_state is null and b.entry_date>date(now()));
						
					select count(*) INTO NOW_VALUE_2
					from att_exam_step a 
					where exam_source = 4 and exam_anchor = 1 and is_over = 0 and state = 2 and a.cust_id = cdid;
					
					IF NOW_VALUE IS NULL THEN SET NOW_VALUE = 0; END IF;
					IF NOW_VALUE_2 IS NULL THEN SET NOW_VALUE_2 = 0; END IF;
					
					SET NOW_VALUE = NOW_VALUE + NOW_VALUE_2;
				ELSE
					SET NOW_VALUE = NULL;
				END IF;
			#操作类型为2，对部门进行操作
			ELSEIF op_type = 2 THEN
				#读取部门的上限设置和有上限设置的父级id
				SELECT a.upper_limit_of_personnel
				       INTO MAX_VALUE 
				FROM dept_info a 
				WHERE a.dept_id=cdid and a.dept_type=1 and a.is_enable=1;
				
				IF MAX_VALUE IS NOT NULL THEN
				
					SELECT count(*) into NOW_VALUE
					FROM emp_base_info a left join emp_post b on a.emp_id=b.emp_id
					WHERE a.is_delete=0 and a.dept_id = cdid 
						AND ((a.emp_state in (1,3) and b.entry_date is not null) or (a.emp_state is null and b.entry_date>date(now())));
						
					select count(*) INTO NOW_VALUE_2
					from att_exam_step a 
					where exam_source = 4 and exam_anchor = 1 and is_over = 0 and state = 2 and a.dept_id = cdid;
				
					#合理性校验
					IF NOW_VALUE IS NULL THEN SET NOW_VALUE = 0; END IF;
					IF NOW_VALUE_2 IS NULL THEN SET NOW_VALUE_2 = 0; END IF;
					SET NOW_VALUE = NOW_VALUE + NOW_VALUE_2;
				END IF;
			        
			END IF;
			
						
			IF MAX_VALUE IS NULL OR MAX_VALUE = 0 THEN
				SET MAX_VALUE = 9999999999999;
			END IF;
			IF NOW_VALUE IS NULL THEN SET NOW_VALUE = 0; END IF;
			#瓒呭嚭杩斿洖0 锛屾病瓒呭嚭杩斿洖1
			IF NOW_VALUE < MAX_VALUE OR MAX_VALUE IS NULL OR MAX_VALUE = 0 THEN
				SET RES = 1;
			ELSE
				SET RES = 0;
			END IF;
		
		END IF;
	ELSE
		SET RES = 0;
	END IF;
RETURN RES;

END;

