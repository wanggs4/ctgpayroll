create function FN_ATT_GET_OVER_HOURS(bgdt datetime, eddt datetime, otid bigint unsigned, deptid bigint unsigned,
                                      emp  bigint unsigned)
  returns decimal(12, 2)
  comment '得到加班的实际时长'
  BEGIN
DECLARE ohours,MY_THIS_OTIME DECIMAL(12,2);
DECLARE MST,MET,AST,AET,MY_THIS_OVER_BG_TIME,MY_THIS_OVER_ED_TIME,i_bgtm,i_edtm TIME;
DECLARE real_bgdt,i_bgdt,i_eddt DATE;
DECLARE IS_IN_SPHOL,IS_OVER_SET_DONE,IS_HAVE_ATT,i_is_overtime,i_dttype,i_over_min_unit,i_compute_rule INT;
DECLARE MY_ATT_ID BIGINT UNSIGNED;
DECLARE ATTID_STR TEXT;
	SET ohours=0;

	#判断参数无效性，当deptid和emp其中一个不为空，且起始时间小于等于结束时间才做计算。
	IF emp IS NOT NULL AND bgdt<=eddt AND otid IS NOT NULL THEN
		#初始化时间变量
		SET i_bgdt = DATE(bgdt);
		SET i_eddt = DATE(eddt);
		SET i_bgtm = TIME(bgdt);
		SET i_edtm = TIME(eddt);
		
		IF i_bgtm < '05:00:00' THEN
			SET i_bgdt = DATE_ADD(i_bgdt,INTERVAL -1 DAY);
			
		END IF;
		
		IF i_edtm < '05:00:00' THEN
			SET i_eddt = DATE_ADD(i_eddt,INTERVAL -1 DAY);
		END IF;

		
		SET real_bgdt = i_bgdt;
		
		SET ohours = 0; 
			
		#开始循环每一天
		WHILE(i_bgdt<=i_eddt) DO
			SET ATTID_STR=NULL,MY_ATT_ID=NULL,i_over_min_unit=NULL,i_compute_rule=NULL,MST=NULL,MET=NULL,AST=NULL,AET=NULL;
			SET MY_THIS_OTIME = 0,MY_THIS_OVER_BG_TIME = NULL,MY_THIS_OVER_ED_TIME = NULL;
			#读出考勤设置
			CALL SP_DPT_GET_SETTINGID(emp,i_bgdt,1,ATTID_STR);
			SET MY_ATT_ID = CAST(ATTID_STR AS UNSIGNED);
			
			
			IF MY_ATT_ID IS NOT NULL THEN
				#读出加班设置
				SELECT A.over_min_unit,A.compute_rule
					INTO i_over_min_unit,i_compute_rule
				FROM att_set_overtime_new A
				WHERE A.ot_id=otid ;
				
				SELECT a.morn_start_time,a.morn_end_time,a.aftn_start_time,a.aftn_end_time
					INTO MST,MET,AST,AET
				FROM att_set_schema_new a 
				where a.att_id=MY_ATT_ID;

				SET i_dttype = FN_ATT_GET_DTTYPE(i_bgdt,emp);
				
				IF real_bgdt = i_eddt THEN	#当加班起止时间在同一天
					SET MY_THIS_OVER_BG_TIME = i_bgtm;
					SET MY_THIS_OVER_ED_TIME = i_edtm;
					
				ELSEIF real_bgdt < i_eddt AND (i_bgdt = real_bgdt) THEN			#第一天的情况
					SET MY_THIS_OVER_BG_TIME = i_bgtm;
					SET MY_THIS_OVER_ED_TIME = '04:59:59';
				ELSEIF real_bgdt < i_eddt AND (i_bgdt = i_eddt) THEN		#最后一天的情况
					SET MY_THIS_OVER_BG_TIME = '05:00:00';
					SET MY_THIS_OVER_ED_TIME = i_edtm;
				ELSE #其余的
					SET MY_THIS_OVER_BG_TIME = '05:00:00';
					SET MY_THIS_OVER_ED_TIME = '04:59:59';
				END IF;
								
				SET MY_THIS_OTIME = FN_ATT_GET_REAL_OVER_HOURS(MY_THIS_OVER_BG_TIME,MY_THIS_OVER_ED_TIME,MY_ATT_ID,otid,emp,i_bgdt);
#select 	i_bgdt,MY_THIS_OVER_BG_TIME,MY_THIS_OVER_ED_TIME,MY_THIS_OTIME;					
			ELSE 
				SET MY_THIS_OTIME = 0;
			END IF;
			
			SET ohours = ohours + IFNULL(MY_THIS_OTIME,0);
			SET i_bgdt = DATE_ADD(i_bgdt,INTERVAL 1 DAY);
		END WHILE;

		IF ohours < 0 THEN SET ohours = 0; END IF;
	ELSE									#参数校验有问题的情况
		SET ohours=0;
	END IF;
RETURN ohours;
END;

