create procedure SP_ATT_REVERSE_MONTH_REPORT(IN bgdt date, IN eddt date, IN archid bigint)
  comment '通过月报逆向计算相应的钱数'
  BEGIN
DECLARE ct,mxct,ctn,mxctn,i_emp,i_deptid,i_custid,i_st_type,i_is_year_hol,i_hol_id,i_ot_id,i_st_unit BIGINT;
DECLARE	i_st_key,i_st_name,i_st_value VARCHAR(50);
DECLARE my_money,my_sala_prog_value DECIMAL(13,2);
DECLARE i_version_code VARCHAR(50);
SET i_version_code = UUID();
SET @i_version_code = i_version_code;

	delete from  tmp_reverse_emp_list where version_code = i_version_code;
	delete from  tmp_reverse_item where version_code = i_version_code;
/*	
  #创建用于存放人名单的临时表
  DROP TABLE IF EXISTS tmp_reverse_emp_list;
  CREATE TEMPORARY TABLE tmp_reverse_emp_list (
   id bigint unsigned not null AUTO_INCREMENT,
   emp_id bigint unsigned ,
   dept_id bigint unsigned ,
   cust_id bigint unsigned ,
     primary key (ID),
     INDEX `idx_cust_id` (`cust_id`),
     INDEX `idx_dept_id` (`dept_id`)
  )engine=memory;
  
  #创建用于存放统计项目的临时表
  DROP TABLE IF EXISTS tmp_reverse_item;
  CREATE TEMPORARY TABLE tmp_reverse_item (
   id bigint unsigned not null AUTO_INCREMENT,
   st_type tinyint,
   st_key varchar(50),
   st_name varchar(50),
   hol_id bigint unsigned,
   is_year_hol tinyint,
   
     primary key (ID)
  )engine=memory;

*/
	#把月报的员工写入临时表
	delete from  tmp_reverse_emp_list where version_code = i_version_code;
	INSERT INTO tmp_reverse_emp_list (version_code,emp_id,dept_id,cust_id) 
		SELECT DISTINCT i_version_code,a.emp_id,a.dept_id,b.cust_id 
		FROM att_st_month_arch_items a left join att_st_month_arch b on a.arch_id=b.arch_id
		WHERE a.arch_id=archid;
				
	#把月报的统计项写入临时表
	SELECT cust_id INTO i_custid FROM att_st_month_arch WHERE arch_id=archid;
	delete from  tmp_reverse_item where version_code = i_version_code;
	INSERT INTO tmp_reverse_item (version_code,st_type,st_key,st_name,hol_id,is_year_hol) 
		VALUES 
				(i_version_code,2,'jrjbsc','节日加班时长（小时）',null,null),
				(i_version_code,2,'gxjbsc','公休加班时长（小时）',null,null),
				(i_version_code,2,'prjbsc','平日加班时长（小时）',null,null);

	#2 得到员工所在公司的假期设置 写进tmp_reverse_item表
	INSERT INTO tmp_reverse_item (version_code,st_type,st_key,st_name,hol_id,is_year_hol) 
		SELECT DISTINCT i_version_code,1,hol_code,hol_name,hol_id,is_year_hol 
		FROM att_set_holiday WHERE cust_id = i_custid and `status`=1 and is_delete=0;


	#遍历每个员工
	SET ct = 0;
	SET mxct = 0;
	SELECT MIN(id),MAX(id) INTO ct,mxct FROM tmp_reverse_emp_list where version_code = i_version_code;
	IF ct IS NULL THEN SET ct = 0 ; END IF;
	IF mxct IS NULL THEN SET mxct = 0 ; END IF;
	WHILE (ct <= mxct and ct>0) DO
		SET i_emp=NULL;
		SET i_deptid=NULL;
		SET i_custid=NULL;
		SELECT emp_id,dept_id,cust_id INTO i_emp,i_deptid,i_custid FROM tmp_reverse_emp_list WHERE id = ct and version_code = i_version_code;
		
		
		IF i_emp IS NOT NULL THEN
			# 遍历每个项目
			SET ctn = 0;
			SET mxctn = 0;
			SELECT MIN(id),MAX(id) INTO ctn,mxctn FROM tmp_reverse_item where version_code = i_version_code;
			IF ctn IS NULL THEN SET ctn = 0 ; END IF;
			IF mxctn IS NULL THEN SET mxctn = 0 ; END IF;
			
			WHILE (ctn <= mxctn and ctn>0) DO
				SET i_st_type=NULL;
				SET i_st_key=NULL;
				SET i_st_name=NULL;
				SET i_hol_id=NULL;
				SET i_is_year_hol=NULL;
			
				#读出单一项信息
				SELECT  st_type,st_key,st_name,hol_id,is_year_hol 
					INTO i_st_type,i_st_key,i_st_name,i_hol_id,i_is_year_hol
				FROM tmp_reverse_item
				WHERE id = ctn and version_code = i_version_code;
				
				IF i_st_key IS NOT NULL THEN
					#读出单一项具体值
					SELECT st_value INTO i_st_value FROM att_st_month_arch_items WHERE ARCH_ID=archid AND EMP_ID = i_emp AND st_key = i_st_key;
		
		
					#固定项反算
					IF (i_st_type=2) THEN
						#得到薪酬项目的值
						SELECT ot_id INTO i_ot_id FROM att_set_overtime WHERE cust_id = i_custid and is_overtime=1;
						CALL SP_ATT_GET_SALA_PROG(i_emp,bgdt,eddt,2,i_ot_id,my_sala_prog_value);
		#SELECT i_emp,bgdt,eddt,2,i_ot_id,my_sala_prog_value;
						#分别扣除加班发薪时数
						CASE i_st_key
						WHEN 'jrjbsc' THEN			#节日加班时长（小时）
							SET my_money = my_sala_prog_value / 21.75 / 8 * 3 * i_st_value ;
						WHEN 'gxjbsc' THEN			#公休加班时长（小时）
							SET my_money = my_sala_prog_value / 21.75 / 8 * 2 * i_st_value ;
						WHEN 'prjbsc' THEN			#平日加班时长（小时）
							SET my_money = my_sala_prog_value / 21.75 / 8 * 1.5 * i_st_value ;
						END CASE;
					#自定义项反算
					ELSE
						#得到薪酬项目的值
						IF i_is_year_hol =1 THEN
							SELECT st_unit into i_st_unit FROM att_set_holiday_year WHERE hol_id = i_hol_id;
							CALL SP_ATT_GET_SALA_PROG(i_emp,bgdt,eddt,3,i_hol_id,my_sala_prog_value);
		#SELECT i_emp,bgdt,eddt,3,i_hol_id,my_sala_prog_value;
						ELSE
							SELECT st_unit into i_st_unit FROM att_set_holiday WHERE hol_id = i_hol_id;
							CALL SP_ATT_GET_SALA_PROG(i_emp,bgdt,eddt,4,i_hol_id,my_sala_prog_value);
		#SELECT i_emp,bgdt,eddt,4,i_hol_id,my_sala_prog_value;
						END IF;
						
						IF i_st_unit =2 THEN	#单位是小时
							set my_money = my_sala_prog_value / 21.75 / 8 * i_st_value ;
						ELSEIF i_st_unit =1 THEN					#单位是天
							set my_money = my_sala_prog_value / 21.75 * i_st_value ;
						ELSE
							SET my_money = 0;
						END IF;
					END IF;
					
					UPDATE att_st_month_arch_items SET st_money = my_money WHERE ARCH_ID=archid AND EMP_ID = i_emp AND st_key = i_st_key;
				END IF;
				SET ctn = ctn + 1;
			END WHILE;
		END IF;
		SET ct = ct + 1;
	END WHILE;
	delete from  tmp_reverse_emp_list where version_code = i_version_code;
	delete from  tmp_reverse_item where version_code = i_version_code;
	
#	SET stat = 1;

END;

