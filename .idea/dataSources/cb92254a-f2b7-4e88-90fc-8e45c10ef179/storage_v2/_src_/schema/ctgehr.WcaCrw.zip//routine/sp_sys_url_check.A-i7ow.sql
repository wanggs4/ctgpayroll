create procedure SP_SYS_URL_CHECK(INOUT ST int)
  comment '清除文件系统中无效文件的过程。'
  BEGIN


	
	REPLACE INTO sys_file_db_list (cust_id,file_url) SELECT DISTINCT cust_id, license_photo FROM cust_info WHERE license_photo IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,file_url) SELECT DISTINCT cust_id, logo_url FROM cust_info WHERE logo_url IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, id_card1 FROM emp_attachment WHERE id_card1 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, id_card2 FROM emp_attachment WHERE id_card2 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, deploma FROM emp_attachment WHERE deploma IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, degree FROM emp_attachment WHERE degree IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, bank_card FROM emp_attachment WHERE bank_card IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, med_report FROM emp_attachment WHERE med_report IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, es_cert FROM emp_attachment WHERE es_cert IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, title_cert FROM emp_attachment WHERE title_cert IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, photo FROM emp_attachment WHERE photo IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, resume FROM emp_attachment WHERE resume IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, share_contract FROM emp_attachment WHERE share_contract IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, emp_contract FROM emp_attachment WHERE emp_contract IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_01 FROM emp_attachment WHERE other_01 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_02 FROM emp_attachment WHERE other_02 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_03 FROM emp_attachment WHERE other_03 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_04 FROM emp_attachment WHERE other_04 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_05 FROM emp_attachment WHERE other_05 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_06 FROM emp_attachment WHERE other_06 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_07 FROM emp_attachment WHERE other_07 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_08 FROM emp_attachment WHERE other_08 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_09 FROM emp_attachment WHERE other_09 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_10 FROM emp_attachment WHERE other_10 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_11 FROM emp_attachment WHERE other_11 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_12 FROM emp_attachment WHERE other_12 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_13 FROM emp_attachment WHERE other_13 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_14 FROM emp_attachment WHERE other_14 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_15 FROM emp_attachment WHERE other_15 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_16 FROM emp_attachment WHERE other_16 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_17 FROM emp_attachment WHERE other_17 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_18 FROM emp_attachment WHERE other_18 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_19 FROM emp_attachment WHERE other_19 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_20 FROM emp_attachment WHERE other_20 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_21 FROM emp_attachment WHERE other_21 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_22 FROM emp_attachment WHERE other_22 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_23 FROM emp_attachment WHERE other_23 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_24 FROM emp_attachment WHERE other_24 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_25 FROM emp_attachment WHERE other_25 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_26 FROM emp_attachment WHERE other_26 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_27 FROM emp_attachment WHERE other_27 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_28 FROM emp_attachment WHERE other_28 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_29 FROM emp_attachment WHERE other_29 IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, other_30 FROM emp_attachment WHERE other_30 IS NOT NULL;
	REPLACE INTO sys_file_db_list (file_url) SELECT DISTINCT bil_url FROM expense_apply_spend_detail_bill WHERE bil_url IS NOT NULL;
	REPLACE INTO sys_file_db_list (cust_id,emp_id,file_url) SELECT DISTINCT cust_id,emp_id, pic_url FROM att_emp_log WHERE pic_url IS NOT NULL;
	
	
	
	UPDATE sys_file_upload_log A,sys_file_db_list B 
	SET A.is_enable=1
	WHERE A.file_url=B.file_url AND A.is_delete_file=0 ;
	
	UPDATE sys_file_upload_log SET is_enable=2 WHERE is_enable<>1 AND is_delete_file=0;
	SET ST = 1;
END;

