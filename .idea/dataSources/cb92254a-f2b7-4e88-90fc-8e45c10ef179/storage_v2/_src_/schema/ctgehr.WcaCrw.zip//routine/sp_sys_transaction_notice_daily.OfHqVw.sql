create procedure SP_SYS_TRANSACTION_NOTICE_DAILY(IN bgdt date, IN eddt date, IN custid bigint unsigned)
  comment '用于跑每天的系统事务提醒的生成'
  BEGIN
/*
   background-color: 
   background-color: 
   background-color: #ff851b
   background-color: #00a65a
   background-color: #dd4b39
zdy {
   background-color: #6fa9d4
*/
DECLARE cst_ct,cst_mxct,tran_ct,emp_ct,tran_mxct,emp_mxct,i_count,i_custid,i_deptid,i_emp,i_stn_id,i_stn_type,i_advance_days,i_delay_days,i_notice_face_range BIGINT;
DECLARE i_notice_time,i_bgdt DATE;
DECLARE i_stn_name,i_notice_range,i_empname,i_deptname,i_background_color,i_border_color VARCHAR(50);
 DECLARE i_version_code VARCHAR(50);
 SET i_version_code = UUID();
/*
	#公司列表临时表
	DROP TABLE IF EXISTS `tmp_stn_cust_list`;
	CREATE TEMPORARY TABLE `tmp_stn_cust_list` (
		ID BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`cust_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '公司id',
			PRIMARY KEY (`ID`)
	)COLLATE='utf8_general_ci' ENGINE=MEMORY;
	#面向列表临时表
	DROP TABLE IF EXISTS `tmp_stn_emp_list`;
	CREATE TEMPORARY TABLE `tmp_stn_emp_list` (
		ID BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`emp_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '公司id',
			PRIMARY KEY (`ID`)
	)COLLATE='utf8_general_ci' ENGINE=MEMORY;	
	#提醒任务临时表
	DROP TABLE IF EXISTS `tmp_sys_transaction_notice`;
	CREATE TEMPORARY TABLE `tmp_sys_transaction_notice` (
		ID BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`stn_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '系统事务提醒id',
		`stn_name` VARCHAR(50) NULL DEFAULT NULL COMMENT '提醒名称',
		`stn_type` TINYINT(4) NULL DEFAULT NULL COMMENT '事务提醒类型 1系统  2自定义',
		`advance_days` INT(11) NULL DEFAULT NULL COMMENT '提前天数',
		`notice_time` DATE NULL DEFAULT NULL COMMENT '提醒时间',
		`delay_days` INT(11) NULL DEFAULT NULL COMMENT '延期天数',
		`notice_range` VARCHAR(50) NULL DEFAULT NULL COMMENT '提醒范围  多选（1男[60周岁 2女[50周岁 3劳动 4劳务]]）',
		`notice_face_range` TINYINT(4) NULL DEFAULT NULL COMMENT '提醒适用范围（1部门 2员工）',
		PRIMARY KEY (`ID`)
	)COLLATE='utf8_general_ci' ENGINE=MEMORY;
	
*/
	#写入公司列表
	IF custid IS NULL THEN
		INSERT INTO tmp_stn_cust_list (version_code,cust_id) 
			SELECT DISTINCT i_version_code,CUST_ID 
			FROM (
				SELECT DISTINCT CUST_ID FROM SYS_TRANSACTION_NOTICE UNION ALL
				SELECT DISTINCT CUST_ID FROM SYS_CUSTOM_TRANSACTION_NOTICE  
				) cst;
	ELSE
		INSERT INTO tmp_stn_cust_list (version_code,cust_id) value (i_version_code,custid);
	END IF;

	
	
	#取出指针起始和结束位置
	SELECT MIN(ID),MAX(ID) INTO cst_ct,cst_mxct FROM tmp_stn_cust_list where version_code = i_version_code;
	IF cst_ct IS NULL THEN SET cst_ct = 0 ; END IF;
	IF cst_mxct IS NULL THEN SET cst_mxct = 0 ; END IF;
	
	#开始循环公司
	WHILE(cst_ct<=cst_mxct AND cst_ct>0)DO
		SET i_custid = NULL;
		#得到当前要做的公司id
		SELECT CUST_ID INTO i_custid FROM tmp_stn_cust_list WHERE ID = cst_ct and version_code = i_version_code;
		IF i_custid IS NOT NULL THEN
			#清除该公司时间段内的log数据
			DELETE FROM sys_transaction_notice_log WHERE CUST_ID = i_custid AND dt BETWEEN bgdt AND eddt;
			
			#把该公司有的提醒写入到tmp_sys_transaction_notice表
			delete from tmp_sys_transaction_notice where version_code = i_version_code;
			
			INSERT INTO tmp_sys_transaction_notice (version_code,`stn_id`,`stn_name`,`stn_type`,`advance_days`,`notice_time`,`delay_days`,`notice_range`,`notice_face_range`) 
				SELECT i_version_code,stn_id,stn_name,1,advance_days,null,delay_days,notice_range,notice_face_range
				FROM sys_transaction_notice WHERE CUST_ID = i_custid and is_enable=1;
				
			INSERT INTO tmp_sys_transaction_notice (version_code,`stn_id`,`stn_name`,`stn_type`,`advance_days`,`notice_time`,`delay_days`,`notice_range`,`notice_face_range`) 
				SELECT i_version_code,cstn_id,cstn_name,2,advance_days,notice_time,delay_days,null,notice_face_range
				FROM sys_custom_transaction_notice WHERE CUST_ID = i_custid ;
				
			#得到事务提醒列表的指针起始和结束位置
			SELECT MIN(ID),MAX(ID) INTO tran_ct,tran_mxct FROM tmp_sys_transaction_notice where version_code = i_version_code;
			IF tran_ct IS NULL THEN SET tran_ct = 0 ; END IF;
			IF tran_mxct IS NULL THEN SET tran_mxct = 0 ; END IF;
			
			WHILE (tran_ct<=tran_mxct AND tran_ct>0) DO
				SET i_stn_id=NULL;
				SET i_stn_name=NULL;
				SET i_stn_type=NULL;
				SET i_advance_days=NULL;
				SET i_notice_time=NULL;
				SET i_delay_days=NULL;
				SET i_notice_range=NULL;
				SET i_notice_face_range=NULL;
				
				#读出相应设置信息
				SELECT stn_id,stn_name,stn_type,
					advance_days,notice_time,delay_days,
					notice_range,notice_face_range
					INTO i_stn_id,i_stn_name,i_stn_type,			
						i_advance_days,i_notice_time,i_delay_days,	
						i_notice_range,i_notice_face_range			
				FROM tmp_sys_transaction_notice WHERE ID = tran_ct and version_code = i_version_code;
				
				IF i_stn_id IS NOT NULL THEN
					#把面向的部门或者员工id转化成emp_id写入临时表
					delete from  tmp_stn_emp_list where version_code = i_version_code;
					IF i_stn_type = 1 THEN 						
						IF i_notice_face_range = 1 THEN 		
							INSERT INTO tmp_stn_emp_list (version_code,emp_id) 
								SELECT distinct i_version_code,a.emp_id 
								FROM emp_base_info a ,sys_rel_transaction_notice_dept b 
								WHERE b.stn_id = i_stn_id AND a.dept_id = b.dept_or_emp_id AND a.emp_state<>2 AND a.is_delete=0;
						ELSEIF i_notice_face_range = 2 THEN 	
							INSERT INTO tmp_stn_emp_list (version_code,emp_id) 
								SELECT i_version_code,dept_or_emp_id FROM sys_rel_transaction_notice_dept WHERE stn_id = i_stn_id;
						END IF;
					ELSEIF i_stn_type = 2 THEN 					
						IF i_notice_face_range = 1 THEN 		
							INSERT INTO tmp_stn_emp_list (version_code,emp_id) 
								SELECT distinct i_version_code,a.emp_id 
								FROM emp_base_info a ,sys_rel_custom_transaction_notice_dept b 
								WHERE b.cstn_id = i_stn_id AND a.dept_id = b.dept_or_emp_id AND a.emp_state<>2 AND a.is_delete=0;
						ELSEIF i_notice_face_range = 2 THEN 	
							INSERT INTO tmp_stn_emp_list (version_code,emp_id) 
								SELECT i_version_code,dept_or_emp_id FROM sys_rel_custom_transaction_notice_dept WHERE cstn_id = i_stn_id;
						END IF;
					END IF;
					
					SELECT MIN(ID),MAX(ID) INTO emp_ct,emp_mxct FROM tmp_stn_emp_list  where version_code = i_version_code;
					IF emp_ct IS NULL THEN SET emp_ct = 0 ; END IF;
					IF emp_mxct IS NULL THEN SET emp_mxct = 0 ; END IF;
					
					WHILE (emp_ct<=emp_mxct AND emp_ct>0) DO
						set i_emp = null;
						SELECT emp_id INTO i_emp FROM tmp_stn_emp_list WHERE ID = emp_ct and version_code = i_version_code ;
						
						IF i_emp IS NOT NULL THEN
							SET i_bgdt = bgdt;
							SET i_count = 0;
							WHILE (i_bgdt<=eddt) DO
								
								IF ( i_stn_type = 1 ) THEN
									CASE i_stn_name
									WHEN '退休年龄提醒' THEN
										SET i_background_color = '#00c0ef';
										SET i_border_color = i_background_color;
										
										IF i_notice_range = '1,2' OR i_notice_range = '2,1' THEN		
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,IF(a.gender=1,DATE_ADD(c.birthday,INTERVAL 60 YEAR),DATE_ADD(c.birthday,INTERVAL 50 YEAR)) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_detail c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												(( a.gender = 1 AND 
													(	DATE_ADD(DATE_ADD(c.birthday,INTERVAL 60 YEAR),INTERVAL -i_advance_days DAY)=i_bgdt	
													 OR DATE_ADD(DATE_ADD(c.birthday,INTERVAL 60 YEAR),INTERVAL i_delay_days DAY)=i_bgdt	
													 OR DATE_ADD(c.birthday,INTERVAL 60 YEAR)=i_bgdt									
													)
												) 
												OR
												( a.gender = 2 AND 
													(	DATE_ADD(DATE_ADD(c.birthday,INTERVAL 50 YEAR),INTERVAL -i_advance_days DAY)=i_bgdt
													 OR DATE_ADD(DATE_ADD(c.birthday,INTERVAL 50 YEAR),INTERVAL i_delay_days DAY)=i_bgdt
													 OR DATE_ADD(c.birthday,INTERVAL 50 YEAR)=i_bgdt
													)					
												)); 
										ELSEIF i_notice_range = '1' THEN	
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,DATE_ADD(c.birthday,INTERVAL 60 YEAR) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_detail c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												( a.gender = 1 AND 
													(	DATE_ADD(DATE_ADD(c.birthday,INTERVAL 60 YEAR),INTERVAL -i_advance_days DAY)=i_bgdt	
													 OR DATE_ADD(DATE_ADD(c.birthday,INTERVAL 60 YEAR),INTERVAL i_delay_days DAY)=i_bgdt	
													 OR DATE_ADD(c.birthday,INTERVAL 60 YEAR)=i_bgdt									
													)
												) ; 
										ELSEIF i_notice_range = '2' THEN	
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,DATE_ADD(c.birthday,INTERVAL 50 YEAR) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_detail c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												( a.gender = 2 AND 
													(	DATE_ADD(DATE_ADD(c.birthday,INTERVAL 50 YEAR),INTERVAL -i_advance_days DAY)=i_bgdt	
													 OR DATE_ADD(DATE_ADD(c.birthday,INTERVAL 50 YEAR),INTERVAL i_delay_days DAY)=i_bgdt	
													 OR DATE_ADD(c.birthday,INTERVAL 50 YEAR)=i_bgdt									
													)
												) ; 
											
										END IF;
									WHEN '试用期到期提醒' THEN
										SET i_background_color = '#f39c12';
										SET i_border_color = i_background_color;
										
										IF i_notice_range = '1,2' OR i_notice_range = '2,1' THEN		
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,IF(c.regu_date IS NULL,DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),c.regu_date) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												(( c.emp_type = 1 AND 
													(  DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH) = i_bgdt 
													OR DATE_ADD(DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),INTERVAL -i_advance_days DAY) = i_bgdt
													OR DATE_ADD(DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),INTERVAL i_delay_days DAY) = i_bgdt
													OR c.regu_date = i_bgdt
													OR DATE_ADD(c.regu_date,INTERVAL -i_advance_days DAY) = i_bgdt
													OR DATE_ADD(c.regu_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												) 
												OR
												( c.emp_type = 2 AND 
													(  DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH) = i_bgdt 
													OR DATE_ADD(DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),INTERVAL -i_advance_days DAY) = i_bgdt
													OR DATE_ADD(DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),INTERVAL i_delay_days DAY) = i_bgdt
													OR c.regu_date = i_bgdt
													OR DATE_ADD(c.regu_date,INTERVAL -i_advance_days DAY) = i_bgdt
													OR DATE_ADD(c.regu_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												)); 
										ELSEIF i_notice_range = '1' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,IF(c.regu_date IS NULL,DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),c.regu_date) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												( c.emp_type = 1 AND 
													(  DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH) = i_bgdt 
													OR DATE_ADD(DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),INTERVAL -i_advance_days DAY) = i_bgdt
													OR DATE_ADD(DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),INTERVAL i_delay_days DAY) = i_bgdt
													OR c.regu_date = i_bgdt
													OR DATE_ADD(c.regu_date,INTERVAL -i_advance_days DAY) = i_bgdt
													OR DATE_ADD(c.regu_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												) ; 
										ELSEIF i_notice_range = '2' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,IF(c.regu_date IS NULL,DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),c.regu_date) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												( c.emp_type = 2 AND 
													(  DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH) = i_bgdt 
													OR DATE_ADD(DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),INTERVAL -i_advance_days DAY) = i_bgdt
													OR DATE_ADD(DATE_ADD(c.entry_date,INTERVAL c.prob_period-1 MONTH),INTERVAL i_delay_days DAY) = i_bgdt
													OR c.regu_date = i_bgdt
													OR DATE_ADD(c.regu_date,INTERVAL -i_advance_days DAY) = i_bgdt
													OR DATE_ADD(c.regu_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												) ; 
										END IF;
									WHEN '劳动合同到期提醒' THEN
										SET i_background_color = '#ff851b';
										SET i_border_color = i_background_color;
										
										IF i_notice_range = '1,2' OR i_notice_range = '2,1' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,c.con_end_date notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post_contract c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												(( c.con_type = 1 AND 
													(   c.con_end_date = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL -i_advance_days DAY) = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												) 
												OR
												( c.con_type = 2 AND 
													(   c.con_end_date = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL -i_advance_days DAY) = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												)); 
										ELSEIF i_notice_range = '1' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,c.con_end_date notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post_contract c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												( c.con_type = 1 AND 
													(   c.con_end_date = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL -i_advance_days DAY) = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												);
										ELSEIF i_notice_range = '2' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,c.con_end_date notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post_contract c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												( c.con_type = 2 AND 
													(   c.con_end_date = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL -i_advance_days DAY) = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												);
										END IF;
									WHEN '签无固定期限劳动合同提醒' THEN
										SET i_background_color = '#00a65a';
										SET i_border_color = i_background_color;
										
										IF i_notice_range = '1,2' OR i_notice_range = '2,1' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,c.con_end_date notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post_contract c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												(( c.con_type = 1 AND c.renew_times = 3 AND
													(   c.con_end_date = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL -i_advance_days DAY) = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												) 
												OR
												( c.con_type = 2 AND c.renew_times = 3 AND
													(   c.con_end_date = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL -i_advance_days DAY) = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL i_delay_days DAY) = i_bgdt
													)	
												)); 
										ELSEIF i_notice_range = '1' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,c.con_end_date notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post_contract c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												( c.con_type = 1 AND c.renew_times = 3 AND
													(   c.con_end_date = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL -i_advance_days DAY) = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												);
										ELSEIF i_notice_range = '2' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,c.con_end_date notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_post_contract c ON a.emp_id = c.emp_id
											WHERE a.emp_id = i_emp AND 
												( c.con_type = 2 AND c.renew_times = 3 AND
													(   c.con_end_date = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL -i_advance_days DAY) = i_bgdt
													 OR DATE_ADD(c.con_end_date,INTERVAL i_delay_days DAY) = i_bgdt
													)
												);
										END IF;
									WHEN '员工生日提醒' THEN
										SET i_background_color = '#dd4b39';
										SET i_border_color = i_background_color;
										
										IF i_notice_range = '1,2' OR i_notice_range = '2,1' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,CONCAT(LEFT(i_bgdt,5),RIGHT(c.birthday,5)) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_detail c ON a.emp_id = c.emp_id
												LEFT JOIN emp_post d on a.emp_id = d.emp_id
											WHERE a.emp_id = i_emp AND 
												(( d.emp_type = 1 AND 
													(  RIGHT(c.birthday,5) = RIGHT(i_bgdt,5)
													 OR RIGHT(DATE_ADD(c.birthday,INTERVAL -i_advance_days DAY),5) = RIGHT(i_bgdt,5)
													 OR RIGHT(DATE_ADD(c.birthday,INTERVAL i_delay_days DAY),5) = RIGHT(i_bgdt,5)
													)
												) 
												OR
												( d.emp_type = 2 AND 
													(  RIGHT(c.birthday,5) = RIGHT(i_bgdt,5)
													 OR RIGHT(DATE_ADD(c.birthday,INTERVAL -i_advance_days DAY),5) = RIGHT(i_bgdt,5)
													 OR RIGHT(DATE_ADD(c.birthday,INTERVAL i_delay_days DAY),5) = RIGHT(i_bgdt,5)
													)
												)); 
										ELSEIF i_notice_range = '1' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,CONCAT(LEFT(i_bgdt,5),RIGHT(c.birthday,5)) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_detail c ON a.emp_id = c.emp_id
												LEFT JOIN emp_post d ON a.emp_id = d.emp_id
											WHERE a.emp_id = i_emp AND 
												( d.emp_type = 1 AND 
													(  RIGHT(c.birthday,5) = RIGHT(i_bgdt,5)
													 OR RIGHT(DATE_ADD(c.birthday,INTERVAL -i_advance_days DAY),5) = RIGHT(i_bgdt,5)
													 OR RIGHT(DATE_ADD(c.birthday,INTERVAL i_delay_days DAY),5) = RIGHT(i_bgdt,5)
													)
												) ;
										ELSEIF i_notice_range = '2' THEN
											SELECT COUNT(*),a.emp_name,b.dept_id,b.dept_name,CONCAT(LEFT(i_bgdt,5),RIGHT(c.birthday,5)) notice_day
												INTO i_count,i_empname,i_deptid,i_deptname,i_notice_time
											FROM emp_base_info a 
												LEFT JOIN dept_info b ON a.dept_id = b.dept_id
												LEFT JOIN emp_detail c ON a.emp_id = c.emp_id
												LEFT JOIN emp_post d ON a.emp_id = d.emp_id
											WHERE a.emp_id = i_emp AND 
												( d.emp_type = 2 AND 
													(  RIGHT(c.birthday,5) = RIGHT(i_bgdt,5)
													 OR RIGHT(DATE_ADD(c.birthday,INTERVAL -i_advance_days DAY),5) = RIGHT(i_bgdt,5)
													 OR RIGHT(DATE_ADD(c.birthday,INTERVAL i_delay_days DAY),5) = RIGHT(i_bgdt,5)
													)
												) ;
										END IF;
									ELSE
										SET @A=1;
									END CASE;
								ELSEIF ( i_stn_type = 2 ) THEN
									SET i_background_color = '#6fa9d4';
									SET i_border_color = i_background_color;
									IF ( i_notice_time = i_bgdt ) OR ( DATE_ADD(i_notice_time,INTERVAL -i_advance_days DAY) = i_bgdt ) OR (DATE_ADD(i_notice_time,INTERVAL i_delay_days DAY) = i_bgdt) THEN
										SET i_count = 1;
									ELSE
										SET i_count = 0;
									END IF;
									SELECT a.emp_name,b.dept_id,b.dept_name
										INTO i_empname,i_deptid,i_deptname
									FROM emp_base_info a left join dept_info b ON a.dept_id=b.dept_id
									WHERE a.emp_id=i_emp;
									
								END IF;
								
								IF i_count > 0  THEN
									INSERT INTO sys_transaction_notice_log (cust_id,dept_id,dept_name,emp_id,emp_name,
																			dt,stn_name,notice_time,background_color,border_color)
										VALUES (i_custid,i_deptid,i_deptname,i_emp,i_empname,
												i_bgdt,i_stn_name,i_notice_time,i_background_color,i_border_color);
								END IF;
								SET i_bgdt = DATE_ADD(i_bgdt,INTERVAL 1 DAY);
							END WHILE;
						END IF;						
						SET emp_ct = emp_ct + 1;			
					END WHILE;
				END IF;
				SET tran_ct = tran_ct + 1;				
			END WHILE;
		END IF;						
		SET cst_ct = cst_ct + 1;
	END WHILE;							
	delete from  tmp_stn_cust_list where version_code = i_version_code;
	delete from tmp_stn_emp_list where version_code = i_version_code;
	delete from tmp_sys_transaction_notice where version_code = i_version_code;
	
END;

