create procedure SP_EMP_MONTH_LIST(IN BGDT             date, IN EDDT date, IN CUSTID bigint unsigned,
                                   IN PVERSION         bigint, IN ADDITIONAL_VALUE int)
  comment '企业花名册生成'
  BEGIN
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE MY_MAINID,MY_EMPID,EMP_CT,EMP_MXCT BIGINT unsigned;
DECLARE MY_DESCOL,THIS_TBNAME,THIS_COLNAME,THIS_SHOWNAME,MY_DESTAB VARCHAR(50);
DECLARE SQL_INSERT,SQL_SELECT,SQL_INSERT2,SQL_SELECT2,SQL_INSERT3,SQL_SELECT3,SQL_INSERT4,SQL_SELECT4,SQL_FROM,SQL_WHERE,SQL_GROUP TEXT;
DECLARE MY_SEQ,COL_CT,COL_MXCT,TB_CT,TB_MXCT BIGINT;
DECLARE IS_HAVE_SALA,THIS_MAX_ENABLETIME,THIS_ADJID BIGINT UNSIGNED;
DECLARE THIS_MAX_CREATETIME DATETIME;

	SET I_VERSION_CODE = UUID();
	SET MY_MAINID = NULL;


	SELECT MAIN_ID INTO MY_MAINID 
	FROM cust_period_emp_main A 
	WHERE A.emp_period_version = PVERSION AND A.cust_id=CUSTID;
	
	IF MY_MAINID IS NULL THEN
		SELECT IFNULL(MAX(MAIN_ID)+1,1) INTO MY_MAINID FROM cust_period_emp_main WHERE MAIN_ID <= 1000000000;
						
		INSERT INTO cust_period_emp_main (main_id,cust_id,emp_period_version,operator,operator_name,remark,create_time) 
			VALUES (MY_MAINID,CUSTID,PVERSION,1,'SYS','系统计算',NOW());		
	END IF;
	
	UPDATE cust_period_emp_main A SET A.STATE = 0,sync_state = 0 WHERE A.main_id=MY_MAINID;
	
	DELETE FROM cust_period_emp_detail WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_emp_detail_2 WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_emp_detail_3 WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_emp_detail_4 WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_emp_dict WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_emp_soin_detail WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_emp_detail_calculation WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_warning_emp_post WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_warning_salary_adj WHERE main_id=MY_MAINID;
	DELETE FROM cust_period_warning_subsidy_project WHERE main_id=MY_MAINID;


	
	SET SQL_GROUP = ' GROUP BY emp_base_info.emp_id;';

	
	INSERT INTO tmp_period_emp_table_list (VERSION_CODE,TABLE_NAME) 
		SELECT DISTINCT I_VERSION_CODE,TABLE_NAME 
		FROM set_show_cols a
		WHERE cust_id=CUSTID and is_show=1 AND TABLE_NAME NOT IN ('emp_salary','emp_black_white_info','emp_base_info','emp_post','emp_detail','emp_attachment','emp_bank','emp_comp','emp_edu','emp_post_contract','emp_record','emp_salary_adj','emp_work_exp','dept_info','dept_pos_level','emp_subsidy_project','log_emp_post_change') 
			and concat(a.table_name,'.',a.col_name)<>'dept_pos_level.dept_staff_rank_id'
			and a.table_name not like 'custom_table_%';



	SET SQL_FROM=CONCAT(' FROM emp_base_info LEFT JOIN emp_post on emp_base_info.emp_id=emp_post.emp_id left join emp_detail on emp_base_info.emp_id=emp_detail.emp_id left join emp_attachment on emp_base_info.emp_id=emp_attachment.emp_id left join emp_bank on emp_base_info.emp_id=emp_bank.emp_id and emp_bank.is_enable=1 left join emp_comp on emp_base_info.emp_id=emp_comp.emp_id left join emp_edu on emp_base_info.emp_id=emp_edu.emp_id and emp_edu.is_top_edu=1 left join emp_post_contract on emp_base_info.emp_id=emp_post_contract.emp_id and emp_post_contract.con_status=2 left join emp_record on emp_base_info.emp_id=emp_record.emp_id left join emp_salary_adj on emp_base_info.emp_id=emp_salary_adj.emp_id AND emp_salary_adj.is_delete=0 AND emp_salary_adj.enable_time <= ''',CAST(REPLACE(EDDT,'-','') AS UNSIGNED),''' left join emp_work_exp on emp_base_info.emp_id=emp_work_exp.emp_id left join dept_info on emp_base_info.dept_id=dept_info.dept_id and dept_info.is_enable=1 left join dept_pos_level on emp_post.position_level_id = dept_pos_level.position_level_id and dept_pos_level.is_delete=0 and dept_pos_level.is_enable=1');
	
	SELECT MIN(ID),MAX(ID) INTO TB_CT,TB_MXCT FROM tmp_period_emp_table_list WHERE VERSION_CODE=I_VERSION_CODE;
	WHILE TB_CT<=TB_MXCT AND TB_CT>0 DO
		SET THIS_TBNAME = NULL;
		SELECT TABLE_NAME INTO  THIS_TBNAME FROM tmp_period_emp_table_list WHERE ID=TB_CT AND VERSION_CODE=I_VERSION_CODE;
		IF THIS_TBNAME IS NOT NULL THEN
			IF THIS_TBNAME LIKE 'custom_table_%' OR THIS_TBNAME LIKE '%_no' THEN
				SET SQL_FROM = SQL_FROM;
			ELSE
				SET SQL_FROM = CONCAT(SQL_FROM,' LEFT JOIN ',THIS_TBNAME,' ON emp_base_info.emp_id = ',THIS_TBNAME,'.emp_id');			
			END IF;
			delete from tmp_period_emp_table_list where id=TB_CT;
		END IF;
		SET TB_CT = TB_CT + 1;
	END WHILE;
	
	
	
	INSERT INTO tmp_period_emp_collumn_list (version_code,table_name,col_name,show_name)
	SELECT I_VERSION_CODE,a.table_name,a.col_name,a.show_name
	from set_show_cols a
	where a.cust_id=CUSTID and a.is_show=1 
		and a.table_name not in ('emp_salary_adj','emp_black_white_info','emp_salary_no','emp_subsidy_project','log_emp_post_change') 
		and a.table_name not like 'custom_table_%'
		and a.col_name is not null
		and concat(a.table_name,'.',a.col_name)<>'dept_pos_level.dept_staff_rank_id'
	order by seq_no ;
	
	SELECT MIN(ID),MAX(ID) INTO COL_CT,COL_MXCT FROM tmp_period_emp_collumn_list WHERE VERSION_CODE=I_VERSION_CODE;
	SET SQL_INSERT='REPLACE INTO cust_period_emp_detail (`main_id`,`emp_id`,`emp_period_version`,`cust_id`,`dept_id`,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10';
	SET SQL_INSERT2='REPLACE INTO cust_period_emp_detail_2 (`main_id`,`emp_id`,`emp_period_version`';
	SET SQL_INSERT3='REPLACE INTO cust_period_emp_detail_3 (`main_id`,`emp_id`,`emp_period_version`';
	SET SQL_INSERT4='REPLACE INTO cust_period_emp_detail_4 (`main_id`,`emp_id`,`emp_period_version`';
	SET SQL_SELECT=CONCAT('SELECT ',MY_MAINID,',emp_base_info.emp_id,',PVERSION,',emp_base_info.cust_id,emp_base_info.dept_id,emp_base_info.prgm_id,emp_base_info.jrdc_id,emp_base_info.dms_id4,emp_base_info.dms_id5,emp_base_info.dms_id6,emp_base_info.dms_id7,emp_base_info.dms_id8,emp_base_info.dms_id9,emp_base_info.dms_id10');
	SET SQL_SELECT2=CONCAT('SELECT ',MY_MAINID,',emp_base_info.emp_id,',PVERSION);
	SET SQL_SELECT3=CONCAT('SELECT ',MY_MAINID,',emp_base_info.emp_id,',PVERSION);
	SET SQL_SELECT4=CONCAT('SELECT ',MY_MAINID,',emp_base_info.emp_id,',PVERSION);
	
	SET MY_SEQ=1;
	WHILE COL_CT <= COL_MXCT AND COL_CT>0 DO
		SET THIS_TBNAME=NULL,THIS_COLNAME=NULL,THIS_SHOWNAME=NULL;
		SELECT A.table_name,A.col_name,A.show_name INTO THIS_TBNAME,THIS_COLNAME,THIS_SHOWNAME FROM tmp_period_emp_collumn_list A WHERE A.id=COL_CT AND A.version_code=I_VERSION_CODE;
		
		IF THIS_COLNAME IS NOT NULL THEN
			IF THIS_COLNAME='enable_time' or THIS_TBNAME = 'emp_salary' THEN
				SET THIS_TBNAME ='emp_salary_adj';
			END IF;
			
			IF MY_SEQ BETWEEN 1 AND 150 THEN
				SET SQL_SELECT=CONCAT(SQL_SELECT,',IFNULL(MAX(',THIS_TBNAME,'.`',THIS_COLNAME,'`),''0'')');
			ELSEIF MY_SEQ BETWEEN 151 AND 300 THEN
				SET SQL_SELECT2=CONCAT(SQL_SELECT2,',IFNULL(MAX(',THIS_TBNAME,'.`',THIS_COLNAME,'`),''0'')');
			ELSEIF MY_SEQ BETWEEN 301 AND 450 THEN
				SET SQL_SELECT3=CONCAT(SQL_SELECT3,',IFNULL(MAX(',THIS_TBNAME,'.`',THIS_COLNAME,'`),''0'')');
			ELSEIF MY_SEQ BETWEEN 451 AND 600 THEN
				SET SQL_SELECT4=CONCAT(SQL_SELECT4,',IFNULL(MAX(',THIS_TBNAME,'.`',THIS_COLNAME,'`),''0'')');
			END IF;

			IF MY_SEQ BETWEEN 1 AND 9 THEN
				SET MY_DESCOL = CONCAT('COL_00',MY_SEQ);
			ELSEIF MY_SEQ BETWEEN 10 AND 99 THEN
				SET MY_DESCOL = CONCAT('COL_0',MY_SEQ);
			ELSEIF MY_SEQ >= 100 THEN
				SET MY_DESCOL = CONCAT('COL_',MY_SEQ);
			END IF;
			
			IF MY_SEQ BETWEEN 1 AND 150 THEN
				SET MY_DESTAB = 'cust_period_emp_detail';
			ELSEIF MY_SEQ BETWEEN 151 AND 300 THEN
				SET MY_DESTAB = 'cust_period_emp_detail_2';
			ELSEIF MY_SEQ BETWEEN 301 AND 450 THEN
				SET MY_DESTAB = 'cust_period_emp_detail_3';
			ELSEIF MY_SEQ BETWEEN 451 AND 600 THEN
				SET MY_DESTAB = 'cust_period_emp_detail_4';
			END IF;
			
			IF MY_SEQ BETWEEN 1 AND 150 THEN
				SET SQL_INSERT = CONCAT(SQL_INSERT,',`',MY_DESCOL,'`');
			ELSEIF MY_SEQ BETWEEN 151 AND 300 THEN
				SET SQL_INSERT2 = CONCAT(SQL_INSERT2,',`',MY_DESCOL,'`');
			ELSEIF MY_SEQ BETWEEN 301 AND 450 THEN
				SET SQL_INSERT3 = CONCAT(SQL_INSERT3,',`',MY_DESCOL,'`');
			ELSEIF MY_SEQ BETWEEN 451 AND 600 THEN
				SET SQL_INSERT4 = CONCAT(SQL_INSERT4,',`',MY_DESCOL,'`');
			END IF;
			
			REPLACE INTO cust_period_emp_dict (main_id,cust_id,emp_period_version,ori_table_name,ori_col_name,show_name,des_tb_name,des_col_name,seq_num) 
				VALUES (MY_MAINID,CUSTID,PVERSION,IF(THIS_TBNAME='emp_salary_adj','emp_salary',THIS_TBNAME),THIS_COLNAME,THIS_SHOWNAME,MY_DESTAB,MY_DESCOL,MY_SEQ);
			
			DELETE FROM tmp_period_emp_collumn_list WHERE ID=COL_CT;
			SET MY_SEQ = MY_SEQ + 1;
		END IF;
		SET COL_CT = COL_CT + 1;
	END WHILE;
	SET SQL_INSERT = CONCAT(SQL_INSERT,') ');
	SET SQL_INSERT2 = CONCAT(SQL_INSERT2,') ');
	SET SQL_INSERT3 = CONCAT(SQL_INSERT3,') ');
	SET SQL_INSERT4 = CONCAT(SQL_INSERT4,') ');
	

	
	INSERT INTO tmp_emp_month_list (version_code,emp_id)
		SELECT I_VERSION_CODE,A.emp_id
		FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
		WHERE A.cust_id=CUSTID AND A.is_delete=0 AND A.emp_state IS NOT NULL
			AND B.entry_date IS NOT NULL AND B.entry_date <= EDDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT);
	
	SET EMP_CT = 0, EMP_MXCT = 0;
	
	SELECT MIN(A.id),MAX(A.id) INTO EMP_CT,EMP_MXCT FROM tmp_emp_month_list A WHERE A.version_code=I_VERSION_CODE;
	
	WHILE EMP_CT <= EMP_MXCT AND EMP_CT > 0 DO
		SET SQL_WHERE = NULL, @SQL1 = NULL,@SQL2 = NULL,@SQL3 = NULL,@SQL4 = NULL, MY_EMPID = NULL;
		SELECT EMP_ID INTO MY_EMPID FROM tmp_emp_month_list A WHERE A.version_code=I_VERSION_CODE AND A.id=EMP_CT; 
		IF MY_EMPID IS NOT NULL THEN


			SET IS_HAVE_SALA = 0;
			SELECT COUNT(*) INTO IS_HAVE_SALA 
			FROM emp_salary_adj A 
			WHERE A.emp_id=MY_EMPID AND A.enable_time <= CAST(REPLACE(EDDT,'-','') AS UNSIGNED) AND A.is_delete=0;
			
			IF IS_HAVE_SALA = 0 OR IS_HAVE_SALA IS NULL THEN
				SET SQL_WHERE=CONCAT(' WHERE emp_base_info.EMP_ID =',MY_EMPID,' AND emp_base_info.is_delete=0 and emp_base_info.emp_state is not null and emp_base_info.cust_id=',CUSTID,' and ((emp_post.entry_date is not null and emp_post.entry_date <= ''',EDDT,''') or (emp_post.leave_date is null or emp_post.leave_date >= ''',BGDT,''')) ');
			ELSE
				SET THIS_MAX_ENABLETIME = NULL, THIS_MAX_CREATETIME = NULL, THIS_ADJID = NULL;
				SELECT MAX(A.enable_time) INTO THIS_MAX_ENABLETIME
				FROM emp_salary_adj A
				WHERE A.emp_id=MY_EMPID AND A.enable_time <= CAST(REPLACE(EDDT,'-','') AS UNSIGNED) AND A.is_delete=0;
 
				SELECT MAX(A.create_time) INTO THIS_MAX_CREATETIME
				FROM emp_salary_adj A
				WHERE A.emp_id=MY_EMPID AND A.enable_time = THIS_MAX_ENABLETIME AND A.is_delete=0;

				SELECT MAX(A.adj_id) INTO THIS_ADJID
				FROM emp_salary_adj A
				WHERE A.emp_id=MY_EMPID AND A.enable_time = THIS_MAX_ENABLETIME AND A.is_delete=0 AND A.create_time = THIS_MAX_CREATETIME;



				IF THIS_ADJID IS NOT NULL THEN
					SET SQL_WHERE=CONCAT(' WHERE emp_salary_adj.adj_id = ',THIS_ADJID,' AND emp_base_info.EMP_ID =',MY_EMPID,' AND emp_base_info.is_delete=0 and emp_base_info.emp_state is not null and emp_base_info.cust_id=',CUSTID,' and ((emp_post.entry_date is not null and emp_post.entry_date <= ''',EDDT,''') or (emp_post.leave_date is null or emp_post.leave_date >= ''',BGDT,''')) ');
				ELSE
					SET SQL_WHERE=CONCAT(' WHERE emp_base_info.EMP_ID =',MY_EMPID,' AND emp_base_info.is_delete=0 and emp_base_info.emp_state is not null and emp_base_info.cust_id=',CUSTID,' and ((emp_post.entry_date is not null and emp_post.entry_date <= ''',EDDT,''') or (emp_post.leave_date is null or emp_post.leave_date >= ''',BGDT,''')) ');
				END IF;
			END IF;
			
			


			
			SET @SQL1 = CONCAT(SQL_INSERT,SQL_SELECT,SQL_FROM,SQL_WHERE,SQL_GROUP);
			
			SET @SQL2 = CONCAT(SQL_INSERT2,SQL_SELECT2,SQL_FROM,SQL_WHERE,SQL_GROUP);
			
			SET @SQL3 = CONCAT(SQL_INSERT3,SQL_SELECT3,SQL_FROM,SQL_WHERE,SQL_GROUP);
			
			SET @SQL4 = CONCAT(SQL_INSERT4,SQL_SELECT4,SQL_FROM,SQL_WHERE,SQL_GROUP);
#SELECT @SQL1,@SQL2,@SQL3,@SQL4;

			PREPARE stmt1 FROM @SQL1;
			EXECUTE stmt1;
			DEALLOCATE PREPARE stmt1;
			
			PREPARE stmt2 FROM @SQL2;
			EXECUTE stmt2;
			DEALLOCATE PREPARE stmt2;
			
			PREPARE stmt3 FROM @SQL3;
			EXECUTE stmt3;
			DEALLOCATE PREPARE stmt3;
			
			PREPARE stmt4 FROM @SQL4;
			EXECUTE stmt4;
			DEALLOCATE PREPARE stmt4;
	
		END IF;
		
		SET EMP_CT = EMP_CT + 1;
	END WHILE;
	
	
	CALL SP_EMP_MONTH_LIST_ADDTIONAL(MY_MAINID,MY_SEQ);
	CALL SP_EMP_MONTH_SOIN(MY_MAINID);
	CALL SP_EMP_MONTH_CALCULATION(MY_MAINID);
	

#	REPLACE INTO cust_period_warning_emp_post (main_id,log_id,create_time,enable_time,creator_id,creator,log_remark,log_from,emp_id,emp_code,cust_id,fst_job_time,pre_entry_date,entry_date,pre_leave_date,leave_date,nx,leave_type,leave_reason,leave_tax_free,leave_pay,prob_period,prob_scale,pre_regu_date,regu_date,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,dept_name,position,position_level_id,work_email,tel,appv_level,emp_type,regu_stat,wh_time,work_time,pos_class,superior,sub_no,auth_stren_id,post_type_id,level_type_id,dept_staff_rank_id,direct_supervisor_id,work_city_id,work_city,work_add,other_01,other_02,other_03,other_04,other_05,other_06,other_07,other_08,other_09,other_10,other_11,other_12,other_13,other_14,other_15,other_16,other_17,other_18,other_19,other_20,other_21,other_22,other_23,other_24,other_25,other_26,other_27,other_28,other_29,other_30,is_delete,reason,emhr_code,recruit_type,fresh_students,recruit_emp_code,recruit_emp_name,api_email,inc_email,customer_email,emp_main,chinese_mainland,prob_end_date,outsource_type,prob_result,pay_type,position_coefficient,gross_profit_rate,cust_legal_id,other_31,other_32,other_33,other_34,other_35,other_36,other_37,other_38,other_39,other_40,other_41,other_42,other_43,other_44,other_45,other_46,other_47,other_48,other_49,other_50)
#		select MY_MAINID,log_id,create_time,enable_time,creator_id,creator,log_remark,log_from,emp_id,emp_code,cust_id,fst_job_time,pre_entry_date,entry_date,pre_leave_date,leave_date,nx,leave_type,leave_reason,leave_tax_free,leave_pay,prob_period,prob_scale,pre_regu_date,regu_date,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,dept_name,position,position_level_id,work_email,tel,appv_level,emp_type,regu_stat,wh_time,work_time,pos_class,superior,sub_no,auth_stren_id,post_type_id,level_type_id,dept_staff_rank_id,direct_supervisor_id,work_city_id,work_city,work_add,other_01,other_02,other_03,other_04,other_05,other_06,other_07,other_08,other_09,other_10,other_11,other_12,other_13,other_14,other_15,other_16,other_17,other_18,other_19,other_20,other_21,other_22,other_23,other_24,other_25,other_26,other_27,other_28,other_29,other_30,is_delete,reason,emhr_code,recruit_type,fresh_students,recruit_emp_code,recruit_emp_name,api_email,inc_email,customer_email,emp_main,chinese_mainland,prob_end_date,outsource_type,prob_result,pay_type,position_coefficient,gross_profit_rate,cust_legal_id,other_31,other_32,other_33,other_34,other_35,other_36,other_37,other_38,other_39,other_40,other_41,other_42,other_43,other_44,other_45,other_46,other_47,other_48,other_49,other_50
#		from log_emp_post_change a
#		where date(a.create_time) >= BGDT and a.enable_time < BGDT AND a.cust_id=CUSTID;


#	REPLACE INTO cust_period_warning_subsidy_project (main_id,ID,EMP_ID,CUST_ID,BATCH_NO,MONEY,FIELD_NAME,COL_NAME,ENABLE_START_DATE,ENABLE_END_DATE,IS_DELETE,CREATE_TIME,CREATOR_ID,CREATOR,MODIFY_TIME,MODIFIER_ID,MODIFIER,REMARK)
#	select MY_MAINID,ID,EMP_ID,CUST_ID,BATCH_NO,MONEY,FIELD_NAME,COL_NAME,ENABLE_START_DATE,ENABLE_END_DATE,IS_DELETE,CREATE_TIME,CREATOR_ID,CREATOR,MODIFY_TIME,MODIFIER_ID,MODIFIER,REMARK
#	from emp_subsidy_project a
#	where date(a.CREATE_TIME) >= BGDT and a.ENABLE_START_DATE < BGDT AND a.CUST_ID=CUSTID;


#	REPLACE INTO cust_period_warning_salary_adj (main_id,adj_id,emp_id,cust_id,base_sala,pos_sala,kpi_sala,hour_sala,test_sala,re_sala,benefit,tax_stand,enable_time,is_enable,other_01,other_02,other_03,other_04,other_05,other_06,other_07,other_08,other_09,other_10,other_11,other_12,other_13,other_14,other_15,other_16,other_17,other_18,other_19,other_20,other_21,other_22,other_23,other_24,other_25,other_26,other_27,other_28,other_29,other_30,create_time,creator_id,creator,modify_time,modifier_id,modifier,opr_time,is_delete)
#	select MY_MAINID,adj_id,emp_id,cust_id,base_sala,pos_sala,kpi_sala,hour_sala,test_sala,re_sala,benefit,tax_stand,enable_time,is_enable,other_01,other_02,other_03,other_04,other_05,other_06,other_07,other_08,other_09,other_10,other_11,other_12,other_13,other_14,other_15,other_16,other_17,other_18,other_19,other_20,other_21,other_22,other_23,other_24,other_25,other_26,other_27,other_28,other_29,other_30,create_time,creator_id,creator,modify_time,modifier_id,modifier,opr_time,is_delete
#	from emp_salary_adj a
#	where date(a.CREATE_TIME) >= BGDT and a.enable_time < CAST(REPLACE(BGDT,'-','') AS UNSIGNED) AND a.cust_id=CUSTID;

	
	UPDATE cust_period_emp_main A SET A.STATE = 1,sync_state = 0 WHERE A.main_id=MY_MAINID;
END;

