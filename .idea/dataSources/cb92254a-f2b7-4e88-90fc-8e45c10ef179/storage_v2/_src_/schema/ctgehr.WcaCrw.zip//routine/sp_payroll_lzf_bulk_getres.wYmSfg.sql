create procedure SP_PAYROLL_LZF_BULK_GETRES(IN custid bigint unsigned, IN ym int, IN setid bigint unsigned)
  comment '批量计算离职费结果'
  BEGIN
	declare sumb_rescnt,ct,mxct,i_emp,i_custid,i_sala,prid,i_deptid bigint;
	declare TAX_VERSION,N_JS,N_BTA,N_BTS,N_ATA,N_ATS,N_TIA,N_TIS,N_TMA,N_TMS,N_AT2BTP,N_AT2BTNP,N_LZF_JS,N_TAX_STAND,N_LZF_ZS,N_LZF_YNSE,N_LZF_SL,N_LZF_KCS,N_LZF_S,N_LZF_SF DECIMAL(13,3);
	declare i_deptname,i_empname varchar(50);
	DECLARE S_GZ_SF,S_LWF_SF,S_LZF_SF,S_NZJ_SF,N_LZF_NX DECIMAL(13,3);
	DECLARE i_version_code VARCHAR(50);
	SET i_version_code = UUID();
	SET TAX_VERSION = LEFT(ym,4);
	set sumb_rescnt=0;
	

	
	select count(*) into sumb_rescnt from payroll_lzf_base where cust_id=custid and MONTH_STEP=ym and is_publish=0 and set_id=setid;

	
	if sumb_rescnt>0 then
		INSERT INTO tmp_payroll_lzf_sum (version_code,payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,MONTH_STEP,TAX_STAND,LZF_JS,LZF_NX,BTA,BTS,ATA,ATS,TIA,TIS,TMA,TMS,AT2BTP,AT2BTNP) 
			select i_version_code,id,CUST_ID,DEPT_ID,DEPT_NAME,emp_id,EMP_NAME,month_step,AVG(TAX_STAND),avg(LZF_JS),AVG(LZF_NX),
				sum(BTA1+BTA2+BTA3+BTA4+BTA5+BTA6+BTA7+BTA8+BTA9+BTA10+BTA11+BTA12+BTA13+BTA14+BTA15+BTA16+BTA17+BTA18+BTA19+BTA20+BTA21+BTA22+BTA23+BTA24+BTA25+BTA26+BTA27+BTA28+BTA29+BTA30) BTA,
				sum(BTS1+BTS2+BTS3+BTS4+BTS5+BTS6+BTS7+BTS8+BTS9+BTS10+BTS11+BTS12+BTS13+BTS14+BTS15+BTS16+BTS17+BTS18+BTS19+BTS20+BTS21+BTS22+BTS23+BTS24+BTS25+BTS26+BTS27+BTS28+BTS29+BTS30) BTS,
				SUM(ATA1+ATA2+ATA3+ATA4+ATA5) ATA,SUM(ATS1+ATS2+ATS3+ATS4+ATS5) ATS,
				SUM(TIA1+TIA2+TIA3+TIA4+TIA5) TIA,SUM(TIS1+TIS2+TIS3+TIS4+TIS5) TIS,
				SUM(TMA1+TMA2+TMA3+TMA4+TMA5) TMA,SUM(TMS1+TMS2+TMS3+TMS4+TMS5) TMS,
				SUM(AT2BTP1+AT2BTP2+AT2BTP3+AT2BTP4+AT2BTP5) AT2BTP,SUM(AT2BTNP1+AT2BTNP2+AT2BTNP3+AT2BTNP4+AT2BTNP5) AT2BTNP
			from payroll_lzf_base where  cust_id=custid and MONTH_STEP=ym and is_publish=0 and set_id=setid
			group by emp_id;
	
	
		
		select min(id),max(id) into ct,mxct from tmp_payroll_lzf_sum  where version_code = i_version_code;
		while (ct<=mxct) do
			SET prid=NULL;
			SET i_custid=NULL;
			SET i_deptid=NULL;
			SET i_deptname=NULL;
			SET i_emp=NULL;
			SET i_empname=NULL;
			SET N_TAX_STAND=NULL;
			SET N_LZF_JS=NULL;
			SET N_LZF_NX=NULL;
			SET N_BTA=NULL;
			SET N_BTS=NULL;
			SET N_ATA=NULL;
			SET N_ATS=NULL;
			SET N_TIA=NULL;
			SET N_TIS=NULL;
			SET N_TMA=NULL;
			SET N_TMS=NULL;
			SET N_AT2BTP=NULL;
			SET N_AT2BTNP=NULL;

			select payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,TAX_STAND,LZF_JS,LZF_NX,BTA,BTS,ATA,ATS,TIA,TIS,TMA,TMS,AT2BTP,AT2BTNP
				into prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,N_TAX_STAND,N_LZF_JS,N_LZF_NX,N_BTA,N_BTS,N_ATA,N_ATS,N_TIA,N_TIS,N_TMA,N_TMS,N_AT2BTP,N_AT2BTNP
			from tmp_payroll_lzf_sum where id = ct  and version_code = i_version_code;
			
			IF prid IS NOT NULL THEN
			
				SET N_LZF_ZS = N_BTA - N_BTS; 
				
				SET N_LZF_YNSE = N_LZF_ZS + N_TIA - N_TIS; 
				SET N_LZF_NX = FN_PAYROLL_GET_NX(i_emp);
				SELECT leave_tax_free INTO N_LZF_JS FROM emp_post WHERE emp_id = i_emp;
				
		
				CALL SP_PAYROLL_LZF_SF(N_LZF_YNSE,
				                    N_LZF_NX,
				                    TAX_VERSION,
				                    N_TAX_STAND,
				                    N_LZF_JS,
				                    N_LZF_SL,
				                    N_LZF_KCS,
				                    N_LZF_YNSE,
										  N_LZF_S
				                    );
				
				SET N_LZF_SF= N_LZF_ZS - N_LZF_S + N_ATA - N_ATS;
		
				
				
				IF N_LZF_ZS IS NULL THEN SET N_LZF_ZS=0; END IF;
				IF N_LZF_S IS NULL THEN SET N_LZF_S=0; END IF;
				IF N_LZF_SF IS NULL THEN SET N_LZF_SF=0; END IF;
				
				DELETE FROM payroll_lzf WHERE id=prid;
				INSERT INTO payroll_lzf (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,IS_PUBLISH,
												LZF_ZS,LZF_JS,LZF_NX,LZF_YNSE,LZF_SL,LZF_KCS,LZF_S,LZF_SF) 
					VALUES (prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,setid,ym,0,
							N_LZF_ZS,N_LZF_JS,N_LZF_NX,N_LZF_YNSE,N_LZF_SL,N_LZF_KCS,N_LZF_S,N_LZF_SF);
				
				UPDATE payroll_lzf_base set is_calc=1 where id = prid;
				
				
				UPDATE payroll_tol 
				SET TAX_BEF_PLUSMIN_TOL=TAX_BEF_PLUSMIN_TOL+N_LZF_ZS,TAX_VALUE=TAX_VALUE+N_LZF_S,SALARY_PAY=SALARY_PAY+N_LZF_SF 
				WHERE ID=prid;
			END IF;
			set ct = ct + 1;
		end while;
	end if;
	delete from  tmp_payroll_lzf_sum where version_code = i_version_code;
END;

