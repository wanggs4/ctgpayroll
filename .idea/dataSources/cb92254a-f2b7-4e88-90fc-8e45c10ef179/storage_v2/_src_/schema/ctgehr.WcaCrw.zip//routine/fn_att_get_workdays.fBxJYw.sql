create function FN_ATT_GET_WORKDAYS(bgdt date, eddt date, empid bigint unsigned, optype int)
  returns decimal(12, 2)
  comment '得到时间区间内该部门的应工作天数'
  BEGIN
#参数说明 
#	optype 	1 考虑计薪方式，进行应出勤天数。
#			2 不考虑计薪方式，直接计算应出勤天数

#********* 规则性默认值：以下情况时理论的应工作天数为0
#*********					1考勤为弹性
#*********					2考勤为排班

DECLARE IS_MORNING_SPECIAL,IS_AFTERNOON_SPECIAL,IS_HAVE_ARR,is_have_emp,a_pay_way,dttype,a_is_exp_hol,i_att_rule int;
DECLARE monthly_work_days,this_sp_days,monthly_sp_days DECIMAL(12,2);
DECLARE ATTID BIGINT UNSIGNED;
DECLARE i_bgdt DATE;
DECLARE MY_BGDTTM,MY_EDDTTM DATETIME;
DECLARE ATTID_STR TEXT;
	SET i_bgdt = bgdt;
	#首先验证参数的有效性
	SELECT COUNT(*) into is_have_emp FROM emp_base_info WHERE emp_id = empid ;
	
	IF (is_have_emp=1 AND bgdt<=eddt) THEN		#如果有部门且初试时间小于等于结束时间时才开始计算
		SET monthly_work_days= 0,monthly_sp_days=0 ;
		WHILE (bgdt<=eddt) DO
			SET ATTID_STR=NULL,ATTID=NULL,MY_BGDTTM=NULL,MY_EDDTTM=NULL,IS_MORNING_SPECIAL=NULL,IS_AFTERNOON_SPECIAL=NULL;
			SET i_att_rule=NULL,a_pay_way=NULL,a_is_exp_hol=NULL,dttype=NULL,this_sp_days=0 ;
			
			CALL SP_DPT_GET_SETTINGID(empid,bgdt,1,ATTID_STR);
			SET ATTID = CAST(ATTID_STR AS UNSIGNED);
			
			SET IS_MORNING_SPECIAL = FN_ATT_IS_THISDAY_IN_SPHOL(bgdt,1,empid,NULL,NULL);
			SET IS_AFTERNOON_SPECIAL = FN_ATT_IS_THISDAY_IN_SPHOL(bgdt,1,empid,NULL,NULL);
			
			#得到考勤规则
			select att_rule,b.payday,is_exp_hol 
				into	i_att_rule,a_pay_way,a_is_exp_hol 
			from att_set_schema_new b where b.att_id=ATTID;
	
			IF i_att_rule = 1 THEN
							
				IF a_is_exp_hol IS NULL OR a_is_exp_hol NOT IN (0,1) THEN SET a_is_exp_hol = 0 ; END IF;
	
				SET dttype = FN_ATT_GET_DTTYPE(bgdt,empid);	#得到日期类型													
				if (dttype in (1,6)) then			#只有工作日算工作日				#if6
					IF IS_AFTERNOON_SPECIAL + IS_MORNING_SPECIAL = 0 THEN
						set monthly_work_days= monthly_work_days + 1;
					ELSEIF IS_AFTERNOON_SPECIAL + IS_MORNING_SPECIAL = 1 THEN
						set monthly_work_days= monthly_work_days + 0.5;
					END IF;
				end if;	
			ELSEIF i_att_rule = 3 THEN
				IF a_pay_way = 1 THEN
					set monthly_work_days= 21.75;
				ELSE
					SELECT COUNT(*) INTO IS_HAVE_ARR FROM att_arrange_schedual A WHERE A.emp_id=empid AND A.dt = bgdt;
					if IS_HAVE_ARR > 0 then			#有排班
						set monthly_work_days= monthly_work_days + 1;
					end if;
				END IF;	
			END IF;
			SET bgdt = DATE_ADD(bgdt,INTERVAL 1 DAY);
		END WHILE;
	ELSE
		set monthly_work_days  = 21.75;
	END IF;
	#如果考虑计薪方式 并且 计薪方式是21.75，超出的设为21.75
	if (a_pay_way = 1 AND optype=1) and (monthly_work_days <> 21.75) then		#if4
		set monthly_work_days = 21.75;
	end if;													#if4
	
	IF monthly_work_days IS NULL OR monthly_work_days < 0 THEN
		SET  monthly_work_days = 21.75;
	END IF;
	
	RETURN monthly_work_days;
END;

