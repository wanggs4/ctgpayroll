create procedure SP_JAVA_EVENT_EVERYDAY_0000()
  BEGIN
DECLARE CT,MXCT,MY_VERSION_CODE,MY_EMPID,MY_DEPTTYPE BIGINT UNSIGNED;
	TRUNCATE TABLE test_event;
	TRUNCATE TABLE att_month_report_oplog;

	CALL SP_SYS_CLEAN_TEMPTAB();
################整理时间轴	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('LOG_EMP_DEPT_CHANGE_ADJUST','start',NOW());
	DROP TABLE IF EXISTS tmp_log_emp_dept_change_list ;
	CREATE TABLE `tmp_log_emp_dept_change_list` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`emp_id` BIGINT(20) UNSIGNED NOT NULL COMMENT '员工id',
		`dept_type` TINYINT(3) UNSIGNED NOT NULL COMMENT '组织结构类型',
		PRIMARY KEY (`id`)
	)
	COLLATE='utf8mb4_general_ci'
	ENGINE=InnoDB;
	
	INSERT INTO tmp_log_emp_dept_change_list (emp_id,dept_type) 
		SELECT DISTINCT EMP_ID,DEPT_TYPE FROM log_emp_dept_change ;
	
	SET CT = 0,MXCT = 0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_log_emp_dept_change_list;
	WHILE CT <= MXCT AND CT > 0 DO
		SELECT EMP_ID,DEPT_TYPE INTO MY_EMPID,MY_DEPTTYPE FROM tmp_log_emp_dept_change_list WHERE ID = CT ;
		
		IF MY_EMPID IS NOT NULL THEN
			CALL SP_LOG_EMP_DEPT_CHANGE_ADJUST(MY_EMPID,MY_DEPTTYPE);
		END IF;
		
		SET CT = CT + 1;
	END WHILE;
	DROP TABLE IF EXISTS tmp_log_emp_dept_change_list ;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('LOG_EMP_DEPT_CHANGE_ADJUST','end',NOW());
	
################清理导入数据
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('TASK_DAILY_IMPORT_EMP_CLEAN','start',NOW());
	DROP TABLE IF EXISTS tmp_task_daily_import_emp_clean;
	CREATE TABLE `tmp_task_daily_import_emp_clean` (
		`ID` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`VERSION_CODE` BIGINT(20) UNSIGNED NOT NULL,
		PRIMARY KEY (`ID`)
	)COLLATE='utf8mb4_general_ci' ENGINE=InnoDB;
	
	UPDATE att_import_emp_daily_check A SET A.STATE=0 WHERE A.EXECUTE_TIME IS NULL;
	
	CALL SP_ATT_IMPORT_EMP_DAILY_CHECK(MY_VERSION_CODE);
	#完成后，清理相关表
	TRUNCATE TABLE att_import_emp_daily_check;

	#找出没有执行成功的版本号，然后依次执行版本号的数据
	INSERT INTO tmp_task_daily_import_emp_clean (VERSION_CODE)	
		SELECT DISTINCT VERSION_CODE FROM att_import_emp_daily_holiday WHERE STATE=0;
	#执行版本号的数据
	SET CT = 0, MXCT = 0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_task_daily_import_emp_clean ;
	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_VERSION_CODE = NULL;
		SELECT A.VERSION_CODE INTO MY_VERSION_CODE FROM tmp_task_daily_import_emp_clean A WHERE A.ID=CT;
		
		IF MY_VERSION_CODE IS NOT NULL THEN
			CALL SP_ATT_IMPORT_EMP_DAILY_HOLIDAY(MY_VERSION_CODE);
		END IF;
		SET CT = CT + 1;
	END WHILE;
	#完成后，清理相关表
	TRUNCATE TABLE att_import_emp_daily_holiday;	
	TRUNCATE TABLE tmp_task_daily_import_emp_clean;	
	

	#找出没有执行成功的版本号，然后依次执行版本号的数据
	INSERT INTO tmp_task_daily_import_emp_clean (VERSION_CODE)	
		SELECT DISTINCT VERSION_CODE FROM att_import_emp_daily_over WHERE STATE=0;
	#执行版本号的数据
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_task_daily_import_emp_clean ;
	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_VERSION_CODE = NULL;
		SELECT A.VERSION_CODE INTO MY_VERSION_CODE FROM tmp_task_daily_import_emp_clean A WHERE A.ID=CT;
		
		IF MY_VERSION_CODE IS NOT NULL THEN
			CALL SP_ATT_IMPORT_EMP_DAILY_OVER(MY_VERSION_CODE);
		END IF;
		SET CT = CT + 1;
	END WHILE;
	#完成后，清理相关表
	TRUNCATE TABLE att_import_emp_daily_over;	
	TRUNCATE TABLE tmp_task_daily_import_emp_clean;	
	

	#找出没有执行成功的版本号，然后依次执行版本号的数据
	INSERT INTO tmp_task_daily_import_emp_clean (VERSION_CODE)	
		SELECT DISTINCT VERSION_CODE FROM att_import_reverse_pool WHERE STATE=0;
	#执行版本号的数据
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_task_daily_import_emp_clean ;
	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_VERSION_CODE = NULL;
		SELECT A.VERSION_CODE INTO MY_VERSION_CODE FROM tmp_task_daily_import_emp_clean A WHERE A.ID=CT;
		
		IF MY_VERSION_CODE IS NOT NULL THEN
			CALL SP_ATT_IMPORT_REVERSE_POOL(MY_VERSION_CODE);
		END IF;
		SET CT = CT + 1;
	END WHILE;
	#完成后，清理相关表
	TRUNCATE TABLE att_import_reverse_pool;	
	DROP TABLE IF EXISTS tmp_task_daily_import_emp_clean;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('TASK_DAILY_IMPORT_EMP_CLEAN','end',NOW());
	
END;

