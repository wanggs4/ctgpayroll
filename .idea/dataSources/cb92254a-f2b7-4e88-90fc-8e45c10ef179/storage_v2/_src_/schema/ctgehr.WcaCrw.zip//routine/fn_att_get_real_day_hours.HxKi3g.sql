create function FN_ATT_GET_REAL_DAY_HOURS(bgtm time, edtm time, empid bigint unsigned, this_date date)
  returns decimal(12, 2)
  comment '通过给出的两个时间和部门id得到实际一天内的发生时间'
  LABEL:BEGIN
DECLARE real_day_hours,i_flex_hour DECIMAL(12,2);	
DECLARE is_have_emp,bgst,edst,minunit,i_att_rule,i_zh_ratio,i_zh_hour INT;
DECLARE mst,met,ast,aet TIME;
DECLARE ATTID BIGINT UNSIGNED;
DECLARE ATTID_STR TEXT;
set real_day_hours = 0;
	SET bgtm = FN_SYS_TMFMT_PURGE_SECOND(bgtm);
	SET edtm = FN_SYS_TMFMT_PURGE_SECOND(edtm);
	#首先验证参数的有效性
	SELECT COUNT(*) into is_have_emp FROM emp_base_info WHERE emp_id = empid;
	
	CALL SP_DPT_GET_SETTINGID(empid,this_date,1,ATTID_STR);
	SET ATTID = CAST(ATTID_STR AS UNSIGNED);

	IF (is_have_emp=1 and ATTID IS NOT NULL and bgtm<=edtm) THEN		
	#如果有部门且有出勤方案且初试时间小于等于结束时间时才开始计算
		#1 得到四个时间
		SELECT att_rule,flex_hour,zh_ratio,zh_hour,
				morn_start_time,morn_end_time,aftn_start_time,aftn_end_time,b.le_fine_compute_unit 
			INTO i_att_rule,i_flex_hour,i_zh_ratio,i_zh_hour,
				mst,met,ast,aet,minunit
		FROM att_set_schema_new b 
		WHERE b.att_id=ATTID;
		
		#如果i_flex_hour为空，也设为0
		if i_flex_hour is null then
			set i_flex_hour = 0;
		end if;
		
		#如果i_flex_hour大于0时，需要把aet追加上i_flex_hour的时间
		IF i_flex_hour>0 THEN
			SET aet = TIME(DATE_ADD(CONCAT(DATE(NOW()),' ',aet),INTERVAL i_flex_hour MINUTE));
		END IF;

		#当坐班考勤时，考虑四个时间
		IF i_att_rule = 1 THEN
			#2 判断起止时间的情况 
				#bgtm
					#条件						目标值		目标所在时段
					#bgtm < mst					mst			bgst=1(上午)
					#mst <= bgtm <= met		bgtm			bgst=1	
					#met < bgtm < ast			ast			bgst=2（下午）
					#ast <= bgtm <= aet		bgtm			bgst=2
					#bgtm > aet					null			bgst=3(不在考勤时间内，返回0)
			IF (bgtm < mst) THEN
				SET bgtm = mst;
				SET bgst = 1;
			END IF;
			
			IF (mst <= bgtm and bgtm <= met) THEN
				SET bgst = 1;			
			END IF;
			
			IF (met < bgtm and bgtm < ast) THEN
				SET bgtm = ast;
				SET bgst = 2;			
			END IF;
			
			IF (ast <= bgtm and bgtm <= aet) THEN
				SET bgst = 2;
			END IF;
			
			IF (bgtm > aet) THEN
				SET bgst = 3;
			END IF;
				#edtm
					#edtm < mst					0				edst=3
					#mst <= edtm <= met		edtm			edst=1(上午)
					#met < edtm < ast			met			edst=1
					#ast <= edtm <= aet		edtm			edst=2（下午）
					#edtm > aet					aet			edst=2
			IF (edtm < mst) THEN
				SET edst = 3;
			END IF;
			
			IF (mst <= edtm and edtm <= met) THEN
				SET edst = 1;			
			END IF;
			
			IF (met < edtm and edtm < ast) THEN
				SET edtm = met;
				SET edst = 1;			
			END IF;
			
			IF (ast <= edtm and edtm <= aet) THEN
				SET edst = 2;
			END IF;
			
			IF (edtm > aet) THEN
				SET edtm = aet;
				SET edst = 2;
			END IF;
			
			IF (bgst=3 or edst=3) or (bgst=2 and edst=1) THEN		#给出的时间不在考勤范围内
				SET real_day_hours = 0 ;
			ELSEIF (bgst=edst and bgst<>3 and edst<>3) THEN			#都在上午或都在下午
				SET real_day_hours = TIME_TO_SEC(timediff(edtm,bgtm))/60;
			ELSEIF (bgst<edst and bgst<>3 and edst<>3) THEN			#一个上午一个下午
				SET real_day_hours = TIME_TO_SEC(timediff(met,bgtm))/60 + TIME_TO_SEC(timediff(edtm,ast))/60;
			END IF;
			
			
			#当发生时间超出了当天的理论工作时长，则替换为理论时长
			IF (real_day_hours > FN_ATT_GET_WORKHOURS(ATTID)*60) THEN
				SET real_day_hours = FN_ATT_GET_WORKHOURS(ATTID)*60;
			END IF;
/*
		ELSEIF i_att_rule = 2 THEN 
		#弹性考勤时
			IF i_zh_ratio=1 THEN	#按天算
				SET real_day_hours=TIME_TO_SEC(TIMEDIFF(edtm,bgtm))/60;
				#如果大于工作时间则等于最大工作时间
				IF real_day_hours/60 > i_zh_hour THEN
					SET real_day_hours = i_zh_hour * 60;				
				END IF;
			ELSEIF i_zh_ratio=2 THEN	#按月算
				SET real_day_hours=TIME_TO_SEC(TIMEDIFF(edtm,bgtm))/60;			
			END IF;
*/
		END IF;
	ELSE	#没有考勤或排班
		SET real_day_hours=TIME_TO_SEC(TIMEDIFF(edtm,bgtm))/60;
	END IF;
	
	IF minunit IS NOT NULL THEN
		CASE minunit 
		WHEN 1 THEN	#15分钟
			set real_day_hours = ROUND(CEILING(real_day_hours/15)*15,2);
		WHEN 2 THEN	#30分钟
			set real_day_hours = ROUND(CEILING(real_day_hours/30)*30,2);
		WHEN 3 THEN	#1小时
			set real_day_hours = ROUND(CEILING(real_day_hours/60)*60,2);
		WHEN 4 THEN	#半天
			set real_day_hours = ROUND(CEILING(real_day_hours/(FN_ATT_GET_WORKHOURS(ATTID)/2*60))*(FN_ATT_GET_WORKHOURS(ATTID)/2*60),2);
		WHEN 5 THEN	#全天
			set real_day_hours = ROUND(CEILING(real_day_hours/(FN_ATT_GET_WORKHOURS(ATTID)*60))*(FN_ATT_GET_WORKHOURS(ATTID)*60),2);
		ELSE
			set real_day_hours = real_day_hours ;
		END CASE;					
	END IF;
	
	RETURN real_day_hours;
END;

