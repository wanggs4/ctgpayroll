create procedure SP_PAYROLL_FML_BULK_GETRES(IN custid bigint unsigned, IN ym int, IN setid bigint unsigned)
  comment '针对自定义公式数据进行计算'
  BEGIN
DECLARE i_custid,i_deptid,i_emp,i_arch_id,i_adj_id BIGINT UNSIGNED;
DECLARE i_schtps,emp_ct,emp_mxct,sch_ct,sch_mxct,bz_ct,bz_mxct,des_ct,des_mxct,is_att,MAX_ENABLE_TIME BIGINT;
DECLARE i_schids,tmp_schids,tmp_schtps,this_schid,this_schtp VARCHAR(200); 
DECLARE i_formula TEXT;
DECLARE s_bgdt,s_eddt DATE;
DECLARE MAX_OPR_TIME DATETIME;
DECLARE i_version_code VARCHAR(50);
 SET i_version_code = UUID();
 SET @i_version_code = i_version_code;
	
	SELECT cust_id,schema_id,schema_type,sala_ymd_begin,sala_ymd_end,att_source,arch_id
		into i_custid,i_schids,i_schtps,s_bgdt,s_eddt,is_att,i_arch_id 
	FROM payroll_sala_settings WHERE SET_ID=setid;
	
	
	
	set sch_ct = 1;
	set sch_mxct = LENGTH(i_schids) - LENGTH(REPLACE(i_schids,',',''))+1;
	SET tmp_schids = i_schids;
	SET tmp_schtps = i_schtps;

	WHILE ( sch_ct <= sch_mxct ) DO													
		IF sch_mxct=1 THEN
			SET this_schid = tmp_schids;
			SET this_schtp = tmp_schtps;
		ELSE
			SET tmp_schids=CONCAT(tmp_schids,',');
			SET tmp_schtps=CONCAT(tmp_schtps,',');
			SET this_schid = LEFT(tmp_schids,LOCATE(',',tmp_schids)-1);
			SET this_schtp = LEFT(tmp_schtps,LOCATE(',',tmp_schtps)-1);
		END IF;
		
		
		
		
		
		
		
		
		delete from  tmp_bz_fml where version_code = i_version_code;
		INSERT INTO tmp_bz_fml (version_code,formula,des_tb_name,des_col_name)
			SELECT i_version_code,formula,des_tb_name,des_col_name
			FROM payroll_set_sala_schema_item 
			WHERE schema_id = this_schid AND is_formula_compute=1 AND formula IS NOT NULL
			ORDER BY COMPUTE_ORDER;
		SET bz_ct = 0 ;
		SET bz_mxct = 0 ;
		SELECT MIN(ID),MAX(ID) INTO bz_ct,bz_mxct FROM tmp_bz_fml where version_code = i_version_code;
		WHILE (bz_ct<=bz_mxct AND bz_ct>0) DO
			SET @DES_TB='';
			SET @DES_COL='';
			SET i_formula = '';
			SET @SELECTION='';
			SET @SQL2 = '';
			SET @I_VALUE=0;
			
			SELECT formula,des_tb_name,des_col_name
				INTO i_formula,@DES_TB,@DES_COL
			FROM tmp_bz_fml WHERE ID = bz_ct and version_code = i_version_code;
			
			delete from TMP_BZ_B where version_code = i_version_code;

			IF @DES_COL IS NOT NULL THEN
				INSERT INTO TMP_BZ_B (version_code,payrollid,EMP_ID) 
					SELECT i_version_code,id,EMP_ID FROM payroll_tol WHERE SET_ID=setid;
					
				set emp_ct = 0;
				set emp_mxct = 0;
				SELECT MIN(ID),MAX(ID) INTO emp_ct,emp_mxct FROM TMP_BZ_B where version_code = i_version_code;
	
				
				WHILE (emp_ct <= emp_mxct and emp_ct>0) DO																		
					SET MAX_ENABLE_TIME = NULL;
					SET MAX_OPR_TIME = NULL;
					SET i_adj_id = NULL;
					SET @i_adj_id = NULL;
					set @PRID=null;
					SELECT payrollid,emp_id INTO @PRID,i_emp FROM TMP_BZ_B WHERE ID=emp_ct and version_code = i_version_code;
					delete from TMP_BZ_A where version_code = i_version_code;
#if @DES_COL ='bz31' then
#	select * FROM TMP_BZ_A;	
#end if;
					
					IF(@PRID is not null) THEN																	
						SELECT MAX(ENABLE_TIME) INTO MAX_ENABLE_TIME FROM emp_salary_adj WHERE emp_id=i_emp and enable_time <= cast(replace(s_eddt,'-','') as unsigned) and is_delete=0;
						SELECT MAX(opr_time) INTO MAX_OPR_TIME FROM emp_salary_adj WHERE emp_id=i_emp and enable_time = MAX_ENABLE_TIME and is_delete=0;
						SELECT adj_id INTO i_adj_id FROM emp_salary_adj WHERE emp_id=i_emp and enable_time = MAX_ENABLE_TIME AND opr_time = MAX_OPR_TIME and is_delete=0;
						
						SET @i_adj_id = i_adj_id;
					
						IF (i_formula = 'KR_DYJBGZ') THEN				
							CASE is_att
							WHEN  3 then		
								CALL SP_PAYROLL_FML_VIP_KR_DYJBGZ(i_emp,s_bgdt,s_eddt,@I_VALUE,3,NULL,this_schid,setid);
							WHEN  1 then 		
								CALL SP_PAYROLL_FML_VIP_KR_DYJBGZ(i_emp,s_bgdt,s_eddt,@I_VALUE,1,NULL,this_schid,setid);
							WHEN  2 then 		
								CALL SP_PAYROLL_FML_VIP_KR_DYJBGZ(i_emp,s_bgdt,s_eddt,@I_VALUE,2,NULL,this_schid,setid);
							WHEN  4 then 		
								CALL SP_PAYROLL_FML_VIP_KR_DYJBGZ(i_emp,s_bgdt,s_eddt,@I_VALUE,4,i_arch_id,this_schid,setid);
							END CASE;
						ELSEIF (i_formula = 'KR_GZRJB') THEN			
							CALL SP_PAYROLL_FML_VIP_KR_JB(i_emp,s_bgdt,s_eddt,@I_VALUE,1,i_arch_id,this_schid,setid);
						ELSEIF (i_formula = 'KR_WKDJB') THEN			
							CALL SP_PAYROLL_FML_VIP_KR_JB(i_emp,s_bgdt,s_eddt,@I_VALUE,2,i_arch_id,this_schid,setid);
						ELSEIF (i_formula = 'KR_HOLJB') THEN			
							CALL SP_PAYROLL_FML_VIP_KR_JB(i_emp,s_bgdt,s_eddt,@I_VALUE,3,i_arch_id,this_schid,setid);
						ELSEIF (i_formula = 'KR_SICK') THEN			
							CALL SP_PAYROLL_FML_VIP_KR_HOL(i_emp,s_bgdt,s_eddt,@I_VALUE,1,i_arch_id,this_schid,setid);
						ELSEIF (i_formula = 'KR_THING') THEN			
							CALL SP_PAYROLL_FML_VIP_KR_HOL(i_emp,s_bgdt,s_eddt,@I_VALUE,2,i_arch_id,this_schid,setid);
						ELSEIF (i_formula = 'KR_BORN') THEN			
							CALL SP_PAYROLL_FML_VIP_KR_HOL(i_emp,s_bgdt,s_eddt,@I_VALUE,3,i_arch_id,this_schid,setid);
						ELSEIF (i_formula = 'MY_QQKK') THEN
							CALL SP_PAYROLL_FML_VIP_MY('MY_QQKK',i_emp,@PRID,setid,this_schid,@I_VALUE);
						ELSEIF (i_formula = 'MY_GTS') THEN
							CALL SP_PAYROLL_FML_VIP_MY('MY_GTS',i_emp,@PRID,setid,this_schid,@I_VALUE);
						ELSEIF (i_formula = 'MY_LZBCJ_TAX') THEN
							CALL SP_PAYROLL_FML_VIP_MY('MY_LZBCJ_TAX',i_emp,@PRID,setid,this_schid,@I_VALUE);
						ELSEIF (i_formula = 'MY_NZJ_TAX') THEN
							CALL SP_PAYROLL_FML_VIP_MY('MY_NZJ_TAX',i_emp,@PRID,setid,this_schid,@I_VALUE);
						ELSEIF (i_formula = 'MY_JJ') THEN
							CALL SP_PAYROLL_FML_VIP_MY('MY_JJ',i_emp,@PRID,setid,this_schid,@I_VALUE);
						ELSEIF (i_formula = 'LNNJ_GLGZ') THEN
							CALL SP_PAYROLL_FML_VIP_LNNJ('LNNJ_GLGZ',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'LNNJ_GRSDS') THEN
							CALL SP_PAYROLL_FML_VIP_LNNJ('LNNJ_GRSDS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'YLHH_BJBL') THEN
							CALL SP_PAYROLL_FML_VIP_YLHH('YLHH_BJBL',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'YLHH_CDKK') THEN
							CALL SP_PAYROLL_FML_VIP_YLHH('YLHH_CDKK',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'YLHH_YCQTS') THEN
							CALL SP_PAYROLL_FML_VIP_YLHH('YLHH_YCQTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'YLHH_YGCQTS') THEN
							CALL SP_PAYROLL_FML_VIP_YLHH('YLHH_YGCQTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_CFBZ') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_CFBZ',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_GS') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_GS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_WORKDAY_OVER') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_WORKDAY_OVER',i_emp,@PRID,setid,@I_VALUE);
#SELECT 'HX_WORKDAY_OVER',i_emp,@PRID,setid,@I_VALUE,@DES_TB,@DES_COL;
						ELSEIF (i_formula = 'HX_WEEKEND_OVER') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_WEEKEND_OVER',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_HOLIDAY_OVER') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_HOLIDAY_OVER',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_BJTS') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_BJTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_SJTS') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_SJTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_KGTS') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_KGTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_CDZTCS') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_CDZTCS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_JBGZ') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_JBGZ',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_GWGZ') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_GWGZ',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'HX_JXGZ') THEN
							CALL SP_PAYROLL_FML_VIP_HX('HX_JXGZ',i_emp,@PRID,setid,@I_VALUE);

						ELSEIF (i_formula = 'XHT_WORKDAY_OVER') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_WORKDAY_OVER',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_WEEKEND_OVER') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_WEEKEND_OVER',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_HOLIDAY_OVER') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_HOLIDAY_OVER',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_BJTS') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_BJTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_SJTS') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_SJTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_KGTS') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_KGTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_CDZT') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_CDZT',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_DXJTS') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_DXJTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_KGS') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_KGS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_YCQTS') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_YCQTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_SJCQTS') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_SJCQTS',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = 'XHT_WCQKK') THEN
							CALL SP_PAYROLL_FML_VIP_XHT('XHT_WCQKK',i_emp,@PRID,setid,@I_VALUE);
						ELSEIF (i_formula = '' OR i_formula IS NULL) THEN
							SET @A=1;
						ELSE										
							SET @SELECTION = i_formula;
							CASE this_schtp 
							WHEN '1' THEN
								IF i_arch_id IS NOT NULL THEN
									SET @SQL2 = CONCAT('INSERT INTO TMP_BZ_A SELECT  ''',@i_version_code,''',',@SELECTION,' FROM payroll_gz_base  LEFT JOIN payroll_bz_gz  ON payroll_gz_base.ID=payroll_bz_gz.id   LEFT JOIN cust_period_emp_detail ON payroll_gz_base.EMP_ID=cust_period_emp_detail.emp_id  AND payroll_gz_base.MONTH_STEP=cust_period_emp_detail.emp_period_version  LEFT JOIN cust_period_emp_detail_calculation ON cust_period_emp_detail.main_id=cust_period_emp_detail_calculation.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_detail_calculation.emp_id LEFT JOIN cust_period_emp_soin_detail ON cust_period_emp_detail.main_id=cust_period_emp_soin_detail.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_soin_detail.emp_id LEFT JOIN att_st_month_quick_view ON payroll_gz_base.EMP_ID=att_st_month_quick_view.emp_id AND att_st_month_quick_view.st_id=',i_arch_id,' WHERE payroll_gz_base.ID=',@PRID,';');
								ELSE
									SET @SQL2 = CONCAT('INSERT INTO TMP_BZ_A SELECT  ''',@i_version_code,''',',@SELECTION,' FROM payroll_gz_base  LEFT JOIN payroll_bz_gz  ON payroll_gz_base.ID=payroll_bz_gz.id   LEFT JOIN cust_period_emp_detail ON payroll_gz_base.EMP_ID=cust_period_emp_detail.emp_id  AND payroll_gz_base.MONTH_STEP=cust_period_emp_detail.emp_period_version  LEFT JOIN cust_period_emp_detail_calculation ON cust_period_emp_detail.main_id=cust_period_emp_detail_calculation.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_detail_calculation.emp_id LEFT JOIN cust_period_emp_soin_detail ON cust_period_emp_detail.main_id=cust_period_emp_soin_detail.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_soin_detail.emp_id  WHERE payroll_gz_base.ID=',@PRID,';');
								END IF;
							WHEN '2' THEN
								IF i_arch_id IS NOT NULL THEN
									SET @SQL2 = CONCAT('INSERT INTO TMP_BZ_A SELECT  ''',@i_version_code,''',',@SELECTION,' FROM payroll_lwf_base LEFT JOIN payroll_bz_lwf ON payroll_lwf_base.ID=payroll_bz_lwf.id LEFT JOIN cust_period_emp_detail ON payroll_lwf_base.EMP_ID=cust_period_emp_detail.emp_id AND payroll_lwf_base.MONTH_STEP=cust_period_emp_detail.emp_period_version LEFT JOIN cust_period_emp_detail_calculation ON cust_period_emp_detail.main_id=cust_period_emp_detail_calculation.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_detail_calculation.emp_id LEFT JOIN cust_period_emp_soin_detail ON cust_period_emp_detail.main_id=cust_period_emp_soin_detail.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_soin_detail.emp_id LEFT JOIN att_st_month_quick_view ON payroll_gz_base.EMP_ID=att_st_month_quick_view.emp_id AND att_st_month_quick_view.st_id=',i_arch_id,' WHERE payroll_lwf_base.ID=',@PRID,';');
								ELSE
									SET @SQL2 = CONCAT('INSERT INTO TMP_BZ_A SELECT  ''',@i_version_code,''',',@SELECTION,' FROM payroll_lwf_base LEFT JOIN payroll_bz_lwf ON payroll_lwf_base.ID=payroll_bz_lwf.id LEFT JOIN cust_period_emp_detail ON payroll_lwf_base.EMP_ID=cust_period_emp_detail.emp_id AND payroll_lwf_base.MONTH_STEP=cust_period_emp_detail.emp_period_version LEFT JOIN cust_period_emp_detail_calculation ON cust_period_emp_detail.main_id=cust_period_emp_detail_calculation.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_detail_calculation.emp_id LEFT JOIN cust_period_emp_soin_detail ON cust_period_emp_detail.main_id=cust_period_emp_soin_detail.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_soin_detail.emp_id WHERE payroll_lwf_base.ID=',@PRID,';');
								END IF;
							WHEN '3' THEN
								IF i_arch_id IS NOT NULL THEN
									SET @SQL2 = CONCAT('INSERT INTO TMP_BZ_A SELECT  ''',@i_version_code,''',',@SELECTION,' FROM payroll_nzj_base LEFT JOIN payroll_bz_nzj ON payroll_nzj_base.ID=payroll_bz_nzj.id LEFT JOIN cust_period_emp_detail ON payroll_nzj_base.EMP_ID=cust_period_emp_detail.emp_id AND payroll_nzj_base.MONTH_STEP=cust_period_emp_detail.emp_period_version LEFT JOIN cust_period_emp_detail_calculation ON cust_period_emp_detail.main_id=cust_period_emp_detail_calculation.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_detail_calculation.emp_id LEFT JOIN cust_period_emp_soin_detail ON cust_period_emp_detail.main_id=cust_period_emp_soin_detail.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_soin_detail.emp_id LEFT JOIN att_st_month_quick_view ON payroll_gz_base.EMP_ID=att_st_month_quick_view.emp_id AND att_st_month_quick_view.st_id=',i_arch_id,' WHERE payroll_nzj_base.ID=',@PRID,';');
								ELSE
									SET @SQL2 = CONCAT('INSERT INTO TMP_BZ_A SELECT  ''',@i_version_code,''',',@SELECTION,' FROM payroll_nzj_base LEFT JOIN payroll_bz_nzj ON payroll_nzj_base.ID=payroll_bz_nzj.id LEFT JOIN cust_period_emp_detail ON payroll_nzj_base.EMP_ID=cust_period_emp_detail.emp_id AND payroll_nzj_base.MONTH_STEP=cust_period_emp_detail.emp_period_version LEFT JOIN cust_period_emp_detail_calculation ON cust_period_emp_detail.main_id=cust_period_emp_detail_calculation.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_detail_calculation.emp_id LEFT JOIN cust_period_emp_soin_detail ON cust_period_emp_detail.main_id=cust_period_emp_soin_detail.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_soin_detail.emp_id  WHERE payroll_nzj_base.ID=',@PRID,';');
								END IF;
							WHEN '4' THEN
								IF i_arch_id IS NOT NULL THEN
									SET @SQL2 = CONCAT('INSERT INTO TMP_BZ_A SELECT  ''',@i_version_code,''',',@SELECTION,' FROM payroll_lzf_base LEFT JOIN payroll_bz_lzf ON payroll_lzf_base.ID=payroll_bz_lzf.id LEFT JOIN cust_period_emp_detail ON payroll_lzf_base.EMP_ID=cust_period_emp_detail.emp_id AND payroll_lzf_base.MONTH_STEP=cust_period_emp_detail.emp_period_version LEFT JOIN cust_period_emp_detail_calculation ON cust_period_emp_detail.main_id=cust_period_emp_detail_calculation.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_detail_calculation.emp_id LEFT JOIN cust_period_emp_soin_detail ON cust_period_emp_detail.main_id=cust_period_emp_soin_detail.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_soin_detail.emp_id LEFT JOIN att_st_month_quick_view ON payroll_gz_base.EMP_ID=att_st_month_quick_view.emp_id AND att_st_month_quick_view.st_id=',i_arch_id,' WHERE payroll_lzf_base.ID=',@PRID,';');
								ELSE
									SET @SQL2 = CONCAT('INSERT INTO TMP_BZ_A SELECT  ''',@i_version_code,''',',@SELECTION,' FROM payroll_lzf_base LEFT JOIN payroll_bz_lzf ON payroll_lzf_base.ID=payroll_bz_lzf.id LEFT JOIN cust_period_emp_detail ON payroll_lzf_base.EMP_ID=cust_period_emp_detail.emp_id AND payroll_lzf_base.MONTH_STEP=cust_period_emp_detail.emp_period_version LEFT JOIN cust_period_emp_detail_calculation ON cust_period_emp_detail.main_id=cust_period_emp_detail_calculation.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_detail_calculation.emp_id LEFT JOIN cust_period_emp_soin_detail ON cust_period_emp_detail.main_id=cust_period_emp_soin_detail.main_id AND cust_period_emp_detail.emp_id=cust_period_emp_soin_detail.emp_id WHERE payroll_lzf_base.ID=',@PRID,';');
								END IF;
							END CASE;

							IF @SQL2 IS NOT NULL THEN
								PREPARE stmt2 FROM @SQL2;
								EXECUTE stmt2;
								DEALLOCATE PREPARE stmt2;
	
	
							END IF;
							
							SELECT COL_VALUE INTO @I_VALUE FROM TMP_BZ_A where version_code = i_version_code;
		
							IF @I_VALUE IS NULL THEN SET @I_VALUE = 0; END IF;
							SET @I_VALUE = ROUND(@I_VALUE,2);
						END IF;
						
						SET @SQL3=CONCAT('UPDATE `',@DES_TB,'` SET `',@DES_COL,'` = ''',@I_VALUE,''' WHERE ID=',@PRID,';');
						IF @SQL3 IS NOT NULL  THEN 
							PREPARE stmt3 FROM @SQL3;
							EXECUTE stmt3;
							DEALLOCATE PREPARE stmt3;
						END IF;
	
					END IF;
	
					SET emp_ct = emp_ct + 1;
				END WHILE;
			END IF;
			SET bz_ct = bz_ct + 1;
		END WHILE;
		SET sch_ct= sch_ct + 1;
	END WHILE;
 DELETE FROM tmp_bz_fml WHERE version_code = i_version_code;
 DELETE FROM TMP_BZ_B WHERE version_code = i_version_code;
 DELETE FROM TMP_BZ_A WHERE version_code = i_version_code;
END;

