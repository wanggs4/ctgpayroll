create procedure SP_ATT_POOL_SICK_OPERATE(IN MY_EMP      bigint, IN MY_APPLY_ID bigint, IN MY_THIS_YEAR int,
                                          IN MY_COL_NAME varchar(50), IN MY_DO_VALUE decimal(10, 5))
  comment '针对带薪病假池的相应计算'
  BEGIN
/*	参数说明
	MY_EMP：			员工id
	MY_APPLY_ID：	本次修改涉及的申请id
	MY_THIS_YEAR：	年度
	MY_COL_NAME：	更改的目标字段名
	MY_DO_VALUE：	改动的值
*/
DECLARE IS_ALREADY_LOGED,IS_HAVE_DAILY_REPORT,IS_HAVE_LOG,IS_HAVE_POOL,IS_HAVE_EMP,IS_HAVE_APPLY INT;
DECLARE LEFT_OUT_DO_VALUE,MOD_THIS_YEAR_LEFT,MOD_THIS_YEAR_USE,MOD_THIS_YEAR_HAVE,ORI_THIS_YEAR_HAVE,ORI_THIS_YEAR_LEFT,ORI_THIS_YEAR_USE,LOG_HAVE_DO_VALUE,LOG_LEFT_DO_VALUE,LOG_USE_DO_VALUE,MY_LEFT_REAL_DO_VALUE DECIMAL(10,5);	
DECLARE ORI_LOG_BG_YEAR,MY_BG_YEAR,MY_ED_YEAR,LOG_BG_YEAR,LOG_ED_YEAR YEAR;
	
	SELECT COUNT(*) INTO IS_HAVE_EMP FROM EMP_BASE_INFO WHERE EMP_ID = MY_EMP AND EMP_STATE IS NOT NULL AND IS_DELETE=0;
	IF MY_COL_NAME IN ('this_year_have','this_year_left') THEN
		IF MY_DO_VALUE < 0 THEN
			SELECT COUNT(*) INTO IS_HAVE_APPLY FROM att_hol_apply WHERE EMP_ID = MY_EMP AND APPLY_ID=MY_APPLY_ID;
			SELECT COUNT(*) + IFNULL(IS_HAVE_APPLY,0) INTO IS_HAVE_APPLY FROM att_over_apply_with_rest WHERE EMP_ID = MY_EMP AND APPLY_ID=MY_APPLY_ID;
		ELSEIF MY_DO_VALUE > 0 THEN 
			SELECT COUNT(*) INTO IS_HAVE_APPLY FROM att_over_apply WHERE EMP_ID = MY_EMP AND APPLY_ID=MY_APPLY_ID;
			SELECT COUNT(*) + IFNULL(IS_HAVE_APPLY,0) INTO IS_HAVE_APPLY FROM att_over_apply_with_rest WHERE EMP_ID = MY_EMP AND APPLY_ID=MY_APPLY_ID;
		ELSEIF MY_DO_VALUE = 0 THEN
			SELECT COUNT(*) INTO IS_HAVE_APPLY FROM att_hol_apply WHERE EMP_ID = MY_EMP AND APPLY_ID=MY_APPLY_ID;
			SELECT COUNT(*)+IS_HAVE_APPLY INTO IS_HAVE_APPLY FROM att_over_apply WHERE EMP_ID = MY_EMP AND APPLY_ID=MY_APPLY_ID;
			SELECT COUNT(*) + IFNULL(IS_HAVE_APPLY,0) INTO IS_HAVE_APPLY FROM att_over_apply_with_rest WHERE EMP_ID = MY_EMP AND APPLY_ID=MY_APPLY_ID;
		END IF;
	ELSEIF MY_COL_NAME = 'this_year_use' THEN
		SELECT COUNT(*) INTO IS_HAVE_APPLY FROM att_hol_apply WHERE EMP_ID = MY_EMP AND APPLY_ID=MY_APPLY_ID;
	END IF;
	
	IF ( IS_HAVE_EMP>0 AND IS_HAVE_APPLY>0 AND MY_COL_NAME IN ('last_year_left','this_year_have','this_year_use','this_year_left') ) THEN
		#找到更新的起止年份
		SELECT MIN(A.this_year),MAX(A.this_year)	INTO MY_BG_YEAR,MY_ED_YEAR
		FROM att_hol_sick A
		WHERE A.emp_id = MY_EMP AND A.is_delete=0 ;

		#开始正式的处理
		CASE MY_COL_NAME
#PART 1
#SELECT 1;
		#剩余：只处理扣减和撤回
		WHEN 'this_year_left' THEN

			IF MY_DO_VALUE < 0 THEN
#SELECT 1.1;
				#先判断此apply_id是否第一次写入
				SELECT COUNT(*) INTO IS_ALREADY_LOGED FROM att_hol_sick_log WHERE APPLY_ID=MY_APPLY_ID ;
				IF IS_ALREADY_LOGED IS NULL THEN SET IS_ALREADY_LOGED = 0 ; END IF;
				
				#如果写入过，先把原有的log值归还，然后在进行逐年减扣计算
				#处理已经写入的数据，全部回退
				IF IS_ALREADY_LOGED > 0 THEN
					#得到LOG里面的最早和最晚年份
					SELECT MIN(A.which_year),MAX(A.which_year) INTO LOG_BG_YEAR,LOG_ED_YEAR
					FROM att_hol_sick_log A
					WHERE A.apply_id = MY_APPLY_ID;
					
					#有效之后再继续
					IF LOG_BG_YEAR IS NOT NULL AND LOG_ED_YEAR IS NOT NULL THEN
						#SET ORI_LOG_BG_YEAR = LOG_BG_YEAR;
						SET LEFT_OUT_DO_VALUE = 0;
						WHILE LOG_BG_YEAR <= LOG_ED_YEAR DO
							#读出log修改值
							SELECT A.do_value INTO LOG_LEFT_DO_VALUE
							FROM att_hol_sick_log A
							WHERE A.apply_id = MY_APPLY_ID AND A.which_year = LOG_BG_YEAR AND A.col_name = 'this_year_left';
							SELECT A.do_value INTO LOG_USE_DO_VALUE
							FROM att_hol_sick_log A
							WHERE A.apply_id = MY_APPLY_ID AND A.which_year = LOG_BG_YEAR AND A.col_name = 'this_year_use';
							IF LOG_LEFT_DO_VALUE IS NULL THEN SET LOG_LEFT_DO_VALUE = 0 ; END IF;						
							IF LOG_USE_DO_VALUE IS NULL THEN SET LOG_USE_DO_VALUE = 0 ; END IF;
							
							#IF LOG_BG_YEAR = ORI_LOG_BG_YEAR THEN
								#读出原始值
								SELECT A.this_year_have,A.this_year_left,A.this_year_use INTO ORI_THIS_YEAR_HAVE,ORI_THIS_YEAR_LEFT,ORI_THIS_YEAR_USE
								FROM att_hol_sick A
								WHERE A.emp_id=MY_EMP AND A.this_year=LOG_BG_YEAR AND IS_DELETE=0;
							#END IF;
							#计算退回值
							IF ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE - LEFT_OUT_DO_VALUE <= ORI_THIS_YEAR_HAVE THEN
								SET MOD_THIS_YEAR_LEFT = ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE - LEFT_OUT_DO_VALUE;
								SET MOD_THIS_YEAR_USE = ORI_THIS_YEAR_USE - LOG_USE_DO_VALUE + LEFT_OUT_DO_VALUE;
								SET LEFT_OUT_DO_VALUE=0;
							ELSE
								SET MOD_THIS_YEAR_LEFT = ORI_THIS_YEAR_HAVE;
								SET MOD_THIS_YEAR_USE = 0;
								SET LEFT_OUT_DO_VALUE = ORI_THIS_YEAR_HAVE - (ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE - LEFT_OUT_DO_VALUE);
							END IF;
							
							#IF MOD_THIS_YEAR_LEFT < 0 THEN SET MOD_THIS_YEAR_LEFT = 0 ; END IF;
							#IF MOD_THIS_YEAR_USE < 0 THEN SET MOD_THIS_YEAR_USE = 0 ; END IF;
							
#SELECT 1,MY_APPLY_ID,LOG_BG_YEAR,ORI_THIS_YEAR_LEFT,LOG_LEFT_DO_VALUE,MOD_THIS_YEAR_LEFT,ORI_THIS_YEAR_USE,LOG_USE_DO_VALUE,MOD_THIS_YEAR_USE;
							#更新到表
							UPDATE att_hol_sick A 
							SET A.this_year_use=IFNULL(MOD_THIS_YEAR_USE,0) ,A.this_year_left=IFNULL(MOD_THIS_YEAR_LEFT,0)
							WHERE A.emp_id=MY_EMP AND A.this_year=LOG_BG_YEAR AND IS_DELETE=0;
							
							DELETE FROM att_hol_sick_log WHERE APPLY_ID=MY_APPLY_ID AND which_year = LOG_BG_YEAR;
							#SET ORI_THIS_YEAR_USE = MOD_THIS_YEAR_USE, ORI_THIS_YEAR_LEFT = MOD_THIS_YEAR_LEFT;
							#累加年份
							SET LOG_BG_YEAR = LOG_BG_YEAR + 1;
						END WHILE;
					END IF;
				END IF;
				
				#重新初始化变量
				SET MOD_THIS_YEAR_USE=0,MOD_THIS_YEAR_LEFT=0,ORI_THIS_YEAR_USE=0,ORI_THIS_YEAR_LEFT=0,LOG_USE_DO_VALUE=0,LOG_LEFT_DO_VALUE=0;
				
				#逐年减扣计算:循环有池子的年份
				WHILE MY_BG_YEAR <= MY_ED_YEAR AND MY_DO_VALUE < 0 DO
					#读出当年是否有数据
					SELECT COUNT(*) INTO IS_HAVE_POOL
					FROM att_hol_sick A 
					WHERE A.emp_id = MY_EMP AND A.this_year = MY_BG_YEAR AND A.is_delete=0 ;
					
					#当年池子有数据时才进行操作
					IF IS_HAVE_POOL > 0 THEN				

						#读出当年的已用和剩余的初始值
						SELECT A.this_year_left,A.this_year_use 
							INTO ORI_THIS_YEAR_LEFT,ORI_THIS_YEAR_USE
						FROM att_hol_sick A 
						WHERE A.emp_id = MY_EMP AND A.this_year = MY_BG_YEAR AND A.is_delete=0 ;
												
						#当年剩余大于零的时候才再往后计算
						IF ORI_THIS_YEAR_LEFT > 0 THEN
							#如果当年池子够扣
							IF ORI_THIS_YEAR_LEFT + MY_DO_VALUE >= 0 THEN
								SET MY_LEFT_REAL_DO_VALUE = MY_DO_VALUE;
								SET MY_DO_VALUE = 0; 
							#如果当年池子不够扣
							ELSE
								SET MY_LEFT_REAL_DO_VALUE = -ORI_THIS_YEAR_LEFT;
								SET MY_DO_VALUE = MY_DO_VALUE - MY_LEFT_REAL_DO_VALUE;
							END IF;
							#计算公式：
							#	rest：ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE + MY_LEFT_REAL_DO_VALUE
							#	use：ORI_THIS_YEAR_USE - LOG_USE_DO_VALUE - MY_LEFT_REAL_DO_VALUE
							SET MOD_THIS_YEAR_LEFT = ORI_THIS_YEAR_LEFT + MY_LEFT_REAL_DO_VALUE;
							SET MOD_THIS_YEAR_USE = ORI_THIS_YEAR_USE - MY_LEFT_REAL_DO_VALUE;
						
#SELECT 2,MY_APPLY_ID,MY_BG_YEAR,MY_ED_YEAR,ORI_THIS_YEAR_LEFT,MY_LEFT_REAL_DO_VALUE,MOD_THIS_YEAR_LEFT,ORI_THIS_YEAR_USE,MY_LEFT_REAL_DO_VALUE,MOD_THIS_YEAR_USE;
							#THIS_YEAR_LEFT
							REPLACE INTO att_hol_sick_log 
								(emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value,log_time,partition_code) VALUES
								(MY_EMP,MY_APPLY_ID,MY_BG_YEAR,MY_COL_NAME,ORI_THIS_YEAR_LEFT,MY_LEFT_REAL_DO_VALUE,MOD_THIS_YEAR_LEFT,NOW(),MD5(CONCAT(MY_EMP,MY_APPLY_ID,MY_BG_YEAR,MY_COL_NAME)));
							#THIS_YEAR_USE
							REPLACE INTO att_hol_sick_log 
								(emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value,log_time,partition_code) VALUES
								(MY_EMP,MY_APPLY_ID,MY_BG_YEAR,'this_year_use',ORI_THIS_YEAR_USE,-MY_LEFT_REAL_DO_VALUE,MOD_THIS_YEAR_USE,NOW(),MD5(CONCAT(MY_EMP,MY_APPLY_ID,MY_BG_YEAR,'this_year_use')));
							#POOL
							UPDATE att_hol_sick A 
							SET A.this_year_use = IFNULL(MOD_THIS_YEAR_USE,0), A.this_year_left = IFNULL(MOD_THIS_YEAR_LEFT,0)
							WHERE A.emp_id=MY_EMP AND A.this_year=MY_BG_YEAR AND A.is_delete=0;
						END IF;
					END IF;
					#年份累加
					SET MY_BG_YEAR = MY_BG_YEAR + 1;
				END WHILE;
			#修改值为0，代表把已经做的修改撤回
			ELSEIF MY_DO_VALUE = 0 THEN

				#先判断此apply_id是否第一次写入
				SELECT COUNT(*) INTO IS_ALREADY_LOGED FROM att_hol_sick_log WHERE APPLY_ID=MY_APPLY_ID ;
				IF IS_ALREADY_LOGED IS NULL THEN SET IS_ALREADY_LOGED = 0 ; END IF;
				
				#如果写入过，把原有的log值归还
				#处理已经写入的数据，全部回退
				IF IS_ALREADY_LOGED > 0 THEN
					#得到LOG里面的最早和最晚年份
					SELECT MIN(A.which_year),MAX(A.which_year) INTO LOG_BG_YEAR,LOG_ED_YEAR
					FROM att_hol_sick_log A
					WHERE A.apply_id = MY_APPLY_ID;
					
					#SET ORI_LOG_BG_YEAR = LOG_BG_YEAR;
					#有效之后再继续
					IF LOG_BG_YEAR IS NOT NULL AND LOG_ED_YEAR IS NOT NULL THEN
						SET LEFT_OUT_DO_VALUE = 0;
						WHILE LOG_BG_YEAR <= LOG_ED_YEAR DO
							#读出log修改值
							SELECT A.do_value INTO LOG_LEFT_DO_VALUE
							FROM att_hol_sick_log A
							WHERE A.apply_id = MY_APPLY_ID AND A.which_year = LOG_BG_YEAR AND A.col_name = 'this_year_left';
							
							SELECT A.do_value INTO LOG_USE_DO_VALUE
							FROM att_hol_sick_log A
							WHERE A.apply_id = MY_APPLY_ID AND A.which_year = LOG_BG_YEAR AND A.col_name = 'this_year_use';
							
							IF LOG_LEFT_DO_VALUE IS NULL THEN SET LOG_LEFT_DO_VALUE = 0 ; END IF;
							IF LOG_USE_DO_VALUE IS NULL THEN SET LOG_USE_DO_VALUE = 0 ; END IF;
							
							#IF LOG_BG_YEAR = ORI_LOG_BG_YEAR THEN
								#读出原始值
								SELECT A.this_year_have,A.this_year_left,A.this_year_use INTO ORI_THIS_YEAR_HAVE,ORI_THIS_YEAR_LEFT,ORI_THIS_YEAR_USE
								FROM att_hol_sick A
								WHERE A.emp_id=MY_EMP AND A.this_year=LOG_BG_YEAR AND IS_DELETE=0;
							#END IF;
							#计算退回值
							IF ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE - LEFT_OUT_DO_VALUE <= ORI_THIS_YEAR_HAVE THEN
								SET MOD_THIS_YEAR_LEFT = ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE - LEFT_OUT_DO_VALUE;
								SET MOD_THIS_YEAR_USE = ORI_THIS_YEAR_USE - LOG_USE_DO_VALUE + LEFT_OUT_DO_VALUE;
								SET LEFT_OUT_DO_VALUE=0;
							ELSE
								SET MOD_THIS_YEAR_LEFT = ORI_THIS_YEAR_HAVE;
								SET MOD_THIS_YEAR_USE = 0;
								SET LEFT_OUT_DO_VALUE = ORI_THIS_YEAR_HAVE - (ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE - LEFT_OUT_DO_VALUE);
							END IF;
							#IF MOD_THIS_YEAR_LEFT < 0 THEN SET MOD_THIS_YEAR_LEFT = 0 ; END IF;
							#IF MOD_THIS_YEAR_USE < 0 THEN SET MOD_THIS_YEAR_USE = 0 ; END IF;
#SELECT 3,MY_APPLY_ID,LOG_BG_YEAR,ORI_THIS_YEAR_LEFT,LOG_LEFT_DO_VALUE,MOD_THIS_YEAR_LEFT,ORI_THIS_YEAR_USE,LOG_USE_DO_VALUE,MOD_THIS_YEAR_USE;
							#更新到表
							#THIS_YEAR_LEFT
							REPLACE INTO att_hol_sick_log 
								(emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value,log_time,partition_code) VALUES
								(MY_EMP,MY_APPLY_ID,LOG_BG_YEAR,MY_COL_NAME,ORI_THIS_YEAR_LEFT,0,MOD_THIS_YEAR_LEFT,NOW(),MD5(CONCAT(MY_EMP,MY_APPLY_ID,LOG_BG_YEAR,MY_COL_NAME)));
							#THIS_YEAR_USE
							REPLACE INTO att_hol_sick_log 
								(emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value,log_time,partition_code) VALUES
								(MY_EMP,MY_APPLY_ID,LOG_BG_YEAR,'this_year_use',ORI_THIS_YEAR_USE,0,MOD_THIS_YEAR_USE,NOW(),MD5(CONCAT(MY_EMP,MY_APPLY_ID,LOG_BG_YEAR,'this_year_use')));
							#POOL
							UPDATE att_hol_sick A 
								SET A.this_year_use = IFNULL(MOD_THIS_YEAR_USE,0), A.this_year_left = IFNULL(MOD_THIS_YEAR_LEFT,0)
								WHERE A.emp_id=MY_EMP AND A.this_year=LOG_BG_YEAR ;
							#沿用	
							#SET ORI_THIS_YEAR_LEFT=MOD_THIS_YEAR_LEFT,ORI_THIS_YEAR_USE=MOD_THIS_YEAR_USE;
							#累加年份
							SET LOG_BG_YEAR = LOG_BG_YEAR + 1;
						END WHILE;
					END IF;
				END IF;
				


			END IF;
			
#PART 2
#SELECT 2;
		#应有：只处理增加和撤回
		WHEN 'this_year_have' THEN
			#修改值为整数，来源都是加班转调休，需要同时对this_year_left进行记录
			IF MY_DO_VALUE > 0 THEN
			#只往MY_THIS_YEAR的年份上修改值
#SELECT 2.1;
				#读出当年是否有数据
				SELECT COUNT(*) INTO IS_HAVE_POOL
				FROM att_hol_sick A 
				WHERE A.emp_id = MY_EMP AND A.this_year = MY_THIS_YEAR AND A.is_delete=0;
				
				#当年池子有数据时才进行操作
				IF IS_HAVE_POOL > 0 THEN				
#------------->STEP1 : 得到和处理初始值
#SELECT 2.1.1;
					#读出当年的应有和剩余的初始值
					SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_left,0)
						INTO ORI_THIS_YEAR_HAVE,ORI_THIS_YEAR_LEFT
					FROM att_hol_sick A 
					WHERE A.emp_id = MY_EMP AND A.this_year = MY_THIS_YEAR AND A.is_delete=0;
						
#------------->STEP2 : 处理上次修改值 LOG_LEFT_DO_VALUE ，LOG_HAVE_DO_VALUE
#SELECT 2.1.2;						
					#得到与这年相关的log记录数量
					SELECT COUNT(*) INTO IS_HAVE_LOG 
					FROM att_hol_sick_log A 
					WHERE A.emp_id=MY_EMP AND A.apply_id=MY_APPLY_ID AND A.which_year=MY_THIS_YEAR AND (A.col_name=MY_COL_NAME OR A.col_name='this_year_left');
					#如果有记录，读出原有纪录的log值
					IF IS_HAVE_LOG > 0 THEN
						#读出上次log中rest的修改值
						SELECT IF(A.do_value IS NULL,0,A.do_value) INTO LOG_HAVE_DO_VALUE
						FROM att_hol_sick_log A 
						WHERE A.emp_id=MY_EMP AND A.apply_id=MY_APPLY_ID AND A.which_year=MY_THIS_YEAR AND A.col_name=MY_COL_NAME ;
						
						#读出上次log中use的修改值
						SELECT IF(A.do_value IS NULL,0,A.do_value) INTO LOG_LEFT_DO_VALUE
						FROM att_hol_sick_log A 
						WHERE A.emp_id=MY_EMP AND A.apply_id=MY_APPLY_ID AND A.which_year=MY_THIS_YEAR AND A.col_name='this_year_left' ;
					
					END IF;				
					IF LOG_LEFT_DO_VALUE IS NULL THEN SET LOG_LEFT_DO_VALUE = 0; END IF;
					IF LOG_HAVE_DO_VALUE IS NULL THEN SET LOG_HAVE_DO_VALUE = 0; END IF;
#------------->STEP3 : 计算修改后值
#SELECT 2.1.3;
					#计算方法：ORI_THIS_YEAR_HAVE - LOG_DO_VALUE + MY_DO_VALUE
					SET MOD_THIS_YEAR_HAVE = ORI_THIS_YEAR_HAVE - LOG_HAVE_DO_VALUE + MY_DO_VALUE;
					SET MOD_THIS_YEAR_LEFT = ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE + MY_DO_VALUE;
#------------->STEP4 : 写表
#SELECT 2.1.4;
					#THIS_YEAR_HAVE
					REPLACE INTO att_hol_sick_log 
						(emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value,log_time,partition_code) VALUES
						(MY_EMP,MY_APPLY_ID,MY_THIS_YEAR,MY_COL_NAME,ORI_THIS_YEAR_HAVE,MY_DO_VALUE,MOD_THIS_YEAR_HAVE,NOW(),MD5(CONCAT(MY_EMP,MY_APPLY_ID,MY_THIS_YEAR,MY_COL_NAME)));
					#THIS_YEAR_LEFT
					REPLACE INTO att_hol_sick_log 
						(emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value,log_time,partition_code) VALUES
						(MY_EMP,MY_APPLY_ID,MY_THIS_YEAR,'this_year_left',ORI_THIS_YEAR_LEFT,MY_DO_VALUE,MOD_THIS_YEAR_LEFT,NOW(),MD5(CONCAT(MY_EMP,MY_APPLY_ID,MY_THIS_YEAR,'this_year_left')));
					#POOL
					UPDATE att_hol_sick A 
						SET A.this_year_have = IFNULL(MOD_THIS_YEAR_HAVE,0), A.this_year_left = IFNULL(MOD_THIS_YEAR_LEFT,0)
						WHERE A.emp_id=MY_EMP AND A.this_year=MY_THIS_YEAR AND A.is_delete=0;
					
				END IF;
			#修改值为0，代表把已经做的修改撤回
			ELSEIF MY_DO_VALUE = 0 THEN
#SELECT 2.2;
				#读出当年是否有数据
				SELECT COUNT(*) INTO IS_HAVE_POOL
				FROM att_hol_sick A 
				WHERE A.emp_id = MY_EMP AND A.this_year = MY_THIS_YEAR AND A.is_delete=0;
				
				#当年池子有数据时才进行操作
				IF IS_HAVE_POOL > 0 THEN				
#------------->STEP1 : 得到和处理初始值
#SELECT 2.2.1;
					#读出当年的应有和剩余的初始值
					SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_left,0)
						INTO ORI_THIS_YEAR_HAVE,ORI_THIS_YEAR_LEFT
					FROM att_hol_sick A 
					WHERE A.emp_id = MY_EMP AND A.this_year = MY_THIS_YEAR AND A.is_delete=0;
						
#------------->STEP2 : 处理上次修改值 LOG_LEFT_DO_VALUE ，LOG_HAVE_DO_VALUE
#SELECT 2.2.2;						
					#得到与这年相关的log记录数量
					SELECT COUNT(*) INTO IS_HAVE_LOG 
					FROM att_hol_sick_log A 
					WHERE A.emp_id=MY_EMP AND A.apply_id=MY_APPLY_ID AND A.which_year=MY_THIS_YEAR AND (A.col_name=MY_COL_NAME OR A.col_name='this_year_left');
					#如果有记录，读出原有纪录的log值
					IF IS_HAVE_LOG > 0 THEN
						#读出上次log中rest的修改值
						SELECT IF(A.do_value IS NULL,0,A.do_value) INTO LOG_HAVE_DO_VALUE
						FROM att_hol_sick_log A 
						WHERE A.emp_id=MY_EMP AND A.apply_id=MY_APPLY_ID AND A.which_year=MY_THIS_YEAR AND A.col_name=MY_COL_NAME ;
						
						#读出上次log中use的修改值
						SELECT IF(A.do_value IS NULL,0,A.do_value) INTO LOG_LEFT_DO_VALUE
						FROM att_hol_sick_log A 
						WHERE A.emp_id=MY_EMP AND A.apply_id=MY_APPLY_ID AND A.which_year=MY_THIS_YEAR AND A.col_name='this_year_left' ;
					
						IF LOG_LEFT_DO_VALUE IS NULL THEN SET LOG_LEFT_DO_VALUE = 0; END IF;
						IF LOG_HAVE_DO_VALUE IS NULL THEN SET LOG_USE_DO_VALUE = 0; END IF;
					END IF;				
#------------->STEP3 : 计算修改后值
#SELECT 2.2.3;
					#计算方法：ORI_THIS_YEAR_HAVE - LOG_DO_VALUE + MY_DO_VALUE
					SET MOD_THIS_YEAR_HAVE = ORI_THIS_YEAR_HAVE - LOG_HAVE_DO_VALUE ;
					SET MOD_THIS_YEAR_LEFT = ORI_THIS_YEAR_LEFT - LOG_LEFT_DO_VALUE ;
#------------->STEP4 : 写表
#SELECT 2.2.4;
					#THIS_YEAR_HAVE
					REPLACE INTO att_hol_sick_log 
						(emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value,log_time,partition_code) VALUES
						(MY_EMP,MY_APPLY_ID,MY_THIS_YEAR,MY_COL_NAME,ORI_THIS_YEAR_HAVE,0,MOD_THIS_YEAR_HAVE,NOW(),MD5(CONCAT(MY_EMP,MY_APPLY_ID,MY_THIS_YEAR,MY_COL_NAME)));
					#THIS_YEAR_LEFT
					REPLACE INTO att_hol_sick_log 
						(emp_id,apply_id,which_year,col_name,ori_value,do_value,mod_value,log_time,partition_code) VALUES
						(MY_EMP,MY_APPLY_ID,MY_THIS_YEAR,'this_year_left',ORI_THIS_YEAR_LEFT,0,MOD_THIS_YEAR_LEFT,NOW(),MD5(CONCAT(MY_EMP,MY_APPLY_ID,MY_THIS_YEAR,'this_year_left')));
					#POOL
					UPDATE att_hol_sick A 
						SET A.this_year_have = IFNULL(MOD_THIS_YEAR_HAVE,0), A.this_year_left = IFNULL(MOD_THIS_YEAR_LEFT,0)
						WHERE A.emp_id=MY_EMP AND A.this_year=MY_THIS_YEAR AND A.is_delete=0;
					
				END IF;
				
			END IF;
			
		END CASE;
	END IF;
END;

