create function FN_GET_EMP_CODE(custid bigint unsigned, deptid bigint unsigned, empcode varchar(50))
  returns varchar(50)
  comment '根据给出的客户id、部门id和增量，更新表中的最大值，并且返回相应的员工编号'
  BEGIN



DECLARE ct,mxct,i_rul_type,i_rul_seed,i_rul_max,IS_HAVE_THIS_CODE,i_rul_step  INT;
DECLARE RES,THIS_RES,i_rul_value,i_dept_code VARCHAR(50);
declare i_ecs_id bigint UNSIGNED;

	IF empcode IS NOT NULL THEN		
		SELECT COUNT(*) INTO IS_HAVE_THIS_CODE FROM emp_post a join emp_base_info b on a.emp_id=b.emp_id WHERE a.cust_id = custid AND a.emp_code = empcode and b.emp_state is not null and b.emp_state <>2;
		
		IF (IS_HAVE_THIS_CODE>0) THEN
			SET RES = 'ERROR';
		ELSE
			UPDATE emp_code_setting a
				left join emp_code_setting_prim b on a.ecs_id=b.ecs_id
				left join emp_rel_code_setting_prim_dept c on b.ecs_id=b.ecs_id 
			SET a.rul_max = a.rul_max + 1 
			WHERE c.dept_id=deptid AND a.rul_type =3 and b.state=1;
			SET RES = empcode;
		END IF;
		
	ELSE
		
		SELECT MIN(a.rul_seq),MAX(a.rul_seq),max(b.ecs_id) INTO ct,mxct ,i_ecs_id
		FROM emp_code_setting a
			left join emp_code_setting_prim b on a.ecs_id=b.ecs_id
			left join emp_rel_code_setting_prim_dept c on b.ecs_id=c.ecs_id 
		WHERE c.dept_id=deptid AND b.state=1;
		
		SET RES = '';
		WHILE (ct<=mxct and ct>0) DO
			SET i_rul_type = NULL; 
			SET i_rul_value = NULL; 
			SET i_rul_seed = NULL; 
			SET i_rul_max = NULL; 
			SET THIS_RES = '';
	
			SELECT rul_type,rul_value,rul_seed,rul_step,rul_max 
				INTO i_rul_type,i_rul_value,i_rul_seed,i_rul_step,i_rul_max 
			FROM emp_code_setting WHERE ecs_id = i_ecs_id AND rul_seq = ct;
			
			CASE i_rul_type 
			WHEN 1 THEN	
				IF deptid IS NOT NULL THEN
					SELECT dept_code INTO i_dept_code FROM dept_info WHERE dept_id = deptid;
					IF i_dept_code IS NULL THEN SET i_dept_code = '' ; END IF;
					SET THIS_RES = i_dept_code;
				ELSE
					
					INSERT INTO DBA_ERROR_TABLE (GO_OUT) VALUE (1);
				END IF;
			WHEN 2 THEN	
				IF i_rul_value IS NULL THEN SET i_rul_value='' ; END IF;
				SET THIS_RES = i_rul_value;
			WHEN 3 THEN	
				IF i_rul_seed IS NULL OR i_rul_step IS NULL THEN
					
					INSERT INTO DBA_ERROR_TABLE (GO_OUT) VALUE (1);
				ELSE
					IF i_rul_max IS NULL THEN SET i_rul_max = i_rul_seed; END IF;
					SET THIS_RES = CONCAT(REPEAT('0',i_rul_step-LENGTH(i_rul_max+1)),i_rul_max+1);
				END IF;
			END CASE;		
			SET RES = CONCAT(RES,THIS_RES);
			SET ct = ct + 1;
		END WHILE;
		IF ct > 0 THEN
			UPDATE emp_code_setting 
			SET rul_max = IF(rul_max IS NULL,if(i_rul_seed is null,0,i_rul_seed),rul_max) + 1 
			WHERE ecs_id = i_ecs_id AND rul_type =3;
	
			SELECT COUNT(*) INTO IS_HAVE_THIS_CODE FROM emp_post a join emp_base_info b on a.emp_id=b.emp_id WHERE a.cust_id = custid AND a.emp_code = RES and b.emp_state is not null and b.emp_state<>2;
			
			IF (IS_HAVE_THIS_CODE>0) THEN
				SET RES = 'ERROR';
	
			END IF;
		ELSE
			SET RES = '';
		END IF;
			
	END IF;
RETURN RES;	
END;

