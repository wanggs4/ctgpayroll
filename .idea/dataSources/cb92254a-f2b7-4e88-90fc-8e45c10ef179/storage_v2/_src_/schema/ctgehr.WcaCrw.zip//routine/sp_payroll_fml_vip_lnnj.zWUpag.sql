create procedure SP_PAYROLL_FML_VIP_LNNJ(IN key_word varchar(50), IN i_emp bigint unsigned, IN prid bigint unsigned,
                                         IN setid    bigint unsigned, OUT res decimal(13, 3))
  comment '给李宁南京的个性化计算'
  BEGIN

DECLARE my_jsgz,MY_NRATE,MY_NDEDUCTION DECIMAL(13,3);
DECLARE MY_TAX_VERSION,MY_WORK_AGE INT;
DECLARE MY_LAST_DATE,MY_ENTRY_DATE,MY_LEAVE_DATE DATE;

	CASE key_word
	WHEN 'LNNJ_GRSDS' THEN
	
	
		SELECT payroll_bz_gz.bz33 INTO my_jsgz FROM payroll_bz_gz WHERE id = prid;
		SELECT LEFT(a.sala_ym,4) into MY_TAX_VERSION FROM payroll_sala_settings a WHERE a.set_id=setid;

		IF my_jsgz IS NULL THEN SET my_jsgz = 0; END IF;

		CALL SP_PAYROLL_GZ_TAX(my_jsgz,MY_TAX_VERSION,MY_NRATE,MY_NDEDUCTION,res);
	WHEN 'LNNJ_GLGZ' THEN
	
	
		SELECT a.sala_ymd_end into MY_LAST_DATE FROM payroll_sala_settings a WHERE a.set_id=setid;
		SELECT entry_date,leave_date into MY_ENTRY_DATE,MY_LEAVE_DATE FROM EMP_POST WHERE EMP_ID = i_emp;
		IF (MY_LEAVE_DATE IS NULL) OR (MY_LEAVE_DATE<MY_LAST_DATE) THEN
			SET MY_WORK_AGE = FLOOR(DATEDIFF(MY_LAST_DATE,MY_ENTRY_DATE)/365);
		ELSE
			SET MY_WORK_AGE = FLOOR(DATEDIFF(MY_LEAVE_DATE,MY_ENTRY_DATE)/365);
		END IF;
		
		IF MY_WORK_AGE <1 THEN
			SET res=0 ;
		ELSEIF MY_WORK_AGE >= 1 THEN
			SET res = MY_WORK_AGE*80;
		END IF;
		
		IF res >800 THEN SET res = 800 ; END IF;
	END CASE;
END;

