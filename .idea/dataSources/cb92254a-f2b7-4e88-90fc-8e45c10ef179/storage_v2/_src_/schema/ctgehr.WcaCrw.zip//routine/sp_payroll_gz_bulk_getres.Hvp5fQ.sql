create procedure SP_PAYROLL_GZ_BULK_GETRES(IN custid bigint, IN ym int, IN setid bigint)
  comment '批量计算工资结果'
  BEGIN
	
declare IS_HAVE_HISTORY,HIS_MONTH_COUNT,calc_ct,THIS_HAVE_SALA,calc_rescnt,ct,mxct,TAX_VERSION,sumb_rescnt int;	
declare i_emp,i_custid,i_deptid bigint;
declare THIS_YM,i_deptname,i_empname varchar(50);
declare THIS_TAX_STAND,BTA,BTS,ATA,ATS,TIA,TIS,TMA,TMS,AT2BTP,AT2BTNP,N_TAX_STAND DECIMAL(12,2);
declare LJ_ITS1TO6,LJ_ALLMON_ASSB_ICM,LJ_ALLMON_TAX,LJ_ALLMON_ICM,LJ_ALLMON_SP_DDCT,LJ_ALLMON_DDCT,LJ_ALLMON_SP_ADD_DDCT,N_TAX_BEF_PLUS_TOL,N_TAX_BEF_PLUSMIN_TOL,N_TAX_BEF_TOL,N_TAX_C_TOL,N_TAX_VALUE,N_TAX_RATE,N_TAX_DEDUCTION,N_TAX_AFT_SALARY,N_AFT_TAX_pay_SUM,N_AFT_TAX_NOpay_SUM,N_TAX_Cpay_SUM,N_TAX_AFT_SUM,N_SALARY_PAY,N_TAX_BASE,N_TAX_VALUE_ALL,N_AFT_TAX_TOL_SUM,N_TAX_Epay_SUM,N_TAX_Cpay_NOpay_SUM,N_TAX_Cpay_pay_SUM,N_five_one,N_PBX_SUM DECIMAL(13,3); 
declare HIS_TAX_BEF_TOL,HIS_TAX_C_TOL,HIS_TAX_EPAY_SUM,HIS_ALLMON_SP_ADD_DDCT,H_TAX_BEF_TOL,H_TAX_Epay_SUM,H_TAX_C_TOL,H_AFT_TAX_TOL_SUM,H_TAX_Cpay_NOpay_SUM,H_TAX_Cpay_SUM,H_AFT_TAX_NOpay_SUM,H_AFT_TAX_pay_SUM,H_TAX_AFT_SALARY DECIMAL(13,3); 
declare H_THISMON_TAX_BEF_TOL,THIS_TAX_BEF_TOL,TMP_TAX_INCOME_L_VALUE  DECIMAL(13,3); 
declare IS_THIS_MONTH_SALAED,prid bigint;
DECLARE S_GZ_SF,S_LWF_SF,S_LZF_SF,S_NZJ_SF DECIMAL(13,3);
DECLARE i_version_code VARCHAR(50);
	SET i_version_code = UUID();
	SET @i_version_code = i_version_code;
	set TAX_VERSION=left(ym,4);
	set TMP_TAX_INCOME_L_VALUE=0;
	set sumb_rescnt=0;

	#查询是否有需要计算的	
	select count(*) into sumb_rescnt 
	from payroll_gz_base a left join payroll_sala_settings b on a.SET_ID=b.set_id 
	where a.cust_id=custid and a.MONTH_STEP=ym and a.set_id=setid and b.is_report=0 and b.schema_type=1 ;

	#有的时候才进行
	if sumb_rescnt>0 then
		#把本期人名单，且求和各项类目，存入临时表
		INSERT INTO tmp_payroll_gz_sum (version_code,payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,MONTH_STEP,TAX_STAND,GZ_BTA,GZ_BTS,GZ_ATA,GZ_ATS,GZ_TIA,GZ_TIS,GZ_TMA,GZ_TMS,GZ_AT2BTP,GZ_AT2BTNP,five_one) 
			select i_version_code,a.id,a.CUST_ID,a.DEPT_ID,a.DEPT_NAME,a.emp_id,a.EMP_NAME,a.month_step,AVG(a.TAX_STAND),
				sum(BTA1+BTA2+BTA3+BTA4+BTA5+BTA6+BTA7+BTA8+BTA9+BTA10+BTA11+BTA12+BTA13+BTA14+BTA15+BTA16+BTA17+BTA18+BTA19+BTA20+BTA21+BTA22+BTA23+BTA24+BTA25+BTA26+BTA27+BTA28+BTA29+BTA30+BTA31+BTA32+BTA33+BTA34+BTA35+BTA36+BTA37+BTA38+BTA39+BTA40+BTA41+BTA42+BTA43+BTA44+BTA45+BTA46+BTA47+BTA48+BTA49+BTA50+BTA51+BTA52+BTA53+BTA54+BTA55+BTA56+BTA57+BTA58+BTA59+BTA60+BTA61+BTA62+BTA63+BTA64+BTA65+BTA66+BTA67+BTA68+BTA69+BTA70+BTA71+BTA72+BTA73+BTA74+BTA75+BTA76+BTA77+BTA78+BTA79+BTA80+BTA81+BTA82+BTA83+BTA84+BTA85+BTA86+BTA87+BTA88+BTA89+BTA90+BTA91+BTA92+BTA93+BTA94+BTA95+BTA96+BTA97+BTA98+BTA99+BTA100) GZ_BTA ,
				sum(BTS1+BTS2+BTS3+BTS4+BTS5+BTS6+BTS7+BTS8+BTS9+BTS10+BTS11+BTS12+BTS13+BTS14+BTS15+BTS16+BTS17+BTS18+BTS19+BTS20+BTS21+BTS22+BTS23+BTS24+BTS25+BTS26+BTS27+BTS28+BTS29+BTS30+BTS31+BTS32+BTS33+BTS34+BTS35+BTS36+BTS37+BTS38+BTS39+BTS40+BTS41+BTS42+BTS43+BTS44+BTS45+BTS46+BTS47+BTS48+BTS49+BTS50+BTS51+BTS52+BTS53+BTS54+BTS55+BTS56+BTS57+BTS58+BTS59+BTS60+BTS61+BTS62+BTS63+BTS64+BTS65+BTS66+BTS67+BTS68+BTS69+BTS70+BTS71+BTS72+BTS73+BTS74+BTS75+BTS76+BTS77+BTS78+BTS79+BTS80+BTS81+BTS82+BTS83+BTS84+BTS85+BTS86+BTS87+BTS88+BTS89+BTS90+BTS91+BTS92+BTS93+BTS94+BTS95+BTS96+BTS97+BTS98+BTS99+BTS100) GZ_BTS,
				sum(ATA1+ATA2+ATA3+ATA4+ATA5+ATA6+ATA7+ATA8+ATA9+ATA10+ATA11+ATA12+ATA13+ATA14+ATA15+ATA16+ATA17+ATA18+ATA19+ATA20+ATA21+ATA22+ATA23+ATA24+ATA25+ATA26+ATA27+ATA28+ATA29+ATA30+ATA31+ATA32+ATA33+ATA34+ATA35+ATA36+ATA37+ATA38+ATA39+ATA40+ATA41+ATA42+ATA43+ATA44+ATA45+ATA46+ATA47+ATA48+ATA49+ATA50) GZ_ATA,
				sum(ATS1+ATS2+ATS3+ATS4+ATS5+ATS6+ATS7+ATS8+ATS9+ATS10+ATS11+ATS12+ATS13+ATS14+ATS15+ATS16+ATS17+ATS18+ATS19+ATS20+ATS21+ATS22+ATS23+ATS24+ATS25+ATS26+ATS27+ATS28+ATS29+ATS30+ATS31+ATS32+ATS33+ATS34+ATS35+ATS36+ATS37+ATS38+ATS39+ATS40+ATS41+ATS42+ATS43+ATS44+ATS45+ATS46+ATS47+ATS48+ATS49+ATS50) GZ_ATS,
				sum(TIA1+TIA2+TIA3+TIA4+TIA5+TIA6+TIA7+TIA8+TIA9+TIA10+TIA11+TIA12+TIA13+TIA14+TIA15+TIA16+TIA17+TIA18+TIA19+TIA20) GZ_TIA,
				SUM(TIS1+TIS2+TIS3+TIS4+TIS5+TIS6+TIS7+TIS8+TIS9+TIS10+TIS11+TIS12+TIS13+TIS14+TIS15+TIS16+TIS17+TIS18+TIS19+TIS20) GZ_TIS,
				sum(TMA1+TMA2+TMA3+TMA4+TMA5+TMA6+TMA7+TMA8+TMA9+TMA10+TMA11+TMA12+TMA13+TMA14+TMA15+TMA16+TMA17+TMA18+TMA19+TMA20) GZ_TMA,
				sum(TMS1+TMS2+TMS3+TMS4+TMS5+TMS6+TMS7+TMS8+TMS9+TMS10+TMS11+TMS12+TMS13+TMS14+TMS15+TMS16+TMS17+TMS18+TMS19+TMS20) GZ_TMS,
				sum(AT2BTP1+AT2BTP2+AT2BTP3+AT2BTP4+AT2BTP5+AT2BTP6+AT2BTP7+AT2BTP8+AT2BTP9+AT2BTP10+AT2BTP11+AT2BTP12+AT2BTP13+AT2BTP14+AT2BTP15+AT2BTP16+AT2BTP17+AT2BTP18+AT2BTP19+AT2BTP20) GZ_AT2BTP,
				sum(AT2BTNP1+AT2BTNP2+AT2BTNP3+AT2BTNP4+AT2BTNP5+AT2BTNP6+AT2BTNP7+AT2BTNP8+AT2BTNP9+AT2BTNP10+AT2BTNP11+AT2BTNP12+AT2BTNP13+AT2BTNP14+AT2BTNP15+AT2BTNP16+AT2BTNP17+AT2BTNP18+AT2BTNP19+AT2BTNP20) GZ_AT2BTNP,
				sum(a.five_one) N_five_one
			from payroll_gz_base a left join payroll_sala_settings b on a.SET_ID=b.set_id 
			where a.cust_id=custid and a.MONTH_STEP=ym and a.set_id=setid and b.schema_type=1 and b.is_report=0
			group by a.emp_id;
			

		
		#按人循环计算
		set calc_rescnt=0;
		select count(*),min(id),max(id) into calc_rescnt,ct,mxct from tmp_payroll_gz_sum where version_code = i_version_code;
		if calc_rescnt>0 then 			
			while (ct<=mxct) do

########################################################################################################################################################
########################################################################################################################################################
##########                    计算正式开始                                                                ##############################################
########################################################################################################################################################
########################################################################################################################################################

				set N_TAX_BEF_PLUS_TOL=0, N_TAX_BEF_PLUSMIN_TOL=0, N_TAX_BEF_TOL=0, N_TAX_C_TOL=0, N_TAX_VALUE=0, N_TAX_RATE=0, N_TAX_DEDUCTION=0, N_TAX_AFT_SALARY=0, N_AFT_TAX_pay_SUM=0, N_AFT_TAX_NOpay_SUM=0, N_TAX_Cpay_SUM=0, N_TAX_AFT_SUM=0, N_SALARY_PAY=0, N_TAX_BASE=0, N_TAX_VALUE_ALL=0, N_AFT_TAX_TOL_SUM=0, N_TAX_Epay_SUM=0, N_TAX_Cpay_NOpay_SUM=0, N_TAX_Cpay_pay_SUM=0, N_five_one=0, N_PBX_SUM=0;

				select payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,TAX_STAND,GZ_BTA,GZ_BTS,GZ_ATA,GZ_ATS,GZ_TIA,GZ_TIS,GZ_TMA,GZ_TMS,GZ_AT2BTP,GZ_AT2BTNP ,five_one
					into prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,N_TAX_STAND,BTA,BTS,ATA,ATS,TIA,TIS,TMA,TMS,AT2BTP,AT2BTNP,N_five_one
				from tmp_payroll_gz_sum 
				where id=ct and version_code = i_version_code;
				
				IF prid IS NOT NULL THEN
#######################################
#	计算历史
#######################################
					#首先得到历史的薪酬计算
					set calc_rescnt = 0;
					select count(DISTINCT a.MONTH_STEP) into calc_rescnt 
					from payroll_gz a left join payroll_sala_settings b on a.SET_ID=b.set_id
					where a.emp_id=i_emp and LEFT(a.MONTH_STEP,4) = LEFT(ym,4) and b.is_report=1 and a.set_id<>setid and b.schema_type=1;

					
					#有人可计算的时候才开始进行
					if calc_rescnt>0 then
						#历史数据PART1 先取已归档的所有历史和值
						SET H_TAX_BEF_TOL=0,H_TAX_Epay_SUM=0,H_TAX_C_TOL=0,H_AFT_TAX_TOL_SUM=0,H_TAX_Cpay_NOpay_SUM=0,H_TAX_Cpay_SUM=0,H_AFT_TAX_NOpay_SUM=0,H_AFT_TAX_pay_SUM=0,H_TAX_AFT_SALARY=0;
						select IFNULL(sum(IF(TAX_BEF_TOL IS NULL,0,TAX_BEF_TOL)),0),
			 				IFNULL(sum(if(TAX_EPAY_SUM is null,0,TAX_EPAY_SUM)),0),
							IFNULL(sum(if(TAX_C_TOL is null,0,TAX_C_TOL)),0),
							IFNULL(sum(if(AFT_TAX_TOL_SUM is null,0,AFT_TAX_TOL_SUM)),0),
							IFNULL(sum(if(TAX_Cpay_NOpay_SUM is null,0,TAX_Cpay_NOpay_SUM)),0),
							IFNULL(sum(if(TAX_Cpay_SUM is null,0,TAX_Cpay_SUM)),0),
							IFNULL(sum(if(AFT_TAX_NOpay_SUM is null,0,AFT_TAX_NOpay_SUM)),0),
							IFNULL(sum(if(AFT_TAX_pay_SUM is null,0,AFT_TAX_pay_SUM)),0),
							IFNULL(sum(if(TAX_AFT_SALARY is null,0,TAX_AFT_SALARY)),0)
						into H_TAX_BEF_TOL,
							H_TAX_Epay_SUM,
							H_TAX_C_TOL,
							H_AFT_TAX_TOL_SUM,
							H_TAX_Cpay_NOpay_SUM,
							H_TAX_Cpay_SUM,
							H_AFT_TAX_NOpay_SUM,
							H_AFT_TAX_pay_SUM,
							H_TAX_AFT_SALARY
						from payroll_gz a left join payroll_sala_settings b on a.SET_ID=b.set_id
						where a.emp_id=i_emp and LEFT(a.MONTH_STEP,4) = LEFT(ym,4) and b.is_report=1 and a.set_id<>setid and b.schema_type=1;

						#历史数据PART2 看当月是否有附带的历史数据
						SET IS_HAVE_HISTORY=0,HIS_MONTH_COUNT=0,HIS_TAX_BEF_TOL=0,HIS_TAX_C_TOL=0,HIS_TAX_EPAY_SUM=0,HIS_ALLMON_SP_ADD_DDCT=0;
						SELECT COUNT(*) INTO IS_HAVE_HISTORY FROM payroll_gz_history A WHERE A.SET_ID=setid AND A.EMP_ID=i_emp;
						IF IS_HAVE_HISTORY > 0 THEN
							SELECT A.MONTH_COUNT,IFNULL(A.TAX_BEF_TOL,0),IFNULL(A.TAX_C_TOL,0),IFNULL(A.TAX_EPAY_SUM,0),IFNULL(A.ALLMON_SP_ADD_DDCT,0)
								INTO HIS_MONTH_COUNT,HIS_TAX_BEF_TOL,HIS_TAX_C_TOL,HIS_TAX_EPAY_SUM,HIS_ALLMON_SP_ADD_DDCT
							FROM payroll_gz_history A
							WHERE A.SET_ID=setid AND A.EMP_ID=i_emp;
							
							SET H_TAX_BEF_TOL = H_TAX_BEF_TOL + HIS_TAX_BEF_TOL;
							SET H_TAX_Epay_SUM = H_TAX_Epay_SUM + HIS_TAX_EPAY_SUM;
							SET H_TAX_C_TOL = H_TAX_C_TOL + HIS_TAX_C_TOL;
						END IF;
						
						#开始计算历史的累积税点
						SET calc_ct = 1;
						WHILE calc_ct<=calc_rescnt DO
							SET THIS_YM=NULL,THIS_TAX_STAND=NULL,THIS_TAX_BEF_TOL=NULL;
							IF calc_ct <= 9 THEN
								SET THIS_YM = CONCAT(TAX_VERSION,'0',calc_ct);
							ELSE	
								SET THIS_YM = CONCAT(TAX_VERSION,calc_ct);
							END IF;
							
							SELECT sum(IF(TAX_BEF_TOL IS NULL,0,TAX_BEF_TOL)) INTO THIS_TAX_BEF_TOL
							FROM payroll_gz a left join payroll_sala_settings b on a.SET_ID=b.set_id
							WHERE a.emp_id=i_emp and a.MONTH_STEP=THIS_YM and b.is_report=1 and a.set_id<>setid and b.schema_type=1;

							IF THIS_TAX_BEF_TOL IS NULL THEN SET THIS_TAX_BEF_TOL = 0 ; END IF;
							
							IF THIS_TAX_BEF_TOL > 0 THEN
								SET THIS_TAX_STAND = 5000;
							ELSE
								SET THIS_TAX_STAND = 0;
							END IF;
							
							SET N_TAX_STAND = N_TAX_STAND + THIS_TAX_STAND;
							set calc_ct = calc_ct + 1;
						END WHILE;
						SET N_TAX_STAND = N_TAX_STAND + (HIS_MONTH_COUNT * 5000);
						
					else
						set H_TAX_BEF_TOL=0;
						set H_TAX_Epay_SUM=0;
						set H_TAX_C_TOL=0;
						set H_AFT_TAX_TOL_SUM=0;
						set H_TAX_Cpay_NOpay_SUM=0;
						set H_TAX_Cpay_SUM=0;
						set H_AFT_TAX_NOpay_SUM=0;
						set H_AFT_TAX_pay_SUM=0;
						set H_TAX_AFT_SALARY=0;
						set N_TAX_STAND = 0;
					end if;
#######################################
#	计算当月
#######################################
			      
			    	SET N_AFT_TAX_TOL_SUM = 0 ,N_TAX_Epay_SUM = 0,N_TAX_Cpay_pay_SUM = 0;
			    	
			    	SET N_TAX_BEF_PLUS_TOL = BTA; 
			    	SET N_TAX_BEF_PLUSMIN_TOL = BTA - BTS; 
			    	SET N_TAX_BEF_TOL = N_TAX_BEF_PLUSMIN_TOL + TIA - TIS; 

					#看当月是否减税当
					#先看已经归档的是否有当月的
					SET IS_THIS_MONTH_SALAED = 0,H_THISMON_TAX_BEF_TOL=0;
					SELECT COUNT(*) INTO IS_THIS_MONTH_SALAED 
					FROM payroll_gz a left join payroll_sala_settings b on a.SET_ID=b.set_id
					where a.emp_id=i_emp and a.MONTH_STEP = ym and b.is_report=1 and a.set_id<>setid and b.schema_type=1;

					IF IS_THIS_MONTH_SALAED > 0 THEN
						SELECT sum(IF(TAX_BEF_TOL IS NULL,0,TAX_BEF_TOL)) INTO H_THISMON_TAX_BEF_TOL
						FROM payroll_gz a left join payroll_sala_settings b on a.SET_ID=b.set_id
						WHERE a.emp_id=i_emp and a.MONTH_STEP=THIS_YM and b.is_report=1 and a.set_id<>setid and b.schema_type=1;
					ELSE
						SET H_THISMON_TAX_BEF_TOL = 0;
					END IF;
					
					#当月收入大于零时 有历史
					IF IS_THIS_MONTH_SALAED >0 AND N_TAX_BEF_TOL + H_THISMON_TAX_BEF_TOL > 0 THEN
						SET N_TAX_STAND = N_TAX_STAND + 5000; 
					#无历史
			    	ELSEIF IS_THIS_MONTH_SALAED < 1 AND N_TAX_BEF_TOL + H_THISMON_TAX_BEF_TOL > 0 THEN
			    		IF N_TAX_STAND = 0 THEN
			    			SET N_TAX_STAND = 5000;
			    		END IF;
			    	ELSE
			    		SET THIS_HAVE_SALA = 0;
			    	END IF;
#SELECT N_TAX_STAND;			    	
					SET H_TAX_BEF_TOL = H_TAX_BEF_TOL +  N_TAX_BEF_TOL ;

			    	if H_TAX_BEF_TOL >= N_TAX_STAND then
						SET N_TAX_C_TOL=H_TAX_BEF_TOL-N_TAX_STAND;
						IF N_TAX_C_TOL > 0 THEN
							CALL SP_payroll_gz_TAX(N_TAX_C_TOL,TAX_VERSION,N_TAX_RATE,N_TAX_DEDUCTION,N_TAX_VALUE);
						ELSE
							SET N_TAX_RATE=0,N_TAX_DEDUCTION=0,N_TAX_VALUE=0;
						END IF;

						IF N_TAX_VALUE - H_TAX_Epay_SUM > 0 THEN
							SET N_TAX_VALUE	= N_TAX_VALUE - H_TAX_Epay_SUM;
						ELSE
							SET N_TAX_VALUE = 0;
						END IF;
			  			
			  			SET N_TAX_AFT_SALARY = H_TAX_BEF_TOL - N_TAX_VALUE - H_TAX_Epay_SUM - H_TAX_AFT_SALARY;

					ELSE
				      	SET N_TAX_C_TOL     = 0;
				      	SET N_TAX_VALUE     = 0;
				      	SET N_TAX_RATE      = 0;
				      	SET N_TAX_DEDUCTION = 0;
				      	
				      	SET N_TAX_AFT_SALARY = N_TAX_BEF_TOL;

					END IF;
					
					SET N_TAX_Epay_SUM = N_TAX_VALUE;	
					SET N_AFT_TAX_pay_SUM = AT2BTP;	
					SET N_AFT_TAX_NOpay_SUM = AT2BTNP;	

						
#######################################
#	当月倒算
#######################################

			    	if ( (AT2BTP + AT2BTNP+H_AFT_TAX_pay_SUM+ H_AFT_TAX_NOpay_SUM) >0 or (AT2BTP + AT2BTNP+H_AFT_TAX_pay_SUM+ H_AFT_TAX_NOpay_SUM) < -50 )then 
				      	if N_TAX_AFT_SALARY +H_TAX_AFT_SALARY+AT2BTP + AT2BTNP+H_AFT_TAX_pay_SUM+ H_AFT_TAX_NOpay_SUM>= N_TAX_STAND then
								
					        	SET TMP_TAX_INCOME_L_VALUE =  N_TAX_C_TOL ;
								
								
								CALL SP_payroll_gz_TAX_BACK(N_TAX_AFT_SALARY+AT2BTP+H_AFT_TAX_pay_SUM+H_TAX_AFT_SALARY,
																		N_TAX_STAND,
																		TAX_VERSION,
																		N_TAX_RATE,
																		N_TAX_DEDUCTION,
																		N_TAX_C_TOL);
#select N_TAX_STAND;									
				        		SET N_AFT_TAX_TOL_SUM = N_TAX_C_TOL - TMP_TAX_INCOME_L_VALUE - H_AFT_TAX_TOL_SUM ;
				        		SET N_TAX_Cpay_pay_SUM = N_TAX_C_TOL * N_TAX_RATE - N_TAX_DEDUCTION - N_TAX_VALUE -H_TAX_Epay_SUM; 
				        		
				        		SET N_TAX_Cpay_pay_SUM  = N_TAX_Cpay_pay_SUM - H_TAX_Cpay_SUM;
					
					
					
								
				        		CALL SP_payroll_gz_TAX_BACK(N_TAX_AFT_SALARY+AT2BTP+AT2BTNP+H_TAX_AFT_SALARY+H_AFT_TAX_pay_SUM+H_AFT_TAX_NOpay_SUM,
								  										N_TAX_STAND,
																		TAX_VERSION,
																		N_TAX_RATE,
																		N_TAX_DEDUCTION,
																		N_TAX_C_TOL); 
																		
								
								
				        		SET N_AFT_TAX_TOL_SUM =   N_TAX_C_TOL - TMP_TAX_INCOME_L_VALUE - H_AFT_TAX_TOL_SUM;
								SET N_TAX_Cpay_NOpay_SUM = N_TAX_C_TOL * 
																		N_TAX_RATE - 
																		N_TAX_DEDUCTION - 
																		N_TAX_VALUE-        	
				                                        	H_TAX_Epay_SUM-
				                                         	N_TAX_Cpay_pay_SUM-
				                                         	H_TAX_Cpay_NOpay_SUM-
				                                         	H_TAX_Cpay_SUM;		

			            	SET N_TAX_VALUE = N_TAX_VALUE +
			                                         N_TAX_Cpay_NOpay_SUM+
			                                         N_TAX_Cpay_pay_SUM  
			                                         ; 

				        		SET N_TAX_C_TOL = N_TAX_C_TOL - H_TAX_C_TOL;			
							
				         	
							
							SET N_TAX_AFT_SALARY = N_TAX_C_TOL - N_TAX_VALUE;

							else
								SET N_TAX_VALUE = 0;
				        		SET N_TAX_RATE = 0;
				        		SET N_TAX_DEDUCTION = 0;
				        		SET N_TAX_C_TOL = 0;
				        		SET N_TAX_Cpay_pay_SUM = 0;
				
							end if;
				
						 else
							if H_TAX_BEF_TOL >= N_TAX_STAND then
								SET N_TAX_C_TOL = N_TAX_C_TOL - H_TAX_C_TOL;
							
				         	
							
							SET N_TAX_AFT_SALARY = N_TAX_C_TOL - N_TAX_VALUE;

				         	SET N_TAX_Cpay_pay_SUM  = 0;
				
				        	else
				      		SET N_TAX_VALUE     = 0;
				         	SET N_TAX_RATE      = 0;
				         	SET N_TAX_DEDUCTION = 0;
				         	SET N_TAX_C_TOL       = 0;
				         	SET N_TAX_Cpay_pay_SUM  = 0;
				         	SET N_TAX_Cpay_NOpay_SUM = 0;
				        	end if;
		
						 end if;
					 	
				
				    	SET N_TAX_AFT_SUM = ATA - ATS;
				    	SET N_SALARY_PAY  = N_TAX_BEF_PLUSMIN_TOL -
				                                    N_TAX_VALUE  +
				                                    N_TAX_Cpay_NOpay_SUM+
				                                    N_TAX_Cpay_pay_SUM +
				                                    N_AFT_TAX_pay_SUM +
				                                    N_TAX_AFT_SUM ;
				    
				   IF N_SALARY_PAY < 0 THEN
				   	SET N_SALARY_PAY = 0;
			    	END IF;

			     	SET N_TAX_VALUE = N_TAX_VALUE + TMA - TMS;
			     	SET N_TAX_BASE = 5000;
			     	IF N_TAX_BEF_PLUSMIN_TOL IS NULL THEN SET N_TAX_BEF_PLUSMIN_TOL = 0; END IF;
					IF N_TAX_VALUE IS NULL THEN SET N_TAX_VALUE  = 0; END IF;
					IF N_five_one IS NULL THEN SET N_five_one  = 0; END IF;
					IF N_SALARY_PAY IS NULL OR N_SALARY_PAY < 0 THEN SET  N_SALARY_PAY = 0; END IF;
					

#######################################
#	计算当月累计
#######################################
					SET LJ_ALLMON_ASSB_ICM=0,LJ_ALLMON_TAX=0,LJ_ALLMON_ICM=0,LJ_ALLMON_SP_DDCT=0,LJ_ALLMON_DDCT=0,LJ_ALLMON_SP_ADD_DDCT=0;
					
					SELECT MAX(IFNULL(a.ALLMON_ASSB_ICM,0)),MAX(IFNULL(a.ALLMON_TAX,0)),MAX(IFNULL(a.ALLMON_ICM,0)),MAX(IFNULL(a.ALLMON_SP_DDCT,0)),MAX(IFNULL(a.ALLMON_DDCT,0)),MAX(IFNULL(a.ALLMON_SP_ADD_DDCT,0))
						INTO LJ_ALLMON_ASSB_ICM,LJ_ALLMON_TAX,LJ_ALLMON_ICM,LJ_ALLMON_SP_DDCT,LJ_ALLMON_DDCT,LJ_ALLMON_SP_ADD_DDCT
					FROM payroll_gz a LEFT JOIN payroll_sala_settings b ON a.SET_ID=b.set_id
					WHERE a.emp_id=i_emp AND LEFT(a.MONTH_STEP,4) = LEFT(ym,4) AND a.MONTH_STEP = ym - 1 
						AND b.is_report=1 AND a.set_id<>setid AND b.schema_type=1 ;
					
					SELECT IFNULL(a.TIS1,0)+IFNULL(a.TIS2,0)+IFNULL(a.TIS3,0)+IFNULL(a.TIS4,0)+IFNULL(a.TIS5,0)+IFNULL(a.TIS6,0) 
						INTO LJ_ITS1TO6
					FROM payroll_gz_base a LEFT JOIN payroll_sala_settings b ON a.SET_ID=b.set_id 
					WHERE a.cust_id=custid AND a.MONTH_STEP=ym AND a.set_id=setid AND b.schema_type=1 AND b.is_report=0 AND a.EMP_ID = i_emp;
	
						
					SET LJ_ALLMON_ASSB_ICM = LJ_ALLMON_ASSB_ICM + N_TAX_C_TOL;
					SET LJ_ALLMON_TAX = LJ_ALLMON_TAX + N_TAX_VALUE;
					SET LJ_ALLMON_ICM = LJ_ALLMON_ICM + N_TAX_AFT_SALARY;
					SET LJ_ALLMON_SP_DDCT = LJ_ALLMON_SP_DDCT + N_five_one;
					SET LJ_ALLMON_DDCT = N_TAX_STAND;
					SET LJ_ALLMON_SP_ADD_DDCT = LJ_ALLMON_SP_ADD_DDCT + LJ_ITS1TO6;

#######################################
#	写入数据
#######################################
			     	DELETE FROM payroll_gz WHERE ID = prid;
					INSERT INTO payroll_gz (`ID`,`CUST_ID`,`DEPT_ID`,`DEPT_NAME`,`EMP_ID`,`EMP_NAME`,`set_id`,`MONTH_STEP`,`IS_PUBLISH`,
								`TAX_BEF_PLUS_TOL`,`TAX_BEF_PLUSMIN_TOL`,`TAX_BEF_TOL`,`TAX_C_TOL`,`TAX_VALUE`,`TAX_RATE`,`TAX_DEDUCTION`,
								`TAX_AFT_SALARY`,`AFT_TAX_pay_SUM`,`AFT_TAX_NOpay_SUM`,`TAX_Cpay_SUM`,`TAX_AFT_SUM`,`SALARY_PAY`,`TAX_BASE`,
								`TAX_VALUE_ALL`,`AFT_TAX_TOL_SUM`,`TAX_Epay_SUM`,`TAX_Cpay_NOpay_SUM`,`TAX_Cpay_pay_SUM`,`five_one`,`PBX_SUM`,
								`ALLMON_ASSB_ICM`,`ALLMON_TAX`,`ALLMON_ICM`,`ALLMON_SP_DDCT`,`ALLMON_DDCT`,`ALLMON_SP_ADD_DDCT`) 
					VALUES (prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,setid,ym,0,
								N_TAX_BEF_PLUS_TOL,N_TAX_BEF_PLUSMIN_TOL,N_TAX_BEF_TOL,N_TAX_C_TOL,N_TAX_VALUE,N_TAX_RATE,N_TAX_DEDUCTION,
								N_TAX_AFT_SALARY,N_AFT_TAX_pay_SUM,N_AFT_TAX_NOpay_SUM,N_TAX_Cpay_SUM,N_TAX_AFT_SUM,N_SALARY_PAY,N_TAX_BASE,
								N_TAX_VALUE_ALL,N_AFT_TAX_TOL_SUM,N_TAX_Epay_SUM,N_TAX_Cpay_NOpay_SUM,N_TAX_Cpay_pay_SUM,N_five_one,N_PBX_SUM,
								LJ_ALLMON_ASSB_ICM,LJ_ALLMON_TAX,LJ_ALLMON_ICM,LJ_ALLMON_SP_DDCT,LJ_ALLMON_DDCT,LJ_ALLMON_SP_ADD_DDCT);
					
					UPDATE payroll_gz_base set is_calc=1 where id = prid;
					
					UPDATE payroll_tol 
					SET TAX_BEF_PLUSMIN_TOL=N_TAX_BEF_PLUSMIN_TOL,TAX_VALUE=N_TAX_VALUE,five_one=N_five_one,SALARY_PAY=N_SALARY_PAY
					WHERE ID=prid;
	

			    	SET N_TAX_Cpay_pay_SUM = 0;
			    	SET N_TAX_Cpay_NOpay_SUM = 0;
			    	SET AT2BTP = 0; 
			    	SET AT2BTNP = 0; 
			
			    	SET H_TAX_BEF_TOL  = 0; 
			    	SET H_TAX_Epay_SUM  = 0; 
			    	SET H_TAX_C_TOL  = 0; 
			    	SET H_AFT_TAX_TOL_SUM =0 ;
			
						
					set calc_rescnt=ct;
				END IF;
				set ct=ct+1;
			end while;
		end if;
	end if;	
END;

