create procedure FN_DEBUG2(IN bgtm time, IN edtm time, IN holid bigint unsigned, IN sonver bigint unsigned,
                           IN emp  bigint unsigned, IN ATTID bigint unsigned, IN this_date date, IN minunit int)
  comment '根据给出的条件和时间，计算出针对于此人的有效请假结束时间点'
  BEGIN
DECLARE THIS_FLEX,WORK_HOUR,CRASH_HOUR,YESTD_WORK_HOUR,YESTD_HOL_HOUR,MY_ARR_WORK_HOUR,THIS_ARR_WORK_HOUR,THIS_HOL_HOUR,MY_SHOULD_WORK_DAY,MY_ZH_HOUR,MY_FLEX_HOUR,real_day_hours,i_month_period_hour,DINNER_DEDUCTION DECIMAL(12,2);	
DECLARE i_st_unit,IS_IN_SPHOL,YESTD_ARR_NO,i_flex_hour,i_hol_rule,MYCT,MY_ARR_NO,MY_ZH_RATIO,ieh,dttype,MY_FLEX_RATIO,MY_ATT_RULE,is_have_hol,bgst,edst,is_have_dept,is_have_att,iyh,isc,i_holunit,is_have_emp,i_is_month_period INT;
DECLARE MY_MST,MY_MET,MY_AST,MY_AET,i_na_start_time_1,i_na_end_time_1,i_na_start_time_2,i_na_end_time_2 TIME;
DECLARE MY_NA1,MY_NA2,YESTD_ARR_START_TIME,YESTD_ARR_END_TIME,YESTD_BGTM,YESTD_EDTM,TMP_BGTM,TMP_EDTM,THIS_BGDT,THIS_EDDT,THIS_MST,THIS_MET,THIS_AST,THIS_AET,MY_PERIOD_BGDT,MY_PERIOD_EDDT,MY_HOL_BGTM,MY_HOL_EDTM,MY_ARR_BG_TIME,MY_ARR_ED_TIME,THIS_NA_BGTM,THIS_NA_EDTM DATETIME;
DECLARE MY_CUST_ID BIGINT UNSIGNED;
DECLARE MY_YESTERDAY DATE;

#mod_log_20190709 deptid 已经无用，保留仅为减少不必要的修改工作量
/*	参数说明
	minunit 最小请假单位，1一刻钟 2半小时 3小时 4半天 5一天  给app返回相应单位的倍数。
			特殊值 99 给存储过程内部调用，返回（最小单位倍数* 最小单位 ）转换成小时
			特殊值 999 实际时长，返回单位分钟
*/
set real_day_hours = 0;
	#首先验证参数的有效性
	SELECT COUNT(*) into is_have_emp 
	FROM emp_base_info a
	WHERE a.emp_id = emp ;
	
	SELECT COUNT(*) into is_have_hol FROM att_set_holiday_main  WHERE hol_id = holid ;
		#如果有假期方案且初试时间小于等于结束时间时才开始计算
	IF is_have_emp > 0 and is_have_hol > 0 and ATTID IS NOT NULL and bgtm <= edtm THEN
		
		#读出假期设置
		SELECT is_year_hol,hol_unit,hol_rule,a.st_unit INTO iyh,i_holunit,i_hol_rule,i_st_unit FROM att_set_holiday_main a where hol_id = holid;
		
		#得到当天的日期类型
		SET dttype = FN_ATT_GET_DTTYPE(this_date,emp);
		
		#读一下出勤规则
		SELECT b.att_rule INTO MY_ATT_RULE
		FROM att_set_schema_new b
		WHERE b.att_id=ATTID;
#----------------------逻辑架构开始-----------------------------*			
		#根据不同考勤规则分别计算
		#做版考勤
		IF MY_ATT_RULE = 1 THEN
			#读出四个时间
			SELECT b.morn_start_time,b.morn_end_time,b.aftn_start_time,b.aftn_end_time,b.is_exp_hol,b.flex_hour,
					b.is_month_period,b.month_period_hour,b.na_start_time_1,b.na_end_time_1,b.na_start_time_2,b.na_end_time_2
				INTO MY_MST,MY_MET,MY_AST,MY_AET,ieh,i_flex_hour,
					i_is_month_period,i_month_period_hour,i_na_start_time_1,i_na_end_time_1,i_na_start_time_2,i_na_end_time_2
					#坐班考勤上午起点时间，坐班考勤上午终点时间，坐班考勤下午起点时间，坐班考勤下午终点时间
			FROM att_set_schema_new b 
			WHERE b.ATT_ID = ATTID;
			
			IF ieh IS NULL OR ieh NOT IN (0,1) THEN SET ieh = 0 ; END IF;
			IF i_flex_hour IS NULL THEN SET i_flex_hour=0 ; END IF;
			SET MY_FLEX_HOUR = 0;
			IF i_flex_hour = 0 AND i_is_month_period = 1 AND i_month_period_hour>0 THEN
				SET MY_FLEX_HOUR = (FN_ATT_GET_WORKHOURS(ATTID) - i_month_period_hour)*60;
			ELSE
				SET MY_FLEX_HOUR = i_flex_hour;
			END IF;
			IF MY_FLEX_HOUR IS NULL THEN SET MY_FLEX_HOUR = 0 ; END IF;
			#设置当天日期时间
			SET THIS_BGDT = CONCAT(this_date,' ',bgtm);
			SET THIS_EDDT = CONCAT(this_date,' ',edtm);
			SET THIS_MST = CONCAT(this_date,' ',MY_MST);
			SET THIS_MET = CONCAT(this_date,' ',MY_MET);
			SET THIS_AST = CONCAT(this_date,' ',MY_AST);
			SET THIS_AET = CONCAT(this_date,' ',MY_AET);
			
			SET MY_NA1 = CONCAT(this_date,' ',i_na_start_time_1);
			IF MY_NA1 IS NOT NULL AND MY_NA1 > THIS_AET THEN
				SET THIS_NA_BGTM = CONCAT(this_date,' ',i_na_start_time_1);
				SET THIS_NA_EDTM = CONCAT(this_date,' ',i_na_end_time_1);
			END IF;
			
			SET MY_NA2 = CONCAT(this_date,' ',i_na_start_time_2);
			IF MY_NA2 IS NOT NULL AND MY_NA2 > THIS_AET THEN
				SET THIS_NA_BGTM = CONCAT(this_date,' ',i_na_start_time_2);
				SET THIS_NA_EDTM = CONCAT(this_date,' ',i_na_end_time_2);
			END IF;
	 
			#得到时间差
			SET THIS_FLEX = TIME_TO_SEC(TIMEDIFF(THIS_BGDT,THIS_MST));
			
			#当时间差小于零，也就是说早于一天起始时间，就设为0
			IF THIS_FLEX <= 0 THEN 
				SET THIS_FLEX = 0 ;
				SET DINNER_DEDUCTION = 0;
			#当请假时间和起始时间的时间差大于零的时候，且比弹性时间少的时候，起始时间和结束时间往后延长时间差秒数
			ELSEIF THIS_FLEX > 0 THEN
#SELECT ROUND(THIS_FLEX/60,2),MY_FLEX_HOUR;
				IF ROUND(THIS_FLEX/60,2) - MY_FLEX_HOUR < 0 THEN
					SET THIS_MST = DATE_ADD(THIS_MST,INTERVAL THIS_FLEX SECOND);
					IF i_flex_hour = 0 OR (i_is_month_period = 1 AND i_month_period_hour>0) THEN
						SET THIS_AET = THIS_AET;
#SELECT 1,THIS_AET;
					ELSE
						SET THIS_AET = DATE_ADD(THIS_AET,INTERVAL THIS_FLEX SECOND);
#SELECT 2,THIS_AET;
					END IF;
				ELSE
					SET THIS_MST = DATE_ADD(THIS_MST,INTERVAL MY_FLEX_HOUR MINUTE);
					IF i_flex_hour = 0 OR (i_is_month_period = 1 AND i_month_period_hour>0) THEN
						SET THIS_AET = THIS_AET;
#SELECT 3,THIS_AET;
					ELSE
						SET THIS_AET = DATE_ADD(THIS_AET,INTERVAL MY_FLEX_HOUR MINUTE);
#SELECT 4,THIS_AET;
					END IF;
				END IF;

				
				IF THIS_AET > THIS_NA_EDTM THEN
					SET THIS_AET = DATE_ADD(THIS_AET,INTERVAL ROUND(TIME_TO_SEC(TIMEDIFF(THIS_NA_EDTM,THIS_NA_BGTM))/60,0) MINUTE);
				ELSEIF THIS_AET >= THIS_NA_BGTM AND THIS_AET <= THIS_NA_EDTM THEN
					SET THIS_AET = DATE_ADD(THIS_AET,INTERVAL ROUND(TIME_TO_SEC(TIMEDIFF(THIS_AET,THIS_NA_BGTM))/60,0) MINUTE);
				END IF;
				
				IF THIS_EDDT > THIS_NA_EDTM AND i_flex_hour > 0 THEN
					SET DINNER_DEDUCTION = ROUND(TIME_TO_SEC(TIMEDIFF(THIS_NA_EDTM,THIS_NA_BGTM))/60,0);
				ELSEIF THIS_EDDT >= THIS_NA_BGTM AND THIS_EDDT <= THIS_NA_EDTM AND i_flex_hour > 0 THEN
					SET DINNER_DEDUCTION = ROUND(TIME_TO_SEC(TIMEDIFF(THIS_EDDT,THIS_NA_BGTM))/60,0);
				ELSE
					SET DINNER_DEDUCTION = 0;
				END IF;
								
			END IF;
			#判断起止时间的情况 
			#THIS_BGDT
				#条件						目标值		目标所在时段
				#THIS_BGDT < MY_MST					MY_MST			bgst=1(上午)
				#MY_MST <= THIS_BGDT <= THIS_MET		THIS_BGDT			bgst=1	
				#THIS_MET < THIS_BGDT < THIS_AST			THIS_AST			bgst=2（下午）
				#THIS_AST <= THIS_BGDT <= THIS_AET		THIS_BGDT			bgst=2
				#THIS_BGDT > THIS_AET					null			bgst=3(不在考勤时间内，返回0)
			IF (THIS_BGDT < THIS_MST) THEN
				SET THIS_BGDT = THIS_MST;
				SET bgst = 1;
			ELSEIF (THIS_MST <= THIS_BGDT and THIS_BGDT <= THIS_MET) THEN
				SET bgst = 1;			
			ELSEIF (THIS_MET < THIS_BGDT and THIS_BGDT < THIS_AST) THEN
				SET THIS_BGDT = THIS_AST;
				SET bgst = 2;			
			ELSEIF (THIS_AST <= THIS_BGDT and THIS_BGDT <= THIS_AET) THEN
				SET bgst = 2;
			ELSEIF (THIS_BGDT > THIS_AET) THEN
				SET bgst = 3;
			END IF;
			#THIS_EDDT
				#THIS_EDDT < THIS_MST					0				edst=3
				#THIS_MST <= THIS_EDDT <= THIS_MET		THIS_EDDT			edst=1(上午)
				#THIS_MET < THIS_EDDT < THIS_AST			THIS_MET			edst=1
				#THIS_AST <= THIS_EDDT <= THIS_AET		THIS_EDDT			edst=2（下午）
				#THIS_EDDT > THIS_AET					THIS_AET			edst=2
			IF (THIS_EDDT < THIS_MST) THEN
				SET edst = 3;
			ELSEIF (THIS_MST <= THIS_EDDT and THIS_EDDT <= THIS_MET) THEN
				SET edst = 1;			
			ELSEIF (THIS_MET < THIS_EDDT and THIS_EDDT < THIS_AST) THEN
				SET THIS_EDDT = THIS_MET;
				SET edst = 1;			
			ELSEIF (THIS_AST <= THIS_EDDT and THIS_EDDT <= THIS_AET) THEN
				SET edst = 2;
			ELSEIF (THIS_EDDT > THIS_AET) THEN
				SET THIS_EDDT = THIS_AET;
				SET edst = 2;
			END IF;
			
			#是否与特殊节假日冲突
			IF bgst = 1 and edst = 2 THEN
				SET IS_IN_SPHOL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(this_date,3,emp,null,null),0);
			ELSEIF bgst = 1 and edst = 1 THEN
				SET IS_IN_SPHOL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(this_date,1,emp,null,null),0);
			ELSEIF bgst = 2 and edst = 2 THEN
				SET IS_IN_SPHOL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(this_date,2,emp,null,null),0);
			END IF;
			
			SET CRASH_HOUR = ROUND(IFNULL(FN_ATT_GET_SPHOLDAYS(THIS_BGDT,THIS_EDDT,emp,2),0) * 60,0);
			SET WORK_HOUR = ROUND(IFNULL(FN_ATT_GET_REAL_DAY_HOURS(TIME(THIS_BGDT),TIME(THIS_EDDT),emp,this_date),0),0);

			#请假规则为工作日
			IF i_hol_rule = 1 THEN
				#工作日，或者节假日不生效的假期
				IF (dttype in (1,6) AND IS_IN_SPHOL = 0)  OR ( dttype = 3 AND ieh=0 ) THEN
					#扣除
					IF (bgst=3 or edst=3) or (bgst=2 and edst=1) THEN		#给出的时间不在考勤范围内
						SET real_day_hours = 0 ;
					ELSEIF (bgst=edst and bgst<>3 and edst<>3) THEN			#都在上午或都在下午
						#不是半天的计为实际分钟数
						IF minunit <> 4 THEN
							#计算分钟数
							SET real_day_hours = TIME_TO_SEC(timediff(THIS_EDDT,THIS_BGDT))/60 - DINNER_DEDUCTION;	
						#是半天的计为0.5天
						ELSE
							SET real_day_hours = 0.5;
						END IF;
					ELSEIF (bgst<edst and bgst<>3 and edst<>3) THEN			#一个上午一个下午
						#不是半天的计为实际分钟数
						IF minunit <> 4 THEN
							#计算分钟数
							SET real_day_hours = (TIME_TO_SEC(timediff(THIS_MET,THIS_BGDT))/60) + (TIME_TO_SEC(timediff(THIS_EDDT,THIS_AST))/60) - DINNER_DEDUCTION;
						ELSE
							SET real_day_hours = 1;
						END IF;
					END IF;
#SELECT real_day_hours;
				#周末或者生效的假期
				ELSEIF (dttype IN (2,4) OR (IS_IN_SPHOL > 0 AND CRASH_HOUR=WORK_HOUR)) OR ( dttype = 3 AND ieh=1 )  THEN
					#不扣除
					SET real_day_hours = 0;
				ELSEIF IS_IN_SPHOL > 0 AND CRASH_HOUR < WORK_HOUR THEN
					SET real_day_hours = WORK_HOUR - CRASH_HOUR;

				END IF;
			#请假规则为自然日
			ELSEIF i_hol_rule =2 THEN
				
				IF (bgst=3 or edst=3) or (bgst=2 and edst=1) THEN		#给出的时间不在考勤范围内
					SET real_day_hours = 0 ;
				ELSEIF (bgst=edst and bgst<>3 and edst<>3) THEN			#都在上午或都在下午
					#不是半天的计为实际分钟数
					IF minunit <> 4 THEN
						#计算分钟数
						SET real_day_hours = TIME_TO_SEC(timediff(THIS_EDDT,THIS_BGDT))/60 - DINNER_DEDUCTION;	
					#是半天的计为0.5天
					ELSE
						SET real_day_hours = 0.5;
					END IF;
				ELSEIF (bgst<edst and bgst<>3 and edst<>3) THEN			#一个上午一个下午
					#不是半天的计为实际分钟数
					IF minunit <> 4 THEN
						#计算分钟数
						SET real_day_hours = (TIME_TO_SEC(timediff(THIS_MET,THIS_BGDT))/60) + (TIME_TO_SEC(timediff(THIS_EDDT,THIS_AST))/60) - DINNER_DEDUCTION;
					ELSE
						SET real_day_hours = 1;
					END IF;
				END IF;
			END IF;
/*		#综合考勤
		ELSEIF MY_ATT_RULE = 2 THEN
			#读出出勤设置
			SELECT zh_ratio,zh_hour
				into MY_ZH_RATIO,MY_ZH_HOUR				#上下午起止时间
			FROM att_set_schema_new b
			WHERE b.att_id = ATTID;
		
			#请假规则为工作日
			IF i_hol_rule = 1 THEN
					#工作日，或者节假日不生效的假期
					IF (dttype in (1,6) AND IS_IN_SPHOL = 0)  OR ( dttype = 3 AND ieh=0 ) THEN
						#扣除
						IF MY_ZH_RATIO = 1 THEN
							#每天的小时数 = MY_ZH_HOUR
							SET real_day_hours = MY_ZH_HOUR;
						ELSEIF MY_ZH_RATIO = 2 THEN
							#得到custid
							SELECT CUST_ID INTO MY_CUST_ID FROM EMP_BASE_INFO WHERE EMP_ID = emp;
							#得到该企业这段时间的考勤区间
							SELECT A.begin_date,A.end_date
								INTO MY_PERIOD_BGDT,MY_PERIOD_EDDT
							FROM cust_period_schedule A
							WHERE A.cust_id = MY_CUST_ID AND A.period_type=1 
								AND THIS_DATE>=A.begin_date AND THIS_DATE<=A.end_date;
							#得到区间内应工作天数
							SET MY_SHOULD_WORK_DAY = FN_ATT_GET_WORKDAYS(MY_PERIOD_BGDT,MY_PERIOD_EDDT,emp,1);
							#每天的小时数 = MY_ZH_HOUR /所在考勤周期的应工作天数
							SET real_day_hours = ROUND(MY_ZH_HOUR / MY_SHOULD_WORK_DAY*60,0);
						END IF;
					#周末或者生效的假期
					ELSEIF (dttype IN (2,4) OR IS_IN_SPHOL=1) OR ( dttype = 3 AND ieh=1 ) THEN
						#不扣除
						SET real_day_hours = 0;
					END IF;
			#请假规则为自然日
			ELSEIF i_hol_rule =2 THEN
				SET real_day_hours = ROUND(TIME_TO_SEC(TIMEDIFF(edtm,bgtm))/60,0);
			END IF;
*/
		#排班出勤				
		ELSEIF MY_ATT_RULE = 3 THEN
			#查看当天排班的日程是否有班
			SELECT MAX(ARR_NO) INTO MY_ARR_NO
			FROM att_arrange_schedual A
			WHERE A.emp_id=emp AND A.dt = this_date ;
			
			IF i_hol_rule = 1 THEN
				IF MY_ARR_NO IS NOT NULL THEN
					SET real_day_hours = 0;
					SET MY_ARR_WORK_HOUR = 0;
					SET MYCT = 1 ;
					WHILE (MYCT <= MY_ARR_NO) DO
						SET MY_ARR_BG_TIME = NULL;
						SET MY_ARR_ED_TIME = NULL;
						SET TMP_BGTM = NULL;
						SET TMP_EDTM = NULL;
						SET THIS_ARR_WORK_HOUR = 0;
						SET THIS_HOL_HOUR = 0;
						
						SELECT A.arr_start_time,A.arr_end_time
							INTO MY_ARR_BG_TIME,MY_ARR_ED_TIME
						FROM att_arrange_schedual A
						WHERE  A.emp_id=emp AND A.dt = this_date AND ARR_NO = MYCT;
#select MYCT,MY_ARR_BG_TIME,MY_ARR_ED_TIME;						
						SET THIS_ARR_WORK_HOUR = ROUND(TIME_TO_SEC(TIMEDIFF(MY_ARR_ED_TIME,MY_ARR_BG_TIME))/60,0);
						#比较请假的开始时间和结束时间 与 排班的开始时间和结束时间的差异
						#在排班时间范围内的，以交集进行循环累加
						#请假开始时间小于该时段开始时间，起始时间设为时段开始时间
						IF CONCAT(this_date,' ',bgtm) < MY_ARR_BG_TIME THEN
							SET TMP_BGTM = MY_ARR_BG_TIME;
						#请假开始时间在该时段内，起始时间设为实际请假开始时间
						ELSEIF CONCAT(this_date,' ',bgtm) >= MY_ARR_BG_TIME AND CONCAT(this_date,' ',bgtm)<=MY_ARR_ED_TIME THEN
							SET TMP_BGTM = CONCAT(this_date,' ',bgtm);
						#请假开始时间大于时段结束时间，那么本次的值设为结束时间（本次结束时间相等，差值为0,）
						ELSEIF CONCAT(this_date,' ',bgtm) > MY_ARR_ED_TIME THEN
							SET TMP_BGTM = MY_ARR_ED_TIME;
						END IF;
						
						
						#请假结束时间比该时段结束时间晚，那么结束时间设为时段结束时间
						IF CONCAT(this_date,' ',edtm) > MY_ARR_ED_TIME THEN
							SET TMP_EDTM = MY_ARR_ED_TIME;
						#请假结束时间在时段内，按实际值算
						ELSEIF CONCAT(this_date,' ',edtm) >= MY_ARR_BG_TIME AND CONCAT(this_date,' ',edtm) <= MY_ARR_ED_TIME THEN
							SET TMP_EDTM = CONCAT(this_date,' ',edtm);
						#请假结束时间小于时段开始时间，本次结束时间就等于时段开始时间（与本次开始时间相等，差值为0）
						ELSEIF CONCAT(this_date,' ',edtm) < MY_ARR_BG_TIME THEN
							SET TMP_EDTM = MY_ARR_BG_TIME;
						END IF;
						#分钟数
						SET THIS_HOL_HOUR = ROUND(TIME_TO_SEC(TIMEDIFF(TMP_EDTM,TMP_BGTM))/60,0);

						IF THIS_HOL_HOUR IS NULL OR THIS_HOL_HOUR < 0 THEN SET THIS_HOL_HOUR = 0; END IF;
						
						SET real_day_hours = real_day_hours + THIS_HOL_HOUR;
				
						SET MY_ARR_WORK_HOUR = MY_ARR_WORK_HOUR + THIS_ARR_WORK_HOUR;
#SELECT MY_ARR_WORK_HOUR,THIS_ARR_WORK_HOUR,MYCT,MY_ARR_BG_TIME,MY_ARR_ED_TIME,TMP_EDTM,TMP_BGTM;
						SET MYCT = MYCT + 1;
					END WHILE;
					
					
				#如果没班
				ELSE 
					#不扣
					SET real_day_hours = 0;
				END IF;
			ELSEIF i_hol_rule = 2 THEN
				SET real_day_hours = ROUND(TIME_TO_SEC(TIMEDIFF(edtm,bgtm))/60,0);
				SET MY_ARR_WORK_HOUR = 24;
#select edtm,bgtm,real_day_hours;
			END IF;
			
			IF i_hol_rule = 1 THEN
				#算完当天的，再继续考虑一下前一天排班是否有跨天的情况，如果有，也需要把前一天的时长计算进来
				SET MY_YESTERDAY = DATE_ADD(this_date,INTERVAL -1 DAY);
				#找出前一天的排班最大序列
				SELECT MAX(A.arr_no) INTO YESTD_ARR_NO 
				FROM att_arrange_schedual A
				WHERE A.emp_id=emp AND A.dt = MY_YESTERDAY ;
				
				#序列号大于零时才开始
				IF YESTD_ARR_NO > 0 AND YESTD_ARR_NO IS NOT NULL THEN
					#读出昨天排班最后一个时间点
					SELECT A.arr_end_time INTO YESTD_ARR_END_TIME
					FROM att_arrange_schedual A
					WHERE A.emp_id=emp AND A.dt = MY_YESTERDAY AND A.arr_no=YESTD_ARR_NO;
					
					#如果这个时间点位于今天
					IF YESTD_ARR_END_TIME > CONCAT(MY_YESTERDAY,' 23:59:59') THEN
						#把今天0点设为起始点
						SET YESTD_ARR_START_TIME = CONCAT(this_date,' 00:00:00');
						
						#比较请假的开始时间和结束时间 与 排班的开始时间和结束时间的差异
						#在排班时间范围内的，以交集进行循环累加
						#请假开始时间小于该时段开始时间，起始时间设为时段开始时间
						IF CONCAT(this_date,' ',bgtm) < YESTD_ARR_START_TIME THEN
							SET YESTD_BGTM = YESTD_ARR_START_TIME;
						#请假开始时间在该时段内，起始时间设为实际请假开始时间
						ELSEIF CONCAT(this_date,' ',bgtm) >= YESTD_ARR_START_TIME AND CONCAT(this_date,' ',bgtm)<=YESTD_ARR_END_TIME THEN
							SET YESTD_BGTM = CONCAT(this_date,' ',bgtm);
						#请假开始时间大于时段结束时间，那么本次的值设为结束时间（本次结束时间相等，差值为0,）
						ELSEIF CONCAT(this_date,' ',bgtm) > YESTD_ARR_END_TIME THEN
							SET YESTD_BGTM = YESTD_ARR_END_TIME;
						END IF;
						
						
						#请假结束时间比该时段结束时间晚，那么结束时间设为时段结束时间
						IF CONCAT(this_date,' ',edtm) > YESTD_ARR_END_TIME THEN
							SET YESTD_EDTM = YESTD_ARR_END_TIME;
						#请假结束时间在时段内，按实际值算
						ELSEIF CONCAT(this_date,' ',edtm) >= YESTD_ARR_START_TIME AND CONCAT(this_date,' ',edtm) <= YESTD_ARR_END_TIME THEN
							SET YESTD_EDTM = CONCAT(this_date,' ',edtm);
						#请假结束时间小于时段开始时间，本次结束时间就等于时段开始时间（与本次开始时间相等，差值为0）
						ELSEIF CONCAT(this_date,' ',edtm) < YESTD_ARR_START_TIME THEN
							SET YESTD_EDTM = YESTD_ARR_START_TIME;
						END IF;
						#分钟数
						SET YESTD_HOL_HOUR = ROUND(TIME_TO_SEC(TIMEDIFF(YESTD_EDTM,YESTD_BGTM))/60,0);
	
						IF YESTD_HOL_HOUR IS NULL OR YESTD_HOL_HOUR < 0 THEN SET YESTD_HOL_HOUR = 0; END IF;
	
						SET real_day_hours = real_day_hours + YESTD_HOL_HOUR;
						SET YESTD_WORK_HOUR = FN_ATT_GET_ARR_WORKHOURS(emp,MY_YESTERDAY);
						SET MY_ARR_WORK_HOUR = MY_ARR_WORK_HOUR + YESTD_WORK_HOUR;
					END IF;
				END IF;
			END IF;
		END IF;
		
		IF minunit <> 4 AND real_day_hours > 480 THEN
			SET real_day_hours = 480;
		END IF;
			
#----------------------逻辑架构结束-----------------------------*			
	

		
		#如果得到负值或者是空，则把请假时间归零
		IF real_day_hours < 0 OR real_day_hours IS NULL THEN
			SET real_day_hours = 0;
		END IF;	
		IF MY_ARR_WORK_HOUR < 0 OR MY_ARR_WORK_HOUR IS NULL THEN
			SET MY_ARR_WORK_HOUR = 0;
		END IF;

		#根据请假单位（1一刻钟 2半小时 3小时 4半天 5一天） 来返回最终的小时数
		IF minunit = 999 THEN
			SET real_day_hours = real_day_hours;
		ELSEIF minunit=99 THEN			#返回根据最小单位转换的小时数
			CASE i_holunit
			WHEN 1 THEN			#15分钟
				SET real_day_hours = ROUND(CEILING(real_day_hours/15)*15/60,2);
			WHEN 2 THEN			#30分钟
				SET real_day_hours = ROUND(CEILING(real_day_hours/30)*30/60,2);		
			WHEN 3 THEN			#一小时
				SET real_day_hours = CEILING(real_day_hours/60);
			WHEN 4 THEN			#半天
				IF real_day_hours > 0 AND i_st_unit = 1 AND MY_ATT_RULE = 1 AND real_day_hours/60 <= FN_ATT_GET_WORKHOURS(ATTID)/2 THEN
					SET real_day_hours =  FN_ATT_GET_WORKHOURS(ATTID)/2;
				ELSEIF real_day_hours > 0 AND i_st_unit = 1 AND MY_ATT_RULE = 1 AND real_day_hours/60 > FN_ATT_GET_WORKHOURS(ATTID)/2 THEN
					SET real_day_hours =  FN_ATT_GET_WORKHOURS(ATTID);
				ELSEIF real_day_hours > 0 AND i_st_unit = 1 AND MY_ATT_RULE = 3 AND real_day_hours/60 <= FN_ATT_GET_ARR_WORKHOURS(emp,this_date)/60/2 THEN
					SET real_day_hours =  FN_ATT_GET_ARR_WORKHOURS(emp,this_date)/60/2;
				ELSEIF real_day_hours > 0 AND i_st_unit = 1 AND MY_ATT_RULE = 3 AND real_day_hours/60 > FN_ATT_GET_ARR_WORKHOURS(emp,this_date)/60/2 THEN
					SET real_day_hours =  FN_ATT_GET_ARR_WORKHOURS(emp,this_date)/60;
				ELSEIF real_day_hours > 0 AND i_st_unit = 2 THEN
					SET real_day_hours = ROUND(real_day_hours/3600,2);
				END IF;
			WHEN 5 THEN			#全天
				IF MY_ATT_RULE IN (1,2) THEN
					IF real_day_hours > 0 THEN
						SET real_day_hours = ROUND(FN_ATT_GET_WORKHOURS(ATTID),2);
					END IF;
				ELSEIF MY_ATT_RULE = 3 THEN
					SET real_day_hours = ROUND(CEILING(real_day_hours/MY_ARR_WORK_HOUR)*(MY_ARR_WORK_HOUR/60),2);
				END IF;
			ELSE
				SET real_day_hours = real_day_hours/60;
			END CASE;
		ELSEIF minunit=1 THEN		#返回最小单位15分钟的换算分钟数
			SET real_day_hours = CEILING(real_day_hours/15)*15;
		ELSEIF minunit=2 THEN		#返回最小单位30分钟的换算分钟数
			SET real_day_hours = CEILING(real_day_hours/30)*30;
		ELSEIF minunit=3 THEN		#返回最小单位1小时的换算小时数
			SET real_day_hours = CEILING(real_day_hours/60);
		ELSEIF minunit=4 AND MY_ATT_RULE <> 1 THEN		#最小单位半天的、出勤规则不是坐班的，计为-3
			SET real_day_hours = -3;
		ELSEIF minunit=4 AND MY_ATT_RULE = 1 THEN		#最小单位半天的、坐班的，按半天算
			SET real_day_hours = real_day_hours;
		ELSEIF minunit=5 THEN
			IF real_day_hours > 0 THEN
				SET real_day_hours = 1;
			ELSE
				SET real_day_hours = 0;
			END IF;
		ELSE
			SET real_day_hours = 0;
		END IF;
	END IF;	
	
	IF real_day_hours IS NULL THEN SET real_day_hours = 0; END IF;
SELECT real_day_hours;

END;

