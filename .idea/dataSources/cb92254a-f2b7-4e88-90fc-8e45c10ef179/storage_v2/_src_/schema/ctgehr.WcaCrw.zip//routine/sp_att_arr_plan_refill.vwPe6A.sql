create procedure SP_ATT_ARR_PLAN_REFILL(IN BGDT date, IN EDDT date, IN CUSTID bigint, IN DEPTID bigint, IN EMP bigint)
  comment '为某个公司、部门或个人按照新的排版设置从新添加旧排班日程'
  BEGIN
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE MY_ARR,MY_CUST,MY_DEPT,MY_DAILY_CT,MY_DAILY_MXCT,MY_EMP,MY_CT,MY_MXCT,MY_ATT BIGINT;
DECLARE MY_SET_NO,MY_ARR_NO,MY_BG_DAY,MY_ED_DAY,i_arrange_bg_day_1,i_arrange_end_day_1,i_arrange_bg_day_2,i_arrange_end_day_2,i_arrange_bg_day_3,i_arrange_end_day_3,STAT INT;
DECLARE i_arrange_bg_time_1,i_arrange_end_time_1,i_arrange_bg_time_2,i_arrange_end_time_2,i_arrange_bg_time_3,i_arrange_end_time_3 TIME;
DECLARE MY_BG_TIME,MY_ED_TIME DATETIME;
#创建本次计算的版本号
SET I_VERSION_CODE = UUID();
#LOOP 1
	WHILE BGDT <= EDDT DO
		#根据输入的参数确定数据范围
		IF (CUSTID IS NULL AND DEPTID IS NULL AND EMP IS NULL) THEN
			SET STAT=4;
		ELSEIF (CUSTID IS not NULL AND DEPTID IS NULL AND EMP IS NULL) THEN
			SET STAT=3;
		ELSEIF (deptid IS not NULL AND EMP IS NULL) THEN
			SET STAT=2;
		ELSEIF (EMP IS not NULL) THEN
			SET STAT=1;
		END IF;
		#把满足条件的排班记录写入临时表，然后循环处理。
 		CASE STAT
			WHEN 1 THEN
				INSERT INTO tmp_arr_plan_refill (VERSION_CODE,emp_id,arr_no,att_id)
					SELECT I_VERSION_CODE,A.emp_id,MAX(A.arr_no),A.att_id
					FROM att_arrange_schedual A  
					WHERE A.emp_id = EMP AND A.dt = BGDT 
					GROUP BY A.emp_id;
			WHEN 2 THEN
				INSERT INTO tmp_arr_plan_refill (VERSION_CODE,emp_id,arr_no,att_id)
					SELECT I_VERSION_CODE,A.emp_id,MAX(A.arr_no),A.att_id
					FROM att_arrange_schedual A  
					WHERE A.dept_id = DEPTID AND A.dt = BGDT 
					GROUP BY A.emp_id;
			WHEN 3 THEN
				INSERT INTO tmp_arr_plan_refill (VERSION_CODE,emp_id,arr_no,att_id)
					SELECT I_VERSION_CODE,A.emp_id,MAX(A.arr_no),A.att_id
					FROM att_arrange_schedual A  
					WHERE A.cust_id = CUSTID AND A.dt = BGDT 
					GROUP BY A.emp_id;
			WHEN 4 THEN
				INSERT INTO tmp_arr_plan_refill (VERSION_CODE,emp_id,arr_no,att_id)
					SELECT I_VERSION_CODE,A.emp_id,MAX(A.arr_no),A.att_id
					FROM att_arrange_schedual A  
					WHERE A.dt = BGDT 
					GROUP BY A.emp_id;
		END CASE;
		
		SET MY_EMP = NULL;
		SET MY_ARR_NO = NULL;
		SET MY_ATT = NULL;

		#循环需要补的人
		SELECT MIN(ID),MAX(ID) INTO MY_DAILY_CT,MY_DAILY_MXCT FROM tmp_arr_plan_refill WHERE VERSION_CODE = I_VERSION_CODE;
		WHILE (MY_DAILY_CT <= MY_DAILY_MXCT AND MY_DAILY_CT > 0 ) DO 
			SELECT A.emp_id,A.arr_no,A.att_id
				INTO MY_EMP,MY_ARR_NO,MY_ATT
			FROM tmp_arr_plan_refill A
			WHERE A.ID = MY_DAILY_CT AND A.VERSION_CODE = I_VERSION_CODE;

			IF MY_EMP IS NOT NULL THEN

				
				SELECT A.arrange_bg_day_1,A.arrange_bg_time_1,A.arrange_end_day_1,A.arrange_end_time_1,
						 A.arrange_bg_day_2,A.arrange_bg_time_2,A.arrange_end_day_2,A.arrange_end_time_2,
						 A.arrange_bg_day_3,A.arrange_bg_time_3,A.arrange_end_day_3,A.arrange_end_time_3
					INTO i_arrange_bg_day_1,i_arrange_bg_time_1,i_arrange_end_day_1,i_arrange_end_time_1,
						 i_arrange_bg_day_2,i_arrange_bg_time_2,i_arrange_end_day_2,i_arrange_end_time_2,
						 i_arrange_bg_day_3,i_arrange_bg_time_3,i_arrange_end_day_3,i_arrange_end_time_3
				FROM att_set_schema_new A
				WHERE A.att_id= MY_ATT;
				
				
				#得到时间段的数量
				IF i_arrange_bg_time_3 IS NOT NULL THEN
					SET MY_SET_NO = 3;
				ELSEIF i_arrange_bg_time_2 IS NOT NULL THEN
					SET MY_SET_NO = 2;
				ELSEIF i_arrange_bg_time_1 IS NOT NULL THEN
					SET MY_SET_NO = 1;
				END IF;
				
				#比较新设定和已经排出班次的时间段数量
				IF MY_SET_NO > MY_ARR_NO THEN 
					SET MY_MXCT = MY_SET_NO;
				ELSE
					SET MY_MXCT = MY_ARR_NO;
				END IF;
				
				SET MY_CT = 1;

				#再循环每个时间段
				WHILE(MY_CT <= MY_MXCT) DO
					SET MY_BG_DAY = NULL;
					SET MY_ED_DAY = NULL;
					SET MY_BG_TIME = NULL;
					SET MY_ED_TIME = NULL;
				
					#判断时间段信息
					IF MY_CT = 1 THEN
						SET MY_BG_DAY = i_arrange_bg_day_1;
						SET MY_ED_DAY = i_arrange_end_day_1;
						
						IF MY_BG_DAY = 1 THEN
							SET MY_BG_TIME = CONCAT(BGDT,' ',i_arrange_bg_time_1);
						ELSEIF MY_BG_DAY = 2 THEN
							SET MY_BG_TIME = CONCAT(DATE_ADD(BGDT,INTERVAL 1 DAY),' ',i_arrange_bg_time_1);
						END IF;
						
						IF MY_ED_DAY = 1 THEN
							SET MY_ED_TIME = CONCAT(BGDT,' ',i_arrange_end_time_1);
						ELSEIF MY_ED_DAY = 2 THEN
							SET MY_ED_TIME = CONCAT(DATE_ADD(BGDT,INTERVAL 1 DAY),' ',i_arrange_end_time_1);
						END IF;

					ELSEIF MY_CT = 2 THEN
						SET MY_BG_DAY = i_arrange_bg_day_2;
						SET MY_ED_DAY = i_arrange_end_day_2;
						
						IF MY_BG_DAY = 1 THEN
							SET MY_BG_TIME = CONCAT(BGDT,' ',i_arrange_bg_time_2);
						ELSEIF MY_BG_DAY = 2 THEN
							SET MY_BG_TIME = CONCAT(DATE_ADD(BGDT,INTERVAL 1 DAY),' ',i_arrange_bg_time_2);
						END IF;
						
						IF MY_ED_DAY = 1 THEN
							SET MY_ED_TIME = CONCAT(BGDT,' ',i_arrange_end_time_2);
						ELSEIF MY_ED_DAY = 2 THEN
							SET MY_ED_TIME = CONCAT(DATE_ADD(BGDT,INTERVAL 1 DAY),' ',i_arrange_end_time_2);
						END IF;

					ELSEIF MY_CT = 3 THEN
						SET MY_BG_DAY = i_arrange_bg_day_2;
						SET MY_ED_DAY = i_arrange_end_day_2;
						
						IF MY_BG_DAY = 1 THEN
							SET MY_BG_TIME = CONCAT(BGDT,' ',i_arrange_bg_time_2);
						ELSEIF MY_BG_DAY = 2 THEN
							SET MY_BG_TIME = CONCAT(DATE_ADD(BGDT,INTERVAL 1 DAY),' ',i_arrange_bg_time_3);
						END IF;
						
						IF MY_ED_DAY = 1 THEN
							SET MY_ED_TIME = CONCAT(BGDT,' ',i_arrange_end_time_3);
						ELSEIF MY_ED_DAY = 2 THEN
							SET MY_ED_TIME = CONCAT(DATE_ADD(BGDT,INTERVAL 1 DAY),' ',i_arrange_end_time_3);
						END IF;					

					END IF;
					
#SELECT MY_ARR,		MY_EMP,		BGDT,	MY_CT,MY_BG_TIME,MY_ED_TIME;					
					SET MY_ARR = NULL;
					SELECT A.arr_id INTO MY_ARR 
					FROM att_arrange_schedual A 
					WHERE A.emp_id = MY_EMP AND A.dt = BGDT AND A.arr_no = MY_CT;

					SET MY_DEPT = NULL;
					SET MY_CUST = NULL;

					#排班和新设置都有这个时间段时-做更新操作
					IF MY_ARR IS NOT NULL AND MY_BG_TIME IS NOT NULL THEN
						UPDATE att_arrange_schedual A SET A.arr_start_time = MY_BG_TIME ,A.arr_end_time=MY_ED_TIME,A.arr_no = MY_CT WHERE A.arr_id = MY_ARR;
					#排班有，新设置没有这个时间段-删除
					ELSEIF MY_ARR IS NOT NULL AND MY_BG_TIME IS NULL THEN
						DELETE FROM att_arrange_schedual WHERE arr_id = MY_ARR;
					#排班没有，新设置有 - 插入
					ELSEIF MY_ARR IS NULL AND MY_BG_TIME IS NOT NULL THEN
						SELECT MAX(IF(arr_id IS NULL,0,arr_id))+1 INTO MY_ARR FROM att_arrange_schedual WHERE ARR_ID < 100000000;
						IF MY_ARR IS NULL THEN SET MY_ARR = 1; END IF;
						SELECT A.dept_id,A.cust_id INTO MY_DEPT,MY_CUST FROM att_arrange_schedual A WHERE A.emp_id = MY_EMP and A.dt=BGDT LIMIT 1;
						INSERT INTO att_arrange_schedual (ARR_ID,CUST_ID,DEPT_ID,EMP_ID,ATT_ID,DT,ARR_NO,arr_start_time,arr_end_time) VALUES
							(MY_ARR,MY_CUST,MY_DEPT,MY_EMP,MY_ATT,BGDT,MY_CT,MY_BG_TIME,MY_ED_TIME);						
					END IF;
#SELECT MY_BG_TIME,MY_ED_TIME;

					SET MY_CT = MY_CT + 1;
				END WHILE;

				DELETE FROM tmp_arr_plan_refill WHERE ID=MY_DAILY_CT AND VERSION_CODE= I_VERSION_CODE;
			END IF;
			SET MY_DAILY_CT = MY_DAILY_CT + 1;
		END WHILE;
		SET BGDT = DATE_ADD(BGDT,INTERVAL 1 DAY);
	END WHILE;
END;

