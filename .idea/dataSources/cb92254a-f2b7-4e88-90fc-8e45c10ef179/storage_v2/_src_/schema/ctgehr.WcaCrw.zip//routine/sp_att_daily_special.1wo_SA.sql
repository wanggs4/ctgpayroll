create procedure SP_ATT_DAILY_SPECIAL(IN BGDT  date, IN EDDT date, IN CUSTID bigint unsigned, IN DEPTID bigint unsigned,
                                      IN EMPID bigint unsigned, IN DEPTTYPE int)
  comment '特殊节假日日报'
  BEGIN
DECLARE I_VERSION_CODE,MY_SPDAYNAME VARCHAR(50);
DECLARE IS_GET_SPDAY,STAT,SP_CT,SP_MXCT,MY_SPDAY_FLAG BIGINT;
DECLARE MY_EMPID,MY_SPDAYID,MY_DEPTID,MY_CUSTID BIGINT UNSIGNED;
DECLARE MY_SPDAY_BGTM,MY_SPDAY_EDTM DATETIME;
DECLARE MY_SP_HOUR DECIMAL(12,2);
DECLARE SPDAY_STR TEXT;
	set sql_mode='';
	set I_VERSION_CODE = uuid();

	/*判断输入的参数
		STAT 1 EMPID		EMPID is not null 按员工查						
		STAT 2 detp		DEPTID is not null and EMPID is null 按部门查
		STAT 3 CUSTID  CUSTID is not null and DEPTID is null and EMPID is null; 按公司查
		STAT 4 all		CUSTID is null and DEPTID is null and EMPID is null  全局查
	*/
	if (CUSTID is null and DEPTID is null AND DEPTTYPE IS NULL and EMPID is null) then
		set STAT=4;
	elseif (CUSTID is not null and DEPTID is null AND DEPTTYPE IS NULL and EMPID is null) then
		set STAT=3;
	elseif (DEPTID is not null AND DEPTTYPE IS NOT NULL and EMPID is null) then
		set STAT=2;
	elseif (EMPID is not null) then
		set STAT=1;
	end if;


	#第一层循环 按日期
	WHILE (BGDT <= EDDT) DO
		#把满足条件的写入列表
		CASE STAT
		WHEN 1 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dept_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=1 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.prgm_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.jrdc_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=3 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id4=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=4 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id5=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=5 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id6=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=6 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id7=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=7 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id8=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=8 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id9=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=9 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id10=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.emp_id=EMPID AND D.dept_type=10 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;				
				
		WHEN 2 THEN
			CASE DEPTTYPE 
			WHEN 1 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dept_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.DEPT_ID=DEPTID AND D.dept_type=1 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 2 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.prgm_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.prgm_id=DEPTID AND D.dept_type=2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 3 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.jrdc_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.jrdc_id=DEPTID AND D.dept_type=3 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 4 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id4=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.dms_id4=DEPTID AND D.dept_type=4 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 5 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id5=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.dms_id5=DEPTID AND D.dept_type=5 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 6 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id6=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.dms_id6=DEPTID AND D.dept_type=6 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 7 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id7=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.dms_id7=DEPTID AND D.dept_type=7 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 8 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id8=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.dms_id8=DEPTID AND D.dept_type=8 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 9 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id9=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.dms_id9=DEPTID AND D.dept_type=9 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			WHEN 10 THEN
				INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
					SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
					FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id10=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
					WHERE A.dms_id10=DEPTID AND D.dept_type=10 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;
			END CASE;
		WHEN 3 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dept_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=1 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.prgm_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.jrdc_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=3 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id4=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=4 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id5=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=5 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id6=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=6 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id7=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=7 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id8=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=8 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id9=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=9 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id10=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE A.cust_id=CUSTID AND D.dept_type=10 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;				
		WHEN 4 THEN
			INSERT INTO tmp_att_specialday_list (version_code,emp_id,sp_day_id)
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dept_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=1 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.prgm_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=2 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.jrdc_id=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=3 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id4=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=4 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id5=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=5 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id6=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=6 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id7=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=7 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id8=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=8 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id9=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=9 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2
				UNION ALL
				SELECT DISTINCT I_VERSION_CODE,A.emp_id,D.sp_day_id
				FROM emp_base_info A	LEFT JOIN emp_post B ON A.emp_id=B.emp_id	LEFT JOIN att_rel_special_dept C ON A.dms_id10=C.dept_id LEFT JOIN att_set_special_day D ON C.sp_day_id=D.sp_day_id
				WHERE D.dept_type=10 AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT) AND D.is_enable=1 AND D.is_delete=0 AND D.begin_date <= BGDT AND D.end_date >= BGDT AND D.sp_type=2;				
		END CASE;
		
#select * from tmp_att_specialday_list a where a.version_code=I_VERSION_CODE;

		#循环每个人的每个特殊节假日
		SET SP_CT=0,SP_MXCT=0;
		SELECT MIN(ID),MAX(ID) INTO SP_CT,SP_MXCT FROM tmp_att_specialday_list A WHERE A.version_code=I_VERSION_CODE;
		WHILE SP_CT <= SP_MXCT AND SP_CT > 0 DO
			SET MY_EMPID=NULL,MY_SPDAYID=NULL,MY_SPDAY_BGTM=NULL,MY_SPDAY_EDTM=NULL,MY_SPDAY_FLAG=NULL;
			SELECT A.emp_id,A.sp_day_id INTO MY_EMPID,MY_SPDAYID FROM tmp_att_specialday_list A WHERE A.version_code=I_VERSION_CODE AND A.id=SP_CT;
			
			CALL SP_DPT_GET_SETTINGID(MY_EMPID,BGDT,4,SPDAY_STR);
			SET IS_GET_SPDAY = LOCATE(CONCAT(SPDAY_STR,','),CONCAT(MY_SPDAYID,','));
			DELETE FROM att_hol_apply_day WHERE emp_id=MY_EMPID AND hol_date=BGDT AND sp_day_id=MY_SPDAYID;
#select MY_EMPID,BGDT,SPDAY_STR;			
			IF MY_EMPID IS NOT NULL AND IS_GET_SPDAY > 0 THEN
				SET MY_DEPTID=NULL,MY_CUSTID=NULL,MY_SPDAYNAME=NULL,MY_SPDAY_BGTM=NULL,MY_SPDAY_EDTM=NULL,MY_SP_HOUR=NULL;
				#计算出该员工在当天的特殊节假日起止时间点和时长，然后替换掉原有的特殊假期日报数据
				SELECT DEPT_ID,CUST_ID INTO MY_DEPTID,MY_CUSTID FROM EMP_BASE_INFO WHERE EMP_ID=MY_EMPID;
				SELECT A.sp_day_name INTO MY_SPDAYNAME FROM att_set_special_day A WHERE A.sp_day_id=MY_SPDAYID;
				CALL FN_ATT_GET_SPDAY_TIME(MY_EMPID,MY_SPDAYID,BGDT,MY_SPDAY_BGTM,MY_SPDAY_EDTM,MY_SPDAY_FLAG);
				SET MY_SP_HOUR = FN_ATT_GET_SPHOLDAYS(MY_SPDAY_BGTM,MY_SPDAY_EDTM,MY_EMPID,2);
#IF MY_EMPID=1585501369032704 THEN
#	SELECT MY_SPDAY_BGTM,MY_SPDAY_EDTM,MY_SPDAY_FLAG;
#END IF;
				REPLACE INTO att_hol_apply_day (emp_id,hol_date,sp_day_id,hol_id,hol_name,cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,start_time,end_time,hol_hours,half_day_flag) 
					SELECT MY_EMPID,BGDT,MY_SPDAYID,MY_SPDAYID,MY_SPDAYNAME,MY_CUSTID,MY_DEPTID,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,TIME(MY_SPDAY_BGTM),TIME(MY_SPDAY_EDTM),MY_SP_HOUR,MY_SPDAY_FLAG
					FROM emp_base_info a
					WHERE a.emp_id=MY_EMPID;
			#	DELETE FROM tmp_att_specialday_list WHERE version_code=I_VERSION_CODE AND id=SP_CT;
			END IF;
			SET SP_CT = SP_CT + 1;
		END WHILE;
		
		#系统预留特殊假期
		IF (MONTH(BGDT) = 3 AND DAY(BGDT) = 8) OR (MONTH(BGDT) = 5 AND DAY(BGDT) = 4) THEN
			CALL SP_ATT_SYS_SPECIAL(BGDT,CUSTID,DEPTID,EMPID,DEPTTYPE);
		END IF;
		SET BGDT = DATE_ADD(BGDT,INTERVAL 1 DAY);
	END WHILE;
END;

