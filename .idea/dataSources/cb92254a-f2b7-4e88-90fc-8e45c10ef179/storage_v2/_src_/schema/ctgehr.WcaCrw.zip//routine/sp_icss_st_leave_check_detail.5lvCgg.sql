create procedure SP_ICSS_ST_LEAVE_CHECK_DETAIL(IN BGDT date, IN EDDT date)
  BEGIN
DECLARE MY_MONTH_VERSION INT;
	WHILE BGDT <= EDDT AND BGDT IS NOT NULL DO
		SET MY_MONTH_VERSION = NULL;
		SELECT A.`version` INTO MY_MONTH_VERSION
		FROM att_st_month A 
		WHERE A.cust_id=2162554862743552 AND A.comp_start_time <= BGDT AND A.comp_end_time >= BGDT;
		
		IF MY_MONTH_VERSION IS NOT NULL THEN
			REPLACE INTO icss_st_leave_check_detail (emp_id,dt,year_mon,leave_check_date,leave_check_time,emp_code,emp_name,admin_place,dept_full_name,dept_id,admin_place_id) 
				SELECT A.emp_id,A.dt,MY_MONTH_VERSION,DATE(A.check_out),TIME(A.check_out),A.emp_code,A.emp_name,B.dept_full_name,C.dept_name,A.dept_id,A.dms_id5
				FROM att_emp_detail A
					LEFT JOIN dept_info B ON A.dept_id=B.dept_id
					LEFT JOIN dept_info C ON A.dms_id5=C.dept_id
				WHERE A.cust_id=2162554862743552 AND A.dt = BGDT AND A.check_out IS NOT NULL 
					AND (TIME(A.check_out)>='20:00:00' OR TIME(A.check_out) < '05:00:00')
					AND A.check_in <> A.check_out;		
		END IF;
		
		SET BGDT = DATE_ADD(BGDT,INTERVAL 1 DAY);
	END WHILE;
END;

