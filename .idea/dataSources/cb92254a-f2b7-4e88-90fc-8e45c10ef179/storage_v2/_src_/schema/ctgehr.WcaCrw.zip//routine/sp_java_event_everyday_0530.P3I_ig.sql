create procedure SP_JAVA_EVENT_EVERYDAY_0530()
  comment '用于从中软中间表同步数据至ctgehr'
  BEGIN
DECLARE TODAY,YESTERDAY DATE;
DECLARE BGDT,EDDT DATETIME;
DECLARE IDSEED BIGINT UNSIGNED;
	SET TODAY = DATE(NOW());
	SET YESTERDAY = DATE_ADD(TODAY,INTERVAL -1 DAY);
	SET BGDT = CONCAT(YESTERDAY,' 05:30:00');
	SET EDDT = CONCAT(TODAY,' 05:29:59');
	#部门
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_DEPT','START',NOW());
	REPLACE INTO ctgehr.dept_info (custom_type,
			cust_id,DEPT_ID,DEPT_CODE,ZR_DEPT_ID,DEPT_NAME,
			dept_full_name,parent_dept_id,
			dept_lv_code,IS_ENABLE)
		SELECT IF(LOCATE('中软国际>TPG>华为业务群',A.ORG_FULL_NAME)>0,'1',
					IF(LOCATE('中软国际>TPG>MNC业务群>HSBC业务线',A.ORG_FULL_NAME)>0,'2',
						IF(LOCATE('中软国际>CIG',A.ORG_FULL_NAME)>0 OR
							LOCATE('中软国际>IIG',A.ORG_FULL_NAME)>0 OR
							LOCATE('中软国际>智能制造事业部',A.ORG_FULL_NAME)>0 OR
							LOCATE('中软国际>政企业务部',A.ORG_FULL_NAME)>0 OR
							LOCATE('中软国际>TPG>其他业务群（虚拟）',A.ORG_FULL_NAME)>0 OR
							LOCATE('中软国际>TPG>高科技业务群>平安业务线>银行科技事业部',A.ORG_FULL_NAME)>0,'3',
							'4')
						)
					),
			2162554862743552,IF(org_coa=0,1,ORG_COA),IF(org_coa=0,1,ORG_COA),dept_id,org_name,
			replace(org_full_name,'>','/'),IF(superior_org_coa=0,1,IF(superior_org_coa=-999,0,superior_org_coa)),
			org_level_id,IF(`status`=-1,0,`status`)
		FROM emp_data_source.cs_department_coa_t A;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_DEPT','END',NOW());
		
	#员工
	#首先把已经存在系统中，需要update关键字段的人导入到中间表
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_EMP_UPDT','START',NOW());
	TRUNCATE TABLE icss_employee_replication;
	INSERT INTO icss_employee_replication 
			(LOB_NUMBER,LAST_UPDATE_DATE,LAST_NAME,SEX,PEOPLE_TYPE,
			NATIONAL_IDENTIFIER,phone,org_coa,
			HIRE_DATE,PROBATION_END_DATE,INTERNAL_LOCATION,SERVICE_YEAR,EMAIL,START_WORK_DATE,
			ACTUAL_TERMINATION_DATE,ONWERSHIP_PLACE)	
		SELECT 
			CAST(REPLACE(A.LOB_NUMBER,'\'','') AS UNSIGNED),A.LAST_UPDATE_DATE,A.LAST_NAME,IF(A.SEX='男',1,2),IF(A.PEOPLE_TYPE='正式员工',1,2),
			upper(LEFT(REPLACE(A.NATIONAL_IDENTIFIER,'\'',''),30)),LEFT(A.phone,11),IF(A.org_coa='TPG',100000,A.org_coa),
			A.HIRE_DATE,DATE(A.PROBATION_END_DATE),A.INTERNAL_LOCATION,A.SERVICE_YEAR,LEFT(A.EMAIL,50),A.START_WORK_DATE,
			A.ACTUAL_TERMINATION_DATE,B.dept_id
		FROM emp_data_source.employee A
				LEFT JOIN ctgehr.dept_info B ON A.ONWERSHIP_PLACE = B.dept_name AND B.dept_type=5 AND B.cust_id=2162554862743552
		WHERE cast(replace(LOB_NUMBER,'\'','') as unsigned) IN (SELECT EMP_ID FROM ctgehr.emp_base_info) 
				AND A.LOB_NUMBER IS NOT NULL AND A.LOB_NUMBER <>'';
	#更新关键字段
	UPDATE ctgehr.icss_employee_replication A, ctgehr.emp_base_info B, ctgehr.emp_post C
	SET B.emp_name = A.LAST_NAME,B.gender=A.SEX,B.emp_state=A.PEOPLE_TYPE,B.cert_no=A.NATIONAL_IDENTIFIER,
		B.mobile=A.phone,B.dept_id=A.org_coa,C.dept_id=A.org_coa,C.entry_date=A.HIRE_DATE,C.regu_date=A.PROBATION_END_DATE,
		C.work_add=A.INTERNAL_LOCATION,C.wh_time=A.SERVICE_YEAR,C.work_email=A.EMAIL,C.fst_job_time=A.START_WORK_DATE,
		C.leave_date=A.ACTUAL_TERMINATION_DATE,B.dms_id5=A.ONWERSHIP_PLACE,C.dms_id5=A.ONWERSHIP_PLACE,A.replication_state=1
	WHERE A.LOB_NUMBER=B.emp_id AND A.LOB_NUMBER=C.emp_id AND A.replication_state=0;

	#把这群人的1和5维度数据备份
	REPLACE INTO log_emp_dept_change_bak 
		SELECT A.elcd_id,A.emp_id,A.dept_id,A.cust_id,A.dept_type,A.entry_date,A.leave_date,A.oprtr_id,A.oprtr_name
		FROM ctgehr.log_emp_dept_change A ,ctgehr.icss_employee_replication B 
		WHERE A.emp_id=B.LOB_NUMBER AND A.dept_type IN (1,5);
	#删除
	DELETE A.*
	FROM ctgehr.log_emp_dept_change A ,ctgehr.icss_employee_replication B 
	WHERE A.emp_id=B.LOB_NUMBER AND A.dept_type IN (1,5);
	#重建维度1时间轴
	INSERT INTO ctgehr.log_emp_dept_change (emp_id,dept_id,cust_id,dept_type,entry_date,leave_date,oprtr_id,oprtr_name)
		SELECT A.emp_id,A.dept_id,A.cust_id,1,A.entry_date,A.leave_date,0,'SYS'
		FROM ctgehr.emp_post A ,ctgehr.icss_employee_replication B
		WHERE A.EMP_ID = B.LOB_NUMBER AND A.entry_date IS NOT NULL AND A.dept_id IS NOT NULL;
	#重建维度5时间轴
	INSERT INTO ctgehr.log_emp_dept_change (emp_id,dept_id,cust_id,dept_type,entry_date,leave_date,oprtr_id,oprtr_name)
		SELECT A.emp_id,A.dms_id5,A.cust_id,5,A.entry_date,A.leave_date,0,'SYS'
		FROM ctgehr.emp_post A  ,ctgehr.icss_employee_replication B
		WHERE A.EMP_ID = B.LOB_NUMBER AND A.entry_date IS NOT NULL AND A.dms_id5 IS NOT NULL;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_EMP_UPDT','END',NOW());
	
	#2没进过系统的人员数据导入
	#emp_base_info
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_EMP_INS','START',NOW());
	REPLACE INTO ctgehr.emp_base_info (dms_id5,CUST_ID,emp_id,emp_name,gender,emp_state,cert_no,MOBILE,dept_id,is_delete,cert_type,create_time)
		SELECT B.dept_id,2162554862743552,cast(replace(LOB_NUMBER,'\'','') as unsigned),LAST_NAME,IF(SEX='男',1,2),IF(PEOPLE_TYPE='正式员工',1,2),upper(LEFT(REPLACE(NATIONAL_IDENTIFIER,'\'',''),30)),LEFT(phone,11),IF(org_coa='TPG',100000,org_coa),0,1,now()
		FROM emp_data_source.employee	 A 
			LEFT JOIN ctgehr.dept_info B ON A.ONWERSHIP_PLACE = B.dept_name AND B.dept_type=5 AND B.cust_id=2162554862743552
		WHERE cast(replace(LOB_NUMBER,'\'','') as unsigned) NOT IN (SELECT EMP_ID FROM ctgehr.emp_base_info) 
			AND A.LOB_NUMBER IS NOT NULL AND A.LOB_NUMBER <>'';
	#emp_post
	REPLACE INTO ctgehr.emp_post (dms_id5,position_level_id,dept_name,dept_id,cust_id,emp_id,emp_code,entry_date,regu_date,work_add,wh_time,work_email,fst_job_time,leave_date)
		SELECT c.dept_id,243212140113920,b.org_name,IF(a.org_coa='TPG',100000,a.org_coa),2162554862743552,cast(replace(a.LOB_NUMBER,'\'','') as unsigned),replace(a.LOB_NUMBER,'\'',''),a.HIRE_DATE,DATE(a.PROBATION_END_DATE),a.INTERNAL_LOCATION,a.SERVICE_YEAR,LEFT(a.EMAIL,50),a.START_WORK_DATE,a.ACTUAL_TERMINATION_DATE
		FROM emp_data_source.employee a 
			left join emp_data_source.cs_department_coa_t b on a.org_coa=b.ORG_COA 
			LEFT JOIN ctgehr.dept_info c ON a.ONWERSHIP_PLACE = c.dept_name AND c.dept_type=5 AND c.cust_id=2162554862743552
		WHERE cast(replace(a.LOB_NUMBER,'\'','') as unsigned) NOT IN (SELECT EMP_ID FROM ctgehr.emp_post)
			AND a.LOB_NUMBER IS NOT NULL AND a.LOB_NUMBER <>'';
	#创建1 5 维度时间轴
	INSERT INTO ctgehr.log_emp_dept_change (emp_id,dept_id,cust_id,dept_type,entry_date,leave_date,oprtr_id,oprtr_name)
		SELECT A.emp_id,A.dept_id,A.cust_id,1,A.entry_date,A.leave_date,0,'SYS'
		FROM ctgehr.emp_post A 
		WHERE A.EMP_ID NOT IN (SELECT DISTINCT EMP_ID FROM ctgehr.log_emp_dept_change WHERE dept_type=1) AND A.entry_date IS NOT NULL AND A.dept_id IS NOT NULL;
	INSERT INTO ctgehr.log_emp_dept_change (emp_id,dept_id,cust_id,dept_type,entry_date,leave_date,oprtr_id,oprtr_name)
		SELECT A.emp_id,A.dms_id5,A.cust_id,5,A.entry_date,A.leave_date,0,'SYS'
		FROM ctgehr.emp_post A 
		WHERE A.EMP_ID NOT IN (SELECT DISTINCT EMP_ID FROM ctgehr.log_emp_dept_change WHERE dept_type=5) AND A.entry_date IS NOT NULL AND A.dms_id5 IS NOT NULL;
	
	TRUNCATE TABLE ctgehr.icss_employee_number ;
	INSERT INTO ctgehr.icss_employee_number (emp_id,emp_code,employee_number)
		SELECT a.emp_id,a.emp_code,b.EMPLOYEE_NUMBER
		FROM ctgehr.emp_post a 
			left join emp_data_source.employee b on a.emp_id = cast(replace(b.LOB_NUMBER,'''','') as unsigned)
			left join ctgehr.emp_base_info c on a.emp_id=c.emp_id 
		where b.LOB_NUMBER is not null and b.LOB_NUMBER<>'' and b.LOB_NUMBER not like '''E%' and c.emp_state in (1,3);
	
	#同步备选岗位表中的部门对应信息
#	UPDATE ctgehr.emp_rel_alternative_dept a ,ctgehr.emp_base_info b
#	set a.DEPT_ID=b.dept_id
#	where a.emp_id=b.emp_id;
	
	UPDATE ctgehr.emp_post A,ctgehr.dept_info B
	SET A.other_02 = B.dept_name
	WHERE A.dms_id5=B.dept_id;
	
	UPDATE ctgehr.emp_post A,emp_data_source.employee B
	SET A.emp_type = 
		CASE 
		WHEN B.EMPLOYEE_CATEGORY='正式员工' THEN 1
		WHEN B.EMPLOYEE_CATEGORY='兼职/劳务' THEN 2
		WHEN B.EMPLOYEE_CATEGORY='退休返聘' THEN 3
		WHEN B.EMPLOYEE_CATEGORY='实习生' THEN 4
		WHEN B.EMPLOYEE_CATEGORY='试用员工' THEN 5
		WHEN B.EMPLOYEE_CATEGORY='Part time' THEN 6
		ELSE NULL
		END
	WHERE A.emp_code = REPLACE(B.LOB_NUMBER,'''','');
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_EMP_INS','END',NOW());
	
	#打卡数据
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_CHECK','START',NOW());
	TRUNCATE TABLE ctgehr.att_emp_log_tmp;
	REPLACE into ctgehr.att_emp_log_tmp (emp_id,check_time,dkj_device_id,loc_set_name,CHECK_TYPE,data_source) 
		select c.emp_id,a.CHECK_TIME,a.SN,concat(IFNULL(b.REGION,''),' ',IFNULL(b.ADDRESS,'')),1,4
		from emp_data_source.cs_fingerprint_record_tmp a
			left join emp_data_source.cs_attendance_machine_t b on a.SN=b.SN
			join ctgehr.emp_post c on a.LOB_NUMBER=c.emp_code
		WHERE a.CREATE_TIME BETWEEN BGDT AND EDDT;
	
	REPLACE into ctgehr.att_emp_log_tmp (emp_id,check_time,dkj_device_id,loc_set_name,CHECK_TYPE,data_source) 
		select b.emp_id,a.BEGIN_TIME,null,concat(IFNULL(a.ONWERSHIP_PLACE,''),''),1,
			CASE a.RECORD_RESOURCE WHEN 'APP' THEN 1 WHEN '小程序' THEN 2 WHEN '导入' THEN 3 WHEN 'CS' THEN 4 WHEN 'OWS' THEN 5 WHEN 'HWDD' THEN 6 WHEN 'CY' THEN 7 WHEN 'ES' THEN 8 WHEN 'LSMS' THEN 9 WHEN 'OMP' THEN 101 WHEN 'WEIXIN' THEN 10 WHEN 'face' THEN 11 WHEN 'DD' THEN 12 ELSE 0 END
		from emp_data_source.cs_attendance_record_t_tmp a,
			ctgehr.emp_post b 
		WHERE a.LOB_NUMBER=b.emp_code and a.CREATE_TIME BETWEEN BGDT AND EDDT;
			
	REPLACE into ctgehr.att_emp_log_tmp (emp_id,check_time,dkj_device_id,loc_set_name,CHECK_TYPE,data_source) 
		select b.emp_id,a.END_TIME,null,concat(IFNULL(a.ONWERSHIP_PLACE,''),''),1,
			CASE a.RECORD_RESOURCE WHEN 'APP' THEN 1 WHEN '小程序' THEN 2 WHEN '导入' THEN 3 WHEN 'CS' THEN 4 WHEN 'OWS' THEN 5 WHEN 'HWDD' THEN 6 WHEN 'CY' THEN 7 WHEN 'ES' THEN 8 WHEN 'LSMS' THEN 9 WHEN 'OMP' THEN 101 WHEN 'WEIXIN' THEN 10 WHEN 'face' THEN 11 WHEN 'DD' THEN 12 ELSE 0 END
		from emp_data_source.cs_attendance_record_t_tmp a,
			ctgehr.emp_post b 
		WHERE a.LOB_NUMBER=b.emp_code and a.CREATE_TIME BETWEEN BGDT AND EDDT;
		
	TRUNCATE TABLE ctgehr.att_emp_log_tmp_with_id;
	INSERT INTO ctgehr.att_emp_log_tmp_with_id (emp_id,check_time,dkj_device_id,loc_set_name,CHECK_TYPE,data_source)
		SELECT emp_id,check_time,dkj_device_id,loc_set_name,CHECK_TYPE,data_source FROM ctgehr.att_emp_log_tmp;
	
	SELECT IFNULL(MAX(A.att_log_id),1) INTO IDSEED FROM att_emp_log A WHERE A.att_log_id <= 10000000000;
	
	REPLACE INTO ctgehr.att_emp_log (att_log_id,emp_id,check_time,dkj_device_id,loc_set_name,CHECK_TYPE,data_source)
		SELECT id+IDSEED,emp_id,check_time,dkj_device_id,loc_set_name,CHECK_TYPE,data_source FROM ctgehr.att_emp_log_tmp_with_id;
	
	update att_emp_log a ,emp_base_info b set a.dept_id=b.dept_id,a.cust_id=b.cust_id where a.emp_id=b.emp_id;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_CHECK','END',NOW());

	#钉钉对应员工号
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_DINGDING','START',NOW());
	REPLACE INTO ctgehr.icss_dict_dingding_empcode
		SELECT * FROM emp_data_source.cs_dingding_lob_number_relation_t;	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_DINGDING','END',NOW());
		
		
	#加班数据
	SET YESTERDAY = DATE_ADD(TODAY,INTERVAL -1 DAY);
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_JIABAN','START',NOW());
	REPLACE INTO ctgehr.icss_work_overtime_result_ti (`ID`,`EMP_ID`,`EMP_CODE`,`OVERTIME_WORKLOAD`,`NEED_DEDUCT_WORKLOAD`,`DIFFERENCE_REASON`,`RIDE_COEFFICIENT_WORK_HOUR`,`COUNT_IDENTIFICATION`,`YEAR_MONTH`,`CTG_YM`)
		SELECT A.ID,B.emp_id,A.LOB_NUMBER,A.OVERTIME_WORKLOAD,A.NEED_DEDUCT_WORKLOAD,A.DIFFERENCE_REASON,A.RIDE_COEFFICIENT_WORK_HOUR,A.COUNT_IDENTIFICATION,REPLACE(A.`YEAR_MONTH`,'-',''),REPLACE(LEFT(YESTERDAY,7),'-','')
		FROM emp_data_source.cs_work_overtime_result_ti A , ctgehr.emp_post B 
		WHERE A.LOB_NUMBER = B.emp_code AND A.COUNT_IDENTIFICATION=0;
		
	UPDATE emp_data_source.cs_work_overtime_result_ti A , ctgehr.emp_post B 
	SET A.COUNT_IDENTIFICATION=1
	WHERE A.LOB_NUMBER = B.emp_code AND A.COUNT_IDENTIFICATION=0;
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_JIABAN','END',NOW());
	
	#维度时间轴去重
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('LOG_EMP_DEPT_CHANGE_REBUILD','END',NOW());
	DROP TABLE IF EXISTS log_emp_dept_change_bak_distinct;
	CREATE TABLE log_emp_dept_change_bak_distinct AS
		SELECT distinct emp_id,dept_id,cust_id,dept_type,entry_date,leave_date,oprtr_id,oprtr_name 
		FROM log_emp_dept_change;
		
	TRUNCATE TABLE log_emp_dept_change;
	INSERT INTO log_emp_dept_change (emp_id,dept_id,cust_id,dept_type,entry_date,leave_date,oprtr_id,oprtr_name )
		SELECT * FROM log_emp_dept_change_bak_distinct;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('LOG_EMP_DEPT_CHANGE_REBUILD','END',NOW());
	
	#全部考勤地点
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_ALL_LOCATION','START',NOW());
	
	TRUNCATE TABLE tmp_all_location_emplist;
	REPLACE INTO tmp_all_location_emplist
		SELECT b.emp_id,c.entry_date,c.leave_date
		FROM dept_info a
			left join emp_base_info b on a.dept_id=b.dept_id
			left join emp_post c on b.emp_id=c.emp_id
		WHERE b.is_delete=0 and b.emp_state is not null and c.entry_date is not null 
			AND b.emp_id not in (select distinct emp_id from att_emp_location_relation)
			and a.is_enable=1 and a.cust_id=2162554862743552
			and a.dept_full_name not like '中软国际/TPG/互联网+业务群%'
			and a.dept_full_name not like '中软国际/TPG/华为业务群%'
			and a.dept_full_name not like '中软国际/TPG/其他业务群（虚拟）/电信业务线%'
			and a.dept_full_name not like '中软国际/TPG/其他业务群（虚拟）/其他业务线（虚拟）/Z计划战略事业部%'
			and a.dept_full_name not like '中软国际/TPG/其他业务群（虚拟）/日本业务线%'
			and a.dept_full_name not like '中软国际/TPG/MNC业务群/HSBC业务线%'
			and a.dept_full_name not like '中软国际/TPG/其他业务群（虚拟）/平安业务线/业务规划与发展部%'
			and a.dept_full_name not like '中软国际/TPG/其他业务群（虚拟）/平安业务线/科技生态事业部%'
			and a.dept_full_name not like '中软国际/TPG/其他业务群（虚拟）/平安业务线/HRBP部%'
			and a.dept_full_name not like '中软国际/TPG/其他业务群（虚拟）/平安业务线/质量管理与运作部%'
			and a.dept_full_name not like '中软国际/TPG/其他业务群（虚拟）/平安业务线/保险资管事业部%';
	
	INSERT INTO att_emp_location_relation (emp_id,start_time,end_time,creator_id,creator_name,create_time)
		SELECT A.emp_id,A.entry_date,A.leave_date,0,'SYS',NOW() 
		FROM tmp_all_location_emplist A;
	
	INSERT INTO att_emp_rel_location (aelr_id,loc_set_id)
		SELECT B.id,0
		FROM tmp_all_location_emplist A ,att_emp_location_relation B 
		WHERE A.emp_id=B.emp_id AND A.entry_date=B.start_time AND A.leave_date=B.end_time;
			
	TRUNCATE TABLE tmp_all_location_emplist;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_ALL_LOCATION','END',NOW());


	#默认班次
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_DEFAULT_BANCI','START',NOW());
	INSERT INTO log_emp_dept_change (emp_id,dept_id,cust_id,dept_type,entry_date,leave_date,oprtr_id,oprtr_name)
		SELECT a.emp_id,c.banci_dept_id,a.cust_id,2,d.entry_date,d.leave_date,0,'SYS'
		FROM emp_base_info a 
			left join icss_default_banci c on a.dept_id=c.bumen_dept_id and a.dms_id5=c.diyu_dept_id
			left join emp_post d on a.emp_id=d.emp_id
		WHERE a.prgm_id is null and a.dms_id5 is not null and a.emp_state is not null and a.is_delete=0
			and c.diyu_dept_id<>0 and c.banci_dept_id <> 0;
	
	update emp_base_info a,emp_post c,icss_default_banci b
	set a.prgm_id=b.banci_dept_id,c.prgm_id=b.banci_dept_id
	where a.dept_id=b.bumen_dept_id and a.dms_id5=b.diyu_dept_id 
		and a.dms_id5 is not null and a.prgm_id is null and a.is_delete=0 and a.emp_state is not null 
		and b.diyu_dept_id<>0 and b.banci_dept_id<>0
		and a.emp_id=c.emp_id;
	
	
	INSERT INTO log_emp_dept_change (emp_id,dept_id,cust_id,dept_type,entry_date,leave_date,oprtr_id,oprtr_name)
		SELECT a.emp_id,c.banci_dept_id,a.cust_id,2,d.entry_date,d.leave_date,0,'SYS'
		FROM emp_base_info a 
			left join icss_default_banci c on a.dept_id=c.bumen_dept_id 
			left join emp_post d on a.emp_id=d.emp_id
		WHERE a.prgm_id is null and a.emp_state is not null and a.is_delete=0
			and c.diyu_dept_id=0 and c.banci_dept_id <> 0;
	
	update emp_base_info a,emp_post c,icss_default_banci b
	set a.prgm_id=b.banci_dept_id,c.prgm_id=b.banci_dept_id
	where a.dept_id=b.bumen_dept_id 
		and a.prgm_id is null and a.is_delete=0 and a.emp_state is not null 
		and b.diyu_dept_id=0 and b.banci_dept_id<>0 and a.emp_id=c.emp_id;
	
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('DATA_TRANS_DEFAULT_BANCI','END',NOW());
	
#######      试点时使用       ###################################################################################	
	TRUNCATE TABLE statistic_shidian_dept_list;
	insert into statistic_shidian_dept_list (dept_id,dept_full_name,is_root)
		select a.dept_id,a.dept_full_name,1
		from dept_info a
		where a.dept_full_name in ('中软国际/总公司/HQ/流程与IT管理部','中软国际/总公司/HQ/人事与行政服务管理部','中软国际/CIG','中软国际/IIG','中软国际/TPG/其他业务群（虚拟）/监管与审计业务线','中软国际/TPG/其他业务群（虚拟）/交通业务线','中软国际/TPG/其他业务群（虚拟）/其他业务线（虚拟）/民生事业部','中软国际/TPG/其他业务群（虚拟）/其他业务线（虚拟）/社保事业部','中软国际/TPG/其他业务群（虚拟）/数据服务业务线','中软国际/TPG/其他业务群（虚拟）/制造与流通业务线','中软国际/业务价值咨询与发展系统部')
			and a.is_enable=1;
		
	insert into statistic_shidian_dept_list (dept_id,dept_full_name)
		select a.dept_id,a.dept_full_name
		from dept_info a
		where a.parent_dept_id in 
			(
				select dept_id
				from dept_info 
				where dept_full_name in ('中软国际/总公司/HQ/流程与IT管理部','中软国际/总公司/HQ/人事与行政服务管理部','中软国际/CIG','中软国际/IIG','中软国际/TPG/其他业务群（虚拟）/监管与审计业务线','中软国际/TPG/其他业务群（虚拟）/交通业务线','中软国际/TPG/其他业务群（虚拟）/其他业务线（虚拟）/民生事业部','中软国际/TPG/其他业务群（虚拟）/其他业务线（虚拟）/社保事业部','中软国际/TPG/其他业务群（虚拟）/数据服务业务线','中软国际/TPG/其他业务群（虚拟）/制造与流通业务线','中软国际/业务价值咨询与发展系统部') and is_enable=1
			) and a.is_enable=1;
		
	CALL SP_ST_SHIDIAN(DATE_ADD(DATE(NOW()),INTERVAL -1 DAY));
##################################################################################################################	


END;

