create procedure SP_ATT_DAILY_ARRANGE_RECHECK(IN bgdt   date, IN eddt date, IN custid bigint unsigned,
                                              IN deptid bigint unsigned, IN emp bigint unsigned, IN depttype int)
  comment '排班补签'
  BEGIN

DECLARE CHK_i_arr_id,SCT,MX_SCT,ct,mxct,apid,i_custid,i_deptid,i_emp,lm,em,i_arr_id,i_att_id bigint;
DECLARE MY_FREE_HOUR_LATE,MY_FREE_HOUR_EARLY,CHK_dttype,MY_DAYOFF,i_late_mins,i_early_mins,i_zh_ratio,i_zh_hour,dttype,i_att_rule,stat,chk_type,is_exist,is_off,i_flex_hour INT;
DECLARE workday,i_deptn,i_empn,i_version_code VARCHAR(200);
DECLARE comp_att_check_in,comp_att_check_out,i_att_check_in,i_att_check_out,i_arr_start_time,i_arr_end_time,chk_time,ci,co,cosd datetime;
DECLARE i_arrange_bg_time_1,i_arrange_bg_time_2,i_arrange_bg_time_3,i_arrange_end_time_1,i_arrange_end_time_2,i_arrange_end_time_3,i_morn_start_time,i_morn_end_time,i_aftn_start_time,i_aftn_end_time TIME;
DECLARE MY_ARR_WORK_MINS,MY_WORK_MINS,MY_LATE_MINS,MY_EARLY_MINS,wki,nl_hour,ne_hour DECIMAL(12,2);
DECLARE i_is_need_bg_check_1,i_is_need_bg_check_2,i_is_need_bg_check_3,i_is_need_ed_check_1,i_is_need_ed_check_2,i_is_need_ed_check_3,i_is_exp_hol,i_arrange_bg_day_1,i_arrange_bg_check_flex_1,i_arrange_end_day_1,i_arrange_end_check_flex_1,i_arrange_bg_day_2,i_arrange_bg_check_flex_2,i_arrange_end_day_2,i_arrange_end_check_flex_2,i_arrange_bg_day_3,i_arrange_bg_check_flex_3,i_arrange_end_day_3,i_arrange_end_check_flex_3 int;
DECLARE i_dt,CK_BGDT,CK_EDDT,CHK_i_dt date;						
DECLARE CHK_i_att_check_in,CHK_i_att_check_out,CHK_comp_att_check_in,CHK_comp_att_check_out,CHK_i_arr_start_time,CHK_i_arr_end_time DATETIME;
DECLARE ARR_CHECK_1,ARR_CHECK_2,ARR_CHECK_3,CHECK_ANCHOR,MY_CHECK_BG_3,MY_CHECK_ED_3,MY_CHECK_BG_2,MY_CHECK_ED_2,MY_CHECK_BG_1,MY_CHECK_ED_1 INT;


	set i_version_code = UUID();
	set sql_mode='';
	
	if (custid is null and deptid is null and depttype is null and emp is null) then
		set stat=4;
	elseif (custid is not null and deptid is null and depttype is null  and emp is null) then
		set stat=3;
	elseif (deptid is not null and depttype between 1 and 10 and emp is null) then
		set stat=2;
	elseif (emp is not null) then
		set stat=1;
	end if;

	
	
	while (bgdt<=eddt) do 										
		
		SET ct = 0;
		SET mxct = 0;
		

		case stat
		when 1 then			
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_exam_step a 
					LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
				where a.exam_source=3 and a.is_over=1 and a.state=1 and b.emp_id=emp 
					and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
					and b.att_rule=3 and b.state=1 and b.data_source=1;
			
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_check_apply a
					left join flow_control d on a.cust_id=d.cust_id
				where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.emp_id=emp 
					and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_check_apply a
				where a.att_rule in (3) and a.data_source=2 and a.emp_id=emp 
					and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
		when 2 then
			case depttype 
			when 1 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.dept_id=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.dept_id=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.dept_id=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 2 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.prgm_id=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.prgm_id=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.prgm_id=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 3 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.jrdc_id=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.jrdc_id=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.jrdc_id=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 4 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.dms_id4=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.dms_id4=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.dms_id4=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 5 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.dms_id5=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.dms_id5=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.dms_id5=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 6 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.dms_id6=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.dms_id6=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.dms_id6=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 7 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.dms_id7=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.dms_id7=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.dms_id7=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 8 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.dms_id8=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.dms_id8=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.dms_id8=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 9 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.dms_id9=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.dms_id9=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.dms_id9=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			when 10 then
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_exam_step a 
						LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
					where a.exam_source=3 and a.is_over=1 and a.state=1 and b.dms_id10=deptid 
						and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
						and b.att_rule=3 and b.state=1 and b.data_source=1;
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
						left join flow_control d on a.cust_id=d.cust_id
					where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.dms_id10=deptid 
						and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				
				insert into tmp_arr_recheck_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_check_apply a
					where a.att_rule in (3) and a.data_source=2 and a.dms_id10=deptid 
						and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			end case;
		when 3 then
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_exam_step a 
					LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
				where a.exam_source=3 and a.is_over=1 and a.state=1 and b.cust_id=custid 
					and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
					and b.att_rule=3 and b.state=1 and b.data_source=1;
			
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_check_apply a
					left join flow_control d on a.cust_id=d.cust_id
				where a.data_source=1 and d.is_open=0 and d.flow_type=3 and a.cust_id=custid 
					and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_check_apply a
				where a.att_rule in (3) and a.data_source=2 and a.cust_id=custid 
					and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
		when 4 then
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_exam_step a 
					LEFT JOIN att_check_apply b on a.apply_id=b.apply_id
				where a.exam_source=3 and a.is_over=1 and a.state=1 
					and a.approval_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59')
					and b.att_rule=3 and b.state=1 and b.data_source=1;
			
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_check_apply a
					left join flow_control d on a.cust_id=d.cust_id
				where a.data_source=1 and d.is_open=0 and d.flow_type=3 
					and a.att_rule in (3) and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			
			insert into tmp_arr_recheck_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_check_apply a
				where a.att_rule in (3) and a.data_source=2 
					and a.check_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
		end case;													

		select min(id),max(id) into ct,mxct from tmp_arr_recheck_list where version_code = i_version_code;
		#循环申请
		while ct<=mxct and ct>0 do
		
			SET i_arr_id = NULL ;
			SET i_att_id = NULL ;
			SET i_arr_start_time = NULL ;
			SET i_arr_end_time = NULL ;
			SET i_att_check_in = NULL ;
			SET i_att_check_out = NULL ;
			SET i_dt = NULL ;
			SET i_late_mins = NULL ;
			SET i_early_mins = NULL ;
			SET i_arrange_bg_day_1 = NULL ;
			SET i_arrange_bg_time_1 = NULL ;
			SET i_arrange_bg_check_flex_1 = NULL ;
			SET i_arrange_end_day_1 = NULL ;
			SET i_arrange_end_time_1 = NULL ;
			SET i_arrange_end_check_flex_1 = NULL ;
			SET i_arrange_bg_day_2 = NULL ;
			SET i_arrange_bg_time_2 = NULL ;
			SET i_arrange_bg_check_flex_2 = NULL ;
			SET i_arrange_end_day_2 = NULL ;
			SET i_arrange_end_time_2 = NULL ;
			SET i_arrange_end_check_flex_2 = NULL ;
			SET i_arrange_bg_day_3 = NULL ;
			SET i_arrange_bg_time_3 = NULL ;
			SET i_arrange_bg_check_flex_3 = NULL ;
			SET i_arrange_end_day_3 = NULL ;
			SET i_arrange_end_time_3 = NULL ;
			SET i_arrange_end_check_flex_3 = NULL ;
			SET i_is_exp_hol = NULL ;
			SET MY_WORK_MINS = NULL ;
			SET MY_LATE_MINS = NULL ;
			SET MY_EARLY_MINS = NULL ;
			SET MY_DAYOFF = NULL ;
			SET MY_FREE_HOUR_LATE = NULL, MY_FREE_HOUR_EARLY = NULL;
			SELECT A.APPLY_ID INTO apid
			FROM tmp_arr_recheck_list A
			WHERE A.ID=ct AND A.VERSION_CODE = i_version_code;

			#有申请时才计算
			IF apid IS NOT NULL THEN
				
				SELECT A.check_time,A.emp_id,A.cust_id,A.dept_id 
					INTO chk_time,i_emp,i_deptid,i_custid
				FROM att_check_apply A 
				WHERE A.apply_id=apid;
				
				#找出符合打卡的dt
				SELECT MIN(DT),MAX(DT) INTO CK_BGDT,CK_EDDT
				FROM att_arrange_schedual 
				WHERE EMP_ID = i_emp AND ( DATE(arr_start_time) = DATE(chk_time) OR DATE(arr_end_time) = DATE(chk_time)  );
				
				#循环符合打卡时间的排班日期
				WHILE CK_BGDT <= CK_EDDT AND CK_BGDT IS NOT NULL DO
					
					INSERT INTO tmp_arr_recheck_list_single_day (version_code,arr_id)
						SELECT i_version_code,arr_id
						FROM att_arrange_schedual 
						WHERE EMP_ID = i_emp AND dt = CK_BGDT;
					
					SET SCT = 0;
					SET MX_SCT = 0;

					SELECT MIN(ID),MAX(ID) 
						INTO SCT,MX_SCT
					FROM tmp_arr_recheck_list_single_day A
					WHERE A.version_code = i_version_code;
					
					#0代表没有打卡 1代表已有打卡  2代表没有这个时段
					SET ARR_CHECK_1 = 2,ARR_CHECK_2 = 2,ARR_CHECK_3 = 2;
					SET CHECK_ANCHOR = 0;
					#循环单天内的所有时段
					WHILE (SCT <= MX_SCT AND SCT > 0) DO
						SET i_arr_id = NULL;
						SELECT arr_id INTO i_arr_id FROM tmp_arr_recheck_list_single_day WHERE version_code = i_version_code AND ID=SCT;
	
						IF i_arr_id IS NOT NULL THEN
							SELECT att_id,arr_start_time,arr_end_time,
									FN_SYS_DTTMFMT_PURGE_SECOND(att_check_in),FN_SYS_DTTMFMT_PURGE_SECOND(att_check_out),dt,late_mins,early_mins
								INTO i_att_id,i_arr_start_time,i_arr_end_time,
									i_att_check_in,i_att_check_out,i_dt,i_late_mins,i_early_mins
							FROM att_arrange_schedual 
							WHERE arr_id = i_arr_id;
							
			
							set dttype=FN_ATT_GET_DTTYPE(i_dt,NULL);
						
							
							SELECT 
									arrange_bg_day_1,arrange_bg_time_1,arrange_bg_check_flex_1,arrange_end_day_1,arrange_end_time_1,arrange_end_check_flex_1,
									
									arrange_bg_day_2,arrange_bg_time_2,arrange_bg_check_flex_2,arrange_end_day_2,arrange_end_time_2,arrange_end_check_flex_2,
									
									arrange_bg_day_3,arrange_bg_time_3,arrange_bg_check_flex_3,arrange_end_day_3,arrange_end_time_3,arrange_end_check_flex_3,
									
									is_need_bg_check_1,is_need_bg_check_2,is_need_bg_check_3,is_need_ed_check_1,is_need_ed_check_2,is_need_ed_check_3,
									
									b.free_hour_late,b.free_hour_early
								INTO 
									i_arrange_bg_day_1,i_arrange_bg_time_1,i_arrange_bg_check_flex_1,i_arrange_end_day_1,i_arrange_end_time_1,i_arrange_end_check_flex_1,
									i_arrange_bg_day_2,i_arrange_bg_time_2,i_arrange_bg_check_flex_2,i_arrange_end_day_2,i_arrange_end_time_2,i_arrange_end_check_flex_2,
									i_arrange_bg_day_3,i_arrange_bg_time_3,i_arrange_bg_check_flex_3,i_arrange_end_day_3,i_arrange_end_time_3,i_arrange_end_check_flex_3,
									i_is_need_bg_check_1,i_is_need_bg_check_2,i_is_need_bg_check_3,i_is_need_ed_check_1,i_is_need_ed_check_2,i_is_need_ed_check_3,
									MY_FREE_HOUR_LATE,MY_FREE_HOUR_EARLY
							FROM att_set_schema_new b 
							WHERE b.att_id = i_att_id ;
							
							IF MY_FREE_HOUR_LATE IS NULL THEN SET MY_FREE_HOUR_LATE=0; END IF;
							IF MY_FREE_HOUR_EARLY IS NULL THEN SET MY_FREE_HOUR_EARLY=0; END IF;

							
							#第一个时间段
							IF TIME(i_arr_start_time) = i_arrange_bg_time_1 THEN
								IF i_att_check_in IS NULL OR i_att_check_out IS NULL THEN
									SET ARR_CHECK_1 = 0;
								ELSE
									SET ARR_CHECK_1 = 1;
								END IF;
								
								IF i_att_check_in IS NOT NULL THEN
									SET MY_CHECK_BG_1 = 1 ;
								ELSE
									SET MY_CHECK_BG_1 = 0 ;
								END IF;
								
								IF i_att_check_out IS NOT NULL THEN
									SET MY_CHECK_ED_1 = 1 ;
								ELSE
									SET MY_CHECK_ED_1 = 0 ;
								END IF;
								
								
								#补签时间在有校打卡时段内
								IF chk_time >= DATE_ADD(i_arr_start_time ,INTERVAL -i_arrange_bg_check_flex_1 MINUTE) AND chk_time <= DATE_ADD(i_arr_end_time ,INTERVAL i_arrange_end_check_flex_1 MINUTE) THEN
									SET comp_att_check_in = i_att_check_in;
									SET comp_att_check_out = i_att_check_out;
									
									SET CHECK_ANCHOR = 1;
									SET ARR_CHECK_1 = 1;
									
									IF i_is_need_bg_check_1 = 1 THEN
										
										IF (i_att_check_in IS NULL OR (i_att_check_in IS NOT NULL AND i_att_check_in > chk_time )) THEN
											
											SET i_att_check_in = chk_time; 
											SET MY_CHECK_BG_1 = 1;
											
											IF i_att_check_in < i_arr_start_time THEN
												SET comp_att_check_in = i_arr_start_time;
											ELSE
												SET comp_att_check_in = i_att_check_in;
											END IF;
										END IF;	
									ELSE
										
										SET i_att_check_in = i_arr_start_time; 
										
										SET comp_att_check_in = i_arr_start_time; 
									END IF;
									
									
									IF i_is_need_ed_check_1 = 1 THEN
										IF (i_att_check_out IS NULL OR (i_att_check_out IS NOT NULL AND i_att_check_out < chk_time )) THEN
											SET i_att_check_out = chk_time; 
											SET MY_CHECK_ED_1 = 1;
											
											IF i_att_check_out > i_arr_end_time THEN
												SET comp_att_check_out = i_arr_end_time;
											ELSE
												SET comp_att_check_out = i_att_check_out;
											END IF;
										END IF;
									ELSE
										
										SET i_att_check_out = i_arr_end_time; 
										
										SET comp_att_check_out = i_arr_end_time; 
									END IF;

									SET CHK_i_att_check_in = i_att_check_in;
									SET CHK_i_att_check_out = i_att_check_out;
									SET CHK_comp_att_check_in = comp_att_check_in;
									SET CHK_comp_att_check_out = comp_att_check_out;
									SET CHK_i_arr_start_time = i_arr_start_time;
									SET CHK_i_arr_end_time = i_arr_end_time;
									SET CHK_i_arr_id = i_arr_id;
									SET CHK_i_dt = i_dt;
									SET CHK_dttype = dttype;

								END IF;
							ELSEIF TIME(i_arr_start_time) = i_arrange_bg_time_2 THEN
								IF i_att_check_in IS NULL OR i_att_check_out IS NULL THEN
									SET ARR_CHECK_2 = 0;
								ELSE
									SET ARR_CHECK_2 = 1;
								END IF;
								
								
								IF i_att_check_in IS NOT NULL THEN
									SET MY_CHECK_BG_2 = 1 ;
								ELSE
									SET MY_CHECK_BG_2 = 0 ;
								END IF;
								
								IF i_att_check_out IS NOT NULL THEN
									SET MY_CHECK_ED_2 = 1 ;
								ELSE
									SET MY_CHECK_ED_2 = 0 ;
								END IF;
								
								IF chk_time >= DATE_ADD(i_arr_start_time ,INTERVAL -i_arrange_bg_check_flex_2 MINUTE) AND chk_time <= DATE_ADD(i_arr_end_time ,INTERVAL i_arrange_end_check_flex_2 MINUTE) THEN
									SET comp_att_check_in = i_att_check_in;
									SET comp_att_check_out = i_att_check_out;
									SET CHECK_ANCHOR = 2;
									SET ARR_CHECK_2 = 1;

									
									IF i_is_need_bg_check_2 = 1 THEN
										
										IF (i_att_check_in IS NULL OR (i_att_check_in IS NOT NULL AND i_att_check_in > chk_time )) THEN
											
											SET i_att_check_in = chk_time; 
											SET MY_CHECK_BG_2 = 1;
											
											IF i_att_check_in < i_arr_start_time THEN
												SET comp_att_check_in = i_arr_start_time;
											ELSE
												SET comp_att_check_in = i_att_check_in;
											END IF;
										END IF;	
									ELSE
										
										SET i_att_check_in = i_arr_start_time; 
										
										SET comp_att_check_in = i_arr_start_time; 
									END IF;
									
									
									IF i_is_need_ed_check_2 = 1 THEN
										IF (i_att_check_out IS NULL OR (i_att_check_out IS NOT NULL AND i_att_check_out < chk_time )) THEN
											SET i_att_check_out = chk_time; 
											SET MY_CHECK_ED_2 = 1;
											
											IF i_att_check_out > i_arr_end_time THEN
												SET comp_att_check_out = i_arr_end_time;
											ELSE
												SET comp_att_check_out = i_att_check_out;
											END IF;
										END IF;
									ELSE
										
										SET i_att_check_out = i_arr_end_time; 
										
										SET comp_att_check_out = i_arr_end_time; 
									END IF;

									SET CHK_i_att_check_in = i_att_check_in;
									SET CHK_i_att_check_out = i_att_check_out;
									SET CHK_comp_att_check_in = comp_att_check_in;
									SET CHK_comp_att_check_out = comp_att_check_out;
									SET CHK_i_arr_start_time = i_arr_start_time;
									SET CHK_i_arr_end_time = i_arr_end_time;
									SET CHK_i_arr_id = i_arr_id;
									SET CHK_i_dt = i_dt;
									SET CHK_dttype = dttype;
								END IF;
							
							ELSEIF TIME(i_arr_start_time) = i_arrange_bg_time_3 THEN
								IF i_att_check_in IS NULL OR i_att_check_out IS NULL THEN
									SET ARR_CHECK_3 = 0;
								ELSE
									SET ARR_CHECK_3 = 1;
								END IF;
																	
								
								IF i_att_check_in IS NOT NULL THEN
									SET MY_CHECK_BG_3 = 1 ;
								ELSE
									SET MY_CHECK_BG_3 = 0 ;
								END IF;
								
								IF i_att_check_out IS NOT NULL THEN
									SET MY_CHECK_ED_3 = 1 ;
								ELSE
									SET MY_CHECK_ED_3 = 0 ;
								END IF;
								
								IF chk_time >= DATE_ADD(i_arr_start_time ,INTERVAL -i_arrange_bg_check_flex_3 MINUTE) AND chk_time <= DATE_ADD(i_arr_end_time ,INTERVAL i_arrange_end_check_flex_3 MINUTE) THEN
									SET comp_att_check_in = i_att_check_in;
									SET comp_att_check_out = i_att_check_out;
									SET CHECK_ANCHOR = 3;
									SET ARR_CHECK_3 = 1;
									
									IF i_is_need_bg_check_3 = 1 THEN
										
										IF (i_att_check_in IS NULL OR (i_att_check_in IS NOT NULL AND i_att_check_in > chk_time )) THEN
											
											SET i_att_check_in = chk_time; 
											SET MY_CHECK_BG_3 = 1;
											
											IF i_att_check_in < i_arr_start_time THEN
												SET comp_att_check_in = i_arr_start_time;
											ELSE
												SET comp_att_check_in = i_att_check_in;
											END IF;
										END IF;	
									ELSE
										
										SET i_att_check_in = i_arr_start_time; 
										
										SET comp_att_check_in = i_arr_start_time; 
									END IF;
									
									
									IF i_is_need_ed_check_3 = 1 THEN
										IF (i_att_check_out IS NULL OR (i_att_check_out IS NOT NULL AND i_att_check_out < chk_time )) THEN
											SET i_att_check_out = chk_time; 
											SET MY_CHECK_ED_3 = 1;
											
											IF i_att_check_out > i_arr_end_time THEN
												SET comp_att_check_out = i_arr_end_time;
											ELSE
												SET comp_att_check_out = i_att_check_out;
											END IF;
										END IF;
									ELSE
										
										SET i_att_check_out = i_arr_end_time; 
										
										SET comp_att_check_out = i_arr_end_time; 
									END IF;

									SET CHK_i_att_check_in = i_att_check_in;
									SET CHK_i_att_check_out = i_att_check_out;
									SET CHK_comp_att_check_in = comp_att_check_in;
									SET CHK_comp_att_check_out = comp_att_check_out;
									SET CHK_i_arr_start_time = i_arr_start_time;
									SET CHK_i_arr_end_time = i_arr_end_time;
									SET CHK_i_arr_id = i_arr_id;
									SET CHK_i_dt = i_dt;
									SET CHK_dttype = dttype;
								END IF;
							END IF;
							DELETE FROM tmp_arr_recheck_list_single_day WHERE ID=SCT AND VERSION_CODE = i_version_code;
						END IF;
						SET SCT = SCT + 1;
					END WHILE;
					
					#判断打卡有效性
					IF CHECK_ANCHOR = 1 THEN
						#当前时段有打卡,且（后面时段有打卡 或 没有后面时段），时段有效，否则无效
						IF (((ARR_CHECK_3=1 OR ARR_CHECK_2=1) OR (ARR_CHECK_2=2 AND ARR_CHECK_3=2)) AND CHK_i_att_check_in IS NOT NULL AND CHK_i_att_check_out IS NOT NULL) OR (CHK_i_att_check_in<CHK_i_att_check_out AND CHK_i_att_check_in IS NOT NULL AND CHK_i_att_check_out IS NOT NULL) THEN
							SET CHK_i_att_check_in = CHK_i_att_check_in, CHK_i_att_check_out = CHK_i_att_check_out;
							SET CHK_comp_att_check_in = CHK_comp_att_check_in, CHK_comp_att_check_out = CHK_comp_att_check_out;
						ELSE
							IF MY_CHECK_BG_1 = 0 THEN
								SET CHK_i_att_check_in = NULL;
							END IF;
							IF MY_CHECK_ED_1 = 0 THEN
								SET CHK_i_att_check_out = NULL;
							END IF;
							SET CHK_comp_att_check_in = CHK_i_arr_end_time, CHK_comp_att_check_out = CHK_i_arr_end_time;
						END IF;
					ELSEIF CHECK_ANCHOR = 2 THEN
						##只有当前时间段有打卡，且前有或后有或前后都有打卡时才生效，否则不生效
						IF ((ARR_CHECK_1=1 OR ARR_CHECK_3=1) AND CHK_i_att_check_in IS NOT NULL AND CHK_i_att_check_out IS NOT NULL) OR (CHK_i_att_check_in<CHK_i_att_check_out AND  CHK_i_att_check_in IS NOT NULL AND CHK_i_att_check_out IS NOT NULL) OR ((CHK_i_att_check_in IS NULL OR CHK_i_att_check_out IS NULL) AND (ARR_CHECK_1=1 AND ARR_CHECK_3=1))  THEN
							SET CHK_i_att_check_in = CHK_i_att_check_in, CHK_i_att_check_out = CHK_i_att_check_out;
							SET CHK_comp_att_check_in = CHK_comp_att_check_in, CHK_comp_att_check_out = CHK_comp_att_check_out;
						ELSE
							IF MY_CHECK_BG_2 = 0 THEN
								SET CHK_i_att_check_in = NULL;
							END IF;
							IF MY_CHECK_ED_2 = 0 THEN
								SET CHK_i_att_check_out = NULL;
							END IF;
							SET CHK_comp_att_check_in = CHK_i_arr_end_time, CHK_comp_att_check_out = CHK_i_arr_end_time;
						END IF;
					ELSEIF CHECK_ANCHOR = 3 THEN
						##只有当前时间段有打卡，且前有打卡时才生效，否则不生效
						IF ((ARR_CHECK_1 = 1 OR ARR_CHECK_2 = 1) AND CHK_i_att_check_in IS NOT NULL AND CHK_i_att_check_out IS NOT NULL) OR (CHK_i_att_check_in<CHK_i_att_check_out AND CHK_i_att_check_in IS NOT NULL AND CHK_i_att_check_out IS NOT NULL) THEN
							SET CHK_i_att_check_in = CHK_i_att_check_in, CHK_i_att_check_out = CHK_i_att_check_out;
							SET CHK_comp_att_check_in = CHK_comp_att_check_in, CHK_comp_att_check_out = CHK_comp_att_check_out;
						ELSE
							IF MY_CHECK_BG_3 = 0 THEN
								SET CHK_i_att_check_in = NULL;
							END IF;
							IF MY_CHECK_ED_3 = 0 THEN
								SET CHK_i_att_check_out = NULL;
							END IF;
							SET CHK_comp_att_check_in = CHK_i_arr_end_time, CHK_comp_att_check_out = CHK_i_arr_end_time;
						END IF;
					END IF;


					IF CHECK_ANCHOR <> 0 THEN
						SET MY_ARR_WORK_MINS = 0;
						SET MY_ARR_WORK_MINS = TIME_TO_SEC(TIMEDIFF(CHK_i_arr_end_time,CHK_i_arr_start_time))/60;
						IF MY_ARR_WORK_MINS IS NULL THEN SET MY_ARR_WORK_MINS = 0 ; END IF;
						
						IF CHK_comp_att_check_in > DATE_ADD(CHK_i_arr_start_time,INTERVAL MY_FREE_HOUR_LATE MINUTE) THEN
							SET MY_LATE_MINS = TIME_TO_SEC(TIMEDIFF(CHK_comp_att_check_in,CHK_i_arr_start_time))/60;
						ELSE
							SET MY_LATE_MINS = 0;
						END IF;
						
						IF MY_LATE_MINS < 0 THEN SET MY_LATE_MINS = 0; END IF;
						IF MY_LATE_MINS > MY_ARR_WORK_MINS THEN SET MY_LATE_MINS = MY_ARR_WORK_MINS; END IF;
						
						IF CHK_comp_att_check_out < DATE_ADD(CHK_i_arr_end_time,INTERVAL -MY_FREE_HOUR_EARLY MINUTE) THEN
							SET MY_EARLY_MINS = TIME_TO_SEC(TIMEDIFF(CHK_i_arr_end_time,CHK_comp_att_check_out))/60;
						ELSE
							SET MY_EARLY_MINS = 0;
						END IF;
						IF MY_EARLY_MINS < 0 THEN SET MY_EARLY_MINS = 0; END IF;
						IF MY_EARLY_MINS > MY_ARR_WORK_MINS THEN SET MY_EARLY_MINS = MY_ARR_WORK_MINS; END IF;
						
						SET MY_WORK_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(CHK_i_arr_end_time,CHK_i_arr_start_time))/60 - MY_LATE_MINS - MY_EARLY_MINS,2);
						IF MY_WORK_MINS < 0 THEN SET MY_WORK_MINS = 0; END IF;
						IF MY_WORK_MINS > MY_ARR_WORK_MINS THEN SET MY_WORK_MINS = MY_ARR_WORK_MINS; END IF;
							
						UPDATE att_arrange_schedual 
						SET att_check_in = CHK_i_att_check_in, att_check_out=CHK_i_att_check_out,
							`weekday`=weekday(CHK_i_dt) + 1,	date_type = CHK_dttype, work_interval=MY_WORK_MINS,
							late_mins = MY_LATE_MINS,early_mins = MY_EARLY_MINS,is_computed=1
						WHERE arr_id = CHK_i_arr_id;
						CALL SP_ATT_DAILY_CHECK(CHK_i_dt,CHK_i_dt,NULL,NULL,i_emp,NULL);
					END IF;
					delete from  tmp_arr_recheck_list WHERE VERSION_CODE = i_version_code AND ID = ct;
					SET CK_BGDT = DATE_ADD(CK_BGDT,INTERVAL 1 DAY);
				END WHILE;
			END IF;
			set ct = ct +1;
		end while;
		SET bgdt = date_add(bgdt,interval 1 day);
	END WHILE; 
	
END;

