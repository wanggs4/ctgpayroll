create procedure SP_ICSS_ST_HOL_POOL_LEFT(IN MY_BGDT date, IN MY_EMP bigint unsigned)
  comment '员工剩余年假&补休明细（按年度拆分）'
  BEGIN
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE CT,MXCT,MY_EMP_ID,MY_DEPT_ID BIGINT UNSIGNED;
DECLARE MY_DEPT_FULL_NAME,MY_EMP_CODE,MY_EMP_NAME VARCHAR(500);
DECLARE MY_ENTRY_DATE,MY_LEAVE_DATE,MY_EDDT DATE;
DECLARE MY_Y_THIS_USE,MY_Y_THIS_LEFT,MY_Y_LAST_LEFT,MY_Y_LAST_2_LEFT,MY_Y_ALL_LEFT DECIMAL(12,2);
DECLARE MY_R_THIS_USE,MY_R_THIS_LEFT,MY_R_LAST_LEFT,MY_R_LAST_2_LEFT,MY_R_ALL_LEFT DECIMAL(12,2);
DECLARE MY_THIS_YEAR INT;

/*
入参说明：
MY_BGDT 入组人员在职时间范围和计算的时间范围的开始日期，NULL时取前天这一年的一月一日
MY_EMP 人员id，只为重跑某个人时使用，平时给NULL既跑所有
所有时间范围结束日期均为前天
*/
	SET I_VERSION_CODE = UUID();
	SET MY_EDDT = DATE(DATE_ADD(NOW(),INTERVAL -2 DAY));
#	SET MY_EDDT = '2020-12-31';
	SET MY_THIS_YEAR = YEAR(MY_EDDT);
	
	#入参MY_BGDT 校验
	#1.如果为空，设为前天的同年一月一日
	IF MY_BGDT IS NULL THEN
		SET MY_BGDT = CONCAT(YEAR(MY_EDDT),'-01-01');
	ELSE
		#2.如果不为空，但是年分和前天的年份不一致，改为前天同年的一月一日
		IF YEAR(MY_BGDT) <> MY_THIS_YEAR THEN
			SET MY_BGDT = CONCAT(YEAR(MY_EDDT),'-01-01');
		END IF;
	END IF;
	
	IF MY_EMP IS NULL THEN
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT);			
	ELSE
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT)
				AND A.emp_id=MY_EMP;			
	END IF;
	
	SET CT = 0, MXCT = 0;
	
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_icss_st_emp_list A WHERE A.version_code = I_VERSION_CODE;
	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_EMP_ID=NULL,MY_DEPT_ID=NULL,MY_DEPT_FULL_NAME=NULL,MY_EMP_CODE=NULL,MY_EMP_NAME=NULL,MY_ENTRY_DATE=NULL,MY_LEAVE_DATE=NULL;
		SET MY_Y_THIS_USE=0,MY_Y_THIS_LEFT=0,MY_Y_LAST_LEFT=0,MY_Y_LAST_2_LEFT=0,MY_Y_ALL_LEFT=0;
		SET MY_R_THIS_USE=0,MY_R_THIS_LEFT=0,MY_R_LAST_LEFT=0,MY_R_LAST_2_LEFT=0,MY_R_ALL_LEFT=0;

		SELECT A.emp_id,A.emp_code,A.emp_name,A.entry_date,A.leave_date,A.dept_id,A.dept_full_name
			INTO MY_EMP_ID,MY_EMP_CODE,MY_EMP_NAME,MY_ENTRY_DATE,MY_LEAVE_DATE,MY_DEPT_ID,MY_DEPT_FULL_NAME
		FROM tmp_icss_st_emp_list A 
		WHERE A.version_code = I_VERSION_CODE AND A.id=CT; 

		IF MY_EMP_ID IS NOT NULL THEN
			SELECT IFNULL(A.this_year_left,0) * 8 INTO MY_Y_LAST_2_LEFT
			FROM att_hol_year A WHERE A.emp_id=MY_EMP_ID AND A.this_year=MY_THIS_YEAR-2 AND A.is_delete=0 LIMIT 1;
			SELECT IFNULL(A.this_year_left,0) * 8 INTO MY_Y_LAST_LEFT
			FROM att_hol_year A WHERE A.emp_id=MY_EMP_ID AND A.this_year=MY_THIS_YEAR-1 AND A.is_delete=0 LIMIT 1;
			SELECT IFNULL(A.this_year_left,0) * 8 INTO MY_Y_THIS_LEFT
			FROM att_hol_year A WHERE A.emp_id=MY_EMP_ID AND A.this_year=MY_THIS_YEAR AND A.is_delete=0 LIMIT 1;
			SELECT IFNULL(MY_Y_THIS_LEFT,0) - (IFNULL(A.this_year_use,0)*8) INTO MY_Y_THIS_LEFT
			FROM att_hol_credit_year A WHERE A.emp_id=MY_EMP_ID AND A.this_year=MY_THIS_YEAR AND A.is_delete=0 LIMIT 1;
			SET MY_Y_ALL_LEFT = IFNULL(MY_Y_LAST_2_LEFT,0) + IFNULL(MY_Y_LAST_LEFT,0) + IFNULL(MY_Y_THIS_LEFT,0);
			
			SELECT IFNULL(A.this_year_left,0) INTO MY_R_LAST_2_LEFT
			FROM att_hol_rest A WHERE A.emp_id=MY_EMP_ID AND A.this_year=MY_THIS_YEAR-2 AND A.is_delete=0 LIMIT 1;
			SELECT IFNULL(A.this_year_left,0) INTO MY_R_LAST_LEFT
			FROM att_hol_rest A WHERE A.emp_id=MY_EMP_ID AND A.this_year=MY_THIS_YEAR-1 AND A.is_delete=0 LIMIT 1;
			SELECT IFNULL(A.this_year_left,0) INTO MY_R_THIS_LEFT
			FROM att_hol_rest A WHERE A.emp_id=MY_EMP_ID AND A.this_year=MY_THIS_YEAR AND A.is_delete=0 LIMIT 1;
			SET MY_R_ALL_LEFT = IFNULL(MY_R_LAST_2_LEFT,0) + IFNULL(MY_R_LAST_LEFT,0) + IFNULL(MY_R_THIS_LEFT,0);
			
			SELECT IFNULL(SUM(IFNULL(A.hol_hours,0)),0) INTO MY_Y_THIS_USE
			FROM att_hol_apply_day A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_date BETWEEN CONCAT(MY_THIS_YEAR,'-01-01') AND MY_EDDT AND A.is_year_hol IN (1,11);
			 
			SELECT IFNULL(SUM(IFNULL(A.hol_hours,0)),0) INTO MY_R_THIS_USE
			FROM att_hol_apply_day A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_date BETWEEN CONCAT(MY_THIS_YEAR,'-01-01') AND MY_EDDT AND A.is_year_hol IN (2) AND A.date_type=2;
			
			REPLACE INTO icss_st_hol_pool_left 
				(emp_id,this_year,this_year_use,last_2_year_left,last_year_left,this_year_left,all_year_left,
					this_rest_use,last_2_rest_left,last_rest_left,this_rest_left,all_rest_left,
					emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			VALUES
				(MY_EMP_ID,MY_THIS_YEAR,MY_Y_THIS_USE,MY_Y_LAST_2_LEFT,MY_Y_LAST_LEFT,MY_Y_THIS_LEFT,MY_Y_ALL_LEFT,
					MY_R_THIS_USE,MY_R_LAST_2_LEFT,MY_R_LAST_LEFT, MY_R_THIS_LEFT,MY_R_ALL_LEFT,
					MY_EMP_CODE,MY_EMP_NAME,MY_ENTRY_DATE,MY_LEAVE_DATE,MY_DEPT_ID,MY_DEPT_FULL_NAME);
		END IF;
		SET CT = CT + 1;
	END WHILE;
END;

