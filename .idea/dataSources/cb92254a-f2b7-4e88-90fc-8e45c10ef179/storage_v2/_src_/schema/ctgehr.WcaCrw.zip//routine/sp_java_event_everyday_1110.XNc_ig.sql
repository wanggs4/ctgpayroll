create procedure SP_JAVA_EVENT_EVERYDAY_1110()
  comment '向中间表同步系统中的打卡信息'
  BEGIN
DECLARE BGDT,EDDT DATETIME;
DECLARE TODAY DATE;
SET TODAY = DATE(NOW());
SET BGDT = CONCAT(DATE_ADD(TODAY,INTERVAL -1 DAY),' 23:10:00');
SET EDDT = CONCAT(TODAY,' 11:09:59');

	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('推送打卡数据1110','START',NOW());
	REPLACE INTO emp_data_source.ctg_att_emp_log (att_log_id,dept_id,dept_full_name,emp_name,lob_number,check_time,loc_set_name)
		SELECT A.att_log_id,B.DEPT_ID,B.DEPT_FULL_NAME,C.emp_name,D.emp_code,A.check_time,A.loc_set_name
		FROM att_emp_log A
			LEFT JOIN icss_check_replication_dept_list B ON A.dept_id=B.DEPT_ID
			LEFT JOIN emp_base_info C ON A.emp_id=C.emp_id
			LEFT JOIN emp_post D ON A.emp_id=D.emp_id
		WHERE A.dept_id = B.DEPT_ID AND A.data_source IN (1,13) AND A.create_time BETWEEN BGDT AND EDDT;
	REPLACE INTO test_event (`procedure`,`status`,`datenow`) VALUES ('推送打卡数据1110','END',NOW());

END;

