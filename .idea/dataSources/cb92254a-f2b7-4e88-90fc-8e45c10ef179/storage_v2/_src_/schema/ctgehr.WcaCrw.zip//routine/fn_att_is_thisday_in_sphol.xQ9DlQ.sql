create function FN_ATT_IS_THISDAY_IN_SPHOL(CHECK_DATE date, TIMEPOINT int, MY_EMPID bigint unsigned,
                                           MY_DEPTID  bigint unsigned, UPDT_SPDAYID bigint unsigned)
  returns int
  comment '用于判断给定的时间点是否被其他特殊假期占用：不同的参数赋予方式代表了不同的两种用途：1只给MY_EMPID不给UPDT_SPDAYID：代表在业务中判断某个人的特殊假期是否占用；2只给UPDT_SPDAYID不给MY_EMPID：代表在设置中修改已经存在的一个特殊假期所用'
  BEGIN
/*	参数说明
	CHECK_DATE 需要检查的日期
	TIMEPOINT	需要检查日期当天所占的时间段 1上午 2下午 3全天
	MY_EMPID	部门id
*/
DECLARE THIS_IS_IN_SPHOL,IS_IN_SPHOL,IS_HAVE_ATT,MY_SP_BGPT,MY_SP_EDPT INT;
DECLARE MST,MET,AST,AET TIME;
DECLARE MY_SP_BGDT,MY_SP_EDDT DATE;
DECLARE MY_SP_BGTM,MY_SP_EDTM,MY_CHECK_BGTM,MY_CHECK_EDTM DATETIME;
DECLARE ATTID,THIS_SPDAYID BIGINT UNSIGNED;
DECLARE ATTID_STR,SPDAYID_STR TEXT;
	#只给emp_id不给UPDT_SPDAYID，说明用于计算考勤的情况
	IF CHECK_DATE IS NOT NULL AND TIMEPOINT IS NOT NULL AND MY_EMPID IS NOT NULL AND MY_DEPTID IS NULL THEN
		CALL SP_DPT_GET_SETTINGID(MY_EMPID,CHECK_DATE,1,ATTID_STR);
		SET ATTID = CAST(ATTID_STR AS UNSIGNED);

		
		IF ATTID IS NOT NULL THEN
			#读出考勤设置
			SELECT b.morn_start_time,b.morn_end_time,b.aftn_start_time,b.aftn_end_time
				INTO MST,MET,AST,AET
			FROM att_set_schema_new b
			WHERE b.att_id=ATTID AND b.att_rule=1;

			#再看看当天是否有特殊节假日，如果有，设置特殊节假日起止时间点
			SET MY_SP_BGDT=NULL,MY_SP_BGPT=NULL,MY_SP_EDDT=NULL,MY_SP_EDPT=NULL;
			CALL SP_DPT_GET_SETTINGID(MY_EMPID,CHECK_DATE,4,SPDAYID_STR);
			SET SPDAYID_STR = CONCAT(SPDAYID_STR,',');
			
			IF SPDAYID_STR IS NOT NULL THEN
				SET IS_IN_SPHOL = 0;
				WHILE LOCATE(',',SPDAYID_STR) <= LENGTH(SPDAYID_STR) AND LOCATE(',',SPDAYID_STR) > 1 DO
					SET THIS_SPDAYID=NULL,MY_SP_BGDT=NULL,MY_SP_BGPT=NULL,MY_SP_EDDT=NULL,MY_SP_EDPT=NULL,THIS_IS_IN_SPHOL=0;
					
					SET THIS_SPDAYID = CAST(REPLACE(LEFT(SPDAYID_STR,LOCATE(',',SPDAYID_STR)),',','') AS UNSIGNED);
					IF THIS_SPDAYID IS NOT NULL THEN
						SELECT MIN(B.begin_date),MIN(B.begin_point),MAX(B.end_date),MAX(B.end_point)
							INTO MY_SP_BGDT,MY_SP_BGPT,MY_SP_EDDT,MY_SP_EDPT
						FROM att_set_special_day B
						WHERE B.sp_day_id = THIS_SPDAYID;
						#看检查点给的时间
						#如果是全天，说明占用
						IF TIMEPOINT = 3 THEN
							SET THIS_IS_IN_SPHOL = 1;
						#检查点如果是上午，需要对比当天上午是否占用了已经有的特殊节假日
						ELSEIF TIMEPOINT = 1 THEN
							#特殊节假日单天，
							IF MY_SP_BGDT = MY_SP_EDDT THEN
								#且只设置了下午，说明没占用
								IF MY_SP_BGPT = 2 AND MY_SP_EDPT = 2 THEN
									SET THIS_IS_IN_SPHOL = 0;
								#否则占用
								ELSE
									SET THIS_IS_IN_SPHOL = 1;
								END IF;
							#特殊节假日多天
							ELSEIF MY_SP_BGDT < MY_SP_EDDT THEN
								#检查日期等于第一天
								IF CHECK_DATE = MY_SP_BGDT THEN
									IF MY_SP_BGPT = 1 THEN
										SET THIS_IS_IN_SPHOL = 1;
									ELSE
										SET THIS_IS_IN_SPHOL = 0;
									END IF;
								#检查日期等于最后一天 OR 在中间
								ELSE
									SET THIS_IS_IN_SPHOL = 1;
								END IF;
							END IF;
						#检查点如果是下午午，需要对比当天下午是否占用了已经有的特殊节假日
						ELSEIF TIMEPOINT = 2 THEN
							#特殊节假日单天，
							IF MY_SP_BGDT = MY_SP_EDDT THEN
								#且只设置了上午，说明没占用
								IF MY_SP_BGPT = 1 AND MY_SP_EDPT = 1 THEN
									SET THIS_IS_IN_SPHOL = 0;
								#否则占用
								ELSE
									SET THIS_IS_IN_SPHOL = 1;
								END IF;
							
							#特殊节假日多天
							ELSEIF MY_SP_BGDT < MY_SP_EDDT THEN
								#检查日期等于最后一天
								IF CHECK_DATE = MY_SP_EDDT THEN
									IF MY_SP_EDPT = 1 THEN
										SET THIS_IS_IN_SPHOL = 0;
									ELSE
										SET THIS_IS_IN_SPHOL = 1;
									END IF;
								#检查日期等于第一天 OR 在中间
								ELSE
									SET THIS_IS_IN_SPHOL = 1;
								END IF;
							END IF;
						END IF;
					END IF;
					SET IS_IN_SPHOL = IS_IN_SPHOL + THIS_IS_IN_SPHOL;
					SET SPDAYID_STR = RIGHT(SPDAYID_STR,LENGTH(SPDAYID_STR)-LOCATE(',',SPDAYID_STR));
				END WHILE;
			#当天搜索不到任何特殊节假日，说明不覆盖
			ELSE
				SET IS_IN_SPHOL = 0;
			END IF;
		END IF;
	#只给UPDT_SPDAYID不给emp_id，说明用于修改设置时校验的情况
	ELSEIF CHECK_DATE IS NOT NULL AND TIMEPOINT IS NOT NULL AND MY_DEPTID IS NOT NULL THEN
		#得到与UPDT_SPDAYID挂钩的所有维度的值，并且找出与这些维度挂钩的除了UPDT_SPDAYID以外的当天有关系的id串
		IF UPDT_SPDAYID IS NOT NULL THEN
			SELECT CONCAT(GROUP_CONCAT(C.sp_day_id),',')
				INTO SPDAYID_STR
			FROM att_rel_special_dept A
				LEFT JOIN att_rel_special_dept B ON A.dept_id=B.dept_id
				LEFT JOIN att_set_special_day C ON B.sp_day_id=C.sp_day_id
			WHERE A.sp_day_id = UPDT_SPDAYID AND B.sp_day_id<>UPDT_SPDAYID 
				AND C.is_enable=1 AND C.is_delete=0 AND C.begin_date<=CHECK_DATE AND C.end_date>=CHECK_DATE;
		ELSE
			SELECT CONCAT(GROUP_CONCAT(C.sp_day_id),',')
				INTO SPDAYID_STR
			FROM att_rel_special_dept A
				LEFT JOIN att_rel_special_dept B ON A.dept_id=B.dept_id
				LEFT JOIN att_set_special_day C ON B.sp_day_id=C.sp_day_id
			WHERE A.sp_day_id = UPDT_SPDAYID
				AND C.is_enable=1 AND C.is_delete=0 AND C.begin_date<=CHECK_DATE AND C.end_date>=CHECK_DATE;
		END IF;
		
		IF SPDAYID_STR IS NOT NULL THEN
			SET IS_IN_SPHOL = 0;
			WHILE LOCATE(',',SPDAYID_STR) <= LENGTH(SPDAYID_STR) AND LOCATE(',',SPDAYID_STR) > 1 DO
				SET THIS_SPDAYID=NULL,MY_SP_BGDT=NULL,MY_SP_BGPT=NULL,MY_SP_EDDT=NULL,MY_SP_EDPT=NULL,THIS_IS_IN_SPHOL=0;
				
				SET THIS_SPDAYID = CAST(REPLACE(LEFT(SPDAYID_STR,LOCATE(',',SPDAYID_STR)),',','') AS UNSIGNED);
				IF THIS_SPDAYID IS NOT NULL THEN
					SELECT MIN(B.begin_date),MIN(B.begin_point),MAX(B.end_date),MAX(B.end_point)
						INTO MY_SP_BGDT,MY_SP_BGPT,MY_SP_EDDT,MY_SP_EDPT
					FROM att_set_special_day B
					WHERE B.sp_day_id = THIS_SPDAYID;
					#看检查点给的时间
					#如果是全天，说明占用
					IF TIMEPOINT = 3 THEN
						SET THIS_IS_IN_SPHOL = 1;
					#检查点如果是上午，需要对比当天上午是否占用了已经有的特殊节假日
					ELSEIF TIMEPOINT = 1 THEN
						#特殊节假日单天，
						IF MY_SP_BGDT = MY_SP_EDDT THEN
							#且只设置了下午，说明没占用
							IF MY_SP_BGPT = 2 AND MY_SP_EDPT = 2 THEN
								SET THIS_IS_IN_SPHOL = 0;
							#否则占用
							ELSE
								SET THIS_IS_IN_SPHOL = 1;
							END IF;
						#特殊节假日多天
						ELSEIF MY_SP_BGDT < MY_SP_EDDT THEN
							#检查日期等于第一天
							IF CHECK_DATE = MY_SP_BGDT THEN
								IF MY_SP_BGPT = 1 THEN
									SET THIS_IS_IN_SPHOL = 1;
								ELSE
									SET THIS_IS_IN_SPHOL = 0;
								END IF;
							#检查日期等于最后一天 OR 在中间
							ELSE
								SET THIS_IS_IN_SPHOL = 1;
							END IF;
						END IF;
					#检查点如果是下午午，需要对比当天下午是否占用了已经有的特殊节假日
					ELSEIF TIMEPOINT = 2 THEN
						#特殊节假日单天，
						IF MY_SP_BGDT = MY_SP_EDDT THEN
							#且只设置了上午，说明没占用
							IF MY_SP_BGPT = 1 AND MY_SP_EDPT = 1 THEN
								SET THIS_IS_IN_SPHOL = 0;
							#否则占用
							ELSE
								SET THIS_IS_IN_SPHOL = 1;
							END IF;
						
						#特殊节假日多天
						ELSEIF MY_SP_BGDT < MY_SP_EDDT THEN
							#检查日期等于最后一天
							IF CHECK_DATE = MY_SP_EDDT THEN
								IF MY_SP_EDPT = 1 THEN
									SET THIS_IS_IN_SPHOL = 0;
								ELSE
									SET THIS_IS_IN_SPHOL = 1;
								END IF;
							#检查日期等于第一天 OR 在中间
							ELSE
								SET THIS_IS_IN_SPHOL = 1;
							END IF;
						END IF;
					END IF;
				END IF;
				SET IS_IN_SPHOL = IS_IN_SPHOL + THIS_IS_IN_SPHOL;
				SET SPDAYID_STR = RIGHT(SPDAYID_STR,LENGTH(SPDAYID_STR)-LOCATE(',',SPDAYID_STR));
			END WHILE;
		#当天搜索不到任何特殊节假日，说明不覆盖
		ELSE
			SET IS_IN_SPHOL = 0;
		END IF;
	END IF;
	IF IS_IN_SPHOL IS NULL THEN SET IS_IN_SPHOL = 1; END IF;
RETURN IS_IN_SPHOL;
END;

