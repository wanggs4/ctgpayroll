create function FN_ATT_GET_WORKDAYS_GENERAL(bgdt date, eddt date, optype int)
  returns decimal(12, 2)
  comment '得到时间区间内该部门的应工作天数'
  BEGIN
/*
optype	1 	应工作天数
			2	法定节假日天数
*/
DECLARE a_pay_way,dttype,a_is_exp_hol,i_att_rule int;
DECLARE monthly_work_days DECIMAL(12,2);
DECLARE i_bgdt DATE;

	SET i_bgdt = bgdt;
	IF (bgdt<=eddt) THEN		#如果有部门且初试时间小于等于结束时间时才开始计算
		SET monthly_work_days= 0;

		WHILE (bgdt<=eddt) DO
			SET dttype=NULL;
			SET dttype = FN_ATT_GET_DTTYPE_GENERAL(bgdt);	#得到日期类型
			IF optype = 1 THEN
				if dttype in (1,6) then			#只有工作日算工作日				#if6
					set monthly_work_days= monthly_work_days + 1;
				end if;
			ELSEIF optype = 2 THEN
				if dttype = 3 then			#只有法定节假日算				#if6
					set monthly_work_days= monthly_work_days + 1;
				end if;
			END IF;
			SET bgdt = DATE_ADD(bgdt,INTERVAL 1 DAY);
		END WHILE;
	END IF;
	
	IF monthly_work_days IS NULL OR monthly_work_days < 0 THEN
		SET  monthly_work_days = 21.75;
	END IF;
	
	RETURN monthly_work_days;
END;

