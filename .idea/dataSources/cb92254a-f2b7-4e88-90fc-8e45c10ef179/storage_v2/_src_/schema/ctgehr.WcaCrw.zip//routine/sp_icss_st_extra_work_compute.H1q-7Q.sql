create procedure SP_ICSS_ST_EXTRA_WORK_COMPUTE(IN THIS_MON int, IN THRESHOLD decimal(12, 2), IN OPTYPE varchar(50),
                                               IN MY_EMP   bigint unsigned)
  comment '针对三个月内超时离场的动态标记'
  BEGIN
/*
入参说明：
THIS_MON 统计月份如：202101
THRESHOLD 阈值 超过这个值会被入选
OPTYPE 针对不同的报表进行操作，目前包含 ：EXTRA_WORK_DETAIL、EXTRA_SUBSIDIES_DETAIL
MY_EMP 针对具体某个员工进行操作，为NULL时，给所有员工操作
*/
	IF MY_EMP IS NULL THEN
		IF OPTYPE IS NOT NULL AND OPTYPE = 'EXTRA_WORK_DETAIL' THEN
			UPDATE icss_st_3months_extra_work_detail A
			SET A.is_last_2_month_extra_work=1
			WHERE A.year_mon=THIS_MON AND A.this_extra_work_mins >= THRESHOLD AND A.last_extra_work_mins >= THRESHOLD;
			
			UPDATE icss_st_3months_extra_work_detail A
			SET A.is_last_3_month_extra_work=1
			WHERE A.year_mon=THIS_MON AND A.this_extra_work_mins >= THRESHOLD AND A.last_extra_work_mins >= THRESHOLD and A.last_2_extra_work_mins >= THRESHOLD;
		
		ELSEIF OPTYPE IS NOT NULL AND OPTYPE = 'EXTRA_SUBSIDIES_DETAIL' THEN
			UPDATE icss_st_3months_extra_subsidies_detail A
			SET A.is_last_2_month_extra_subsidies=1
			WHERE A.year_mon=THIS_MON AND A.this_extra_subsidies >= THRESHOLD AND A.last_extra_subsidies >= THRESHOLD;
			
			UPDATE icss_st_3months_extra_subsidies_detail A
			SET A.is_last_3_month_extra_subsidies=1
			WHERE A.year_mon=THIS_MON AND A.this_extra_subsidies >= THRESHOLD AND A.last_extra_subsidies >= THRESHOLD and A.last_2_extra_work_mins >= THRESHOLD;
		END IF;
	ELSE
		IF OPTYPE IS NOT NULL AND OPTYPE = 'EXTRA_WORK_DETAIL' THEN
			UPDATE icss_st_3months_extra_work_detail A
			SET A.is_last_2_month_extra_work=1
			WHERE A.year_mon=THIS_MON AND A.this_extra_work_mins >= THRESHOLD AND A.last_extra_work_mins >= THRESHOLD AND A.emp_id=MY_EMP;
			
			UPDATE icss_st_3months_extra_work_detail A
			SET A.is_last_3_month_extra_work=1
			WHERE A.year_mon=THIS_MON AND A.this_extra_work_mins >= THRESHOLD AND A.last_extra_work_mins >= THRESHOLD and A.last_2_extra_work_mins >= THRESHOLD AND A.emp_id=MY_EMP;
		
		ELSEIF OPTYPE IS NOT NULL AND OPTYPE = 'EXTRA_SUBSIDIES_DETAIL' THEN
			UPDATE icss_st_3months_extra_subsidies_detail A
			SET A.is_last_2_month_extra_subsidies=1
			WHERE A.year_mon=THIS_MON AND A.this_extra_subsidies >= THRESHOLD AND A.last_extra_subsidies >= THRESHOLD AND A.emp_id=MY_EMP;
			
			UPDATE icss_st_3months_extra_subsidies_detail A
			SET A.is_last_3_month_extra_subsidies=1
			WHERE A.year_mon=THIS_MON AND A.this_extra_subsidies >= THRESHOLD AND A.last_extra_subsidies >= THRESHOLD and A.last_2_extra_work_mins >= THRESHOLD AND A.emp_id=MY_EMP;
		END IF;
	END IF;
END;

