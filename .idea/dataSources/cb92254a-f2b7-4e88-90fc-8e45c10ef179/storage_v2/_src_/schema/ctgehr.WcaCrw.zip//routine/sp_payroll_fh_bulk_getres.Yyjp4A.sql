create procedure SP_PAYROLL_FH_BULK_GETRES(IN custid bigint unsigned, IN ym int, IN setid bigint unsigned)
  comment '批量计算分红结果'
  BEGIN
	
	declare sumb_rescnt,ct,mxct,TOLCNT int;
	declare prid,i_custid,i_deptid,i_emp bigint;
	declare N_FH_TI,N_FH_T,N_FH_SF,N_TAX_STAND,N_BTA,N_BTS,N_ATA,N_ATS,N_TIA,N_TIS,N_TMA,N_TMS,N_AT2BTP,N_AT2BTNP DECIMAL(13,3);
	declare i_deptname,i_empname varchar(50);
	 DECLARE i_version_code VARCHAR(50);
 SET i_version_code = UUID();

	
	set sumb_rescnt=0;

	select count(*) into sumb_rescnt from payroll_fh_base where cust_id=custid and MONTH_STEP=ym AND SET_ID=setid and is_publish=0 ;
	
	
	if sumb_rescnt>0 then
		INSERT INTO tmp_payroll_fh_sum (version_code,payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,MONTH_STEP,TAX_STAND,FH_BTA,FH_BTS,FH_ATA,FH_ATS,FH_TIA,FH_TIS,FH_TMA,FH_TMS,FH_AT2BTP,FH_AT2BTNP) 
			select i_version_code,id,cust_id,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,month_step,avg(TAX_STAND),
				sum(BTA1+BTA2+BTA3+BTA4+BTA5) fh_BTA,
				sum(BTS1+BTS2+BTS3+BTS4+BTS5) fh_BTS,
				sum(ATA1+ATA2+ATA3+ATA4+ATA5) fh_ATA,
				sum(ATS1+ATS2+ATS3+ATS4+ATS5) fh_ATS,
				sum(TIA1+TIA2+TIA3+TIA4+TIA5) fh_TIA,
				sum(TIS1+TIS2+TIS3+TIS4+TIS5) fh_TIS,
				sum(TMA1+TMA2+TMA3+TMA4+TMA5) fh_TMA,
				sum(TMS1+TMS2+TMS3+TMS4+TMS5) fh_TMS,
				sum(AT2BTP1+AT2BTP2+AT2BTP3+AT2BTP4+AT2BTP5) fh_AT2BTP,
				sum(AT2BTNP1+AT2BTNP2+AT2BTNP3+AT2BTNP4+AT2BTNP5) fh_AT2BTNP
			from payroll_fh_base where is_publish=0 and cust_id=custid and MONTH_STEP=ym AND SET_ID=setid
			group by emp_id;
		
		select min(id),max(id) into ct,mxct from tmp_payroll_fh_sum  where version_code = i_version_code;
		while (ct<=mxct) do
			SET prid=NULL;
			SET i_custid=NULL;
			SET i_deptid=NULL;
			SET i_deptname=NULL;
			SET i_emp=NULL;
			SET i_empname=NULL;
			SET N_TAX_STAND=NULL;
			SET N_BTA=NULL;
			SET N_BTS=NULL;
			SET N_ATA=NULL;
			SET N_ATS=NULL;
			SET N_TIA=NULL;
			SET N_TIS=NULL;
			SET N_TMA=NULL;
			SET N_TMS=NULL;
			SET N_AT2BTP=NULL;
			SET N_AT2BTNP=NULL;
			
			SELECT payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,TAX_STAND,
					FH_BTA,FH_BTS,FH_ATA,FH_ATS,FH_TIA,FH_TIS,FH_TMA,FH_TMS,FH_AT2BTP,FH_AT2BTNP
				INTO prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,N_TAX_STAND,
					N_BTA,N_BTS,N_ATA,N_ATS,N_TIA,N_TIS,N_TMA,N_TMS,N_AT2BTP,N_AT2BTNP
			FROM tmp_payroll_fh_sum
			WHERE id = ct and version_code = i_version_code;
			
			IF prid IS NOT NULL THEN
					
				SET N_FH_TI= N_BTA - N_BTS + N_TIA - N_TIS ; 
				
				CALL SP_PAYROLL_FH_TAX(N_FH_TI,N_FH_T);
				
				SET N_FH_SF= N_BTA - N_BTS - N_FH_T + N_ATA - N_ATS;
				
				
				DELETE FROM payroll_fh WHERE ID = prid;
				INSERT INTO payroll_fh (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,set_id,MONTH_STEP,IS_PUBLISH,FH_TI,FH_T,FH_SF)
					VALUES (prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,setid,ym,0,N_FH_TI,N_FH_T,N_FH_SF);
				UPDATE payroll_fh_base SET IS_CALC = 1 WHERE ID = prid;			
	
				
				SET N_TAX_STAND = 0;
				SET N_BTA = 0;
				SET N_BTS = 0;
				SET N_ATA = 0;
				SET N_ATS = 0;
				SET N_TIA = 0;
				SET N_TIS = 0;
				SET N_TMA = 0;
				SET N_TMS = 0;
				SET N_AT2BTP = 0;
				SET N_AT2BTNP = 0;
	
				
				UPDATE payroll_tol 
				SET TAX_BEF_PLUSMIN_TOL=TAX_BEF_PLUSMIN_TOL+N_FH_TI,TAX_VALUE=TAX_VALUE+N_FH_T,SALARY_PAY=SALARY_PAY+N_FH_SF 
				WHERE ID=prid;
				
			END IF;
			set ct = ct + 1;
		end while;
		
		select count(*) into sumb_rescnt from tmp_payroll_fh_sum where version_code = i_version_code;
	else
	
		set sumb_rescnt=0;
	end if;
	delete from  tmp_payroll_fh_sum where version_code = i_version_code;

END;

