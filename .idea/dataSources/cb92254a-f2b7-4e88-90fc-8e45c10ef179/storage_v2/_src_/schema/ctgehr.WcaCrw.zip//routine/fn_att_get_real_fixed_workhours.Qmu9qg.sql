create function FN_ATT_GET_REAL_FIXED_WORKHOURS(ckin_time time, ckout_time time, ATTID bigint unsigned)
  returns decimal(12, 2)
  comment '针对坐班，根据给出的签到签退时间，计算实际的工作时长'
  BEGIN

DECLARE MY_WORK_HOURS,MY_SHOULD_WORK_HOURS,MY_LATE_MINS,MY_EARLY_MINS DECIMAL(12,2);
DECLARE IS_HAVE_ATT,MY_ATT_RULE INT;
	#初始化变量
	SET MY_WORK_HOURS = 0;
	
	SET ckin_time = FN_SYS_TMFMT_PURGE_SECOND(ckin_time);
	SET ckout_time = FN_SYS_TMFMT_PURGE_SECOND(ckout_time);
	#验证是否存在出勤规则
	SELECT COUNT(*) INTO IS_HAVE_ATT 
	FROM att_set_schema_new B
	WHERE B.att_id=ATTID;
	
	#有出勤方案才计算
	IF IS_HAVE_ATT > 0 THEN
		#签到或签退有空值时 或者 签退时间比签到时间早时，工作时长为0
		IF ckin_time IS NULL OR ckout_time IS NULL OR ckout_time <= ckin_time THEN
			SET MY_WORK_HOURS = 0;
		#签到签退都存在时
		ELSE
			SELECT B.att_rule INTO MY_ATT_RULE
			FROM att_set_schema_new B
			WHERE B.att_id=ATTID;
			
			IF MY_ATT_RULE = 1 THEN
				#首先得到一天的应工作时长，并折算成分钟
				SET MY_SHOULD_WORK_HOURS = FN_ATT_GET_WORKHOURS(ATTID)*60;
				#得到迟到早退分钟数
				CALL FN_ATT_GET_MINS_FIXED_NA(ckin_time,ckout_time,ATTID,MY_LATE_MINS,MY_EARLY_MINS);
				#计算实际工作时长
				SET MY_WORK_HOURS = MY_SHOULD_WORK_HOURS - MY_LATE_MINS - MY_EARLY_MINS;
			END IF;	
					
		END IF;
		
	END IF;
RETURN MY_WORK_HOURS;
END;

