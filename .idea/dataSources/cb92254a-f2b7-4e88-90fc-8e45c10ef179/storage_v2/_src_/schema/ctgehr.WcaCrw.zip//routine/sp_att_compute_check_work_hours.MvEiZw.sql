create procedure SP_ATT_COMPUTE_CHECK_WORK_HOURS(IN BGDT date, IN EDDT date, IN MY_EMPID bigint unsigned)
  comment '计算并更新一个时间段内的某个人的日报中打卡时长，归档和定稿的不跑'
  BEGIN
DECLARE MY_CUSTID BIGINT UNSIGNED;
DECLARE IS_ARCH,IS_DAILY_REPORT INT;
	SET MY_CUSTID = 2162554862743552;
	
	WHILE BGDT <= EDDT AND BGDT IS NOT NULL AND EDDT IS NOT NULL AND MY_EMPID IS NOT NULL DO
		SET IS_ARCH = 1, IS_DAILY_REPORT = 0;
		#判断是否有日报
		SELECT IFNULL(COUNT(*),0) INTO IS_DAILY_REPORT FROM att_emp_detail A where A.emp_id = MY_EMPID AND A.dt = BGDT AND A.date_type IN (1,6);
		#判断当天是否月报归档
		SELECT IFNULL(COUNT(*),0) INTO IS_ARCH
		FROM att_st_month A LEFT JOIN att_st_month_quick_view_icss B ON A.st_id=B.st_id
		WHERE A.cust_id=MY_CUSTID AND B.emp_id=MY_EMPID AND A.comp_start_time <= BGDT AND A.comp_end_time >= BGDT 
			AND (A.archive_state <> 0 OR B.personal_archive_state <> 0);
		#有日报，且月报未归档、未定稿的情况下，才去实施。（没有月报也更）
		IF IS_DAILY_REPORT > 0 AND IS_ARCH = 0 THEN
			UPDATE att_emp_detail A 
			SET A.check_work_interval = FN_ATT_GET_CHECK_WORK_HOURS(A.check_in,A.check_out,A.att_id,A.emp_id)
			WHERE A.emp_id=MY_EMPID AND A.dt=BGDT;
		END IF;
		SET BGDT = DATE_ADD(BGDT,INTERVAL 1 DAY);
	END WHILE;
END;

