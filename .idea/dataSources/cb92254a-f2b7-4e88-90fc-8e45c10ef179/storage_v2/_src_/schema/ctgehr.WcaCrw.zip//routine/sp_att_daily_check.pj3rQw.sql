create procedure SP_ATT_DAILY_CHECK(IN bgdt date, IN eddt date, IN custid bigint unsigned, IN deptid bigint unsigned,
                                    IN emp  bigint unsigned, IN depttype int)
  comment '打卡日报汇总计算,'
  BEGIN
DECLARE MY_APPLYID,ct,mxct,i_emp,i_custid,i_deptid,i_att_id,MY_ATT_ID,i_loc_set_id,i_loc_set_id_2 bigint UNSIGNED;
DECLARE i_data_source,i_data_source2,i_att_rule,dttype,wkday,stat,lsi,lsi2,MY_ATTGROUPNUMBER bigint;
DECLARE Olsn1,workday,lsn1,lsn2,i_version_code,i_loc_set_name,i_loc_set_name_2 VARCHAR(200);
DECLARE ori_ck_ot1,ckin,ckout,ori_ck_st,ori_ck_et,ck_st,ck_ot,ck_et datetime;
DECLARE MY_APPLYID_STR,ori_ck_ot,Olsn,MY_CKOSD_DETAIL,MY_RE_CKOSD_DETAIL,MY_CKOSD_RMK,MY_RE_CKOSD_RMK TEXT;
DECLARE mst,aet,met,ast time;
DECLARE MY_WCBZCS,i_is_month_period,i_is_full_attendance,i_is_leave_full_attendance,MY_BOSSLEVEL,i_is_app_checkin,i_is_import_att,attrule,fr,rh,is_off,is_check,do_have_att,ck_osdtms,minunit,ieh,i_check_type,flexhour int;
DECLARE i_should_work_interval,i_month_period_hour,nl_hour,ne_hour,i_ck_workhours,i_WORKHOURS,i_late_m,i_early_m decimal(12,2);
DECLARE i_bgdt,i_entry_date,i_leave_date date;
DECLARE ATTID_STR TEXT;
DECLARE i_dkj_device_id,i_dkj_device_id2 VARCHAR(50);


#基础变量配置

set sql_mode='';
set i_bgdt = bgdt;


	if (custid is null and deptid is null and depttype is null and emp is null) then
		set stat=4;
	elseif (custid is not null and deptid is null and depttype is null  and emp is null) then
		set stat=3;
	elseif (deptid is not null and depttype between 1 and 10 and emp is null) then
		set stat=2;
	elseif (emp is not null) then
		set stat=1;
	end if;

	
	#循环日期
	WHILE (bgdt<=eddt) DO 
		#初始化指针
		SET ct=0;
		SET mxct=0;
		set i_version_code = UUID();
		
		#PART 1 坐班和综合工时的考勤日报
		case stat
		when 1 then
			insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
				select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
				from emp_base_info a 
					left join emp_post d on a.emp_id=d.emp_id 
				where (d.entry_date is not null and d.entry_date <= eddt and (d.leave_date is null or d.leave_date>=bgdt)) 
					and (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
					and a.emp_id=emp and a.dept_id is not null and a.is_delete=0;
		when 2 then
			case depttype
			when 1 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.dept_id=deptid and a.dept_id is not null and a.is_delete=0;
			when 2 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.prgm_id=deptid and a.dept_id is not null and a.is_delete=0;
			when 3 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.jrdc_id=deptid and a.dept_id is not null and a.is_delete=0;
			when 4 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.dms_id4=deptid and a.dept_id is not null and a.is_delete=0;
			when 5 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.dms_id5=deptid and a.dept_id is not null and a.is_delete=0;
			when 6 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.dms_id6=deptid and a.dept_id is not null and a.is_delete=0;
			when 7 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.dms_id7=deptid and a.dept_id is not null and a.is_delete=0;
			when 8 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.dms_id8=deptid and a.dept_id is not null and a.is_delete=0;
			when 9 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.dms_id9=deptid and a.dept_id is not null and a.is_delete=0;
			when 10 then
				insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
					from emp_base_info a 
						left join emp_post d on a.emp_id=d.emp_id 
					where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
						and a.dms_id10=deptid and a.dept_id is not null and a.is_delete=0;
			end case;			
		when 3 then
			insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
				select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
				from emp_base_info a 
					left join emp_post d on a.emp_id=d.emp_id 
				where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
					and a.cust_id=custid and a.dept_id is not null and a.is_delete=0;
		when 4 then
			insert into tmp_att_log_list (version_code,emp_id,dept_id,cust_id) 
				select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
				from emp_base_info a 
					left join emp_post d on a.emp_id=d.emp_id 
				where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null 
					 and a.dept_id is not null and a.is_delete=0;
		end case;
		
		
		select min(id),max(id) into ct,mxct from tmp_att_log_list where version_code = i_version_code;
		#循环每一个人
		WHILE (ct<=mxct and ct>0) DO 
			#初始化变量
			SET i_emp=NULL,i_deptid=NULL,i_custid=NULL,is_check=NULL,dttype=NULL,do_have_att=NULL;
			SET mst=NULL,met=NULL,ast=NULL,aet=NULL,nl_hour=NULL,ne_hour=NULL,attrule=NULL,minunit=NULL,lsi=NULL,lsn1=NULL;
			SET ori_ck_st=NULL,ori_ck_et=NULL,ori_ck_ot=NULL,ck_st=NULL,ck_et=NULL,ck_ot=NULL,ck_osdtms=NULL,i_late_m =NULL;
			SET i_early_m=NULL,is_off=NULL,i_ck_workhours=NULL,i_WORKHOURS=NULL,ieh = NULL,i_entry_date=NULL,i_leave_date=NULL,MY_WCBZCS=0;			
			SET Olsn = NULL,MY_ATT_ID=NULL,MY_ATTGROUPNUMBER=NULL,ori_ck_ot1=NULL,Olsn1=NULL,i_att_rule=NULL;
			set MY_CKOSD_DETAIL=NULL,MY_RE_CKOSD_DETAIL=NULL,MY_CKOSD_RMK=NULL,MY_RE_CKOSD_RMK=NULL,MY_BOSSLEVEL=NULL;
			SET i_is_month_period=NULL,i_month_period_hour=NULL,i_is_full_attendance=null,i_is_leave_full_attendance=NULL,i_should_work_interval=NULL;
			SET lsi=NULL,lsn1=NULL,i_dkj_device_id=NULL,i_data_source=NULL,lsi2=NULL,lsn2=NULL,i_dkj_device_id2=NULL,i_data_source2=NULL,Olsn1=NULL,ori_ck_ot=NULL,MY_CKOSD_DETAIL=NULL,MY_RE_CKOSD_DETAIL=NULL,MY_CKOSD_RMK=NULL,MY_RE_CKOSD_RMK=NULL,Olsn=NULL;
			#得到id，id不为空才开始计算
			select emp_id,dept_id,cust_id into i_emp,i_deptid,i_custid from tmp_att_log_list where id=ct and version_code=i_version_code limit 1;
			IF i_emp IS NOT NULL THEN
				#清掉原日报当天该员工的数据
				delete from att_emp_detail where emp_id=i_emp and dt=bgdt;
				#得到员工的日离职日期，用以得到正确的起止日期
				SELECT entry_date,leave_date into i_entry_date,i_leave_date from emp_post where emp_id=i_emp limit 1;
				SELECT A.boss_level INTO MY_BOSSLEVEL FROM emp_base_info A WHERE A.emp_id=i_emp;
				#检查是否有出勤规则
				CALL SP_DPT_GET_SETTINGID(i_emp,bgdt,1,ATTID_STR);
				SET MY_ATT_ID = CAST(ATTID_STR AS UNSIGNED);
						
				#有规则才记录日报
				IF MY_ATT_ID IS NOT NULL THEN
					#读出考勤规则
					select morn_start_time,morn_end_time,aftn_start_time,aftn_end_time,
							att_rule,le_fine_compute_unit,is_exp_hol,flex_hour,
							b.is_app_checkin,b.is_import_att,b.att_rule,
							b.is_month_period,b.month_period_hour,b.is_full_attendance,b.is_leave_full_attendance
						into mst,met,ast,aet,
							attrule,minunit,ieh,flexhour,
							i_is_app_checkin,i_is_import_att,i_att_rule,
							i_is_month_period,i_month_period_hour,i_is_full_attendance,i_is_leave_full_attendance
					from att_set_schema_new b
					where b.att_id=MY_ATT_ID;
					
					SET MY_ATTGROUPNUMBER = FN_ATT_GET_DAILY_GROUP_NUMBER(i_emp,MY_ATT_ID,bgdt);
				END IF;
								
				#当起止日期处于员工的在职日起才开始计算日报
				IF i_att_rule = 1 AND (i_is_app_checkin=1 OR i_is_import_att=1) AND (i_entry_date IS NOT NULL AND i_entry_date <= eddt) AND (i_leave_date IS NULL OR i_leave_date >= bgdt) THEN
					#先看看有没有当天的打卡
					select count(*) into is_check from att_emp_log where check_time between concat(bgdt,' 05:00:00') and concat(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and emp_id=i_emp;
					#得到日期类型
					SET dttype = FN_ATT_GET_DTTYPE(bgdt,i_emp);
					#如果没有打卡
		 			if is_check =0 then
						#如果日期类型是工作日
						if (dttype in (1,6)) AND (MY_BOSSLEVEL = 0 OR MY_BOSSLEVEL IS NULL) then				
			 				set i_late_m = FN_ATT_GET_WORKHOURS(MY_ATT_ID)*60;
							set i_early_m = 0;
							set is_off = 1;
							set i_WORKHOURS = 0;
							SET i_ck_workhours = i_WORKHOURS ;
							set i_should_work_interval = i_late_m;
						elseif dttype in (1,6) AND MY_BOSSLEVEL in (2,3) AND MY_BOSSLEVEL IS NOT NULL then
			 				set i_late_m = 0;
							set i_early_m = 0;
							set is_off = 0 ;
							set i_should_work_interval =FN_ATT_GET_WORKHOURS(MY_ATT_ID)*60;
							set i_WORKHOURS = i_should_work_interval;
							SET i_ck_workhours = i_WORKHOURS ;
						#如果日期类型非工作日
						else 
			 				set i_late_m = 0;
							set i_early_m = 0;
							set is_off = 0 ;
							set i_WORKHOURS = 0;
							set i_should_work_interval =0;
							SET i_ck_workhours = i_WORKHOURS ;
						end if;
						
						#入离职全勤控制
						IF (i_is_full_attendance=1 AND bgdt = i_entry_date AND i_entry_date IS NOT NULL) or (i_is_leave_full_attendance = 1  AND bgdt = i_leave_date AND i_leave_date IS NOT NULL ) THEN
			 				set i_late_m = 0;
							set i_early_m = 0;
							set is_off = 0 ;
							set i_WORKHOURS = i_should_work_interval;
							SET i_ck_workhours = i_WORKHOURS ;
						END IF;
						
						SET MY_WCBZCS = 0;
						
						
#select 1,bgdt,dttype,MY_BOSSLEVEL,i_late_m,i_early_m;
						#写入日报
						replace into att_emp_detail (check_work_interval,wcbzcs,should_work_interval,work_interval,osd_addr,att_group_number,position_level_id,att_id,att_rule,cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,emp_id,emp_code,emp_name,dt,`weekday`,date_type,is_dayoff,partition_code,LATE_MINS,EARLY_MINS)
							select i_ck_workhours,MY_WCBZCS,i_should_work_interval,i_WORKHOURS,Olsn1,MY_ATTGROUPNUMBER,b.position_level_id,MY_ATT_ID,attrule,a.cust_id,a.dept_id,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,i_emp,b.emp_code,a.emp_name,bgdt,weekday(bgdt)+1,dttype,is_off,md5(concat(i_emp,bgdt)),i_late_m,i_early_m
							from emp_base_info a left join emp_post b on a.emp_id=b.emp_id 
							where a.emp_id = i_emp;
#*/

					#如果有打卡
		 			else						
						#分别得到当天最大最小的非外勤打卡和地址、以及最后一次外勤打卡和地址
						CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,bgdt,1,ori_ck_st,ori_ck_et,ori_ck_ot1);

						SET i_dkj_device_id=NULL,i_data_source=NULL,i_dkj_device_id2=NULL,i_data_source2=NULL;
						SELECT loc_set_id,loc_set_name,if(data_source=4,device_id,dkj_device_id),data_source INTO lsi,lsn1,i_dkj_device_id,i_data_source from att_emp_log where check_time =ori_ck_st and emp_id=i_emp and  check_type <>3 limit 1;
						SELECT loc_set_id,loc_set_name,if(data_source=4,device_id,dkj_device_id),data_source INTO lsi2,lsn2,i_dkj_device_id2,i_data_source2 from att_emp_log where check_time =ori_ck_et and emp_id=i_emp and  check_type <>3 limit 1;
						SELECT a.check_add INTO Olsn1 from att_emp_log a where check_time =ori_ck_ot1 and emp_id=i_emp and check_type =3 limit 1;
						#外勤明细
						SELECT GROUP_CONCAT(DISTINCT IFNULL(A.check_time,''),'/',IFNULL(A.check_add,'')) INTO MY_CKOSD_DETAIL FROM att_emp_log A WHERE A.check_time between concat(bgdt,' 05:00:00') and concat(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and A.emp_id=i_emp and  A.check_type =3;
						SELECT GROUP_CONCAT(DISTINCT IFNULL(A.check_time,''),'/补签') INTO MY_RE_CKOSD_DETAIL FROM att_check_apply A WHERE A.emp_id=i_emp AND A.check_time between concat(bgdt,' 05:00:00') and concat(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') AND A.check_type=3 AND A.state=1 GROUP BY A.emp_id;
						IF MY_CKOSD_DETAIL IS NULL AND MY_RE_CKOSD_DETAIL IS NULL THEN
							SET ori_ck_ot = NULL;
						ELSEIF MY_CKOSD_DETAIL IS NOT NULL AND MY_RE_CKOSD_DETAIL IS NULL THEN 
							SET ori_ck_ot = MY_CKOSD_DETAIL;
						ELSEIF MY_CKOSD_DETAIL IS NULL AND MY_RE_CKOSD_DETAIL IS NOT NULL THEN 
							SET ori_ck_ot = MY_RE_CKOSD_DETAIL;
						ELSEIF MY_CKOSD_DETAIL IS NOT NULL AND MY_RE_CKOSD_DETAIL IS NOT NULL THEN 
							SET ori_ck_ot = CONCAT(MY_CKOSD_DETAIL,',',MY_RE_CKOSD_DETAIL);
						END IF;

						#去掉双逗号
						WHILE LOCATE(',,',ori_ck_ot) > 0 AND LENGTH(ori_ck_ot)>2 DO
							SET ori_ck_ot = REPLACE(ori_ck_ot,',,',',');
						END WHILE;
						
						#外勤备注
						SELECT GROUP_CONCAT(DISTINCT IFNULL(A.remark,'')) INTO MY_CKOSD_RMK FROM att_emp_log A WHERE A.check_time between concat(bgdt,' 05:00:00') and concat(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and A.emp_id=i_emp and  A.check_type =3;
						SELECT GROUP_CONCAT(DISTINCT IFNULL(A.remark,'')) INTO MY_RE_CKOSD_RMK FROM att_check_apply A WHERE A.check_time between concat(bgdt,' 05:00:00') and concat(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and A.emp_id=i_emp and  A.check_type =3 AND state=1;
						IF MY_CKOSD_RMK IS NULL AND MY_RE_CKOSD_RMK IS NULL THEN
							SET Olsn = NULL;
						ELSEIF MY_CKOSD_RMK IS NOT NULL AND MY_RE_CKOSD_RMK IS NULL THEN 
							SET Olsn = MY_CKOSD_RMK;
						ELSEIF MY_CKOSD_RMK IS NULL AND MY_RE_CKOSD_RMK IS NOT NULL THEN 
							SET Olsn = MY_RE_CKOSD_RMK;
						ELSEIF MY_CKOSD_RMK IS NOT NULL AND MY_RE_CKOSD_RMK IS NOT NULL THEN 
							SET Olsn = CONCAT(MY_CKOSD_RMK,',',MY_RE_CKOSD_RMK);
						END IF;

						#去掉双逗号
						WHILE LOCATE(',,',Olsn) > 0 AND LENGTH(Olsn) > 2 DO
							SET Olsn = REPLACE(Olsn,',,',',');
						END WHILE;
							
						#计算打卡和补签的外勤打卡次数
						SELECT IF(COUNT(*) IS NULL,0,COUNT(*)) INTO ck_osdtms from att_emp_log where check_time between concat(bgdt,' 05:00:00') and concat(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and emp_id=i_emp and  check_type =3;
						SELECT IF(COUNT(*) IS NULL,0,COUNT(*)) + ck_osdtms INTO ck_osdtms FROM att_check_apply A WHERE check_time between concat(bgdt,' 05:00:00') and concat(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and emp_id=i_emp and  check_type =3 AND STATE=1;

						
						set ck_st = ori_ck_st;
						set ck_et = ori_ck_et;
						set ck_ot = ori_ck_ot1;
						
						#工作日，特殊工作日、且法定节假日不生效的节假日：工作
						IF dttype in (1,6) AND (MY_BOSSLEVEL = 0 OR MY_BOSSLEVEL IS NULL) THEN
							set i_should_work_interval = FN_ATT_GET_WORKHOURS(MY_ATT_ID)*60;
							#没有外勤的情况下
							if ck_osdtms=0 then 	
								
								#坐班按照实际情况计算迟到早退
								if (attrule=1) then
									IF TIME(ck_st) > TIME(ck_et) THEN
										CALL FN_ATT_GET_MINS_FIXED_NA(time(ck_st),'23:59:59',MY_ATT_ID,i_late_m,i_early_m);
#select 1,time(ck_st),'23:59:59',MY_ATT_ID,i_late_m,i_early_m;
									ELSE
										CALL FN_ATT_GET_MINS_FIXED_NA(time(ck_st),time(ck_et),MY_ATT_ID,i_late_m,i_early_m);
#select 2,time(ck_st),time(ck_et),MY_ATT_ID,i_late_m,i_early_m;
									END IF;
								end if;


								IF (i_late_m IS NULL) THEN SET i_late_m=0; END IF;
								IF (i_early_m IS NULL) THEN SET i_early_m=0; END IF;
								
								#是否旷工
								set is_off = FN_ATT_GET_DAYOFF_STATUS(i_late_m,i_early_m,MY_ATT_ID) ;
								
								IF i_is_month_period = 1 THEN

									SET i_WORKHOURS = FN_ATT_GET_MINUNIT_MINS_FLOOR(FN_ATT_GET_REAL_DAY_HOURS_WITH_ATTID(time(ori_ck_st),time(ori_ck_et),MY_ATT_ID),MY_ATT_ID);
#SELECT 1,i_WORKHOURS;
								ELSE
									#实际工时
									SET i_WORKHOURS = FN_ATT_GET_WORKHOURS(MY_ATT_ID)*60 - i_late_m - i_early_m;
#SELECT 2,i_WORKHOURS;
								END IF;
#select ori_ck_st,ori_ck_et,MY_ATT_ID,i_WORKHOURS;
							#有外勤的情况下
							else				
								#只要有外勤就是全勤
								set i_late_m = 0;
								set i_early_m = 0;
								set is_off = 0;
								SET i_WORKHOURS = i_should_work_interval;
							end if;		
						ELSEIF dttype in (1,6) AND MY_BOSSLEVEL IN (2,3) AND MY_BOSSLEVEL IS NOT NULL then
							set i_late_m = 0;
							set i_early_m = 0;
							set is_off = 0;
							set i_should_work_interval = FN_ATT_GET_WORKHOURS(MY_ATT_ID)*60;
							set i_WORKHOURS = i_should_work_interval;
						#周末和法定节假日生效下的法定节假日：不工作
						ELSE													
							set i_late_m = 0;
							set i_early_m = 0;
							set is_off = 0;
							set i_WORKHOURS = 0;
							set i_should_work_interval = 0;
						END IF;	
						IF (i_WORKHOURS IS NULL) THEN SET i_WORKHOURS=0; END IF;
						
						SET i_ck_workhours = FN_ATT_GET_CHECK_WORK_HOURS(ori_ck_st,ori_ck_et,MY_ATT_ID,i_emp);
						#出勤白名单
						IF MY_BOSSLEVEL IN (2,3) AND MY_BOSSLEVEL IS NOT NULL THEN
							SET i_late_m=0,i_early_m=0,is_off=0,i_WORKHOURS=i_should_work_interval;
							SET i_ck_workhours = i_WORKHOURS ;
						END IF;
						
						#入离职全勤控制
						IF (i_is_full_attendance=1 AND bgdt = i_entry_date) or (i_is_leave_full_attendance = 1  and bgdt = i_leave_date) THEN
			 				set i_late_m = 0;
							set i_early_m = 0;
							set is_off = 0 ;
							set i_WORKHOURS = i_should_work_interval;
							SET i_ck_workhours = i_WORKHOURS;
						END IF;

#select 2,ori_ck_st,ori_ck_et,bgdt,i_entry_date,i_leave_date,i_late_m,i_early_m,i_ck_workhours;
						
						SET MY_WCBZCS = FN_ATT_GET_DINNER_SUBSIDY_COUNT(bgdt,i_emp);
						IF i_WORKHOURS < 0 THEN SET i_WORKHOURS = 0; END IF;
						replace into att_emp_detail (check_work_interval,wcbzcs,dkj_device_id,data_source,dkj_device_id_2,data_source_2,should_work_interval,
																att_group_number,position_level_id,att_id,att_rule,cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,emp_id,emp_code,emp_name,
																dt,`weekday`,date_type,check_in,check_out,check_osd_detail,check_osd_remark,check_osd_times,
																loc_set_id,loc_set_name,loc_set_id_2,loc_set_name_2,check_osd,osd_addr,
																work_interval,
																late_mins,early_mins,
																is_dayoff,partition_code) 
													select i_ck_workhours,MY_WCBZCS,i_dkj_device_id,i_data_source,i_dkj_device_id2,i_data_source2,i_should_work_interval,
																MY_ATTGROUPNUMBER,b.position_level_id,MY_ATT_ID,attrule,a.cust_id,a.dept_id,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,i_emp,b.emp_code,a.emp_name,
																bgdt,weekday(bgdt)+1,dttype,ori_ck_st,ori_ck_et,ori_ck_ot,Olsn,ck_osdtms,
																lsi,lsn1,lsi2,lsn2,ori_ck_ot1,Olsn1,
																i_WORKHOURS,
																i_late_m,i_early_m,
																is_off,md5(concat(i_emp,bgdt))
													from emp_base_info a left join emp_post b on a.emp_id=b.emp_id where a.emp_id=i_emp;

					end if;
				END IF;
			END IF;
			set ct=ct+1;
		END WHILE; 
		SET bgdt = date_add(bgdt,interval 1 day);
	END WHILE;

	CALL SP_ATT_DAILY_RECHECK(i_bgdt,eddt,custid,deptid,emp,depttype);
END;

