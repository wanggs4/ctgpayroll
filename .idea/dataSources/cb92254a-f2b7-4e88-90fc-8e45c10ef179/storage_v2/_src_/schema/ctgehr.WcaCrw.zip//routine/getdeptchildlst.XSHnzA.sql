create function getDeptChildLst(rootId bigint)
  returns varchar(4000)
  BEGIN
	 DECLARE sTemp VARCHAR(4000);
   DECLARE sTempChd VARCHAR(4000);
   
   SET sTemp = '$';
   SET sTempChd =cast(rootId as CHAR);
    
   WHILE sTempChd is not null DO
      SET sTemp = concat(sTemp,',',sTempChd);
      SELECT group_concat(dept_id) INTO sTempChd FROM dept_info where FIND_IN_SET(parent_dept_id,sTempChd)>0;
       END WHILE;
       RETURN sTemp;
END;

