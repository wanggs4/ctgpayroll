create procedure SP_ICSS_ST_HOL_EVERY(IN MY_BGDT date, IN MY_EMP bigint unsigned)
  comment '员工整体请假情况表'
  BEGIN
DECLARE CT,MXCT,MY_EMP_ID,MY_DEPT_ID BIGINT UNSIGNED;
DECLARE MY_DEPT_FULL_NAME,MY_EMP_CODE,MY_EMP_NAME,I_VERSION_CODE VARCHAR(500);
DECLARE MY_ENTRY_DATE,MY_LEAVE_DATE,MY_EDDT DATE;
DECLARE MY_THIS_YEAR INT;
DECLARE MY_BJ,MY_HJ,MY_CJ,MY_CJJ,MY_BRJ,MY_HLJ,MY_SJYLCJ,MY_BX,MY_NJ,MY_WDK DECIMAL(12,2);
/*
入参说明：
MY_BGDT 入组人员在职时间范围和计算的时间范围的开始日期，NULL时取前天这一年的一月一日
MY_EMP 人员id，只为重跑某个人时使用，平时给NULL既跑所有
所有时间范围结束日期均为前天
*/
	


	SET I_VERSION_CODE = UUID();
	#结束日期只能为上月最后一天
	SET MY_EDDT = DATE_ADD(CONCAT(LEFT(DATE(NOW()),8),'01'),INTERVAL -1 DAY);
	SET MY_THIS_YEAR = YEAR(MY_EDDT);
	
	#入参MY_BGDT 校验
	#1.如果为空，设为前天的同年一月一日
	IF MY_BGDT IS NULL THEN
		SET MY_BGDT = CONCAT(MY_THIS_YEAR,'-01-01');
	ELSE
		IF YEAR(MY_BGDT) <> MY_THIS_YEAR THEN
			SET MY_BGDT = CONCAT(MY_THIS_YEAR,'-01-01');
		END IF;
	END IF;
	
	IF MY_EMP IS NULL THEN
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT);			

		REPLACE INTO icss_st_hol_every (emp_id,this_year,sj)
			SELECT A.emp_id,MY_THIS_YEAR,IFNULL(SUM(A.hol_hours),0)
			FROM icss_st_hol_detail A 
			WHERE A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED) 
				AND A.hol_id=2162555034710027
			GROUP BY A.emp_id;
	ELSE
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT)
				AND A.emp_id=MY_EMP;			

		REPLACE INTO icss_st_hol_every (emp_id,this_year,sj)
				SELECT A.emp_id,MY_THIS_YEAR,IFNULL(SUM(A.hol_hours),0)
				FROM icss_st_hol_detail A 
				WHERE A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
					AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED) 
					AND A.hol_id=2162555034710027
					AND A.emp_id=MY_EMP
				GROUP BY A.emp_id;
	END IF;		
	

	SET CT = 0, MXCT = 0;
	
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_icss_st_emp_list A WHERE A.version_code = I_VERSION_CODE;
	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_EMP_ID=NULL,MY_DEPT_ID=NULL,MY_DEPT_FULL_NAME=NULL,MY_EMP_CODE=NULL,MY_EMP_NAME=NULL,MY_ENTRY_DATE=NULL,MY_LEAVE_DATE=NULL;
		SET MY_BJ=0,MY_HJ=0,MY_CJ=0,MY_CJJ=0,MY_BRJ=0,MY_HLJ=0,MY_SJYLCJ=0,MY_BX=0,MY_NJ=0,MY_WDK=0;

		SELECT A.emp_id,A.emp_code,A.emp_name,A.entry_date,A.leave_date,A.dept_id,A.dept_full_name
			INTO MY_EMP_ID,MY_EMP_CODE,MY_EMP_NAME,MY_ENTRY_DATE,MY_LEAVE_DATE,MY_DEPT_ID,MY_DEPT_FULL_NAME
		FROM tmp_icss_st_emp_list A 
		WHERE A.version_code = I_VERSION_CODE AND A.id=CT; 

		IF MY_EMP_ID IS NOT NULL THEN
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_BJ
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id=107735517896704 
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
				
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_HJ
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id=2162555034710023 
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
				
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_CJ
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id=2162555034710025 
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
				
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_CJJ
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id=2162555034710021 
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
				
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_BRJ
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id=2162555034710019 
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
				
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_HLJ
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id=90727623565312 
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
				
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_SJYLCJ
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id=85442001686528 
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
		
			
			
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_BX
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id IN (2162554992766976,202006120001,643762283548672)
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
		
			
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_NJ
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id IN (2162555009544192,201912120001)
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
		
			
			SELECT IFNULL(SUM(A.hol_hours),0) INTO MY_WDK
			FROM icss_st_hol_detail A
			WHERE A.emp_id=MY_EMP_ID AND A.hol_id=1 
				AND A.this_year_mon BETWEEN CAST(CONCAT(MY_THIS_YEAR,'01') AS UNSIGNED) 
				AND CAST(CONCAT(MY_THIS_YEAR,'12') AS UNSIGNED); 
			
			
			UPDATE icss_st_hol_every A
			SET bj=MY_BJ ,hj=MY_HJ ,cj=MY_CJ ,cjj=MY_CJJ ,brj=MY_BRJ ,hlj=MY_HLJ ,sjylcj=MY_SJYLCJ ,bx=MY_BX ,nj=MY_NJ ,
				wdk=MY_WDK ,all_hol_hours=(MY_BJ+MY_HJ+MY_CJ+MY_CJJ+MY_BRJ+MY_HLJ+MY_SJYLCJ+MY_BX+MY_NJ)+ A.sj ,
				all_hol_days= (MY_BJ+MY_HJ+MY_CJ+MY_CJJ+MY_BRJ+MY_HLJ+MY_SJYLCJ+MY_BX+MY_NJ+A.sj)/8,
				emp_code=MY_EMP_CODE ,emp_name=MY_EMP_NAME ,entry_date=MY_ENTRY_DATE ,leave_date=MY_LEAVE_DATE ,
				dept_id=MY_DEPT_ID,dept_full_name=MY_DEPT_FULL_NAME
			WHERE A.emp_id = MY_EMP_ID AND A.this_year = MY_THIS_YEAR;
		END IF;
		SET CT = CT + 1;
	END WHILE;
END;

