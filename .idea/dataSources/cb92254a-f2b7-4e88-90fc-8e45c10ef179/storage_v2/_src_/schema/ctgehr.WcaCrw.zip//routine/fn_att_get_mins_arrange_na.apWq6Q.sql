create procedure FN_ATT_GET_MINS_ARRANGE_NA(IN  ckin_time     time, IN ckout_time time, IN this_date date,
                                            IN  emp           bigint unsigned, OUT MY_LATE_MINS decimal(12, 2),
                                            OUT MY_EARLY_MINS decimal(12, 2))
  comment '给两个时间点，计算弹性工作制的迟到早退时间，此程序只用于判断请假的时间段对于排班的时间段的覆盖情况'
  BEGIN
DECLARE IS_HAVE_ARRANGE INT;
DECLARE ARR_CT,ARR_MXCT,MY_ATT_ID BIGINT;
DECLARE MY_HOL_BG_TIME,MY_HOL_ED_TIME,MY_ARR_BG_TIME,MY_ARR_ED_TIME,MY_CHECK_BG_TIME,MY_CHECK_ED_TIME DATETIME;
DECLARE THIS_LATE_MINS,THIS_EARLY_MINS,THIS_WORKTIME DECIMAL(12,2);



	SET MY_HOL_BG_TIME = CONCAT(this_date,' ',ckin_time);
	SET MY_HOL_ED_TIME = CONCAT(this_date,' ',ckout_time);
	SET MY_LATE_MINS = 0;
	SET MY_EARLY_MINS = 0;
	#看一下当天有没有排班
	SELECT COUNT(*) INTO IS_HAVE_ARRANGE FROM att_arrange_schedual A WHERE A.emp_id=emp AND A.dt = this_date;
	#如果当天有排班
	IF IS_HAVE_ARRANGE > 0 THEN
		#读出当天排班时间段的指针值和出勤设置的值
		SELECT MIN(A.arr_no),MAX(A.arr_no),MAX(A.att_id) INTO ARR_CT,ARR_MXCT,MY_ATT_ID 
		FROM att_arrange_schedual A WHERE A.emp_id=emp AND A.dt = this_date;
		
		
		WHILE (ARR_CT <= ARR_MXCT) DO
			SET MY_ARR_BG_TIME = NULL;
			SET MY_ARR_ED_TIME = NULL;
			SET MY_CHECK_BG_TIME = NULL;
			SET MY_CHECK_ED_TIME = NULL;
			SET THIS_LATE_MINS = NULL;
			SET THIS_EARLY_MINS = NULL;

			#读出时段的应打卡时间段、实际打卡时间段、迟到早退时间
			SELECT A.arr_start_time,A.arr_end_time,A.att_check_in,A.att_check_out,A.late_mins,A.early_mins
				INTO MY_ARR_BG_TIME,MY_ARR_ED_TIME,MY_CHECK_BG_TIME,MY_CHECK_ED_TIME,THIS_LATE_MINS,THIS_EARLY_MINS
			FROM att_arrange_schedual A WHERE A.emp_id=emp AND A.dt = this_date AND A.arr_no=ARR_CT;
			
			#请假起止点完全覆盖排班时间段的情况
			IF MY_HOL_BG_TIME <= MY_ARR_BG_TIME AND MY_HOL_ED_TIME >= MY_ARR_ED_TIME THEN
				SET THIS_LATE_MINS = 0;
				SET THIS_EARLY_MINS = 0;
			#部分覆盖的情况，请假起点早于排班起点
			ELSEIF MY_HOL_BG_TIME <= MY_ARR_BG_TIME AND MY_HOL_ED_TIME < MY_ARR_ED_TIME AND MY_HOL_ED_TIME > MY_ARR_BG_TIME THEN
				SET THIS_LATE_MINS = 0;
				#只有请假终点比实际打卡终点晚时，早退的值才做改变
				IF MY_HOL_ED_TIME > MY_CHECK_ED_TIME OR MY_CHECK_ED_TIME IS NULL THEN
					SET THIS_EARLY_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(MY_ARR_ED_TIME,MY_HOL_ED_TIME))/60,0);
				END IF;
			#部分覆盖的情况，请假终点晚于排班终点
			ELSEIF MY_HOL_BG_TIME > MY_ARR_BG_TIME AND MY_HOL_BG_TIME < MY_ARR_ED_TIME AND MY_HOL_ED_TIME >= MY_ARR_ED_TIME THEN
				#只有当请假起始点比实际打卡起点早的时候，才做迟到的改变
				IF MY_HOL_BG_TIME < MY_CHECK_BG_TIME OR MY_CHECK_BG_TIME IS NULL THEN
					SET THIS_LATE_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(MY_HOL_BG_TIME,MY_ARR_BG_TIME))/60,0);
				END IF;
				SET THIS_EARLY_MINS = 0;
			#包含的情况，请假起始点在应打卡时间段中间，结合实际打卡按实际计算
			ELSEIF MY_HOL_BG_TIME > MY_ARR_BG_TIME AND MY_HOL_BG_TIME <= MY_ARR_ED_TIME AND MY_HOL_ED_TIME > MY_ARR_BG_TIME AND MY_HOL_ED_TIME <= MY_ARR_ED_TIME THEN
				#只有当请假起始点比实际打卡起点早的时候，才做迟到的改变
				IF MY_HOL_BG_TIME < MY_CHECK_BG_TIME OR MY_CHECK_BG_TIME IS NULL THEN
					SET THIS_LATE_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(MY_HOL_BG_TIME,MY_ARR_BG_TIME))/60,0);
				END IF;
				#只有请假终点比实际打卡终点晚时，早退的值才做改变
				IF MY_HOL_ED_TIME > MY_CHECK_ED_TIME OR MY_CHECK_ED_TIME IS NULL THEN
					SET THIS_EARLY_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(MY_ARR_ED_TIME,MY_HOL_ED_TIME))/60,0);
				END IF;
			END IF;
			IF THIS_LATE_MINS IS NULL OR THIS_LATE_MINS < 0 THEN SET THIS_LATE_MINS = 0; END IF;
			IF THIS_EARLY_MINS IS NULL OR THIS_EARLY_MINS < 0 THEN SET THIS_EARLY_MINS = 0; END IF;
			
			SET THIS_WORKTIME = ROUND(TIME_TO_SEC(TIMEDIFF(MY_ARR_ED_TIME,MY_ARR_BG_TIME))/60,0) -  THIS_LATE_MINS - THIS_EARLY_MINS;
			
			UPDATE att_arrange_schedual A 
			SET A.late_mins=THIS_LATE_MINS,A.early_mins=THIS_EARLY_MINS,A.work_interval=THIS_WORKTIME
			WHERE A.emp_id=emp AND A.dt = this_date AND A.arr_no=ARR_CT;
			
			SET MY_LATE_MINS = MY_LATE_MINS + THIS_LATE_MINS;
			SET MY_EARLY_MINS = MY_EARLY_MINS + THIS_EARLY_MINS;
			
			SET ARR_CT = ARR_CT + 1;
		END WHILE;
		
	#如果当天没有排班
	ELSE
		SET MY_LATE_MINS = 0;
		SET MY_EARLY_MINS = 0;	
	END IF;
END;

