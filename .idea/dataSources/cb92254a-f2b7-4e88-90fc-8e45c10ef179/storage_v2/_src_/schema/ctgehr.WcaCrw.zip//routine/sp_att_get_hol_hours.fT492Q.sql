create procedure SP_ATT_GET_HOL_HOURS(IN bgdt datetime, IN eddt datetime, IN hol_id bigint unsigned, IN sonver int,
                                      IN emp  bigint unsigned, OUT hol_hours float, IN minunit int)
  comment '通过给出的两个时间和部门id得到实际的发生时间'
  BEGIN
	#海翔公司ID：352030686900224
	set @hx_cust_id = 140086305538048;
	set @cust_id = 0;
	
	select cust_id into @cust_id from emp_base_info where emp_id = emp;


	SET hol_hours = FN_ATT_GET_HOL_HOURS(bgdt,eddt,hol_id,sonver,emp,minunit);

	
END;

