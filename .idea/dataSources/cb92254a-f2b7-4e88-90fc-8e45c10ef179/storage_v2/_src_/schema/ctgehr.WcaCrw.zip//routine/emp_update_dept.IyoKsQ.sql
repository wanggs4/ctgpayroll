create procedure emp_update_dept()
  comment '变更部门的员工是否是系统管理员'
  BEGIN
SELECT bb.emp_name 姓名,b.emp_code 工号,bb.mobile 手机号,c.dept_full_name 部门全称,CASE bb.emp_state WHEN 1 THEN '在职' WHEN 2 THEN '离职' WHEN 3 THEN '试用' end as 员工状态
 FROM token_flush_emp_list a
LEFT JOIN emp_post b ON a.emp_id=b.emp_id
LEFT JOIN emp_base_info bb ON b.emp_id=bb.emp_id
LEFT JOIN dept_info c ON b.dept_id=c.dept_id
 WHERE a.emp_id in(
SELECT emp_id FROM au_users WHERE is_enable=1);
END;

