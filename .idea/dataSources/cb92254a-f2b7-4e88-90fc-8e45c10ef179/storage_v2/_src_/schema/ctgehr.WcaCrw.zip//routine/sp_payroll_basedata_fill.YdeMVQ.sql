create procedure SP_PAYROLL_BASEDATA_FILL(IN setid bigint unsigned, IN optype int)
  comment '填充base表数据'
  BEGIN
#************** 变量说明 ************* 
#** optype		
#*			1:全局新增	根据setid把参与计算的人相关数据全部写入base表
#*			2:局部新增	跟局setid把payroll_tol表里有，但是base表里没有的人的数据写入base表
#** schema_type
#*			薪酬类型（1工资 2劳务费 3年终奖 4离职补偿金 5分红 6股票期权）
DECLARE i_emp,i_deptid,i_custid,prid bigint UNSIGNED;
DECLARE emp_ct,emp_mxct,sch_ct,sch_mxct,item_ct,item_mxct,ym,i_sub_pay_way,i_attsource,is_have_att,i_pay_way,MY_SERVICETYPE BIGint;
DECLARE i_empname,i_deptname,i_schids,i_schtps,tmp_schids,tmp_schtps,this_schid,this_schtp varchar(200);
DECLARE i_value_num,i_taxstand,SJCQTS,JXTS,YCQGZR,JXBZ,i_value DECIMAL(13,3);
DECLARE att_bgdt,att_eddt DATE;
DECLARE i_version_code VARCHAR(50);
SET i_version_code = UUID();
SET @i_version_code = i_version_code;

set @setid = setid;




#************ part 0 全局变量获取 ************* 
	#-----step 0.1 根据setid去 payroll_sala_settings 读出cust_id、schema_id、schema_type
	
	SELECT cust_id,schema_id,schema_type,sala_ym,att_source
		into i_custid,i_schids,i_schtps,ym,i_attsource 
	FROM payroll_sala_settings WHERE SET_ID=setid;


#************ part 1 循环参与的人 ************* 
	#-----step 1.1 根据setid 去 payroll_tol 得到人员列表 写进临时表 TMP_BASEFILL_B
	
	delete from  TMP_BASEFILL_B where version_code = i_version_code;
	INSERT INTO TMP_BASEFILL_B (version_code,payrollid,EMP_ID) 
		SELECT i_version_code,id,EMP_ID FROM payroll_tol WHERE SET_ID=setid ;
		
		#---case 1 optype=1	全部tpayroll_tol表 b 里的人
		#---case 2 optype=2  从临时表里删除掉base表里已经有的emp_id
	IF ( optype=2 ) THEN
		DELETE a.* FROM TMP_BASEFILL_B a,payroll_fh_base b where a.payrollid=b.ID and b.set_id = setid and version_code = i_version_code;
		DELETE a.* FROM TMP_BASEFILL_B a,payroll_gpqq_base b where a.payrollid=b.ID and b.set_id = setid and version_code = i_version_code;
		DELETE a.* FROM TMP_BASEFILL_B a,payroll_gz_base b where a.payrollid=b.ID and b.set_id = setid and version_code = i_version_code;
		DELETE a.* FROM TMP_BASEFILL_B a,payroll_lwf_base b where a.payrollid=b.ID and b.set_id = setid and version_code = i_version_code;
		DELETE a.* FROM TMP_BASEFILL_B a,payroll_lzf_base b where a.payrollid=b.ID and b.set_id = setid and version_code = i_version_code;
		DELETE a.* FROM TMP_BASEFILL_B a,payroll_nzj_base b where a.payrollid=b.ID and b.set_id = setid and version_code = i_version_code;
	END IF;


#************* part 2 循环薪酬方案 ************* 
#-----step 2.2 利用函数得到 schema_id和schema_type里面存储的数量 ,进行循环	
	set sch_ct = 1;
	set sch_mxct = LENGTH(i_schids) - LENGTH(REPLACE(i_schids,',',''))+1;
	SET tmp_schids = i_schids;
	SET tmp_schtps = i_schtps;
	

	WHILE ( sch_ct <= sch_mxct ) DO													
#-----step 2.2 得到独立的schema_id和schema_type，在相应的base表里新建一条该员工数据
		IF sch_mxct=1 THEN
			SET this_schid = tmp_schids;
			SET this_schtp = tmp_schtps;
		ELSE
			SET tmp_schids=CONCAT(tmp_schids,',');
			SET tmp_schtps=CONCAT(tmp_schtps,',');
			SET this_schid = LEFT(tmp_schids,LOCATE(',',tmp_schids)-1);
			SET this_schtp = LEFT(tmp_schtps,LOCATE(',',tmp_schtps)-1);
		END IF;


		
		#1工资 2劳务费 3年终奖 4离职补偿金 5分红 6股票期权
		IF  this_schtp='1' THEN
			IF optype = 1 THEN
				DELETE FROM payroll_gz_base WHERE set_id = setid;
				DELETE FROM payroll_bz_gz WHERE set_id = setid;
			END IF;	
			REPLACE INTO payroll_bz_gz (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
			REPLACE INTO payroll_gz_base (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,TAX_STAND)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,5000
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
		ELSEIF this_schtp='2' THEN
			IF optype = 1 THEN
				DELETE FROM payroll_lwf_base WHERE set_id = setid;
				DELETE FROM payroll_bz_lwf WHERE set_id = setid;
			END IF;	
			
			REPLACE INTO payroll_bz_lwf (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
			REPLACE INTO payroll_lwf_base (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,TAX_STAND)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,5000
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
		ELSEIF this_schtp='3' THEN
			IF optype = 1 THEN
				DELETE FROM payroll_nzj_base WHERE set_id = setid;
				DELETE FROM payroll_bz_nzj WHERE set_id = setid;
			END IF;	
			
			REPLACE INTO payroll_bz_nzj (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
			REPLACE INTO payroll_nzj_base (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,TAX_STAND)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,5000
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
		ELSEIF this_schtp='4' THEN
			IF optype = 1 THEN
				DELETE FROM payroll_lzf_base WHERE set_id = setid;
				DELETE FROM payroll_bz_lzf WHERE set_id = setid;
			END IF;	
			
			REPLACE INTO payroll_bz_lzf (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
			REPLACE INTO payroll_lzf_base (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,TAX_STAND)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP,5000
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
		ELSEIF this_schtp='5' THEN
			IF optype = 1 THEN
				DELETE FROM payroll_fh_base WHERE set_id = setid;
			END IF;	
			REPLACE INTO payroll_fh_base (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
		ELSEIF this_schtp='6' THEN
			IF optype = 1 THEN
				DELETE FROM payroll_gpqq_base WHERE set_id = setid;
			END IF;	
			REPLACE INTO payroll_gpqq_base (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,SET_ID,MONTH_STEP)
				SELECT b.ID,CUST_ID,DEPT_ID,DEPT_NAME,b.EMP_ID,EMP_NAME,SET_ID,MONTH_STEP
				FROM TMP_BASEFILL_B a left join payroll_tol b ON a.payrollid=b.ID
				WHERE b.set_id = setid and version_code = i_version_code;
		END IF;

	#-----step 1.2 根据临时表 TMP_BASEFILL_B 去循环人       
		set emp_ct = 0;
		set emp_mxct = 0;
		SELECT MIN(ID),MAX(ID) INTO emp_ct,emp_mxct FROM TMP_BASEFILL_B where version_code = i_version_code;
		WHILE (emp_ct <= emp_mxct and emp_ct>0) DO
			SET prid=NULL;
			SET i_emp=NULL;
			
			SELECT payrollid,emp_id INTO prid,i_emp FROM TMP_BASEFILL_B WHERE ID=emp_ct and version_code = i_version_code;
			IF prid IS NOT NULL THEN
				SET @prid =prid;
				SELECT a.emp_name,b.dept_id,b.dept_name,c.tax_stand INTO i_empname,i_deptid,i_deptname,i_taxstand
				FROM emp_base_info a LEFT JOIN dept_info b ON a.dept_id=b.dept_id 
					LEFT JOIN emp_salary c on a.emp_id=c.emp_id
				WHERE a.emp_id=i_emp;
				
				SELECT A.service_type INTO MY_SERVICETYPE
				FROM soin_emp A
				WHERE A.ehr_emp_id=i_emp
				ORDER BY A.create_dt DESC LIMIT 1;
				
				IF i_taxstand IS NULL THEN SET i_taxstand =5000 ; END IF;
				
				IF(prid is not null) THEN																	
				
					delete from  TMP_BASEFILL_C where version_code = i_version_code;
					INSERT INTO TMP_BASEFILL_C (version_code,s_tb_name,s_col_name,des_tb_name,des_col_name)
						SELECT i_version_code,s_tb_name,s_col_name,des_tb_name,des_col_name 
						FROM payroll_set_sala_schema_item 
						WHERE schema_id = this_schid and (item_float_type=1 OR (/*group_id IN (112,212,312,412) AND*/ is_formula_compute<>1 AND s_tb_name IS NOT NULL)) and is_enable=1;
		#-----step 2.4 遍历临时表 TMP_BASEFILL_C 把相应值写入 	loop3
					SELECT MIN(ID),MAX(ID) INTO item_ct,item_mxct FROM TMP_BASEFILL_C where version_code = i_version_code;
	
					WHILE (item_ct <= item_mxct AND item_ct>0) DO											
					#初始化变量
						SET @s_tb_name = '';
						SET @s_col_name = '';
						SET @des_tb_name = '';
						SET @des_col_name  = '';
						SET @SQL1 = '';
						SET i_value = 0;
						SET i_value_num = 0;
	#-----step 2.3 联合查询 payroll_set_sala_schema_item 
	#					把 item_float_type=1（固定项）的每一个配置项的
	# 					s_tb_name、s_col_name、des_tb_name、des_col_name 等数据写入临时表 TMP_BASEFILL_C
	
					#得到原表和目标表的表名和字段名
						SELECT s_tb_name,s_col_name,des_tb_name,des_col_name 
							INTO	@s_tb_name,@s_col_name,@des_tb_name,@des_col_name 
						FROM TMP_BASEFILL_C WHERE ID=item_ct and version_code = i_version_code;
						
						IF @des_col_name IS NOT NULL AND @des_col_name <> '' AND @s_col_name IS NOT NULL AND @s_col_name <> '' THEN
						#取得源表中的值
							delete from  TMP_BASEFILL_A where version_code = i_version_code;
							delete from  TMP_BASEFILL_SUB where version_code = i_version_code;
							SET @i_emp = i_emp;
							SET @i_value = 0;
						#读出考勤月报的id
							SELECT arch_id INTO @i_archid FROM payroll_sala_settings WHERE set_id = setid;
							IF @i_archid IS NOT NULL THEN
								SELECT comp_start_time,comp_end_time INTO att_bgdt,att_eddt FROM att_st_month WHERE  st_id=@i_archid;
							END IF;
						#根据不同来源的表，设置不同的sql
							IF (@s_tb_name = 'att_st_month_arch_items') THEN	
							#i_attsource 1 考勤模块 3 不计考勤							
								IF  i_attsource = 1 THEN
									SET @SQL1 = CONCAT('INSERT INTO TMP_BASEFILL_A SELECT ''',@i_version_code,''',IFNULL(`',@s_col_name,'`,0) FROM `att_st_month_quick_view` WHERE EMP_ID=',@i_emp,' AND st_id=',@i_archid,' LIMIT 1;');
#if @i_emp=37338251542529 then
#SELECT 'att_st_month_arch_items',@SQL1,@i_version_code,@s_col_name,@i_emp,@i_archid;
#end if;
									
									PREPARE stmt1 FROM @SQL1;
									EXECUTE stmt1;
									DEALLOCATE PREPARE stmt1;
								END IF;
							#津贴
							ELSEIF (@s_tb_name = 'emp_salary_subsidy') THEN		
								SET @SQL1 = CONCAT('INSERT INTO TMP_BASEFILL_SUB SELECT ''',@i_version_code,''',sub_pay_way,if(`sub_pay_sum` is null,0,`sub_pay_sum`) FROM `',@s_tb_name,'` WHERE EMP_ID=',@i_emp,' and sub_name=''',@s_col_name,''' AND is_delete=0 LIMIT 1;');
								PREPARE stmt1 FROM @SQL1;
								EXECUTE stmt1;
								DEALLOCATE PREPARE stmt1;
							#工资	
							ELSEIF (@s_tb_name = 'emp_salary_adj') THEN			
								SET @ym = ym;												
								SELECT MAX(OPR_TIME) into @max_opr_time FROM `emp_salary_adj` WHERE LEFT(ENABLE_TIME,6) <= ym AND emp_id = i_emp and is_delete=0;
								IF @max_opr_time IS NOT NULL THEN
									SET @SQL1 = CONCAT('INSERT INTO TMP_BASEFILL_A SELECT ''',@i_version_code,''',if(`',@s_col_name,'` is null,0,`',@s_col_name,'`) FROM `',@s_tb_name,'` WHERE EMP_ID=',@i_emp,' AND OPR_TIME = ''',@max_opr_time,'''  LIMIT 1;');						
									PREPARE stmt1 FROM @SQL1;
									EXECUTE stmt1;
									DEALLOCATE PREPARE stmt1;
								ELSE
									delete from  TMP_BASEFILL_A where version_code = i_version_code;
								END IF;
							#社保单项
							ELSEIF @s_tb_name = 'soin' THEN
								IF MY_SERVICETYPE = 100 THEN
									INSERT INTO TMP_BASEFILL_A 
										SELECT i_version_code,SUM(ifnull(p_amt,0))
										FROM soin_receivable_detail a
										where a.ehr_emp_id = i_emp and a.service_mon = ym and a.product_id=@s_col_name;
								ELSEIF MY_SERVICETYPE<>100 AND MY_SERVICETYPE IS NOT NULL THEN
									INSERT INTO TMP_BASEFILL_A 
										SELECT i_version_code,SUM(ifnull(p_amt,0))
										FROM soin_bill_detail a
										where a.ehr_emp_id = i_emp and a.service_mon = ym and a.product_id=@s_col_name;
								ELSE
									SET @SQL1 = '';
								END IF;
#SELECT 'soin',@s_col_name;
							#社保汇总
							ELSEIF @s_tb_name = 'soin_total' THEN
								SET @ym = ym;												
								IF MY_SERVICETYPE = 100 THEN
									SET @SQL1 = CONCAT('INSERT INTO TMP_BASEFILL_A SELECT ''',@i_version_code,''',SUM(ifnull(',@s_col_name,',0)) FROM soin_receivable_total a where a.ehr_emp_id = ',@i_emp,' and a.service_mon = ',@ym,';');
								ELSEIF MY_SERVICETYPE<>100 AND MY_SERVICETYPE IS NOT NULL THEN
									SET @SQL1 = CONCAT('INSERT INTO TMP_BASEFILL_A SELECT ''',@i_version_code,''',SUM(ifnull(',@s_col_name,',0)) FROM soin_bill_total a where a.ehr_emp_id = ',@i_emp,' and a.service_mon = ',@ym,';');
								ELSE
									SET @SQL1 = '';
								END IF;
								PREPARE stmt1 FROM @SQL1;
								EXECUTE stmt1;
								DEALLOCATE PREPARE stmt1;
							#备注
							ELSEIF (@s_tb_name in ('payroll_bz_gz','payroll_bz_lwf','payroll_bz_lzf','payroll_bz_nzj','payroll_gz_base','payroll_lwf_base','payroll_lzf_base','payroll_nzj_base')) THEN
								SET @ym = ym;
								SET @SQL1 = CONCAT('INSERT INTO TMP_BASEFILL_A SELECT ''',@i_version_code,''',`',@s_col_name,'` FROM `',@s_tb_name,'` WHERE EMP_ID=',@i_emp,' AND set_id=',@setid,' LIMIT 1;');
								PREPARE stmt1 FROM @SQL1;
								EXECUTE stmt1;
								DEALLOCATE PREPARE stmt1;
								#其他
							ELSE
								SET @SQL1 = CONCAT('INSERT INTO TMP_BASEFILL_A SELECT ''',@i_version_code,''',if(`',@s_col_name,'` IS NULL,0,`',@s_col_name,'`) FROM `',@s_tb_name,'` WHERE EMP_ID=',@i_emp,' LIMIT 1;');
								PREPARE stmt1 FROM @SQL1;
								EXECUTE stmt1;
								DEALLOCATE PREPARE stmt1;
							END IF;
		
							IF (@s_tb_name = 'emp_salary_subsidy') THEN		
						#这里有如下几种情况
						#	记考勤
						#		从考勤日报里得到实际的开始结束时间
						#	记为全勤
						#		有以下几种情况：
						# 		1.该公司没有考勤设置	所有天数 = 21.75
						# 		2.该公司有考勤设置	且是否计算薪酬开	实际出勤天数 = 计薪标准
						#		3.该公司有考勤设置	且是否计算薪酬关	实际出勤天数=21.75	计薪标准=21.75
							
							#当全勤时，记为自然月起止
								IF i_attsource = 3 THEN
									SET att_bgdt = CONCAT(LEFT(ym,4),'-',RIGHT(ym,2),'-01');
									SET att_eddt = DATE_ADD(DATE_ADD(att_bgdt,INTERVAL 1 MONTH),INTERVAL -1 DAY);
								END IF;
							#是否有考勤
								SELECT COUNT(*) into is_have_att
									FROM att_rel_schema_dept a left join att_set_schema b on a.schema_id=b.att_id 
									WHERE b.is_delete=0 and a.dept_id=i_deptid;
							#记为全勤且没有考勤时
								IF (is_have_att=0 AND i_attsource=3) THEN
									SET SJCQTS = 21.75;
									SET JXTS = 21.75;
									SET YCQGZR = 21.75;
									SET JXBZ = 21.75;
							#记为全勤且有考勤时
								ELSEIF (is_have_att>0 AND i_attsource=3) THEN
									SELECT IF(pay_way IS NULL,0,pay_way) INTO i_pay_way 
										FROM att_rel_schema_dept a left join att_set_schema b on a.schema_id=b.att_id 
										WHERE b.is_delete=0 and a.dept_id=i_deptid;
								#计薪标准为空
									IF i_pay_way = 0 THEN
										SET SJCQTS = 21.75;
										SET JXTS = 21.75;
										SET YCQGZR = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,2);
										SET JXBZ = 21.75;
								#计薪标准21.75
									ELSEIF i_pay_way = 1 THEN 
										SET SJCQTS = 21.75;
										SET JXTS = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,1);
										SET YCQGZR = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,2);
										SET JXBZ = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,1);
								#计薪标准实际工作日
									ELSEIF i_pay_way = 2 THEN 
										SET SJCQTS = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,1);
										SET JXTS = FN_ATT_GET_EMP_REAL_WORKDAY(att_bgdt,att_eddt,i_emp,2);
										SET YCQGZR = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,2);
										SET JXBZ = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,1);
									END IF;
							#导入或者使用考勤，且有出勤方案时
								ELSEIF (is_have_att>0 AND i_attsource<>3) THEN
									SET SJCQTS = FN_ATT_GET_EMP_REAL_WORKDAY(att_bgdt,att_eddt,i_emp,1);
									SET JXTS = FN_ATT_GET_EMP_REAL_WORKDAY(att_bgdt,att_eddt,i_emp,2);
									SET YCQGZR = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,2);
									SET JXBZ = FN_ATT_GET_WORKDAYS(att_bgdt,att_eddt,i_emp,1);	
								END IF;
								
								SELECT sub_pay_way,sub_pay_sum INTO i_sub_pay_way,i_value_num FROM TMP_BASEFILL_SUB where version_code = i_version_code;
		
		
								CASE i_sub_pay_way
								#1	每月固定：固定金额；
									WHEN 1 THEN		
										SET i_value = i_value_num;
								#2	每出勤日：每日金额*实际出勤天数（节假日加班也算）
									WHEN 2 THEN		
										SET i_value = i_value_num*SJCQTS;
								#3	每计薪日：每日金额*计薪天数（实际工作日不包括加班）；
									WHEN 3 THEN		
										SET i_value = i_value_num*JXTS;
								#4	每月(按出勤日)：每月固定金额*实际出勤天数/应出勤工作日； 
									WHEN 4 THEN		
										SET i_value = i_value_num*SJCQTS/YCQGZR;
								#5	每月(按计薪日)）：每月固定金额*计薪天数/计薪标准（如21.75）；		
									WHEN 5 THEN		
										SET i_value = i_value_num*JXTS/JXBZ;
								#其余的		
									ELSE
										SET i_value = i_value_num;
								END CASE;
		
							ELSE
								SELECT COL_VALUE INTO i_value FROM TMP_BASEFILL_A where version_code = i_version_code;
							END IF;
							
							IF i_value IS NULL THEN
								SET i_value = 0;
							END IF;
		
							IF (i_attsource = 3 AND @s_tb_name = 'att_st_month_arch_items') THEN #只有不计考勤的情况不用写数据，其他都王里写
								SET i_value = 0;
							END IF;
					
							SET @i_value = i_value;
							SET @SQL2 = CONCAT('UPDATE `',@des_tb_name,'` SET ',@des_col_name,'= ',@i_value,' WHERE ID=',@prid,';');
		
							IF @SQL2 IS NOT NULL THEN
								PREPARE stmt2 FROM @SQL2;
								EXECUTE stmt2;
								DEALLOCATE PREPARE stmt2;
							END IF;
						END IF;
						SET item_ct = item_ct + 1;
					END WHILE;
								
		
				END IF;
			END IF;																			
			SET emp_ct=emp_ct+1;
		END WHILE;																				
		SET tmp_schids = RIGHT(tmp_schids,LENGTH(tmp_schids)-LOCATE(',',tmp_schids));
		SET tmp_schtps = RIGHT(tmp_schtps,LENGTH(tmp_schtps)-LOCATE(',',tmp_schtps));
		SET sch_ct = sch_ct + 1;
	END WHILE;																								
delete from  `TMP_BASEFILL_A` where version_code = i_version_code;
delete from  `TMP_BASEFILL_B` where version_code = i_version_code;
delete from  `TMP_BASEFILL_C` where version_code = i_version_code;
delete from  `TMP_BASEFILL_SUB` where version_code = i_version_code;

END;

