create procedure SP_ATT_MONTH_REPORT(IN bgdt    date, IN eddt date, IN custid bigint, IN deptid bigint, IN emp bigint,
                                     IN i_st_id bigint, INOUT state int, IN depttype int)
  comment '月报计算'
  BEGIN
DECLARE i_custom_type,MY_YM,MY_BOSSLEVEL,IS_ARCHIVED,IS_HAVE_DAILY,IS_HAVE_ARR,HOL_CT,IS_ARCH,THIS_SONVER,i_hol_rule,i_min_unit,ct,mxct,ctn,mxctn,i_st_type,i_is_year_hol,stat,app_cnt,app_mxcnt,i_enable_time,enb_bgdt,enb_eddt,i_st_unit,i_late_credit,i_late_credit_switch,i_early_credit,i_early_credit_count_switch int;
DECLARE THIS_ATTID,MY_POSITION_LEVEL_ID,THIS_ATTRULE,i_hol_id,i_emp,i_deptid,i_custid,i_applyid,i_act_do_num,i_should_do_num,THIS_HOL_ID,THIS_ST_UNIT,MY_prgm_id,MY_jrdc_id,MY_dms_id4,MY_dms_id5,MY_dms_id6,MY_dms_id7,MY_dms_id8,MY_dms_id9,MY_dms_id10 bigint UNSIGNED;
DECLARE THIS_ST_VALUE,THIS_HOL_DAYS,MY_HOL_DAYS,i_daily_work_hour,MY_HOL_HOURS,MY_DAILY_HOL_HOURS,i_hol_days DECIMAL(15,5);
DECLARE HOL_CODE,i_st_key,i_st_name,i_st_value,i_uid VARCHAR(50);
DECLARE HOL_BGDT,HOL_EDDT,i_bgdt,i_regu_date,my_begin_date,my_end_date,i_entry_date,i_leave_date,THIS_ATT_BGDT,THIS_ATT_EDDT date;
DECLARE THIS_HOL_BGTM,THIS_HOL_EDTM,i_start_time,i_end_time TIME;
DECLARE i_op_time datetime;
DECLARE i_version_code,MY_OWNERSHIP_PLACE VARCHAR(50);
DECLARE MY_EMP_NAME,MY_EMP_CODE,MY_POSITION_LEVEL_NAME VARCHAR(50);
DECLARE ATT_DETAIL_STR,ORI_ATT_DETAIL_STR,THIS_ATT_DETAIL_STR TEXT;
DECLARE this_wcbzcs,this_cdcs,this_cd,this_ztcs,this_zt,this_kgcs,this_kgss,this_bqcs,this_jrjbsc,this_byxzbxxs,this_ybzcqgs,this_yyxcqgs decimal(15,5);
DECLARE all_wcbzcs,all_cdcs,all_cd,all_ztcs,all_zt,all_kgcs,all_kgss,all_bqcs,all_jrjbsc,all_byxzbxxs,all_ybzcqgs,all_yyxcqgs decimal(15,5);
DECLARE this_ygsqsxs,this_sd_szqnjybx,this_sd_jzsybzqzjybx,this_sd_bxzjy,this_sd_jzdykxnj,this_sd_jzdnkxnj,this_sd_fdnwxnj,this_sd_njzjy,this_hw_byxzffjbxs,this_hw_byjsffjbxs,this_hw_ylffjbxs,this_hw_khgs,this_sjdkgzsc,this_kqkx,this_jbsc,this_jbf,MY_FLEXHOUR,MY_MONTHFLEX decimal(15,5);
DECLARE all_qjsc,all_ygsqsxs,all_sd_szqnjybx,all_sd_jzsybzqzjybx,all_sd_bxzjy,all_sd_jzdykxnj,all_sd_jzdnkxnj,all_sd_fdnwxnj,all_sd_njzjy,all_hw_byxzffjbxs,all_hw_byjsffjbxs,all_hw_ylffjbxs,all_hw_khgs,all_fhw_hsbcbxkj,all_sjdkgzsc,all_kqkx,all_jbsc,all_jbf decimal(15,5);
DECLARE this_sd_jzbydkxnj,this_hw_omp_cxsjbgs,all_ycqts,all_gzrts,all_fdjjrts,all_sjcqts,all_sd_jzbydkxnj,all_hw_omp_sjjbgs,all_hw_omp_cxsjbgs decimal(15,5);
DECLARE this_TYPE0001,this_TYPE0002,this_TYPE0003,this_TYPE0004,this_TYPE0005,this_TYPE0006,this_TYPE0007,this_TYPE0008,this_TYPE0009,this_TYPE0010,this_TYPE0011,this_TYPE0012,this_TYPE0013,this_TYPE0014,this_TYPE0015 decimal(15,5);
DECLARE all_TYPE0001,all_TYPE0002,all_TYPE0003,all_TYPE0004,all_TYPE0005,all_TYPE0006,all_TYPE0007,all_TYPE0008,all_TYPE0009,all_TYPE0010,all_TYPE0011,all_TYPE0012,all_TYPE0013,all_TYPE0014,all_TYPE0015 decimal(15,5);
DECLARE this_TYPE0016,this_TYPE0017,this_TYPE0018,this_TYPE0019,this_TYPE0020,this_TYPE0021,this_TYPE0022,this_TYPE0023,this_TYPE0024,this_TYPE0025,this_TYPE0026,this_TYPE0027,this_TYPE0028,this_TYPE0029,this_TYPE0030 decimal(15,5);
DECLARE all_TYPE0016,all_TYPE0017,all_TYPE0018,all_TYPE0019,all_TYPE0020,all_TYPE0021,all_TYPE0022,all_TYPE0023,all_TYPE0024,all_TYPE0025,all_TYPE0026,all_TYPE0027,all_TYPE0028,all_TYPE0029,all_TYPE0030 decimal(15,5);
DECLARE all_hw_khgsyy VARCHAR(200);
DECLARE MY_DEPT_NAME VARCHAR(500);
DECLARE CALLTIME DATETIME;

	SET i_version_code = UUID();
	SET @i_version_code = i_version_code;
	SET CALLTIME = NOW();
	
	IF eddt >= DATE_ADD(DATE(CALLTIME),INTERVAL -1 DAY) THEN
		IF MONTH(CALLTIME) = MONTH(DATE_ADD(DATE(CALLTIME),INTERVAL -1 DAY)) THEN
			SET eddt = DATE_ADD(DATE(CALLTIME),INTERVAL -2 DAY);
		END IF;
	END IF;
	set i_act_do_num=0;

	IF (i_st_id IS NOT NULL and state=0 or state is null AND bgdt<=eddt) THEN		#月报id是必填参数，否则无法写入
		#################################################################
		#																					 #
		#						PART 1   初始化										 #
		#																					 #
		#################################################################


		/*
		stat 1 emp		emp is not null 按员工查						
		stat 2 detp		deptid is not null and emp is null 按部门查
		stat 3 custid  custid is not null and deptid is null and emp is null; 按公司查
		stat 4 all		custid is null and deptid is null and emp is null  全局查
		*/
		if (custid is not null and deptid is null and emp is null) then
			set stat=3;
		elseif (deptid is not null and depttype is not null and emp is null) then
			set stat=2;
		elseif (emp is not null) then
			set stat=1;
		end if;
		#根据不同的参数输入情况初始化要遍历的员工列表	
		case stat
		when 1 then
			#得到变量
			SELECT cust_id INTO i_custid FROM emp_base_info A WHERE A.emp_id=emp;
			#判断是否有日报，没有日报，不跑
			SELECT COUNT(*) INTO IS_HAVE_DAILY FROM att_emp_detail A WHERE A.emp_id=emp AND A.dt BETWEEN bgdt AND eddt;
			set IS_ARCHIVED = 0;
			SELECT A.archive_state INTO IS_ARCHIVED FROM att_st_month A WHERE A.st_id=i_st_id ;
			SELECT A.personal_archive_state + IFNULL(IS_ARCHIVED,0) INTO IS_ARCHIVED FROM att_st_month_quick_view_icss A WHERE A.st_id=i_st_id AND A.emp_id=emp;

			IF IS_HAVE_DAILY IS NULL OR IS_HAVE_DAILY=0 OR IS_ARCHIVED > 0 THEN
				SET emp = NULL;
			END IF;

		when 2 then
			SELECT cust_id INTO i_custid FROM dept_info A WHERE A.dept_id=deptid;
			CASE depttype 
			WHEN 1 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id 
					from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.dept_id=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;

			WHEN 2 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.prgm_id=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			WHEN 3 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.jrdc_id=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			WHEN 4 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.dms_id4=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			WHEN 5 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.dms_id5=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			WHEN 6 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.dms_id6=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			WHEN 7 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.dms_id7=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			WHEN 8 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.dms_id8=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			WHEN 9 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.dms_id9=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			WHEN 10 THEN
				#写入列表
				insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
					select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
						left join att_emp_detail d on b.emp_id=d.emp_id
					where b.dms_id10=deptid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
						and d.dt between bgdt and eddt;
			END CASE;
		when 3 then
			SET i_custid = custid;
			#写入列表
			insert into tmp_att_month_emp_list (version_code,emp_id,dept_id,cust_id) 
				select distinct i_version_code,b.emp_id,b.dept_id,b.cust_id from att_st_month a left join emp_base_info b on a.cust_id = b.cust_id left join emp_post c on b.emp_id=c.emp_id
					left join att_emp_detail d on b.emp_id=d.emp_id
				where b.cust_id=custid and (b.boss_level<>1 or b.boss_level is null) and b.emp_state is not null and b.is_delete=0 and (c.leave_date is null or c.leave_date >= bgdt) and c.entry_date <= eddt AND c.entry_date is not null and (a.archive_state=0 or a.archive_state is null) and a.st_id=i_st_id
					and d.dt between bgdt and eddt;
		end case;
		
		#################################################################
		#																					 #
		#		PART 2  根据每个人所在的公司的假期设置统计具体数  		  #
		#																					 #
		#################################################################
		
		# 获取临时表中id起止点，轮流计算和写入月报表。
		SET ct = 0;
		SET mxct = 0;
		
		IF stat = 1 THEN
			SET ct=1,mxct=1,i_should_do_num=1;
		ELSE
			SELECT MIN(ID),MAX(ID),count(*) INTO ct,mxct,i_should_do_num FROM tmp_att_month_emp_list where version_code = i_version_code;
		END IF;
		

		INSERT INTO att_month_report_oplog 
			(id,call_time,should_do_num,bgdt,eddt,cust_id,dept_id,emp_id,st_id,DEPT_TYPE) 
		VALUES
			(i_version_code,NOW(),i_should_do_num,bgdt,eddt,custid,deptid,emp,i_st_id,depttype);

			
#		insert into att_month_report_oplog (id,call_time,`spname`,`bgdt`,`eddt`,`cust_id`,`dept_id`,`emp_id`,`st_id`,`should_do_num`)  
#												values (i_version_code,now(),'SP_ATT_MONTH_REPORT',bgdt,eddt,custid,deptid,emp,i_st_id,i_should_do_num);

		WHILE (ct <= mxct) DO											#LOOP OUTSIDE 轮询tmp_att_month_emp_list
			#初始化变量
			SET i_emp = NULL;
			SET i_deptid = NULL;
			SET i_custid = NULL;
			set my_begin_date = null;
			set my_end_date = null;
			
			#得到该员工的各项id
			IF stat = 1 AND emp IS NOT NULL THEN
				SELECT emp_id,dept_id,cust_id INTO i_emp,i_deptid,i_custid 
				FROM emp_base_info 
				WHERE emp_id = emp;
			ELSE
				SELECT emp_id,dept_id,cust_id INTO i_emp,i_deptid,i_custid 
				FROM tmp_att_month_emp_list 
				WHERE id = ct and version_code = i_version_code;
			END IF;
			
			IF i_emp IS NOT NULL THEN
				SET MY_YM = NULL;
				SELECT A.year_mon INTO MY_YM
				FROM cust_period_schedule A
				WHERE A.cust_id=i_custid AND A.period_type=1 AND A.begin_date = bgdt LIMIT 1;
				
				SET IS_ARCH = NULL;
				SELECT a.personal_archive_state into IS_ARCH from att_st_month_quick_view_icss a where a.st_id=i_st_id and a.emp_id=i_emp;
				
				IF IS_ARCH = 0 OR IS_ARCH IS NULL THEN
					IF IS_ARCH = 0 THEN
						DELETE FROM att_st_month_quick_view_icss where st_id=i_st_id and emp_id=i_emp;
					END IF;
					#初始化数据
					SET MY_prgm_id=NULL, MY_jrdc_id=NULL, MY_dms_id4=NULL, MY_dms_id5=NULL, MY_dms_id6=NULL, MY_dms_id7=NULL, MY_dms_id8=NULL, MY_dms_id9=NULL, MY_dms_id10=NULL,MY_BOSSLEVEL=NULL;
					SET MY_OWNERSHIP_PLACE=NULL,i_custom_type=NULL;
					SET all_qjsc=0,all_ycqts=0,all_gzrts=0,all_fdjjrts=0,all_sjcqts=0,all_wcbzcs=0,all_cdcs=0,all_cd=0,all_ztcs=0,all_zt=0,all_kgcs=0,all_kgss=0,all_bqcs=0;
					SET all_jrjbsc=0,all_byxzbxxs=0,all_ybzcqgs=0,all_yyxcqgs=0,all_ygsqsxs=0,all_sd_szqnjybx=0,all_sd_jzsybzqzjybx=0,all_sd_bxzjy=0,all_sd_jzdykxnj=0,all_sd_jzdnkxnj=0,all_sd_fdnwxnj=0;
					SET all_sd_jzbydkxnj=0,all_sd_njzjy=0,all_hw_omp_sjjbgs=0,all_hw_omp_cxsjbgs=0,all_hw_byxzffjbxs=0,all_hw_byjsffjbxs=0,all_hw_ylffjbxs=0,all_hw_khgs=0,all_hw_khgsyy='',all_fhw_hsbcbxkj=0;
					SET all_sjdkgzsc=0,all_kqkx=0,all_jbsc=0,all_jbf=0,all_TYPE0001=0,all_TYPE0002=0,all_TYPE0003=0,all_TYPE0004=0,all_TYPE0005=0,all_TYPE0006=0,all_TYPE0007=0,all_TYPE0008=0,all_TYPE0009=0;
					SET all_TYPE0010=0,all_TYPE0011=0,all_TYPE0012=0,all_TYPE0013=0,all_TYPE0014=0,all_TYPE0015=0,all_TYPE0016=0,all_TYPE0017=0,all_TYPE0018=0,all_TYPE0019=0,all_TYPE0020=0,all_TYPE0021=0,all_TYPE0022=0;
					SET all_TYPE0023=0,all_TYPE0024=0,all_TYPE0025=0,all_TYPE0026=0,all_TYPE0027=0,all_TYPE0028=0,all_TYPE0029=0,all_TYPE0030=0;

					#得到基础信息 and 员工转正日期
					SET i_regu_date = NULL;
					SET i_entry_date = NULL;
					SET i_leave_date = NULL;

					SELECT A.boss_level,A.emp_name,B.emp_code,B.position_level_id,D.position_level_name,C.dept_full_name,A.prgm_id,A.jrdc_id,A.dms_id4,A.dms_id5,A.dms_id6,A.dms_id7,A.dms_id8,A.dms_id9,A.dms_id10,E.dept_name,
							B.regu_date,B.entry_date,B.leave_date,C.custom_type
						INTO MY_BOSSLEVEL,MY_EMP_NAME,MY_EMP_CODE,MY_POSITION_LEVEL_ID,MY_POSITION_LEVEL_NAME,MY_DEPT_NAME,MY_prgm_id,MY_jrdc_id,MY_dms_id4,MY_dms_id5,MY_dms_id6,MY_dms_id7,MY_dms_id8,MY_dms_id9,MY_dms_id10,MY_OWNERSHIP_PLACE,
							i_regu_date,i_entry_date,i_leave_date,i_custom_type
					FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
						LEFT JOIN dept_info C ON A.dept_id=C.dept_id
						LEFT JOIN dept_pos_level D ON B.position_level_id=D.position_level_id
						LEFT JOIN dept_info E ON A.dms_id5 = E.dept_id
					WHERE A.emp_id = i_emp;					
					
					#每个人的实际周期，考虑到入离职时间
					IF (i_entry_date > bgdt and i_entry_date is not null) THEN
						SET my_begin_date=i_entry_date;
					else
						SET my_begin_date=bgdt;
					end if;
									
					IF (i_leave_date<eddt and i_leave_date is not null) THEN
						SET my_end_date=i_leave_date;
					else
						SET my_end_date=eddt;
					end if;
	
#第一波全局计算变量，不需要分段计算求和
	#1 法定节假日天数
					SET all_fdjjrts = IFNULL(FN_ATT_GET_WORKDAYS_GENERAL(bgdt,eddt,2),0);
	#2 工作日天数
					SET all_gzrts = IFNULL(FN_ATT_GET_WORKDAYS_GENERAL(bgdt,eddt,1),0);
	#3 应出勤天数
					SET all_ycqts = all_fdjjrts + all_gzrts;
#select all_ycqts;
	#4 实际出勤天数
					#当月有入离职
					IF (i_leave_date <= eddt AND i_leave_date >= bgdt) OR (i_entry_date <= eddt AND i_entry_date >= bgdt) THEN
						SET all_sjcqts = FN_ATT_GET_WORKDAYS(my_begin_date,my_end_date,i_emp,2) + IFNULL(FN_ATT_GET_HOLIDAY_NUMS(my_begin_date,my_end_date,1,i_emp),0);
					#当月无入离职
					ELSE
						SET all_sjcqts = all_ycqts;
					END IF;
	#5 晚餐补助次SHU					
					SELECT SUM(IF(IFNULL(A.wcbzcs,0) + IFNULL(B.wcbzcs,0)>0,1,0) ) WCBZCS INTO all_wcbzcs 
					FROM att_emp_detail A 
						LEFT JOIN att_hol_apply_day B ON A.emp_id=B.emp_id AND A.dt=B.hol_date AND B.is_year_hol=10
					WHERE A.dt BETWEEN my_begin_date AND my_end_date AND A.emp_id=i_emp;
						
	#6 hw_omp_sjjbgs	华为OMP中实际加班工时（天）
	#7 hw_omp_cxsjbgs	已乘系数的OMP加班工时（天）
	#8 hw_byxzffjbxs	本月新增付费加班小时数
	#9 hw_khgs	确认缺勤工时差异需扣回工时			
	#10 hw_khgsyy	扣回工时差异原因说明
					SELECT SUM(IFNULL(A.OVERTIME_WORKLOAD,0)),SUM(IFNULL(A.RIDE_COEFFICIENT_WORK_HOUR,0)),SUM(IFNULL(A.RIDE_COEFFICIENT_WORK_HOUR,0))*8,
							SUM(IFNULL(A.NEED_DEDUCT_WORKLOAD,0)),GROUP_CONCAT(IFNULL(A.DIFFERENCE_REASON,''))
						INTO all_hw_omp_sjjbgs,all_hw_omp_cxsjbgs,all_hw_byxzffjbxs,
							all_hw_khgs,all_hw_khgsyy
					FROM icss_work_overtime_result_ti A
					WHERE A.EMP_ID=i_emp AND A.LAST_UPDATE_TIME BETWEEN CONCAT(bgdt,' 05:00:00') AND CONCAT(DATE_ADD(eddt,INTERVAL 1 DAY),' 04:59:59');
	#11 hw_byjsffjbxs	本月结算的付费加班小时
	#12 hw_ylffjbxs	预留付费加班小时
					#本月有离职
					IF i_leave_date IS NOT NULL AND i_leave_date >= bgdt AND i_leave_date <= eddt THEN
						SET all_hw_byjsffjbxs = 0;
						SELECT SUM(IFNULL(A.settlement_hours,0))
							INTO all_hw_ylffjbxs
						FROM icss_work_overtime_hol_pay_rest A
						WHERE A.emp_id=i_emp AND A.ctg_ym=MY_YM;

					#本月无离职
					ELSE
						SELECT SUM(IFNULL(A.settlement_hours,0))
							INTO all_hw_byjsffjbxs
						FROM icss_work_overtime_hol_pay_rest A
						WHERE A.emp_id=i_emp AND A.ctg_ym=MY_YM;
						
						SET all_hw_ylffjbxs = 0;
					END IF;
	#13 qjsc	预留付费加班小时
					SELECT IFNULL(SUM(IFNULL(A.hol_hours,0)),0)
						INTO all_qjsc
					FROM att_hol_apply_day A
					WHERE A.emp_id=i_emp AND A.hol_date BETWEEN my_begin_date AND my_end_date
						AND A.apply_id <> 0 AND A.apply_id IS NOT NULL;
#<-------------------------------------------------------------------------------------------第一波全局计算结束


					
					SET ATT_DETAIL_STR = NULL;
					#得到考勤方式
					SELECT GROUP_CONCAT(RES) 
						INTO ATT_DETAIL_STR
					FROM 
						(
						SELECT CONCAT(IFNULL(A.att_id,''),'|',IFNULL(A.att_rule,''),'|',IFNULL(MIN(A.dt),''),'|',IFNULL(MAX(A.dt),'')) RES
						FROM att_emp_detail A
						WHERE A.emp_id= i_emp AND A.dt BETWEEN my_begin_date AND my_end_date AND A.att_id IS NOT NULL AND A.att_rule IS NOT NULL
						GROUP BY A.att_id,A.att_group_number
						) ABC;
					SET ATT_DETAIL_STR = CONCAT(ATT_DETAIL_STR,',');
					SET ORI_ATT_DETAIL_STR = ATT_DETAIL_STR;
	
					#开始为员工在月报期间内的每一个出勤方案计算相应的汇总计算
					WHILE LOCATE(',',ATT_DETAIL_STR) <= LENGTH(ATT_DETAIL_STR) AND LOCATE(',',ATT_DETAIL_STR)>1 AND ATT_DETAIL_STR IS NOT NULL DO
						#解析日报中的不同的考勤方案及其起止时间点
						#得到出勤方案
						SET THIS_ATT_DETAIL_STR = CONCAT(LEFT(ATT_DETAIL_STR,LOCATE(',',ATT_DETAIL_STR)-1),'|');
						SET THIS_ATTID = CAST(LEFT(THIS_ATT_DETAIL_STR,LOCATE('|',THIS_ATT_DETAIL_STR)-1) AS UNSIGNED);

						#得到出勤规则
						SET THIS_ATT_DETAIL_STR = RIGHT(THIS_ATT_DETAIL_STR,LENGTH(THIS_ATT_DETAIL_STR)-(LENGTH(THIS_ATTID)+1));
						SET THIS_ATTRULE = CAST(LEFT(THIS_ATT_DETAIL_STR,LOCATE('|',THIS_ATT_DETAIL_STR)-1) AS UNSIGNED);

						#得到起始时间点
						SET THIS_ATT_DETAIL_STR = RIGHT(THIS_ATT_DETAIL_STR,LENGTH(THIS_ATT_DETAIL_STR)-(LENGTH(THIS_ATTRULE)+1));
						SET THIS_ATT_BGDT = CAST(LEFT(THIS_ATT_DETAIL_STR,LOCATE('|',THIS_ATT_DETAIL_STR)-1) AS DATE);

						#得到结束时间点
						SET THIS_ATT_DETAIL_STR = RIGHT(THIS_ATT_DETAIL_STR,LENGTH(THIS_ATT_DETAIL_STR)-(LENGTH(THIS_ATT_BGDT)+1));
						SET THIS_ATT_EDDT = CAST(LEFT(THIS_ATT_DETAIL_STR,LOCATE('|',THIS_ATT_DETAIL_STR)-1) AS DATE);

	
						CALL SP_ATT_MONTH_CONSTRAINT_SINGLE(THIS_ATT_BGDT,THIS_ATT_EDDT,i_emp);
#						CALL SP_ATT_MONTH_CONSTRAINT_DERATE_SINGLE(THIS_ATT_BGDT,THIS_ATT_EDDT,i_emp);
#						CALL SP_ATT_MONTH_HOLIDAY_FINE_SINGLE(THIS_ATT_BGDT,THIS_ATT_EDDT,i_emp);
#						CALL SP_ATT_MONTH_ATT_FINE_SINGLE(THIS_ATT_BGDT,THIS_ATT_EDDT,i_emp);
#						CALL SP_ATT_MONTH_OVER_PAY_SINGLE(THIS_ATT_BGDT,THIS_ATT_EDDT,i_emp,i_st_id);
	
################################计算单项开始########################################
						SET this_wcbzcs=0,this_cdcs=0,this_cd=0,this_ztcs=0,this_zt=0;
						SET this_kgcs=0,this_kgss=0,this_bqcs=0,this_jrjbsc=0,this_byxzbxxs=0,this_ybzcqgs=0,this_yyxcqgs=0;
						SET this_ygsqsxs=0,this_sd_szqnjybx=0,this_sd_jzsybzqzjybx=0,this_sd_bxzjy=0,this_sd_jzdykxnj=0,this_sd_jzdnkxnj=0,this_sd_fdnwxnj=0;
						SET this_sd_jzbydkxnj=0,this_sd_njzjy=0;
						SET this_hw_khgs=0,this_sjdkgzsc=0,this_kqkx=0,this_jbsc=0,this_jbf=0,this_TYPE0001=0,this_TYPE0002=0,this_TYPE0003=0;
						SET this_TYPE0004=0,this_TYPE0005=0,this_TYPE0006=0,this_TYPE0007=0,this_TYPE0008=0,this_TYPE0009=0,this_TYPE0010=0,this_TYPE0011=0,this_TYPE0012=0;
						SET this_TYPE0013=0,this_TYPE0014=0,this_TYPE0015=0,this_TYPE0016=0,this_TYPE0017=0,this_TYPE0018=0,this_TYPE0019=0,this_TYPE0020=0,this_TYPE0021=0;
						SET this_TYPE0022=0,this_TYPE0023=0,this_TYPE0024=0,this_TYPE0025=0,this_TYPE0026=0,this_TYPE0027=0,this_TYPE0028=0,this_TYPE0029=0,this_TYPE0030=0;

	
#第二波考勤分段计算变量
#1 cd 迟到（小时）
						SELECT ROUND((SUM(IF(A.late_mins IS NULL,0,A.late_mins) - IF(A.derate_late_mins IS NULL,0,A.derate_late_mins)))/60,2) INTO this_cd 
						FROM att_emp_detail A 
						WHERE A.emp_id=i_emp and dt between THIS_ATT_BGDT and THIS_ATT_EDDT and is_dayoff=0;						
						
#2 迟到次数	WHEN 'cdcs' THEN				
						SELECT COUNT(*) INTO this_cdcs 
						FROM att_emp_detail A 
						WHERE A.emp_id = i_emp and A.dt between THIS_ATT_BGDT and THIS_ATT_EDDT 
							and A.date_type in (1,6) and is_dayoff=0 AND A.late_mins - A.derate_late_mins > 0;			
#3 早退（小时）
						SELECT ROUND((SUM(IF(A.early_mins IS NULL,0,A.early_mins) - IF(A.derate_early_mins IS NULL,0,A.derate_early_mins)))/60,2) INTO this_zt 
						FROM att_emp_detail A 
						WHERE A.emp_id=i_emp and dt between THIS_ATT_BGDT and THIS_ATT_EDDT and is_dayoff=0;			
#4 早退次数	WHEN 'ztcs' THEN				
						SELECT COUNT(*) INTO this_ztcs 
						FROM att_emp_detail A 
						WHERE A.emp_id = i_emp and A.dt between THIS_ATT_BGDT and THIS_ATT_EDDT 
							and A.date_type in (1,6) and is_dayoff=0 AND A.early_mins - A.derate_early_mins > 0;		
#5 旷工次数	WHEN 'kgcs' THEN 				
						SELECT COUNT(*) INTO this_kgcs FROM att_emp_detail A WHERE A.emp_id=i_emp AND A.dt BETWEEN THIS_ATT_BGDT AND THIS_ATT_EDDT AND A.is_dayoff<>0;											
#6 矿工时数
						SELECT (SUM(IFNULL(A.late_mins,0))+SUM(IFNULL(A.early_mins,0))-SUM(IFNULL(A.derate_late_mins,0))-SUM(IFNULL(A.derate_early_mins,0)))/60
							INTO this_kgss
						FROM att_emp_detail A  
						WHERE emp_id = i_emp and dt between THIS_ATT_BGDT and THIS_ATT_EDDT and  is_dayoff>0;
#7 补签次数	WHEN 'bqcs' THEN 				
						SELECT COUNT(*) INTO this_bqcs FROM att_check_apply A WHERE A.emp_id=i_emp AND A.state=1 AND A.check_time BETWEEN CONCAT(THIS_ATT_BGDT,' 00:00:00') and CONCAT(THIS_ATT_EDDT,' 23:59:59') AND A.data_source=1;
#8 节日加班时长（小时）	WHEN 'jrjbsc' THEN			
						SELECT ROUND(sum(if(a.work_hour is null,0,a.work_hour)),2) INTO this_jrjbsc 
						FROM att_over_apply_day a left join att_over_apply b on a.apply_id=b.apply_id
						WHERE a.emp_id = i_emp and work_day between THIS_ATT_BGDT and THIS_ATT_EDDT and a.date_type = 3
							and b.is_delete=0 and b.is_clear=0 and b.state=1 and a.date_repay_type=1 AND a.is_over_with_rest=0; 							
#9 本月新增补休小时
						SELECT SUM(A.work_hour) INTO this_byxzbxxs
						FROM att_over_apply_day A 
						WHERE A.emp_id	= i_emp AND A.work_day between THIS_ATT_BGDT and THIS_ATT_EDDT AND A.date_repay_type=2 AND A.is_over_with_rest=0;		

#10 sjdkgzsc 实际打卡工作时长
						SELECT ROUND(SUM(IFNULL(A.check_work_interval,0))/60,2) INTO this_sjdkgzsc
						FROM att_emp_detail A 
						WHERE A.emp_id	= i_emp AND A.dt between THIS_ATT_BGDT and THIS_ATT_EDDT AND A.date_type IN (1,6);		




#100 考勤扣薪	WHEN 'kqkx' THEN				
						SELECT ROUND(SUM(dock_pay),2) INTO this_kqkx FROM att_emp_detail WHERE emp_id = i_emp and dt between THIS_ATT_BGDT and THIS_ATT_EDDT;
						
								
#101 加班时长	WHEN 'jbsc' THEN				
						SELECT ROUND(sum(IF(a.work_hour IS NULL,0,a.work_hour)),2)INTO this_jbsc 
						FROM att_over_apply_day a 
						WHERE emp_id = i_emp and work_day between THIS_ATT_BGDT and THIS_ATT_EDDT AND a.is_over_with_rest=0;
														
#102 加班费	WHEN 'jbf' THEN				
						SELECT ROUND(sum(if(a.pay_money is null,0,a.pay_money)),2)INTO this_jbf 
						FROM att_over_apply_day a left join att_over_apply b on a.apply_id=b.apply_id
						WHERE a.emp_id = i_emp and work_day between THIS_ATT_BGDT and THIS_ATT_EDDT 
							and b.is_delete=0 and b.is_clear=0 and b.state=1 and a.date_repay_type=1 AND a.is_over_with_rest=0; 

					

						#普通员工和白名单中计算假期的才计算
						IF MY_BOSSLEVEL <> 3 OR MY_BOSSLEVEL IS NULL	THEN
	#32 假期
							SET HOL_CT = 1;
							#预留30个假期位
							WHILE HOL_CT <= 30 DO
								SET THIS_ST_VALUE=0,i_daily_work_hour=0;
								#拼code
								IF HOL_CT < 10 THEN
									SET HOL_CODE = CONCAT('TYPE000',HOL_CT);
								ELSEIF HOL_CT < 100 AND HOL_CT >= 10 THEN
									SET HOL_CODE = CONCAT('TYPE00',HOL_CT);
								END IF;
								SET i_hol_id=NULL,i_st_name=NULL,i_is_year_hol=NULL,i_st_unit=NULL,i_min_unit=NULL,i_hol_rule=NULL;
								#依次读取假期信息
								SELECT A.hol_id,A.hol_name,A.is_year_hol,A.st_unit,A.hol_unit,A.hol_rule  
								 INTO i_hol_id,i_st_name,i_is_year_hol,i_st_unit,i_min_unit,i_hol_rule
								FROM att_set_holiday_main A 
								WHERE A.cust_id = i_custid AND A.hol_code = HOL_CODE AND A.is_delete=0 AND A.`status`=1;
								IF i_hol_id IS NOT NULL THEN
	#SELECT HOL_CODE,i_hol_id,i_st_name,i_is_year_hol,i_st_unit,i_min_unit,i_hol_rule;
								
			#32.1 坐班
									IF THIS_ATTRULE = 1 THEN
				#先得到每天应工作小时 i_daily_work_hour
										SET i_daily_work_hour = FN_ATT_GET_WORKHOURS(THIS_ATTID);	
										SET MY_HOL_HOURS = 0;
				#请假规则按自然日，需要增加工作日的统计
										IF i_hol_rule = 2 THEN
					#根据时间段从日报求和
											SELECT SUM(hol_hours) INTO MY_HOL_HOURS FROM att_hol_apply_day 
											WHERE EMP_ID=i_emp AND hol_date BETWEEN THIS_ATT_BGDT and THIS_ATT_EDDT 
												AND hol_id=i_hol_id;
											IF MY_HOL_HOURS IS NULL THEN SET MY_HOL_HOURS=0 ; END IF;
					#根据半天flag计算天数
											SET MY_HOL_DAYS = 0;
											SELECT count(*) * 0.5 INTO MY_HOL_DAYS FROM att_hol_apply_day A 
											WHERE EMP_ID=i_emp AND hol_date BETWEEN THIS_ATT_BGDT and THIS_ATT_EDDT AND A.half_day_flag IN (1,2) 
												AND hol_id=i_hol_id;
											IF MY_HOL_DAYS IS NULL THEN SET MY_HOL_DAYS = 0; END IF;									
											SELECT count(*) + MY_HOL_DAYS INTO MY_HOL_DAYS FROM att_hol_apply_day A 
											WHERE EMP_ID=i_emp AND hol_date BETWEEN THIS_ATT_BGDT and THIS_ATT_EDDT AND A.half_day_flag =3 
												AND hol_id=i_hol_id;
											IF MY_HOL_DAYS IS NULL THEN SET MY_HOL_DAYS = 0; END IF;
		
				#请假规则按工作日，gzr的内容为0
										ELSEIF i_hol_rule = 1 THEN
					#根据时间段从日报求和
											SELECT SUM(hol_hours) INTO MY_HOL_HOURS FROM att_hol_apply_day 
											WHERE EMP_ID=i_emp AND hol_date BETWEEN THIS_ATT_BGDT and THIS_ATT_EDDT 
												AND hol_id=i_hol_id;
											IF MY_HOL_HOURS IS NULL THEN SET MY_HOL_HOURS=0 ; END IF;
					#根据半天flag计算天数
											SET MY_HOL_DAYS = 0;
											SELECT count(*) * 0.5 INTO MY_HOL_DAYS FROM att_hol_apply_day A 
											WHERE EMP_ID=i_emp AND hol_date BETWEEN THIS_ATT_BGDT and THIS_ATT_EDDT AND A.half_day_flag IN (1,2) 
												AND hol_id=i_hol_id;
											IF MY_HOL_DAYS IS NULL THEN SET MY_HOL_DAYS = 0; END IF;									
											SELECT count(*) + MY_HOL_DAYS INTO MY_HOL_DAYS FROM att_hol_apply_day A 
											WHERE EMP_ID=i_emp AND hol_date BETWEEN THIS_ATT_BGDT and THIS_ATT_EDDT AND A.half_day_flag =3 
												AND hol_id=i_hol_id;
											IF MY_HOL_DAYS IS NULL THEN SET MY_HOL_DAYS = 0; END IF;
											END IF;
			
										IF i_st_unit = 1 THEN	#天
											IF i_min_unit <> 4 THEN
												SET THIS_ST_VALUE = CONCAT(ROUND(MY_HOL_HOURS/i_daily_work_hour,5),'');
											ELSEIF i_min_unit = 4 THEN
												SET THIS_ST_VALUE = MY_HOL_DAYS;	
											END IF;
														
										ELSEIF i_st_unit = 2 THEN #小时
											SET THIS_ST_VALUE = MY_HOL_HOURS;
										END IF;
										
			#32.2排班
									ELSEIF THIS_ATTRULE = 3 THEN															
										SET MY_HOL_HOURS = 0,HOL_BGDT=NULL,HOL_EDDT=NULL;
										SELECT MIN(HOL_DATE),MAX(HOL_DATE) INTO HOL_BGDT,HOL_EDDT 
										FROM att_hol_apply_day A 
										WHERE A.hol_id=i_hol_id AND emp_id = i_emp and hol_date between THIS_ATT_BGDT and THIS_ATT_EDDT;
										WHILE HOL_BGDT<=HOL_EDDT AND HOL_BGDT IS NOT NULL DO
											SET i_daily_work_hour = 0,MY_DAILY_HOL_HOURS=0,THIS_HOL_BGTM=NULL,THIS_HOL_EDTM=NULL;
											
					#当天是否有排班
											SET IS_HAVE_ARR = 0;
											SELECT COUNT(*) INTO IS_HAVE_ARR
											FROM att_arrange_schedual A
											WHERE A.emp_id=i_emp AND A.dt=HOL_BGDT;
		
											SELECT sum(IFNULL(A.hol_hours,0)) INTO MY_DAILY_HOL_HOURS
											FROM att_hol_apply_day A 
											WHERE A.emp_id = i_emp AND A.hol_date=HOL_BGDT AND A.hol_hours>0 AND A.hol_id=i_hol_id;
											
											IF MY_DAILY_HOL_HOURS IS NULL THEN SET MY_DAILY_HOL_HOURS=0 ; END IF;
											
					#当天应工作小时
											IF i_hol_rule = 1 THEN
												SET i_daily_work_hour = FN_ATT_GET_ARR_WORKHOURS(i_emp,HOL_BGDT)/60;
											ELSEIF i_hol_rule = 2 THEN
												SET i_daily_work_hour = 24;
											END IF;
											
					#根据不同的统计单位进行累计
											IF i_st_unit = 1 THEN	#天
												SET MY_HOL_HOURS = MY_HOL_HOURS + ROUND(MY_DAILY_HOL_HOURS/i_daily_work_hour,2);
											ELSEIF i_st_unit = 2 THEN #小时
												SET MY_HOL_HOURS = MY_HOL_HOURS + MY_DAILY_HOL_HOURS;
											END IF;
											
											SET HOL_BGDT = DATE_ADD(HOL_BGDT,INTERVAL 1 DAY);
										END WHILE;
										
				#累加
										SET THIS_ST_VALUE = MY_HOL_HOURS;										
				#算钱
									END IF;
									IF THIS_ST_VALUE IS NULL THEN SET THIS_ST_VALUE = 0 ; END IF;
			#分配变量
									CASE HOL_CT 
									WHEN 1 THEN	
										SET this_TYPE0001 = THIS_ST_VALUE;
									WHEN 2 THEN	
										SET this_TYPE0002 = THIS_ST_VALUE;
									WHEN 3 THEN	
										SET this_TYPE0003 = THIS_ST_VALUE;
									WHEN 4 THEN	
										SET this_TYPE0004 = THIS_ST_VALUE;
									WHEN 5 THEN	
										SET this_TYPE0005 = THIS_ST_VALUE;
									WHEN 6 THEN	
										SET this_TYPE0006 = THIS_ST_VALUE;
									WHEN 7 THEN	
										SET this_TYPE0007 = THIS_ST_VALUE;
									WHEN 8 THEN	
										SET this_TYPE0008 = THIS_ST_VALUE;
									WHEN 9 THEN	
										SET this_TYPE0009 = THIS_ST_VALUE;
									WHEN 10 THEN	
										SET this_TYPE0010 = THIS_ST_VALUE;
									WHEN 11 THEN	
										SET this_TYPE0011 = THIS_ST_VALUE;
									WHEN 12 THEN	
										SET this_TYPE0012 = THIS_ST_VALUE;
									WHEN 13 THEN	
										SET this_TYPE0013 = THIS_ST_VALUE;
									WHEN 14 THEN	
										SET this_TYPE0014 = THIS_ST_VALUE;
									WHEN 15 THEN	
										SET this_TYPE0015 = THIS_ST_VALUE;
									WHEN 16 THEN	
										SET this_TYPE0016 = THIS_ST_VALUE;
									WHEN 17 THEN	
										SET this_TYPE0017 = THIS_ST_VALUE;
									WHEN 18 THEN	
										SET this_TYPE0018 = THIS_ST_VALUE;
									WHEN 19 THEN	
										SET this_TYPE0019 = THIS_ST_VALUE;
									WHEN 20 THEN	
										SET this_TYPE0020 = THIS_ST_VALUE;
									WHEN 21 THEN	
										SET this_TYPE0021 = THIS_ST_VALUE;
									WHEN 22 THEN	
										SET this_TYPE0022 = THIS_ST_VALUE;
									WHEN 23 THEN	
										SET this_TYPE0023 = THIS_ST_VALUE;
									WHEN 24 THEN	
										SET this_TYPE0024 = THIS_ST_VALUE;
									WHEN 25 THEN	
										SET this_TYPE0025 = THIS_ST_VALUE;
									WHEN 26 THEN	
										SET this_TYPE0026 = THIS_ST_VALUE;
									WHEN 27 THEN	
										SET this_TYPE0027 = THIS_ST_VALUE;
									WHEN 28 THEN	
										SET this_TYPE0028 = THIS_ST_VALUE;
									WHEN 29 THEN	
										SET this_TYPE0029 = THIS_ST_VALUE;
									WHEN 30 THEN	
										SET this_TYPE0030 = THIS_ST_VALUE;
									END CASE;
								END IF;
								SET HOL_CT = HOL_CT + 1;
							END WHILE;
						END IF;
################################计算单项结束########################################
						
#各项求和
						
						SET all_wcbzcs = all_wcbzcs + IFNULL(this_wcbzcs,0);
						SET all_cdcs = all_cdcs + IFNULL(this_cdcs,0), all_cd = all_cd + IFNULL(this_cd,0), all_ztcs = all_ztcs + IFNULL(this_ztcs,0), all_zt = all_zt + IFNULL(this_zt,0);
						SET all_kgcs = all_kgcs + IFNULL(this_kgcs,0);
						SET all_kgss = all_kgss + IFNULL(this_kgss,0), all_bqcs = all_bqcs + IFNULL(this_bqcs,0), all_jrjbsc = all_jrjbsc + IFNULL(this_jrjbsc,0), all_byxzbxxs = all_byxzbxxs + IFNULL(this_byxzbxxs,0);
						SET all_ygsqsxs = all_ygsqsxs + IFNULL(this_ygsqsxs,0);
						SET all_sd_szqnjybx = all_sd_szqnjybx + IFNULL(this_sd_szqnjybx,0), all_sd_jzsybzqzjybx = all_sd_jzsybzqzjybx + IFNULL(this_sd_jzsybzqzjybx,0), all_sd_bxzjy = all_sd_bxzjy + IFNULL(this_sd_bxzjy,0);
						SET all_sd_jzdykxnj = all_sd_jzdykxnj + IFNULL(this_sd_jzdykxnj,0), all_sd_jzdnkxnj = all_sd_jzdnkxnj + IFNULL(this_sd_jzdnkxnj,0), all_sd_fdnwxnj = all_sd_fdnwxnj + IFNULL(this_sd_fdnwxnj,0);
						SET all_sd_jzbydkxnj = all_sd_jzbydkxnj + IFNULL(this_sd_jzbydkxnj,0), all_sd_njzjy = all_sd_njzjy + IFNULL(this_sd_njzjy,0);
						SET all_sjdkgzsc = all_sjdkgzsc + IFNULL(this_sjdkgzsc,0), all_kqkx = all_kqkx + IFNULL(this_kqkx,0), all_jbsc = all_jbsc + IFNULL(this_jbsc,0), all_jbf = all_jbf + IFNULL(this_jbf,0);
						SET all_TYPE0001 = all_TYPE0001 + IFNULL(this_TYPE0001,0), all_TYPE0002 = all_TYPE0002 + IFNULL(this_TYPE0002,0), all_TYPE0003 = all_TYPE0003 + IFNULL(this_TYPE0003,0), all_TYPE0004 = all_TYPE0004 + IFNULL(this_TYPE0004,0); 
						SET all_TYPE0005 = all_TYPE0005 + IFNULL(this_TYPE0005,0), all_TYPE0006 = all_TYPE0006 + IFNULL(this_TYPE0006,0), all_TYPE0007 = all_TYPE0007 + IFNULL(this_TYPE0007,0), all_TYPE0008 = all_TYPE0008 + IFNULL(this_TYPE0008,0); 
						SET all_TYPE0009 = all_TYPE0009 + IFNULL(this_TYPE0009,0), all_TYPE0010 = all_TYPE0010 + IFNULL(this_TYPE0010,0), all_TYPE0011 = all_TYPE0011 + IFNULL(this_TYPE0011,0), all_TYPE0012 = all_TYPE0012 + IFNULL(this_TYPE0012,0); 
						SET all_TYPE0013 = all_TYPE0013 + IFNULL(this_TYPE0013,0), all_TYPE0014 = all_TYPE0014 + IFNULL(this_TYPE0014,0), all_TYPE0015 = all_TYPE0015 + IFNULL(this_TYPE0015,0), all_TYPE0016 = all_TYPE0016 + IFNULL(this_TYPE0016,0); 
						SET all_TYPE0017 = all_TYPE0017 + IFNULL(this_TYPE0017,0), all_TYPE0018 = all_TYPE0018 + IFNULL(this_TYPE0018,0), all_TYPE0019 = all_TYPE0019 + IFNULL(this_TYPE0019,0), all_TYPE0020 = all_TYPE0020 + IFNULL(this_TYPE0020,0); 
						SET all_TYPE0021 = all_TYPE0021 + IFNULL(this_TYPE0021,0), all_TYPE0022 = all_TYPE0022 + IFNULL(this_TYPE0022,0), all_TYPE0023 = all_TYPE0023 + IFNULL(this_TYPE0023,0), all_TYPE0024 = all_TYPE0024 + IFNULL(this_TYPE0024,0); 
						SET all_TYPE0025 = all_TYPE0025 + IFNULL(this_TYPE0025,0), all_TYPE0026 = all_TYPE0026 + IFNULL(this_TYPE0026,0), all_TYPE0027 = all_TYPE0027 + IFNULL(this_TYPE0027,0), all_TYPE0028 = all_TYPE0028 + IFNULL(this_TYPE0028,0);
						SET all_TYPE0029 = all_TYPE0029 + IFNULL(this_TYPE0029,0), all_TYPE0030 = all_TYPE0030 + IFNULL(this_TYPE0030,0);
						SET ATT_DETAIL_STR = RIGHT(ATT_DETAIL_STR,LENGTH(ATT_DETAIL_STR)-LOCATE(',',ATT_DETAIL_STR));
					END WHILE;
#第三波变量计算，全局汇总项
#1 ybzcqgs	月标准出勤工时
					SET all_ybzcqgs = IFNULL(FN_ATT_GET_WORKDAYS(my_begin_date,my_end_date,i_emp,2),0) * 8  + IFNULL(FN_ATT_GET_HOLIDAY_NUMS(my_begin_date,my_end_date,1,i_emp),0) * 8;
#2 yyxcqgs	月有效出勤工时（含实际出勤工时、各类假期小时）
	#"有效工时=打卡+请假+法定节假日+迟到+早退+旷工
					SET all_yyxcqgs = IFNULL(all_sjdkgzsc,0) + IFNULL(all_qjsc,0) + (IFNULL(FN_ATT_GET_HOLIDAY_NUMS(my_begin_date,my_end_date,1,i_emp),0)*8) + IFNULL(all_cd,0) + IFNULL(all_zt,0) + IFNULL(all_kgss,0) ;

#3 ygsqsxs	月工时缺失小时数
					IF all_yyxcqgs >= all_ybzcqgs THEN
						SET all_ygsqsxs = 0;
					ELSE
						SET all_ygsqsxs = IFNULL(all_ybzcqgs,0) - IFNULL(all_yyxcqgs,0);
					END IF;
					
					IF all_ygsqsxs > 0 THEN
						SET MY_FLEXHOUR=NULL,MY_MONTHFLEX=NULL;
						SELECT MAX(B.flex_hour),MAX(B.month_period_hour) INTO MY_FLEXHOUR ,MY_MONTHFLEX
						FROM att_emp_detail A LEFT JOIN att_set_schema_new B ON A.att_id=B.att_id
						WHERE A.emp_id = i_emp AND A.dt BETWEEN THIS_ATT_BGDT AND THIS_ATT_EDDT ;
						IF (MY_FLEXHOUR IS NOT NULL AND MY_FLEXHOUR > 0 AND (MY_MONTHFLEX IS NULL OR MY_MONTHFLEX = 0 )) 
							OR (MY_FLEXHOUR IS NULL AND MY_MONTHFLEX IS NULL)
						THEN
							SET all_ygsqsxs = 0;
							SET all_yyxcqgs = all_ybzcqgs;
						END IF;
					END IF;
#4 fhw_hsbcbxkj	HSBC补休扣减资源池（小时）
					SELECT IFNULL(SUM(IFNULL(this_year_left,0)),0)
						INTO all_fhw_hsbcbxkj
					FROM att_hol_pay_rest A
					WHERE A.pool_type in (13) and emp_id = i_emp and A.is_delete=0 ;
					#AND A.this_year=YEAR(bgdt); 改动原因：目前是取当前年份的结余，修改为 所有有效（未清零）年份的结余之和。——梁伟 2021-01-14
					

					
					REPLACE INTO att_st_month_quick_view_icss 
						(`st_id`,`cust_id`,`dept_id`,`prgm_id`,`jrdc_id`,`dms_id4`,`dms_id5`,`dms_id6`,`dms_id7`,`dms_id8`,`dms_id9`,`dms_id10`,`dept_full_name`,`emp_id`,`emp_name`,`emp_code`,`position_level_id`,`position_level_name`,`personal_archive_state`,OWNERSHIP_PLACE,entry_date,leave_date,custom_type,
							TYPE0001,TYPE0002,TYPE0003,TYPE0004,TYPE0005,TYPE0006,TYPE0007,TYPE0008,TYPE0009,TYPE0010,TYPE0011,TYPE0012,TYPE0013,TYPE0014,TYPE0015,TYPE0016,TYPE0017,TYPE0018,TYPE0019,TYPE0020,TYPE0021,TYPE0022,TYPE0023,TYPE0024,TYPE0025,TYPE0026,TYPE0027,TYPE0028,TYPE0029,TYPE0030,
							ycqts,gzrts,fdjjrts,sjcqts,wcbzcs,cdcs,cd,ztcs,zt,kgcs,kgss,bqcs,hw_omp_sjjbgs,hw_omp_cxsjbgs,hw_byxzffjbxs,hw_byjsffjbxs,hw_ylffjbxs,jrjbsc,byxzbxxs,ybzcqgs,yyxcqgs,ygsqsxs,hw_khgs,hw_khgsyy,fhw_hsbcbxkj
						 ) 
					VALUES (i_st_id,i_custid,i_deptid,MY_prgm_id,MY_jrdc_id,MY_dms_id4,MY_dms_id5,MY_dms_id6,MY_dms_id7,MY_dms_id8,MY_dms_id9,MY_dms_id10,MY_DEPT_NAME,i_emp,MY_EMP_NAME,MY_EMP_CODE,MY_POSITION_LEVEL_ID,MY_POSITION_LEVEL_NAME,0,MY_OWNERSHIP_PLACE,i_entry_date,i_leave_date,i_custom_type,
								all_TYPE0001,all_TYPE0002+all_TYPE0010,all_TYPE0003,all_TYPE0004,all_TYPE0005,all_TYPE0006,all_TYPE0007,all_TYPE0008,all_TYPE0009,all_TYPE0010,all_TYPE0011,all_TYPE0012,all_TYPE0013,all_TYPE0014,all_TYPE0015,all_TYPE0016,all_TYPE0017,all_TYPE0018,all_TYPE0019,all_TYPE0020,all_TYPE0021,all_TYPE0022,all_TYPE0023,all_TYPE0024,all_TYPE0025,all_TYPE0026,all_TYPE0027,all_TYPE0028,all_TYPE0029,all_TYPE0030,
								all_ycqts,all_gzrts,all_fdjjrts,all_sjcqts,all_wcbzcs,all_cdcs,all_cd,all_ztcs,all_zt,all_kgcs,all_kgss,all_bqcs,all_hw_omp_sjjbgs,all_hw_omp_cxsjbgs,all_hw_byxzffjbxs,all_hw_byjsffjbxs,all_hw_ylffjbxs,all_jrjbsc,all_byxzbxxs,all_ybzcqgs,all_yyxcqgs,all_ygsqsxs,all_hw_khgs,all_hw_khgsyy,all_fhw_hsbcbxkj
							);
					CALL SP_ATT_MONTH_REPORT_ST_POOL(i_st_id,i_emp);
				END IF;
			END IF;
			
			SET ct = ct + 1;
			set i_act_do_num = i_act_do_num+1;
		END WHILE;														#LOOP OUTSIDE 轮询tmp_att_month_emp_list
	END IF;
	
	#删除由于入离职变更导致的不在这个考勤周期内的人员信息
#	delete a.* 
#	from att_st_month_quick_view_icss a ,emp_post b
#	where a.st_id=i_st_id and a.emp_id=b.emp_id
#		and ((b.entry_date > eddt and b.entry_date is not null) or (b.leave_date is not null and b.leave_date < bgdt));



	IF emp IS NULL AND stat=1 THEN
		SET state=1;
#	ELSE
#		CALL SP_ATT_EMP_MONTH_DETAIL(eddt,custid,deptid,emp,depttype);
	END IF;
	 
	
	UPDATE att_month_report_oplog A SET A.end_time=NOW() WHERE A.id=i_version_code;
	SET state=1;
END;

