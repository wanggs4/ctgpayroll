create procedure SP_ATT_MONTH_REPORT_LAST_MONTH()
  comment '每天晚上重跑当天记录下来的上月相关的产生电子流和导入打卡的人员上月的月报'
  BEGIN
DECLARE CT,MXCT,MY_EMPID,MY_STID BIGINT UNSIGNED;
DECLARE TODAY,MY_BGDT,MY_EDDT DATE;
DECLARE MY_STAT INT;
	
	SET TODAY = DATE_ADD(DATE(NOW()),INTERVAL -1 MONTH);
	
	SET MY_STID = NULL, MY_BGDT = NULL, MY_EDDT = NULL;
	SELECT A.st_id,A.comp_start_time,A.comp_end_time INTO MY_STID,MY_BGDT,MY_EDDT
	FROM att_st_month	A
	WHERE A.cust_id=2162554862743552 AND A.archive_state=0
		AND A.comp_start_time <= TODAY AND A.comp_end_time >= TODAY LIMIT 1;
	
	IF MY_STID IS NOT NULL THEN
		TRUNCATE TABLE att_st_last_month_emp_distinct;
		INSERT INTO att_st_last_month_emp_distinct (EMP_ID)
			SELECT DISTINCT EMP_ID FROM att_st_last_month_emp;
		SET CT = 0, MXCT = 0;
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM att_st_last_month_emp_distinct;
		WHILE CT <= MXCT AND CT > 0 DO
			SET MY_EMPID = NULL, MY_STAT = NULL;
			SELECT EMP_ID INTO MY_EMPID FROM att_st_last_month_emp_distinct A WHERE A.ID=CT;
			CALL SP_ATT_MONTH_REPORT(MY_BGDT,MY_EDDT,NULL,NULL,MY_EMPID,MY_STID,MY_STAT,NULL);
			SET CT = CT + 1;
		END WHILE;
#		SELECT * FROM att_st_last_month_emp_distinct;
		TRUNCATE TABLE att_st_last_month_emp;
#		TRUNCATE TABLE att_st_last_month_emp_distinct;
	ELSE
		TRUNCATE TABLE att_st_last_month_emp;
#		TRUNCATE TABLE att_st_last_month_emp_distinct;
	END IF;
END;

