create procedure SP_PAYROLL_FML_VIP_MY(IN key_word varchar(50), IN i_emp bigint unsigned, IN prid bigint unsigned,
                                       IN setid    bigint unsigned, IN schemaid bigint unsigned, OUT res decimal(13, 2))
  comment '上海美亚项目个性化的计算需求'
  BEGIN
DECLARE my_entry_date,my_leave_date,my_sala_ymd_begin,my_sala_ymd_end DATE;
DECLARE my_sqgz,my_lzbcj,my_lzbcj_tax,N_TAX_STAND,N_LZF_JS,my_pay_val,my_gts DECIMAL(13,2);
DECLARE my_xse,my_xsmb,my_jxstc,my_qysjxse,my_mdtc DECIMAL(13,2);
DECLARE my_nzj,my_nzj_tax,my_INNRATE,my_INNDEDUCTION DECIMAL(13,2);
DECLARE my_jbgz,my_sj,my_bj,my_kg,my_gl,my_glbl,my_qqkk DECIMAL(13,2);
DECLARE my_TAX_VERSION,my_nx,my_dyrs INT;
DECLARE my_pos VARCHAR(50);

	SELECT a.sala_ymd_begin,a.sala_ymd_end,left(a.sala_ym,4) 
			into my_sala_ymd_begin,my_sala_ymd_end,my_TAX_VERSION	
	FROM payroll_sala_settings a 
	WHERE a.set_id=setid;

	IF key_word IS NOT NULL AND my_sala_ymd_begin IS NOT NULL AND my_sala_ymd_end IS NOT NULL AND i_emp IS NOT NULL AND prid IS NOT NULL AND setid IS NOT NULL AND schemaid IS NOT NULL THEN
		SELECT entry_date,leave_date into my_entry_date,my_leave_date from emp_post where emp_id=i_emp;
		CASE key_word 
		
		WHEN 'MY_GTS' THEN		
		
		
			
			SELECT bz33,bz8,bz6 INTO my_sqgz,my_lzbcj,my_nzj from payroll_bz_gz where id = prid;
			SET my_pay_val = my_sqgz - my_lzbcj - my_nzj -5000;
		   IF my_pay_val <= 0 OR my_pay_val IS NULL THEN
		      set my_INNRATE = 0;
		      set my_INNDEDUCTION = 0;
		      set my_gts = 0;
		   END IF;
		   
		   SELECT RATE,DEDUCTION INTO my_INNRATE,my_INNDEDUCTION
		   FROM payroll_GZ_TAX 
		   WHERE INCOME = (SELECT MAX(INCOME) INCOME
		                         FROM payroll_GZ_TAX 
		                        WHERE  INCOME < my_pay_val);
		
		    IF my_INNRATE IS NULL THEN SET my_INNRATE = 0; END IF;
		    IF my_INNDEDUCTION IS NULL THEN SET my_INNDEDUCTION = 0; END IF;
		    
		    
		    SET res= my_pay_val * my_INNRATE - my_INNDEDUCTION;

		    
		WHEN 'MY_LZBCJ_TAX' THEN
		
			
			SELECT bz8 INTO my_lzbcj from payroll_bz_gz where id = prid;
			if my_lzbcj is null then set my_lzbcj=0; end if;
			
			
			SET my_nx = FN_PAYROLL_GET_NX(i_emp);
			IF my_nx IS NULL THEN SET my_nx = 0 ; END IF;
			SET N_TAX_STAND = 5000;
			SET N_LZF_JS=0;
			CALL SP_PAYROLL_LZF_SF(my_lzbcj,
	                    my_nx,
	                    my_TAX_VERSION,
	                    N_TAX_STAND,
	                    N_LZF_JS,				
	                    my_INNRATE,
	                    my_INNDEDUCTION,
	                    my_lzbcj,
							  res
	                    );
			
		WHEN 'MY_NZJ_TAX' THEN
		
		
			
			SELECT bz6 INTO my_nzj from payroll_bz_gz where id =prid;
			if my_nzj is null then set my_nzj=0 ; end if;
			CALL SP_PAYROLL_NZJ_TAX(my_nzj,my_TAX_VERSION,my_INNRATE,my_INNDEDUCTION,res);
			if res is null then set res=0 ;end if;
			
			
		WHEN 'MY_QQKK' THEN
		
		
			IF my_entry_date IS NOT NULL THEN
				
				SELECT bz4,bz24,bz27,bz29 into my_jbgz,my_sj,my_bj,my_kg FROM payroll_bz_gz WHERE id = prid;
				IF my_jbgz IS NULL THEN SET my_jbgz=0; END IF;
				IF my_sj IS NULL THEN SET my_sj=0; END IF;
				IF my_bj IS NULL THEN SET my_bj=0; END IF;
				IF my_kg IS NULL THEN SET my_kg=0; END IF;
		
				IF my_leave_date IS NOT NULL THEN
					IF my_leave_date > my_sala_ymd_end THEN
						SET my_gl = round(datediff(my_sala_ymd_end,my_entry_date)/365,2);
					ELSE
						SET my_gl = round(datediff(my_leave_date,my_entry_date)/365,2);
					END IF;
				ELSE
					IF my_entry_date <= my_sala_ymd_end THEN
						SET my_gl = round(datediff(my_sala_ymd_end,my_entry_date)/365,2);
					ELSE
						SET my_gl = 1;
					END IF;
				END IF;
				
				
		
				IF my_gl <2 THEN
					SET my_glbl = 0.6;	
				ELSEIF my_gl>=2 AND my_gl<4 THEN
					SET my_glbl = 0.7;	
				ELSEIF my_gl>=4 AND my_gl<6 THEN
					SET my_glbl = 0.8;	
				ELSEIF my_gl>=6 AND my_gl<8 THEN
					SET my_glbl = 0.9;	
				ELSEIF my_gl>=8 THEN
					SET my_glbl = 1;
				END IF;
				
				SET res = ROUND((my_jbgz/174*my_sj) + (my_jbgz/174*my_bj*(1-(0.7*my_glbl))) + (my_jbgz/174*my_kg),2);
				
				
			END IF;
		WHEN 'MY_JJ' THEN	
		
			
			SELECT b.position_level_name INTO my_pos 
			FROM emp_post a left join dept_pos_level b on a.position_level_id=b.position_level_id 
			WHERE a.emp_id = i_emp;
			
			select bz49,bz47,bz2,bz1,bz62
				into my_xsmb,my_xse,my_jxstc,my_qysjxse,my_dyrs
			from payroll_bz_gz
			where id = prid;
			
			IF my_xse IS NULL THEN SET my_xse = 0; END IF;
			IF my_xsmb IS NULL THEN SET my_xsmb = 0 ; END IF;
			IF my_jxstc IS NULL THEN SET my_jxstc = 0; END IF;
			IF my_qysjxse IS NULL THEN SET my_qysjxse = 0; END IF;
			
			CASE my_pos
			WHEN '导购店长' THEN
				
				IF my_xse < my_xsmb THEN
				
					SET res = (my_xse/my_dyrs*0.03) + (my_xse*0.005);
				ELSE
				
					SET res = (my_xse/my_dyrs*0.04) + (my_xse*0.01);
				END IF;
			WHEN '导购店员' THEN
				IF my_xse < my_xsmb THEN
				
					SET res = (my_xse/my_dyrs*0.03);
				ELSE
				
					SET res = (my_xse/my_dyrs*0.04);
				END IF;
			WHEN '大区经理' THEN
				IF my_xse < my_xsmb THEN
				
					SET my_mdtc = (my_xse*0.005);
				ELSE
				
					SET my_mdtc = (my_xse*0.006);
				END IF;
				
				set res = my_mdtc + my_jxstc;
			WHEN '办公室主任' THEN
				
				SET my_mdtc = my_qysjxse*0.001;
				set res = my_mdtc + my_jxstc;
			WHEN '销售主任' THEN
				IF my_xse < my_xsmb THEN
				
					SET res = my_xse*0.005;
				ELSE
				
					SET res = my_xse*0.006;
				END IF;
			
			WHEN '销售专员' THEN
				IF my_xse < my_xsmb THEN
				
					SET res = my_xse*0.005;
				ELSE
				
					SET res = my_xse*0.006;
				END IF;
			ELSE
				SET res=0;
			END CASE;
		ELSE
			SET res=0;		
		END CASE;
		SET res = ROUND(res,2);
	END IF;
END;

