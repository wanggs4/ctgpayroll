create procedure SP_ATT_DAILY_ARRANGE(IN bgdt date, IN eddt date, IN custid bigint unsigned, IN deptid bigint unsigned,
                                      IN emp  bigint unsigned, IN depttype int)
  comment '排班日报计算'
  BEGIN
DECLARE i_data_source,i_data_source2,emp_ct,emp_mxct,i_arr_id_1,i_arr_id_2,i_arr_id_3,stat,ct,mxct,i_arr_id,i_emp_id,i_dept_id,i_cust_id,i_att_id,i_bg_loc_set_id_1,i_bg_loc_set_id_2,i_bg_loc_set_id_3,i_ed_loc_set_id_1,i_ed_loc_set_id_2,i_ed_loc_set_id_3 BIGINT;
DECLARE i_version_code,i_bg_loc_set_name_1,i_bg_loc_set_name_2,i_bg_loc_set_name_3,i_ed_loc_set_name_1,i_ed_loc_set_name_2,i_ed_loc_set_name_3 VARCHAR(200);
DECLARE i_dt,I_BGDT DATE;
DECLARE i_arrange_bg_time_1,i_arrange_bg_time_2,i_arrange_bg_time_3,i_arrange_end_time_1,i_arrange_end_time_2,i_arrange_end_time_3 TIME;
DECLARE MY_FREE_HOUR_LATE,MY_FREE_HOUR_EARLY,i_arrange_bg_day_1,i_arrange_bg_check_flex_1,i_arrange_end_day_1,i_arrange_end_check_flex_1,i_arrange_bg_day_2,i_arrange_bg_check_flex_2,i_arrange_end_day_2,i_arrange_end_check_flex_2,i_arrange_bg_day_3,i_arrange_bg_check_flex_3,i_arrange_end_day_3,i_arrange_end_check_flex_3 INT;
DECLARE i_half_dayoff_late_mins,i_all_dayoff_late_mins,i_half_dayoff_early_mins,i_all_dayoff_early_mins,i_half_dayoff_qq_mins,i_all_dayoff_qq_mins INT;
DECLARE ARR_WORK_MINS_3,ARR_WORK_MINS_2,ARR_WORK_MINS_1,my_qq_mins,i_late_mins,i_early_mins,my_late_kg,my_early_kg,my_qq_kg,i_work_interval DECIMAL(12,2);							
DECLARE i_is_dayoff,i_weekday,i_date_type,i_is_need_bg_check_1,i_is_need_bg_check_2,i_is_need_bg_check_3,i_is_need_ed_check_1,i_is_need_ed_check_2,i_is_need_ed_check_3 INT;
DECLARE i_arr_start_time,i_arr_end_time,i_arr_start_time_1,i_arr_end_time_1,i_arr_start_time_2,i_arr_end_time_2,i_arr_start_time_3,i_arr_end_time_3 DATETIME;
DECLARE I_CK_OSD,ori_i_att_check_in_1,ori_i_att_check_out_1,i_att_check_in_1,i_att_check_out_1 DATETIME;
DECLARE ori_i_att_check_in_2,ori_i_att_check_out_2,i_att_check_in_2,i_att_check_out_2 DATETIME;
DECLARE ori_i_att_check_in_3,ori_i_att_check_out_3,i_att_check_in_3,i_att_check_out_3 DATETIME;
DECLARE ARR_CHECK_1,ARR_CHECK_2,ARR_CHECK_3,MY_CHECK_ED_3,MY_CHECK_BG_3,MY_CHECK_ED_2,MY_CHECK_BG_2,MY_CHECK_ED_1,MY_CHECK_BG_1 INT;
DECLARE i_bg_dkj_device_id1,i_bg_dkj_device_id2,i_bg_dkj_device_id3,i_ed_dkj_device_id1,i_ed_dkj_device_id2,i_ed_dkj_device_id3 VARCHAR(50);
DECLARE i_bg_data_source1,i_bg_data_source2,i_bg_data_source3,i_ed_data_source1,i_ed_data_source2,i_ed_data_source3 INT;

	
	SET i_version_code = UUID();
	SET I_BGDT = bgdt;
	
	if (custid is null and deptid is null and depttype is null and emp is null) then
		set stat=4;
	elseif (custid is not null and deptid is null and depttype is null  and emp is null) then
		set stat=3;
	elseif (deptid is not null and depttype between 1 and 10 and emp is null) then
		set stat=2;
	elseif (emp is not null) then
		set stat=1;
	end if;

	WHILE bgdt <= eddt DO
 		case stat
			when 1 then
				insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
				select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
				from att_arrange_schedual a 
					LEFT JOIN emp_post b on a.emp_id=b.emp_id
				where a.emp_id=emp AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
					and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
			when 2 then
				case depttype
				when 1 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.dept_id=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 2 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.prgm_id=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 3 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.jrdc_id=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 4 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.dms_id4=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 5 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.dms_id5=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 6 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.dms_id6=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 7 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.dms_id7=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 8 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.dms_id8=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 9 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.dms_id9=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				when 10 then
					insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
					select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
					from att_arrange_schedual a 
						LEFT JOIN emp_post b on a.emp_id=b.emp_id
					where a.dms_id10=deptid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
						and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
				end case;
			when 3 then
				insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
				select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
				from att_arrange_schedual a 
					LEFT JOIN emp_post b on a.emp_id=b.emp_id
				where a.cust_id=custid AND a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
					and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
			when 4 then
				insert into tmp_att_arrange (version_code,arr_id,emp_id,dept_id,cust_id,att_id,arr_start_time,arr_end_time) 
				select distinct i_version_code,a.arr_id,a.emp_id,a.dept_id,a.cust_id,a.att_id,a.arr_start_time,a.arr_end_time
				from att_arrange_schedual a 
					LEFT JOIN emp_post b on a.emp_id=b.emp_id
				where a.arr_start_time between concat(bgdt,' 00:00:00') AND concat(bgdt,' 23:59:59')
					and (b.entry_date is not null and b.entry_date<=bgdt) and (b.leave_date is null or b.leave_date >= bgdt);
		end case;
		
		INSERT INTO tmp_att_arrange_emplist (version_code,emp_id) 
			SELECT DISTINCT i_version_code,EMP_ID FROM tmp_att_arrange A;
		set emp_ct=0,emp_mxct=0;
		select min(id),max(id) into emp_ct,emp_mxct from tmp_att_arrange_emplist where version_code=i_version_code;
		WHILE emp_ct<=emp_mxct AND emp_ct>0 DO
			set i_emp_id = NULL;
			select emp_id into i_emp_id from tmp_att_arrange_emplist A WHERE version_code=i_version_code AND ID=emp_ct;
			
			IF i_emp_id IS NOT NULL THEN
				set ct = 0 ;
				set mxct = 0;
			
				SELECT MIN(ID),MAX(ID) INTO ct,mxct FROM tmp_att_arrange WHERE version_code=i_version_code and emp_id=i_emp_id;
				SET ori_i_att_check_in_1 = NULL,ori_i_att_check_out_1 = NULL,i_att_check_in_1 = NULL,i_att_check_out_1 = NULL;
				SET ori_i_att_check_in_2 = NULL,ori_i_att_check_out_2 = NULL,i_att_check_in_2 = NULL,i_att_check_out_2 = NULL;
				SET ori_i_att_check_in_3 = NULL,ori_i_att_check_out_3 = NULL,i_att_check_in_3 = NULL,i_att_check_out_3 = NULL;
				SET i_bg_loc_set_id_1=NULL,i_ed_loc_set_id_1=NULL,i_bg_loc_set_name_1=NULL,i_bg_loc_set_name_1=NULL;
				SET i_bg_loc_set_id_2=NULL,i_ed_loc_set_id_2=NULL,i_bg_loc_set_name_2=NULL,i_bg_loc_set_name_2=NULL;
				SET i_bg_loc_set_id_3=NULL,i_ed_loc_set_id_3=NULL,i_bg_loc_set_name_3=NULL,i_bg_loc_set_name_3=NULL;
				SET ARR_CHECK_1=2, ARR_CHECK_2=2, ARR_CHECK_3=2;
				SET i_arr_id_1=NULL,i_arr_id_2=NULL,i_arr_id_3=NULL;
				SET i_work_interval = NULL,i_late_mins = NULL,i_early_mins = NULL,i_is_dayoff = NULL,my_late_kg = NULL,my_early_kg = NULL, my_qq_kg = NULL;
				
				WHILE ct<=mxct and ct>0 DO
					
					SET i_arr_start_time = NULL,i_arr_end_time = NULL,i_arr_id = NULL,i_dept_id = NULL,i_cust_id = NULL,i_att_id = NULL,i_dt = NULL,i_weekday = NULL,i_date_type = NULL;
					SET i_arrange_bg_day_1 = NULL,i_arrange_bg_time_1 = NULL,i_arrange_bg_check_flex_1 = NULL,i_arrange_end_day_1 = NULL,i_arrange_end_time_1 = NULL,i_arrange_end_check_flex_1 = NULL;
					SET i_arrange_bg_day_2 = NULL,i_arrange_bg_time_2 = NULL,i_arrange_bg_check_flex_2 = NULL,i_arrange_end_day_2 = NULL,i_arrange_end_time_2 = NULL,i_arrange_end_check_flex_2 = NULL;
					SET i_arrange_bg_day_3 = NULL,i_arrange_bg_time_3 = NULL,i_arrange_bg_check_flex_3 = NULL,i_arrange_end_day_3 = NULL,i_arrange_end_time_3 = NULL,i_arrange_end_check_flex_3 = NULL;
					
					SELECT arr_id,dept_id,cust_id,att_id,
							arr_start_time,arr_end_time
						INTO i_arr_id,i_dept_id,i_cust_id,i_att_id,
							i_arr_start_time,i_arr_end_time
					FROM tmp_att_arrange WHERE ID = ct and version_code=i_version_code and emp_id = i_emp_id;
		
					
					IF i_arr_id IS NOT NULL THEN
						
						SELECT `arrange_bg_day_1`,`arrange_bg_time_1`,`arrange_bg_check_flex_1`,
								`arrange_end_day_1`,`arrange_end_time_1`,`arrange_end_check_flex_1`,
								`arrange_bg_day_2`,`arrange_bg_time_2`,`arrange_bg_check_flex_2`,
								`arrange_end_day_2`,`arrange_end_time_2`,`arrange_end_check_flex_2`,
								`arrange_bg_day_3`,`arrange_bg_time_3`,`arrange_bg_check_flex_3`,
								`arrange_end_day_3`,`arrange_end_time_3`,`arrange_end_check_flex_3`,
								is_need_bg_check_1,is_need_bg_check_2,is_need_bg_check_3,
								is_need_ed_check_1,is_need_ed_check_2,is_need_ed_check_3
							INTO i_arrange_bg_day_1,i_arrange_bg_time_1,i_arrange_bg_check_flex_1,	
									
								i_arrange_end_day_1,i_arrange_end_time_1,i_arrange_end_check_flex_1,	
									
								i_arrange_bg_day_2,i_arrange_bg_time_2,i_arrange_bg_check_flex_2,		
									
								i_arrange_end_day_2,i_arrange_end_time_2,i_arrange_end_check_flex_2,	
									
								i_arrange_bg_day_3,i_arrange_bg_time_3,i_arrange_bg_check_flex_3,		
									
								i_arrange_end_day_3,i_arrange_end_time_3,i_arrange_end_check_flex_3,	
									
								i_is_need_bg_check_1,i_is_need_bg_check_2,i_is_need_bg_check_3,
								i_is_need_ed_check_1,i_is_need_ed_check_2,i_is_need_ed_check_3														
						FROM att_set_schema_new WHERE att_id = i_att_id;
						
		
						
						IF TIME(i_arr_start_time) = i_arrange_bg_time_1 THEN
							SET i_bg_loc_set_id_1=NULL,i_ed_loc_set_id_1=NULL,i_bg_loc_set_name_1=NULL,i_ed_loc_set_name_1=NULL;
							SET i_arr_start_time_1 = i_arr_start_time;
							SET i_arr_end_time_1 = i_arr_end_time;
							SET i_arr_id_1 = i_arr_id;
							SET i_bg_dkj_device_id1=NULL,i_ed_dkj_device_id1=NULL,i_bg_data_source1=NULL,i_ed_data_source1=NULL;
						/*
							SELECT MIN(CHECK_TIME),MAX(CHECK_TIME)
								INTO i_att_check_in_1,i_att_check_out_1
							FROM att_emp_log A
							WHERE EMP_ID = i_emp_id AND CHECK_TIME BETWEEN 
									DATE_ADD(i_arr_start_time,INTERVAL -i_arrange_bg_check_flex_1 MINUTE) 
									AND DATE_ADD(i_arr_end_time,INTERVAL i_arrange_end_check_flex_1 MINUTE);
						*/		
							CALL FN_ATT_GET_DAILY_ARRANGE_CHECKTIME(i_emp_id,bgdt,1,1,i_att_check_in_1,i_att_check_out_1,I_CK_OSD);
							
							SET ori_i_att_check_in_1=i_att_check_in_1;
							SET ori_i_att_check_out_1=i_att_check_out_1;
							
							IF ori_i_att_check_in_1 IS NOT NULL THEN
								SET MY_CHECK_BG_1 = 1;
							ELSE
								SET MY_CHECK_BG_1 = 0;
							END IF;
							
							IF ori_i_att_check_out_1 IS NOT NULL THEN
								SET MY_CHECK_ED_1 = 1;
							ELSE
								SET MY_CHECK_ED_1 = 0;
							END IF;
		
							IF ori_i_att_check_in_1 IS NULL AND ori_i_att_check_out_1 IS NULL THEN
								SET ARR_CHECK_1 = 0;
								SET i_bg_loc_set_id_1=NULL,i_ed_loc_set_id_1=NULL,i_bg_loc_set_name_1=NULL,i_bg_loc_set_name_1=NULL;
							ELSEIF ori_i_att_check_in_1 IS NOT NULL AND ori_i_att_check_out_1 IS NOT NULL THEN
								SET ARR_CHECK_1 = 1;
								
								SELECT A.loc_set_id,IF(A.loc_set_name IS NULL,A.check_add,A.loc_set_name),if(data_source=4,device_id,dkj_device_id),data_source  
									INTO i_bg_loc_set_id_1,i_bg_loc_set_name_1,i_bg_dkj_device_id1,i_bg_data_source1
									FROM att_emp_log A WHERE EMP_ID=i_emp_id AND CHECK_TIME = ori_i_att_check_in_1 limit 1;
									
								SELECT A.loc_set_id,IF(A.loc_set_name IS NULL,A.check_add,A.loc_set_name),if(data_source=4,device_id,dkj_device_id),data_source  
									INTO i_ed_loc_set_id_1,i_ed_loc_set_name_1,i_ed_dkj_device_id1,i_ed_data_source1
									FROM att_emp_log A WHERE EMP_ID=i_emp_id AND CHECK_TIME = ori_i_att_check_out_1 limit 1;
							END IF;
						
							
							IF i_is_need_bg_check_1 = 0 THEN
								IF ori_i_att_check_in_1 = ori_i_att_check_out_1 THEN
									SET MY_CHECK_BG_1 = 0;
								END IF;
								
								IF ori_i_att_check_in_1 IS NOT NULL AND ori_i_att_check_in_1 > i_arr_start_time THEN
									SET ori_i_att_check_in_1 = i_arr_start_time;
									SET i_att_check_in_1 = i_arr_start_time;
								ELSEIF ori_i_att_check_in_1 IS NOT NULL AND ori_i_att_check_in_1 <= i_arr_start_time THEN
									SET i_att_check_in_1 = i_arr_start_time;
								ELSEIF ori_i_att_check_in_1 IS NULL THEN
									SET i_att_check_in_1 = i_arr_start_time;
									SET MY_CHECK_BG_1 = 0;
								END IF;
							ELSE
								IF ori_i_att_check_in_1 IS NULL THEN
									SET i_att_check_in_1 = i_arr_end_time;
									SET MY_CHECK_BG_1 = 0;
								ELSEIF ori_i_att_check_in_1 IS NOT NULL AND ori_i_att_check_in_1 < i_arr_start_time THEN
									SET i_att_check_in_1 = i_arr_start_time;
								END IF;
							END IF;
							
							IF i_is_need_ed_check_1 = 0 THEN
								IF ori_i_att_check_in_1 = ori_i_att_check_out_1 THEN
									SET MY_CHECK_ED_1 = 0;
								END IF;
								
								IF ori_i_att_check_out_1 IS NOT NULL AND ori_i_att_check_out_1 >= i_arr_end_time THEN
									SET i_att_check_out_1 = i_arr_end_time;
								
								ELSEIF ori_i_att_check_out_1 IS NOT NULL AND ori_i_att_check_out_1 < i_arr_end_time THEN
									SET ori_i_att_check_out_1 = i_arr_end_time;
									SET i_att_check_out_1 = i_arr_end_time;
								
								ELSEIF ori_i_att_check_out_1 IS NULL THEN
									SET i_att_check_out_1 = i_arr_end_time;
									SET MY_CHECK_ED_1 = 0;
								END IF;
							ELSE
								IF i_is_need_bg_check_1 = 1 AND (ori_i_att_check_out_1 IS NULL OR (ori_i_att_check_out_1 IS NOT NULL AND ori_i_att_check_out_1 > i_arr_end_time)) THEN
									SET i_att_check_out_1 = i_arr_end_time;
								ELSEIF i_is_need_bg_check_1 = 0 AND ori_i_att_check_out_1 IS NULL THEN
									SET i_att_check_out_1 = i_arr_start_time;
									SET MY_CHECK_ED_1 = 0;
								END IF;
							END IF;
		
						ELSEIF TIME(i_arr_start_time) = i_arrange_bg_time_2 THEN
							SET i_bg_loc_set_id_2=NULL,i_ed_loc_set_id_2=NULL,i_bg_loc_set_name_2=NULL,i_ed_loc_set_name_2=NULL;
							SET i_arr_start_time_2 = i_arr_start_time;
							SET i_arr_end_time_2 = i_arr_end_time;
							SET i_arr_id_2 = i_arr_id;
							SET i_bg_dkj_device_id2=NULL,i_ed_dkj_device_id2=NULL,i_bg_data_source2=NULL,i_ed_data_source2=NULL;
							
						/*
							SELECT MIN(CHECK_TIME),MAX(CHECK_TIME)
								INTO i_att_check_in_2,i_att_check_out_2
							FROM att_emp_log A
							WHERE EMP_ID = i_emp_id AND CHECK_TIME BETWEEN 
									DATE_ADD(i_arr_start_time,INTERVAL -i_arrange_bg_check_flex_2 MINUTE) 
									AND DATE_ADD(i_arr_end_time,INTERVAL i_arrange_end_check_flex_2 MINUTE);
						*/
							CALL FN_ATT_GET_DAILY_ARRANGE_CHECKTIME(i_emp_id,bgdt,2,1,i_att_check_in_2,i_att_check_out_2,I_CK_OSD);
							
							SET ori_i_att_check_in_2=i_att_check_in_2;
							SET ori_i_att_check_out_2=i_att_check_out_2;
							IF ori_i_att_check_in_2 IS NOT NULL THEN
								SET MY_CHECK_BG_2 = 1;
							ELSE
								SET MY_CHECK_BG_2 = 0;
							END IF;
							IF ori_i_att_check_out_2 IS NOT NULL THEN
								SET MY_CHECK_ED_2 = 1;
							ELSE
								SET MY_CHECK_ED_2 = 0;
							END IF;
		
							IF ori_i_att_check_in_2 IS NULL AND ori_i_att_check_out_2 IS NULL THEN
								SET ARR_CHECK_2 = 0;
								SET i_bg_loc_set_id_2=NULL,i_ed_loc_set_id_2=NULL,i_bg_loc_set_name_2=NULL,i_bg_loc_set_name_2=NULL;
								
							ELSEIF ori_i_att_check_in_2 IS NOT NULL AND ori_i_att_check_out_2 IS NOT NULL THEN
								SET ARR_CHECK_2 = 1;
								SELECT A.loc_set_id,IF(A.loc_set_name IS NULL,A.check_add,A.loc_set_name),if(data_source=4,device_id,dkj_device_id),data_source  
									INTO i_bg_loc_set_id_2,i_bg_loc_set_name_2,i_bg_dkj_device_id2,i_bg_data_source2
									FROM att_emp_log A WHERE EMP_ID=i_emp_id AND CHECK_TIME = ori_i_att_check_in_2 limit 1;
									
								SELECT A.loc_set_id,IF(A.loc_set_name IS NULL,A.check_add,A.loc_set_name),if(data_source=4,device_id,dkj_device_id),data_source  
									INTO i_ed_loc_set_id_2,i_ed_loc_set_name_2,i_ed_dkj_device_id2,i_ed_data_source2
									FROM att_emp_log A WHERE EMP_ID=i_emp_id AND CHECK_TIME = ori_i_att_check_out_2 limit 1;
							END IF;
						
							
							IF i_is_need_bg_check_2 = 0 THEN
								IF ori_i_att_check_in_2 = ori_i_att_check_out_2 THEN
									SET MY_CHECK_BG_2 = 0;
								END IF;
								
								IF ori_i_att_check_in_2 IS NOT NULL AND ori_i_att_check_in_2 > i_arr_start_time THEN
									SET ori_i_att_check_in_2 = i_arr_start_time;
									SET i_att_check_in_2 = i_arr_start_time;
								ELSEIF ori_i_att_check_in_2 IS NOT NULL AND ori_i_att_check_in_2 <= i_arr_start_time THEN
									SET i_att_check_in_2 = i_arr_start_time;
								ELSEIF ori_i_att_check_in_2 IS NULL THEN
									SET i_att_check_in_2 = i_arr_start_time;
									SET MY_CHECK_BG_2 = 0;
								END IF;
							ELSE
								IF ori_i_att_check_in_2 IS NULL THEN
									SET i_att_check_in_2 = i_arr_end_time;
									SET MY_CHECK_BG_2 = 0;
								ELSEIF ori_i_att_check_in_2 IS NOT NULL AND ori_i_att_check_in_2 < i_arr_start_time THEN
									SET i_att_check_in_2 = i_arr_start_time;
								END IF;
							END IF;
							
							IF i_is_need_ed_check_2 = 0 THEN
								IF ori_i_att_check_in_2 = ori_i_att_check_out_2 THEN
									SET MY_CHECK_ED_2 = 0;
								END IF;
								
								IF ori_i_att_check_out_2 IS NOT NULL AND ori_i_att_check_out_2 >= i_arr_end_time THEN
									SET i_att_check_out_2 = i_arr_end_time;
								
								ELSEIF ori_i_att_check_out_2 IS NOT NULL AND ori_i_att_check_out_2 < i_arr_end_time THEN
									SET ori_i_att_check_out_2 = i_arr_end_time;
									SET i_att_check_out_2 = i_arr_end_time;
								
								ELSEIF ori_i_att_check_out_2 IS NULL THEN
									SET i_att_check_out_2 = i_arr_end_time;
									SET MY_CHECK_ED_2 = 0;
								END IF;
							ELSE
								IF i_is_need_bg_check_2 = 1 AND (ori_i_att_check_out_2 IS NULL OR (ori_i_att_check_out_2 IS NOT NULL AND ori_i_att_check_out_2 > i_arr_end_time)) THEN
									SET i_att_check_out_2 = i_arr_end_time;
								ELSEIF i_is_need_bg_check_2 = 0 AND ori_i_att_check_out_2 IS NULL THEN
									SET i_att_check_out_2 = i_arr_start_time;
									SET MY_CHECK_ED_2 = 0;
								END IF;
							END IF;
						ELSEIF TIME(i_arr_start_time) = i_arrange_bg_time_3 THEN
							SET i_bg_loc_set_id_3=NULL,i_ed_loc_set_id_3=NULL,i_bg_loc_set_name_3=NULL,i_ed_loc_set_name_3=NULL;
							SET i_arr_start_time_3 = i_arr_start_time;
							SET i_arr_end_time_3 = i_arr_end_time;
							SET i_arr_id_3 = i_arr_id;
							SET i_bg_dkj_device_id3=NULL,i_ed_dkj_device_id3=NULL,i_bg_data_source3=NULL,i_ed_data_source3=NULL;
						/*	
							SELECT MIN(CHECK_TIME),MAX(CHECK_TIME)
								INTO i_att_check_in_3,i_att_check_out_3
							FROM att_emp_log A
							WHERE EMP_ID = i_emp_id AND CHECK_TIME BETWEEN 
									DATE_ADD(i_arr_start_time,INTERVAL -i_arrange_bg_check_flex_3 MINUTE) 
									AND DATE_ADD(i_arr_end_time,INTERVAL i_arrange_end_check_flex_3 MINUTE);
						*/
						
							CALL FN_ATT_GET_DAILY_ARRANGE_CHECKTIME(i_emp_id,bgdt,3,1,i_att_check_in_3,i_att_check_out_3,I_CK_OSD);
									
							SET ori_i_att_check_in_3=i_att_check_in_3;
							SET ori_i_att_check_out_3=i_att_check_out_3;
							IF ori_i_att_check_in_3 IS NOT NULL THEN
								SET MY_CHECK_BG_3 = 1;
							ELSE
								SET MY_CHECK_BG_3 = 0;
							END IF;
							IF ori_i_att_check_out_3 IS NOT NULL THEN
								SET MY_CHECK_ED_3 = 1;
							ELSE
								SET MY_CHECK_ED_3 = 0;
							END IF;
		
							IF ori_i_att_check_in_3 IS NULL AND ori_i_att_check_out_3 IS NULL THEN
								SET ARR_CHECK_3 = 0;
								SET i_bg_loc_set_id_3=NULL,i_ed_loc_set_id_3=NULL,i_bg_loc_set_name_3=NULL,i_bg_loc_set_name_3=NULL;
								
							ELSEIF ori_i_att_check_in_3 IS NOT NULL AND ori_i_att_check_out_3 IS NOT NULL THEN
								SET ARR_CHECK_3 = 1;
								SELECT A.loc_set_id,IF(A.loc_set_name IS NULL,A.check_add,A.loc_set_name),if(data_source=4,device_id,dkj_device_id),data_source  
									INTO i_bg_loc_set_id_3,i_bg_loc_set_name_3,i_bg_dkj_device_id3,i_bg_data_source3
									FROM att_emp_log A WHERE EMP_ID=i_emp_id AND CHECK_TIME = ori_i_att_check_in_3 limit 1;
									
								SELECT A.loc_set_id,IF(A.loc_set_name IS NULL,A.check_add,A.loc_set_name),if(data_source=4,device_id,dkj_device_id),data_source  
									INTO i_ed_loc_set_id_3,i_ed_loc_set_name_3,i_ed_dkj_device_id3,i_ed_data_source3
									FROM att_emp_log A WHERE EMP_ID=i_emp_id AND CHECK_TIME = ori_i_att_check_out_3 limit 1;
							END IF;
						
							
							IF i_is_need_bg_check_3 = 0 THEN
								IF ori_i_att_check_in_3 = ori_i_att_check_out_3 THEN
									SET MY_CHECK_BG_3 = 0;
								END IF;
								
								IF ori_i_att_check_in_3 IS NOT NULL AND ori_i_att_check_in_3 > i_arr_start_time THEN
									SET ori_i_att_check_in_3 = i_arr_start_time;
									SET i_att_check_in_3 = i_arr_start_time;
								ELSEIF ori_i_att_check_in_3 IS NOT NULL AND ori_i_att_check_in_3 <= i_arr_start_time THEN
									SET i_att_check_in_3 = i_arr_start_time;
								ELSEIF ori_i_att_check_in_3 IS NULL THEN
									SET i_att_check_in_3 = i_arr_start_time;
									SET MY_CHECK_BG_3 = 0;
								END IF;
							ELSE
								IF ori_i_att_check_in_3 IS NULL THEN
									SET i_att_check_in_3 = i_arr_end_time;
									SET MY_CHECK_BG_3 = 0;
								ELSEIF ori_i_att_check_in_3 IS NOT NULL AND ori_i_att_check_in_3 < i_arr_start_time THEN
									SET i_att_check_in_3 = i_arr_start_time;
								END IF;
							END IF;
							
							IF i_is_need_ed_check_3 = 0 THEN
								IF ori_i_att_check_in_3 = ori_i_att_check_out_3 THEN
									SET MY_CHECK_ED_3 = 0;
								END IF;
								
								IF ori_i_att_check_out_3 IS NOT NULL AND ori_i_att_check_out_3 >= i_arr_end_time THEN
									SET i_att_check_out_3 = i_arr_end_time;
								
								ELSEIF ori_i_att_check_out_3 IS NOT NULL AND ori_i_att_check_out_3 < i_arr_end_time THEN
									SET ori_i_att_check_out_3 = i_arr_end_time;
									SET i_att_check_out_3 = i_arr_end_time;
								
								ELSEIF ori_i_att_check_out_3 IS NULL THEN
									SET i_att_check_out_3 = i_arr_end_time;
									SET MY_CHECK_ED_3 = 0;
								END IF;
							ELSE
								IF i_is_need_bg_check_3 = 1 AND (ori_i_att_check_out_3 IS NULL OR (ori_i_att_check_out_3 IS NOT NULL AND ori_i_att_check_out_3 > i_arr_end_time)) THEN
									SET i_att_check_out_3 = i_arr_end_time;
								ELSEIF i_is_need_bg_check_3 = 0 AND ori_i_att_check_out_3 IS NULL THEN
									SET i_att_check_out_3 = i_arr_start_time;
									SET MY_CHECK_ED_3 = 0;
								END IF;
							END IF;
		
						END IF;				
						DELETE FROM tmp_att_arrange WHERE id = ct;
					END IF;
					
					SET ct = ct + 1;
				
				END WHILE;
	
	
				IF ARR_CHECK_1 IS NULL THEN SET ARR_CHECK_1 = 2; END IF;
				IF ARR_CHECK_2 IS NULL THEN SET ARR_CHECK_2 = 2; END IF;
				IF ARR_CHECK_3 IS NULL THEN SET ARR_CHECK_3 = 2; END IF;
				SET ARR_WORK_MINS_3=0,ARR_WORK_MINS_2=0,ARR_WORK_MINS_1=0;
				
				SET i_dt = bgdt;		
				
				SET i_weekday = weekday(i_dt) + 1;	
				
				SET i_date_type = FN_ATT_GET_DTTYPE(i_dt,i_emp_id);
				
				SET MY_FREE_HOUR_LATE = NULL,MY_FREE_HOUR_EARLY = NULL;
				SELECT A.free_hour_late,A.free_hour_early INTO MY_FREE_HOUR_LATE,MY_FREE_HOUR_EARLY
				FROM att_set_schema_new A
				WHERE A.att_id=i_att_id;
				IF MY_FREE_HOUR_LATE IS NULL THEN SET MY_FREE_HOUR_LATE = 0; END IF;
				IF MY_FREE_HOUR_EARLY IS NULL THEN SET MY_FREE_HOUR_EARLY = 0; END IF;
				
				IF i_arr_id_1 IS NOT NULL THEN
					#只有当此时间段有打卡，且后面的时段有打卡或不需要打卡时才生效，否则为空
					IF ((ori_i_att_check_in_1 IS NOT NULL AND ori_i_att_check_out_1 IS NOT NULL) AND ((ARR_CHECK_2=2 AND ARR_CHECK_3=2) OR (ARR_CHECK_2=1 OR ARR_CHECK_3=1) )) OR (ori_i_att_check_in_1<ori_i_att_check_out_1 AND ori_i_att_check_in_1 IS NOT NULL AND ori_i_att_check_out_1 IS NOT NULL) THEN
						SET ori_i_att_check_in_1=ori_i_att_check_in_1;
						SET ori_i_att_check_out_1 = ori_i_att_check_out_1;
						SET i_att_check_in_1 = i_att_check_in_1;
						SET i_att_check_out_1 = i_att_check_out_1;
					ELSE
						#如果有打卡还要保留记录
						IF MY_CHECK_BG_1 = 0 THEN
							SET ori_i_att_check_in_1 = NULL;
						END IF;
						IF MY_CHECK_ED_1 = 0 THEN
							SET ori_i_att_check_out_1 = NULL;
						END IF;
						SET i_att_check_out_1 = i_arr_end_time_1;
						SET i_att_check_in_1 = i_att_check_out_1;
					END IF;
					
					SET i_work_interval = 0,i_late_mins = 0,i_early_mins = 0,i_is_dayoff = 0;
					SET ARR_WORK_MINS_1 = TIME_TO_SEC(TIMEDIFF(i_arr_end_time_1,i_arr_start_time_1))/60;
					
					IF i_att_check_in_1 > DATE_ADD(i_arr_start_time_1,INTERVAL MY_FREE_HOUR_LATE MINUTE) THEN
						SET i_late_mins = TIME_TO_SEC(TIMEDIFF(i_att_check_in_1,i_arr_start_time_1))/60;
					ELSE
						SET i_late_mins = 0;
					END IF;
					
					IF i_att_check_out_1 < DATE_ADD(i_arr_end_time_1,INTERVAL -MY_FREE_HOUR_EARLY MINUTE) THEN
						SET i_early_mins = TIME_TO_SEC(TIMEDIFF(i_arr_end_time_1,i_att_check_out_1))/60;
					ELSE
						SET i_early_mins = 0;
					END IF; 
					
					IF i_late_mins IS NULL OR i_late_mins<0 THEN SET i_late_mins = 0; END IF;
					IF i_early_mins IS NULL OR i_early_mins<0 THEN SET i_early_mins = 0; END IF;
					IF i_late_mins > ARR_WORK_MINS_1 THEN SET i_late_mins = ARR_WORK_MINS_1; END IF;
					IF i_early_mins > ARR_WORK_MINS_1 THEN SET i_early_mins = ARR_WORK_MINS_1; END IF;
					SET my_qq_mins = i_late_mins+i_early_mins;
					
					SET i_work_interval = ROUND(TIME_TO_SEC(TIMEDIFF(i_arr_end_time_1,i_arr_start_time_1))/60,2) - i_late_mins - i_early_mins;	
					IF i_work_interval IS NULL OR i_work_interval<0 THEN SET i_work_interval = 0; END IF;
					IF i_work_interval > ARR_WORK_MINS_1 THEN SET i_work_interval = ARR_WORK_MINS_1; END IF;
					
		
					UPDATE att_arrange_schedual A 
					SET A.att_check_in = ori_i_att_check_in_1, A.att_check_out = ori_i_att_check_out_1,
						 A.`weekday` = i_weekday, A.date_type = i_date_type,
						A.work_interval = i_work_interval, A.late_mins = i_late_mins, 
						A.early_mins = i_early_mins,A.is_computed=1,
						A.loc_set_id=i_bg_loc_set_id_1,A.loc_set_name = i_bg_loc_set_name_1,
						A.loc_set_id_2=i_ed_loc_set_id_1,A.loc_set_name_2=i_ed_loc_set_name_1,
						A.dkj_device_id=i_bg_dkj_device_id1,A.data_source=i_bg_data_source1,A.dkj_device_id_2=i_ed_dkj_device_id1,A.data_source_2=i_ed_data_source1
					WHERE A.arr_id=i_arr_id_1;
				END IF;
				
		
				IF i_arr_id_2 IS NOT NULL THEN
					#只有当前时间段有打卡，且前有或后有或前后都有打卡时才生效，否则不生效
					IF ((ori_i_att_check_in_2 IS NOT NULL AND ori_i_att_check_out_2 IS NOT NULL) AND (ARR_CHECK_1=1 OR ARR_CHECK_3=1)) OR ((ori_i_att_check_in_2 IS NULL OR ori_i_att_check_out_2 IS NULL) AND (ARR_CHECK_1=1 AND ARR_CHECK_3=1)) OR (ori_i_att_check_in_2<ori_i_att_check_out_2 AND ori_i_att_check_in_2 IS NOT NULL AND ori_i_att_check_out_2 IS NOT NULL) THEN
						SET ori_i_att_check_in_2 = ori_i_att_check_in_2,ori_i_att_check_out_2 = ori_i_att_check_out_2;
						SET i_att_check_out_2 = i_att_check_out_2;
						SET i_att_check_in_2 = i_att_check_in_2;
					ELSE
						#如果有打卡还要保留记录
						IF MY_CHECK_BG_2 = 0 THEN
							SET ori_i_att_check_in_2 = NULL;
						END IF;
						IF MY_CHECK_ED_2 = 0 THEN
							SET ori_i_att_check_out_2 = NULL;
						END IF;
						SET i_att_check_out_2 = i_arr_end_time_2;
						SET i_att_check_in_2 = i_att_check_out_2;
					END IF;
					
					SET i_work_interval = 0,i_late_mins = 0,i_early_mins = 0,i_is_dayoff = 0;
					SET ARR_WORK_MINS_2 = TIME_TO_SEC(TIMEDIFF(i_arr_end_time_2,i_arr_start_time_2))/60;
					
					IF i_att_check_in_2 > DATE_ADD(i_arr_start_time_2,INTERVAL MY_FREE_HOUR_LATE MINUTE) THEN
						SET i_late_mins = TIME_TO_SEC(TIMEDIFF(i_att_check_in_2,i_arr_start_time_2))/60;
					ELSE
						SET i_late_mins = 0;
					END IF;
					
					IF i_att_check_out_2 < DATE_ADD(i_arr_end_time_2,INTERVAL -MY_FREE_HOUR_EARLY MINUTE) THEN
						SET i_early_mins = TIME_TO_SEC(TIMEDIFF(i_arr_end_time_2,i_att_check_out_2))/60;
					ELSE
						SET i_early_mins = 0;
					END IF; 
					
					IF i_late_mins IS NULL OR i_late_mins<0 THEN SET i_late_mins = 0; END IF;
					IF i_early_mins IS NULL OR i_early_mins<0 THEN SET i_early_mins = 0; END IF;
					IF i_late_mins > ARR_WORK_MINS_2 THEN SET i_late_mins = ARR_WORK_MINS_2; END IF;
					IF i_early_mins > ARR_WORK_MINS_2 THEN SET i_early_mins = ARR_WORK_MINS_2; END IF;
					SET my_qq_mins = i_late_mins+i_early_mins;
					
					SET i_work_interval = ROUND(TIME_TO_SEC(TIMEDIFF(i_arr_end_time_2,i_arr_start_time_2))/60,2) - i_late_mins - i_early_mins;	
					IF i_work_interval IS NULL OR i_work_interval<0 THEN SET i_work_interval = 0; END IF;
					IF i_work_interval > ARR_WORK_MINS_2 THEN SET i_work_interval = ARR_WORK_MINS_2; END IF;
					
					UPDATE att_arrange_schedual A 
					SET A.att_check_in = ori_i_att_check_in_2, A.att_check_out = ori_i_att_check_out_2,
						 A.`weekday` = i_weekday, A.date_type = i_date_type,
						A.work_interval = i_work_interval, A.late_mins = i_late_mins, 
						A.early_mins = i_early_mins,A.is_computed=1,
						A.loc_set_id=i_bg_loc_set_id_2,A.loc_set_name = i_bg_loc_set_name_2,
						A.loc_set_id_2=i_ed_loc_set_id_2,A.loc_set_name_2=i_ed_loc_set_name_2,
						A.dkj_device_id=i_bg_dkj_device_id2,A.data_source=i_bg_data_source2,A.dkj_device_id_2=i_ed_dkj_device_id2,A.data_source_2=i_ed_data_source2
					WHERE A.arr_id=i_arr_id_2;
				
				END IF;
				
		
				IF i_arr_id_3 IS NOT NULL THEN
					
					#只有当前时间段有打卡，且前有打卡时才生效，否则不生效
					IF ((ori_i_att_check_in_3 IS NOT NULL AND ori_i_att_check_out_3 IS NOT NULL) AND (ARR_CHECK_1=1 OR ARR_CHECK_2=1)) OR (ori_i_att_check_in_3<ori_i_att_check_out_3 AND ori_i_att_check_in_3 IS NOT NULL AND ori_i_att_check_out_3 IS NOT NULL) THEN
						SET ori_i_att_check_in_3 = ori_i_att_check_in_3,ori_i_att_check_out_3 = ori_i_att_check_out_3;
						SET i_att_check_out_3 = i_att_check_out_3;
						SET i_att_check_in_3 = i_att_check_in_3;
					ELSE
						#如果有打卡还要保留记录
						IF MY_CHECK_BG_3 = 0 THEN
							SET ori_i_att_check_in_3 = NULL;
						END IF;
						IF MY_CHECK_ED_3 = 0 THEN
							SET ori_i_att_check_out_3 = NULL;
						END IF;
						SET i_att_check_out_3 = i_arr_end_time_3;
						SET i_att_check_in_3 = i_att_check_out_3;
					END IF;
		
					
					SET i_work_interval = 0,i_late_mins = 0,i_early_mins = 0,i_is_dayoff = 0;
					
					SET ARR_WORK_MINS_3 = TIME_TO_SEC(TIMEDIFF(i_arr_end_time_3,i_arr_start_time_3))/60;
					
					IF i_att_check_in_3 > DATE_ADD(i_arr_start_time_3,INTERVAL MY_FREE_HOUR_LATE MINUTE) THEN
						SET i_late_mins = TIME_TO_SEC(TIMEDIFF(i_att_check_in_3,i_arr_start_time_3))/60;
					ELSE
						SET i_late_mins = 0;
					END IF;
					
					IF i_att_check_out_3 < DATE_ADD(i_arr_end_time_3,INTERVAL -MY_FREE_HOUR_EARLY MINUTE) THEN
						SET i_early_mins = TIME_TO_SEC(TIMEDIFF(i_arr_end_time_3,i_att_check_out_3))/60;
					ELSE
						SET i_early_mins = 0;
					END IF; 
					
					IF i_late_mins IS NULL OR i_late_mins<0 THEN SET i_late_mins = 0; END IF;
					IF i_early_mins IS NULL OR i_early_mins<0 THEN SET i_early_mins = 0; END IF;
					IF i_late_mins > ARR_WORK_MINS_3 THEN SET i_late_mins = ARR_WORK_MINS_3; END IF;
					IF i_early_mins > ARR_WORK_MINS_3 THEN SET i_early_mins = ARR_WORK_MINS_3; END IF;
					SET my_qq_mins = i_late_mins+i_early_mins;
								
					SET i_work_interval = ROUND(TIME_TO_SEC(TIMEDIFF(i_arr_end_time_3,i_arr_start_time_3))/60,2) - i_late_mins - i_early_mins;	
					IF i_work_interval IS NULL OR i_work_interval<0 THEN SET i_work_interval = 0; END IF;
					IF i_work_interval > ARR_WORK_MINS_3 THEN SET i_work_interval = ARR_WORK_MINS_3; END IF;
		
					UPDATE att_arrange_schedual A 
					SET A.att_check_in = ori_i_att_check_in_3, A.att_check_out = ori_i_att_check_out_3,
						 A.`weekday` = i_weekday, A.date_type = i_date_type,
						A.work_interval = i_work_interval, A.late_mins = i_late_mins, 
						A.early_mins = i_early_mins,A.is_computed=1,
						A.loc_set_id=i_bg_loc_set_id_3,A.loc_set_name = i_bg_loc_set_name_3,
						A.loc_set_id_2=i_ed_loc_set_id_3,A.loc_set_name_2=i_ed_loc_set_name_3,
						A.dkj_device_id=i_bg_dkj_device_id3,A.data_source=i_bg_data_source3,A.dkj_device_id_2=i_ed_dkj_device_id3,A.data_source_2=i_ed_data_source3
					WHERE A.arr_id=i_arr_id_3;
				
				END IF;
				DELETE FROM tmp_att_arrange_emplist WHERE ID=emp_ct;
			END IF;
			SET emp_ct = emp_ct + 1;
		END WHILE;
		
		SET bgdt = DATE_ADD(bgdt,INTERVAL 1 DAY);
		
	
	END WHILE;

	CALL SP_ATT_DAILY_ARRANGE_RECHECK(I_BGDT,eddt,custid,deptid,emp,depttype);

END;

