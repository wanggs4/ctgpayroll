create procedure SP_PAYROLL_GZ_TAX_BACK_NEW(IN  PAYVAL      decimal(13, 3), IN TAX_BASE decimal(13, 3),
                                            IN  TAX_VERSION int, IN PAYVAL_TYPE int, OUT NRATE decimal(13, 3),
                                            OUT NDEDUCTION  decimal(13, 3), OUT RES decimal(13, 3))
  comment '逆向所得税函数（PAYVAL税后工资是包含基数的,返回税前工资是不含基数的）'
  BEGIN

DECLARE INIT_PAYVAL DECIMAL(13,3);


 	IF PAYVAL_TYPE = 1 THEN
		SET PAYVAL = PAYVAL  * 12;
	END IF;

    
	IF PAYVAL <= TAX_BASE*12 OR PAYVAL IS NULL THEN
		SET NRATE      = 0;
		SET NDEDUCTION = 0;
		SET RES = 0;
	ELSE	
		SELECT RATE,DEDUCTION
		INTO NRATE,NDEDUCTION
		FROM payroll_GZ_TAX F
		WHERE F.INCOME = (SELECT MAX(T.INCOME) INCOME
		                   FROM payroll_GZ_TAX T
		                   WHERE T.Netpay + TAX_BASE < PAYVAL);
		                   
		IF NRATE IS NULL THEN SET NRATE = 0; END IF;
		IF NDEDUCTION IS NULL THEN SET NDEDUCTION = 0; END IF;
		
		
		
		IF PAYVAL_TYPE = 1 THEN
			SET NDEDUCTION = ROUND(NDEDUCTION/12,2);
	 		SET RES = ROUND((PAYVAL/12 - NDEDUCTION - TAX_BASE)/(1-NRATE),2);
		ELSEIF PAYVAL_TYPE = 2 THEN
	 		SET RES = ROUND((PAYVAL - NDEDUCTION - TAX_BASE*12)/(1-NRATE),2);
		END IF;
	END IF;
END;

