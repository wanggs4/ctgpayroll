create procedure FN_ATT_GET_MINS_FIXED_NA(IN  ckin_time    time, IN ckout_time time, IN ATTID bigint unsigned,
                                          OUT MY_LATE_MINS decimal(12, 2), OUT MY_EARLY_MINS decimal(12, 2))
  comment '坐班用-给出上下班打卡时间和出勤方案id，得到迟到和早退分钟数'
  BEGIN
DECLARE MY_DAILY_WORK_MINS,MY_REALDAY_WORK_MINS int;
DECLARE MY_CK_DINNER_MINS,MY_DINNER_MINS,MY_REAL_FLEX_MINS,MY_LEFT_MINS,MONTH_FLEX_MIN,SHOULD_WORK_MINS,OK_MINS,i_all_dayoff_late_mins,i_all_dayoff_early_mins,THIS_DAY_WORK_TIME,i_free_hour_late,i_free_hour_early,i_flex_hour,i_month_period_hour DECIMAL(12,2);
DECLARE i_is_month_period,is_have_att,attrule,flag,i_min_unit INT;
DECLARE mst,met,ast,aet,my_ck_time TIME;
DECLARE TODAY,TOMORROW DATE;
DECLARE MY_DINNER_BGTM,MY_DINNER_EDTM,THIS_NA1_BGTM,THIS_NA1_EDTM,THIS_NA2_BGTM,THIS_NA2_EDTM,CPT_MST,CPT_AET,THIS_MST,THIS_MET,THIS_AST,THIS_AET,MY_CHECKIN,MY_CHECKOUT DATETIME;
	
	SET ckin_time = FN_SYS_TMFMT_PURGE_SECOND(ckin_time);
	SET ckout_time = FN_SYS_TMFMT_PURGE_SECOND(ckout_time);
	SET TODAY = DATE(NOW());
	SET TOMORROW = DATE_ADD(TODAY,INTERVAL 1 DAY);
	
	#检查该部门有没有相应的出勤规则
	SELECT COUNT(*) INTO is_have_att FROM att_set_schema_new WHERE ATT_ID = ATTID;
	
	IF ( is_have_att > 0 ) THEN
		#得到部门的出勤规则和四个时间点
		SELECT b.morn_start_time,b.morn_end_time,
				b.aftn_start_time,b.aftn_end_time,b.all_dayoff_late_mins,b.all_dayoff_early_mins,
				b.att_rule,le_fine_compute_unit,b.flex_hour,b.free_hour_late,b.free_hour_early,
				b.is_month_period,b.month_period_hour,
				CONCAT(TODAY,' ',b.na_start_time_1),
				CONCAT(TODAY,' ',b.na_end_time_1),
				CONCAT(TODAY,' ',b.na_start_time_2),
				CONCAT(TODAY,' ',b.na_end_time_2)
			INTO mst,met,
				ast,aet,i_all_dayoff_late_mins,i_all_dayoff_early_mins,
				attrule,i_min_unit,i_flex_hour,i_free_hour_late,i_free_hour_early,
				i_is_month_period,i_month_period_hour,
				THIS_NA1_BGTM,THIS_NA1_EDTM,THIS_NA2_BGTM,THIS_NA2_EDTM
		FROM att_set_schema_new b
		WHERE b.att_id = ATTID;
		
		
		IF i_all_dayoff_late_mins IS NULL OR i_all_dayoff_late_mins = 0 OR i_all_dayoff_late_mins > 10000 THEN
			SET i_all_dayoff_late_mins = 0;
		END IF;
		IF i_all_dayoff_early_mins IS NULL OR i_all_dayoff_early_mins = 0 OR i_all_dayoff_early_mins > 10000 THEN
			SET i_all_dayoff_early_mins = 0;
		END IF;
		
		IF i_all_dayoff_late_mins >= i_all_dayoff_early_mins THEN
			SET OK_MINS = i_all_dayoff_late_mins;
		ELSE
			SET OK_MINS = i_all_dayoff_early_mins;
		END IF;
		
		IF OK_MINS = 0 THEN 
			SET OK_MINS = 120;
		END IF;
		

		SET SHOULD_WORK_MINS = FN_ATT_GET_WORKHOURS(ATTID)*60;
		
		IF i_flex_hour IS NULL THEN SET i_flex_hour = 0; END IF;
		IF i_free_hour_late IS NULL THEN SET i_free_hour_late = 0; END IF;
		IF i_free_hour_early IS NULL THEN SET i_free_hour_early = 0; END IF;
		
		SET THIS_DAY_WORK_TIME = FN_ATT_GET_REAL_DAY_HOURS_WITH_ATTID(ckin_time,ckout_time,ATTID);
		
#select THIS_DAY_WORK_TIME,ckin_time,ckout_time,ATTID;
# free_hour_late 和 FLEX_HOUR 互斥规则
# 如果FLEX_HOUR > 0，那么按照弹性规则计算迟到早退；
# 如果FLEX_HOUR = 0, 那么忽略弹性规则，按照
		#签到签退都有时
		IF (ckin_time is null and ckout_time is not null) THEN
			SET ckin_time = ckout_time;
		ELSEIF (ckout_time is null and ckin_time is not null) THEN
			SET ckout_time = ckin_time;
		ELSEIF (ckout_time is null and ckin_time is null) THEN
			SET ckin_time = aet;
			SET ckout_time = aet;
		END IF;

		SET MY_CHECKIN = CONCAT(TODAY,' ',ckin_time);
		
		IF ckout_time < ckin_time THEN
			SET MY_CHECKOUT = CONCAT(TOMORROW,' ',ckout_time);
		ELSEIF ckin_time <= ckout_time THEN
			SET MY_CHECKOUT = CONCAT(TODAY,' ',ckout_time);
		END IF;
		
		SET THIS_MST = CONCAT(TODAY,' ',mst);
		SET THIS_MET = CONCAT(TODAY,' ',met);
		SET THIS_AST = CONCAT(TODAY,' ',ast);
		SET THIS_AET = CONCAT(TODAY,' ',aet);
		

	#获得饭补时间段
		#无效时间段取最晚的一个
		IF THIS_NA1_BGTM IS NOT NULL AND THIS_NA2_BGTM IS NOT NULL THEN
			IF THIS_NA1_BGTM > THIS_NA2_BGTM THEN
				SET MY_DINNER_BGTM = THIS_NA1_BGTM ;
				SET MY_DINNER_EDTM = THIS_NA1_EDTM ;
			ELSE
				SET MY_DINNER_BGTM = THIS_NA2_BGTM ;
				SET MY_DINNER_EDTM = THIS_NA2_EDTM ;
			END IF;
		END IF;
		#在和下班点对比得到真的饭补时间段
		IF THIS_AET >= MY_DINNER_BGTM OR MY_DINNER_BGTM IS NULL THEN
			SET MY_DINNER_BGTM = NULL;
			SET MY_DINNER_EDTM = NULL;
		END IF;			
		#日弹
		/*
			迟到：上班打卡/电子流开始时间晚于最晚上班时间； 迟到时间从弹性后的时间点计算
			早退（下班点不做弹性计算）：下班打卡/电子流结束时间早于下班时间；全天有效工时大于6小时且小于8小时；
			旷工：上班打卡/电子流开始时间晚于等于最晚上班时间+2小时；全天无打卡记录（即没有外出电子流、
				也没有请假电子流等冲抵情况）；当天只有1个有效打卡时间或无任何打卡数据的情况；全天有效工时小于6小时；
		*/
		IF i_flex_hour > 0 AND i_flex_hour IS NOT NULL THEN
			SET CPT_MST = DATE_ADD(THIS_MST,INTERVAL i_flex_hour MINUTE);
			
			SET MY_REAL_FLEX_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(MY_CHECKIN,THIS_MST))/60,0);
			
			IF MY_REAL_FLEX_MINS > i_flex_hour THEN
				SET MY_REAL_FLEX_MINS = i_flex_hour;
			ELSEIF MY_REAL_FLEX_MINS < 0 THEN
				SET MY_REAL_FLEX_MINS = 0;
			END IF;
			
			
			#设定最晚下班时间点
			#首先网后天实际产生的弹性时间
			SET CPT_AET = DATE_ADD(THIS_AET,INTERVAL MY_REAL_FLEX_MINS MINUTE);

			#然后判断这个时间点是否落在了晚补时间段内
			IF CPT_AET >= MY_DINNER_EDTM THEN
				SET MY_DINNER_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(MY_DINNER_EDTM,MY_DINNER_BGTM))/60,0);
			ELSEIF MY_DINNER_BGTM <= CPT_AET AND MY_DINNER_EDTM > CPT_AET THEN
				SET MY_DINNER_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(CPT_AET,MY_DINNER_BGTM))/60,0);
			ELSE
				SET MY_DINNER_MINS = 0;
			END IF;
			
			SET CPT_AET = DATE_ADD(CPT_AET,INTERVAL MY_DINNER_MINS MINUTE);

			#签到时间早于最晚上班点
			IF (MY_CHECKIN <= CPT_MST) THEN
				SET MY_LATE_MINS = 0;
			#签到时间处于最晚上班点和上午结束时间点之间
			ELSEIF(MY_CHECKIN > CPT_MST and MY_CHECKIN < THIS_MET) THEN
				SET MY_LATE_MINS = TIME_TO_SEC(timediff(MY_CHECKIN,CPT_MST))/60;
			#签到时间处于中午午饭时间	
			ELSEIF(MY_CHECKIN >= THIS_MET and MY_CHECKIN < THIS_AST) THEN
				SET MY_LATE_MINS = TIME_TO_SEC(timediff(THIS_MET,CPT_MST))/60;
			#签到时间按处于下午时间
			ELSEIF(MY_CHECKIN >= THIS_AST and MY_CHECKIN < CPT_AET) THEN
				SET MY_LATE_MINS = (TIME_TO_SEC(timediff(MY_CHECKIN,CPT_MST)) - TIME_TO_SEC(timediff(THIS_AST,THIS_MET)))/60;
			#签到时间晚于下班时间
			ELSEIF(MY_CHECKIN >= CPT_AET) THEN
				SET MY_LATE_MINS = (TIME_TO_SEC(timediff(CPT_AET,CPT_MST)) - TIME_TO_SEC(timediff(THIS_AST,THIS_MET)))/60;

			END IF;
			
			SET MY_LEFT_MINS = SHOULD_WORK_MINS - THIS_DAY_WORK_TIME - MY_LATE_MINS;
			#判断签退时间是否落在饭补上
			IF MY_CHECKOUT >= MY_DINNER_EDTM THEN
				SET MY_CK_DINNER_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(MY_DINNER_EDTM,MY_DINNER_BGTM))/60,0);
			ELSEIF MY_DINNER_BGTM <= MY_CHECKOUT AND MY_DINNER_EDTM > MY_CHECKOUT THEN
				SET MY_CK_DINNER_MINS = ROUND(TIME_TO_SEC(TIMEDIFF(MY_CHECKOUT,MY_DINNER_BGTM))/60,0);
			ELSE
				SET MY_CK_DINNER_MINS = 0;
			END IF;
#select MY_CHECKOUT,CPT_AET,THIS_AET;
			#打卡时间早于下班时间
			IF MY_CHECKOUT < CPT_AET THEN
				IF (MY_CHECKOUT <= THIS_MST) THEN
#select 1;
					SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,THIS_MST))/60 - TIME_TO_SEC(timediff(THIS_AST,THIS_MET))/60;
				ELSEIF(MY_CHECKOUT > THIS_MST and MY_CHECKOUT < THIS_MET) THEN
#select 2;
					SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,MY_CHECKOUT))/60 - TIME_TO_SEC(timediff(THIS_AST,THIS_MET))/60;
				ELSEIF(MY_CHECKOUT >= THIS_MET and MY_CHECKOUT <= THIS_AST) THEN
#select 3;
					SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,THIS_AST))/60;
				ELSEIF(MY_CHECKOUT > THIS_AST and MY_CHECKOUT < CPT_AET) THEN
#select 4;
					SET MY_EARLY_MINS = TIME_TO_SEC(timediff(CPT_AET,MY_CHECKOUT))/60;
				END IF;
			ELSE
				IF MY_CHECKOUT <= CPT_AET AND THIS_DAY_WORK_TIME < SHOULD_WORK_MINS AND THIS_DAY_WORK_TIME > (SHOULD_WORK_MINS - OK_MINS) THEN
					SET MY_EARLY_MINS  = SHOULD_WORK_MINS - THIS_DAY_WORK_TIME - IFNULL(MY_LATE_MINS,0);
				ELSEIF MY_CHECKOUT > CPT_AET THEN
					SET MY_EARLY_MINS = 0;
				END IF;
			END IF;
#select MY_EARLY_MINS;			
			IF (MY_CHECKOUT <= CPT_AET OR MY_CHECKIN > CPT_AET) AND MY_EARLY_MINS < MY_LEFT_MINS THEN
				SET MY_EARLY_MINS = MY_LEFT_MINS;
			END IF;
#select MY_LATE_MINS,MY_EARLY_MINS,MY_LEFT_MINS,MY_CHECKOUT,MY_CHECKIN,CPT_AET;
		#月弹
		/*
			迟到：上班打卡/电子流开始时间晚于最晚上班时间；
			早退：下班打卡/下班打卡/电子流结束时间早于下班时间；全天有效工时大于（6小时-弹性时间）且小于（8小时-弹性时间）；
			旷工：上班打卡/电子流开始时间晚于等于最晚上班时间+2小时；全天无打卡记录（即没有外出电子流、也没有请假电子流等冲抵情况）；
				当天只有1个有效打卡时间或无任何打卡数据的情况；全天有效工时小于6小时；
		*/
		ELSEIF i_is_month_period=1 AND i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN
			SET MONTH_FLEX_MIN = SHOULD_WORK_MINS-i_month_period_hour*60;
			SET CPT_MST = DATE_ADD(CONCAT(TODAY,' ',mst),INTERVAL MONTH_FLEX_MIN MINUTE);

 
			IF MY_CHECKIN <= date_add(CPT_MST,interval i_free_hour_late minute) THEN
				SET MY_LATE_MINS = 0;
			ELSE
				#签到时间早于最晚上班点
				IF (MY_CHECKIN <= CPT_MST) THEN
					SET MY_LATE_MINS = 0;
				#签到时间处于最晚上班点和上午结束时间点之间
				ELSEIF(MY_CHECKIN > CPT_MST and MY_CHECKIN < THIS_MET) THEN
					SET MY_LATE_MINS = TIME_TO_SEC(timediff(MY_CHECKIN,CPT_MST))/60;
				#签到时间处于中午午饭时间	
				ELSEIF(MY_CHECKIN >= THIS_MET and MY_CHECKIN < THIS_AST) THEN
					SET MY_LATE_MINS = TIME_TO_SEC(timediff(THIS_MET,CPT_MST))/60;
				#签到时间按处于下午时间
				ELSEIF(MY_CHECKIN >= THIS_AST and MY_CHECKIN < THIS_AET) THEN
					SET MY_LATE_MINS = (TIME_TO_SEC(timediff(MY_CHECKIN,CPT_MST)) - TIME_TO_SEC(timediff(THIS_AST,THIS_MET)))/60;
				#签到时间晚于下班时间
				ELSEIF(MY_CHECKIN >= THIS_AET) THEN
					SET MY_LATE_MINS = (TIME_TO_SEC(timediff(THIS_AET,CPT_MST)) - TIME_TO_SEC(timediff(THIS_AST,THIS_MET)))/60;
				END IF;
			END IF;
			
			#下班打卡/电子流结束时间早于下班时间；
			IF MY_CHECKOUT < THIS_AET THEN
				IF (MY_CHECKOUT <= THIS_MST) THEN
					SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,THIS_MST))/60 - TIME_TO_SEC(timediff(THIS_AST,THIS_MET))/60;
				ELSEIF(MY_CHECKOUT > THIS_MST and MY_CHECKOUT < THIS_MET) THEN
					SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,MY_CHECKOUT))/60 - TIME_TO_SEC(timediff(THIS_AST,THIS_MET))/60;
				ELSEIF(MY_CHECKOUT >= THIS_MET and MY_CHECKOUT <= THIS_AST) THEN
					SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,THIS_AST))/60;
				ELSEIF(MY_CHECKOUT > THIS_AST and MY_CHECKOUT < THIS_AET) THEN
					SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,MY_CHECKOUT))/60;
				END IF;
			END IF;
		#其余
		ELSE
			#计算迟到
			#只要签到早于减免时间范围内，就按没迟到计算
			IF MY_CHECKIN <= date_add(THIS_MST,interval i_free_hour_late minute) THEN
				SET MY_LATE_MINS = 0;
			#签到晚于减免范围，按照正常计算
			ELSE
				IF (MY_CHECKIN <= THIS_MST) THEN
					SET MY_LATE_MINS = 0;
				ELSEIF(MY_CHECKIN > THIS_MST and MY_CHECKIN < THIS_MET) THEN
					SET MY_LATE_MINS = TIME_TO_SEC(timediff(MY_CHECKIN,THIS_MST))/60;
				ELSEIF(MY_CHECKIN >= THIS_MET and MY_CHECKIN <= THIS_AST) THEN
					SET MY_LATE_MINS = TIME_TO_SEC(timediff(THIS_MET,THIS_MST))/60;
				ELSEIF(MY_CHECKIN > THIS_AST and MY_CHECKIN < THIS_AET) THEN
					SET MY_LATE_MINS = (TIME_TO_SEC(timediff(MY_CHECKIN,THIS_MST)) - TIME_TO_SEC(timediff(THIS_AST,THIS_MET)))/60;
				ELSEIF(MY_CHECKIN >= THIS_AET) THEN
					SET MY_LATE_MINS = (TIME_TO_SEC(timediff(THIS_AET,THIS_MST)) - TIME_TO_SEC(timediff(THIS_AST,THIS_MET)))/60;
				END IF;
			END IF;

			#计算早退
			#只要签退晚于减免时间范围内，就按没迟到计算
			IF MY_CHECKOUT >= date_add(THIS_AET,interval -i_free_hour_early minute) THEN
				SET MY_EARLY_MINS = 0;
			#签退早于于减免范围，按照正常计算
			ELSE
				IF MY_CHECKOUT < THIS_AET THEN
					IF (MY_CHECKOUT <= THIS_MST) THEN
						SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,THIS_MST))/60 - TIME_TO_SEC(timediff(THIS_AST,THIS_MET))/60;
					ELSEIF(MY_CHECKOUT > THIS_MST and MY_CHECKOUT < THIS_MET) THEN
						SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,MY_CHECKOUT))/60 - TIME_TO_SEC(timediff(THIS_AST,THIS_MET))/60;
					ELSEIF(MY_CHECKOUT >= THIS_MET and MY_CHECKOUT <= THIS_AST) THEN
						SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,THIS_AST))/60;
					ELSEIF(MY_CHECKOUT > THIS_AST and MY_CHECKOUT < THIS_AET) THEN
						SET MY_EARLY_MINS = TIME_TO_SEC(timediff(THIS_AET,MY_CHECKOUT))/60;
					ELSEIF(MY_CHECKOUT >= THIS_AET) THEN
						SET MY_EARLY_MINS = 0;
					END IF;
				ELSE
					IF THIS_DAY_WORK_TIME < SHOULD_WORK_MINS AND THIS_DAY_WORK_TIME > (SHOULD_WORK_MINS - OK_MINS) THEN
						SET MY_EARLY_MINS  = SHOULD_WORK_MINS - THIS_DAY_WORK_TIME - IFNULL(MY_LATE_MINS,0);
					END IF;
				END IF;
			END IF;				
		END IF;
		
		#如果签或签退是空或两次打卡一样的情况
		IF ckin_time = ckout_time OR ckin_time IS NULL OR ckout_time IS NULL THEN
			SET MY_LATE_MINS = TIME_TO_SEC(timediff(aet,mst))/60 - TIME_TO_SEC(timediff(ast,met))/60;
			SET MY_EARLY_MINS = 0;
		END IF;
		
		IF MY_LATE_MINS IS NULL THEN SET MY_LATE_MINS = 0 ; END IF;
		IF MY_EARLY_MINS IS NULL THEN SET MY_EARLY_MINS = 0 ; END IF;
		
		SET MY_LATE_MINS = ROUND(MY_LATE_MINS,2);
		SET MY_EARLY_MINS = ROUND(MY_EARLY_MINS,2);
		
		#转化成最小单位
		if i_min_unit is not null then
		#最小单位（1:15分钟,2:30分钟,3:小时,4:半天,5:1天）
			case i_min_unit 
			when 1 then
				SET MY_LATE_MINS = ceiling(MY_LATE_MINS/15)*15;
				SET MY_EARLY_MINS = ceiling(MY_EARLY_MINS/15)*15;
			when 2 then
				SET MY_LATE_MINS = ceiling(MY_LATE_MINS/30)*30;
				SET MY_EARLY_MINS = ceiling(MY_EARLY_MINS/30)*30;
			when 3 then
				SET MY_LATE_MINS = ceiling(MY_LATE_MINS/60)*60;
				SET MY_EARLY_MINS = ceiling(MY_EARLY_MINS/60)*60;
			when 4 then
				SET MY_LATE_MINS = ceiling( MY_LATE_MINS / (FN_ATT_GET_WORKHOURS(deptid)*60/2) )*(FN_ATT_GET_WORKHOURS(deptid)*60/2);
				SET MY_EARLY_MINS = ceiling( MY_EARLY_MINS / (FN_ATT_GET_WORKHOURS(deptid)*60/2) )*(FN_ATT_GET_WORKHOURS(deptid)*60/2);
			when 5 then
				SET MY_LATE_MINS = ceiling(MY_LATE_MINS/(FN_ATT_GET_WORKHOURS(deptid)*60))*(FN_ATT_GET_WORKHOURS(deptid)*60);
				SET MY_EARLY_MINS = ceiling(MY_EARLY_MINS/(FN_ATT_GET_WORKHOURS(deptid)*60))*(FN_ATT_GET_WORKHOURS(deptid)*60);
			ELSE
				SET MY_LATE_MINS = MY_LATE_MINS;
				SET MY_EARLY_MINS = MY_EARLY_MINS;
			end case;
		end if;
		
#select SHOULD_WORK_MINS,MY_LATE_MINS,MY_EARLY_MINS;
		IF SHOULD_WORK_MINS - MY_LATE_MINS - MY_EARLY_MINS < 0 THEN
			IF MY_LATE_MINS > MY_EARLY_MINS THEN
				SET MY_LATE_MINS  = MY_LATE_MINS - (MY_LATE_MINS + MY_EARLY_MINS - SHOULD_WORK_MINS);
			ELSEIF MY_EARLY_MINS > MY_LATE_MINS THEN
				SET MY_EARLY_MINS = MY_EARLY_MINS - (MY_LATE_MINS + MY_EARLY_MINS - SHOULD_WORK_MINS);
			END IF;
		END IF;
		
#select SHOULD_WORK_MINS,MY_LATE_MINS,MY_EARLY_MINS;
	END IF;

END;

