create procedure SP_PAYROLL_FML_VIP_KR_HOL(IN  my_emp    bigint unsigned, IN bgdt date, IN eddt date,
                                           OUT my_salary decimal(13, 3), IN op_type int, IN archid bigint unsigned,
                                           IN  schemaid  bigint unsigned, IN setid bigint unsigned)
  comment '薪酬部分公式定制化计算-科瑞-病事假'
  BEGIN
DECLARE my_sick_hour,my_thing_hour,my_born_day,my_base_sala,my_pos_sala DECIMAL(13,3);
DECLARE my_opr_time DATETIME;
DECLARE my_enabletime INT;
 DECLARE i_version_code VARCHAR(50);
 SET i_version_code = UUID();
 SET @i_version_code = i_version_code;





	
	SET my_salary = 0;

	IF archid IS NOT NULL THEN
		
		SELECT st_value INTO my_sick_hour FROM att_st_month_arch_items WHERE st_name='病假' AND emp_id=my_emp AND arch_id = archid;
		SELECT st_value INTO my_thing_hour FROM att_st_month_arch_items WHERE st_name='事假' AND emp_id=my_emp AND arch_id = archid;
		SELECT st_value INTO my_born_day FROM att_st_month_arch_items WHERE st_name='产假' AND emp_id=my_emp AND arch_id = archid;
	
		IF my_sick_hour IS NULL THEN SET my_sick_hour = 0 ; END IF;
		IF my_thing_hour IS NULL THEN SET my_thing_hour = 0 ; END IF;
		IF my_born_day IS NULL THEN SET my_born_day = 0 ; END IF;
				
		
		SELECT MAX(ENABLE_TIME) INTO my_enabletime
		FROM EMP_SALARY_ADJ 
		WHERE EMP_ID = my_emp AND IS_ENABLE=1 AND ENABLE_TIME <= CAST(REPLACE(eddt,'-','') AS UNSIGNED);

		SELECT MAX(OPR_TIME) INTO my_opr_time
		FROM EMP_SALARY_ADJ 
		WHERE EMP_ID = my_emp AND IS_ENABLE=1 AND ENABLE_TIME = my_enabletime;

		
		SELECT DES_TB_NAME,DES_COL_NAME into @tb_jbgz,@col_jbgz FROM payroll_set_sala_schema_item WHERE SCHEMA_ID=42862561185792 AND ITEM_NAME='基本工资';
		SELECT DES_TB_NAME,DES_COL_NAME into @tb_gwgz,@col_gwgz FROM payroll_set_sala_schema_item WHERE SCHEMA_ID=42862561185792 AND ITEM_NAME='岗位工资';
		
		delete from  TMP_FML_VIP_VALUE where version_code = i_version_code;
		SET @setid = setid;
		SET @my_emp = my_emp;
		SET @SQL_JBGZ = CONCAT('INSERT INTO TMP_FML_VIP_VALUE SELECT ''',@i_version_code,''',`',@col_jbgz,'` FROM `',@tb_jbgz,'` WHERE SET_ID = ',@setid,' AND emp_id=',@my_emp,';');
		PREPARE stmt_jbgz FROM @SQL_JBGZ;
		EXECUTE stmt_jbgz;
		DEALLOCATE PREPARE stmt_jbgz;
		SELECT COL_VALUE INTO my_base_sala FROM TMP_FML_VIP_VALUE where version_code = i_version_code;
		IF my_base_sala IS NULL THEN SET my_base_sala = 0; END IF;
		
		delete from  TMP_FML_VIP_VALUE where version_code = i_version_code;
		SET @SQL_GWSE = CONCAT('INSERT INTO TMP_FML_VIP_VALUE SELECT ''',@i_version_code,''',`',@col_gwgz,'` FROM `',@tb_gwgz,'` WHERE SET_ID = ',@setid,' AND emp_id=',@my_emp,';');
		PREPARE stmt_gwgz FROM @SQL_GWSE;
		EXECUTE stmt_gwgz;
		DEALLOCATE PREPARE stmt_gwgz;
		SELECT COL_VALUE INTO my_pos_sala FROM TMP_FML_VIP_VALUE where version_code = i_version_code;
		IF my_pos_sala IS NULL THEN SET my_pos_sala = 0; END IF;
		
			
		IF my_opr_time IS NOT NULL AND (my_base_sala+my_pos_sala=0) THEN
			SELECT base_sala,pos_sala 
				INTO my_base_sala,my_pos_sala
			FROM EMP_SALARY_ADJ 
			WHERE EMP_ID = my_emp AND IS_ENABLE=1 AND OPR_TIME=my_opr_time;
			IF my_base_sala IS NULL THEN SET my_base_sala = 0 ; END IF;
			IF my_pos_sala IS NULL THEN SET my_pos_sala = 0 ; END IF;
		END IF;
				
		CASE op_type 
		
		WHEN 1 THEN
			
			SET my_salary = (my_base_sala + my_pos_sala)/21.75/8*0.4*my_sick_hour;
		
		WHEN 2 THEN
			
			SET my_salary = (my_base_sala + my_pos_sala)/21.75/8*my_thing_hour;
		
		WHEN 3 THEN
			
			SET my_salary = (my_base_sala + my_pos_sala)/21.75*my_born_day;
		END CASE;
	END IF;
	delete from  TMP_FML_VIP_VALUE where version_code = i_version_code;

END;

