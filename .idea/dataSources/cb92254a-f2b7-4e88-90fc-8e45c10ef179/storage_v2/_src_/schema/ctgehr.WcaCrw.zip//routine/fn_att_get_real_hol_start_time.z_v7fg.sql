create function FN_ATT_GET_REAL_HOL_START_TIME(MY_HOL_START_TIME datetime, MY_EMPID bigint unsigned,
                                               MY_HOLID          bigint unsigned)
  returns datetime
  comment '根据给出的条件和时间，计算出针对于此人的有效请假起始时间点'
  BEGIN
DECLARE BGDT DATE;
DECLARE ATTSET_MST,ATTSET_MET,ATTSET_AST,ATTSET_AET TIME;
DECLARE TMR_MST,THIS_ARRST,THIS_ARRET,THIS_MST,THIS_MET,THIS_AST,THIS_AET,MY_THIS_START_TIME DATETIME;
DECLARE TMR_ATTID_STR,ATTID_STR TEXT;
DECLARE TMR_ATTSET_ATTRULE,THIS_DTTYPE,ARR_CT,ARR_MXCT,SAFE_COUNT,HOLSET_HOLRULE,ATTSET_ATTRULE,IS_HAVE_EMP,IS_HAVE_HOL INT;
DECLARE MY_TMR_ATTID,MY_ATTID BIGINT UNSIGNED;

	IF MY_HOL_START_TIME IS NOT NULL AND MY_EMPID IS NOT NULL AND MY_HOLID IS NOT NULL THEN
		SELECT COUNT(*) INTO IS_HAVE_EMP FROM emp_base_info A WHERE A.emp_id=MY_EMPID;
		SELECT COUNT(*) INTO IS_HAVE_HOL FROM att_set_holiday_main A WHERE A.hol_id=MY_HOLID;
		#全部条件都满足后开始计算
		IF IS_HAVE_EMP>0 AND IS_HAVE_HOL>0 THEN
	########################################################################################################################################################################		
	#	1.前提准备 读取各种设置
	########################################################################################################################################################################		
			SELECT A.hol_rule INTO HOLSET_HOLRULE
			FROM att_set_holiday_main A
			WHERE A.hol_id=MY_HOLID;
			
			SET BGDT = DATE(MY_HOL_START_TIME);
	########################################################################################################################################################################
	#	2.按工作日
	########################################################################################################################################################################
			IF HOLSET_HOLRULE = 1 THEN

		########################################################################################################################################################################
		#	2.1 坐班
		########################################################################################################################################################################
					SET SAFE_COUNT = 1, THIS_DTTYPE = NULL;
					
					#如果给的日期不是工作日，那么需要往后取工作日
					WHILE SAFE_COUNT <= 10 AND MY_THIS_START_TIME IS NULL DO
						SET ATTID_STR=NULL,MY_ATTID=NULL,ATTSET_ATTRULE=NULL;
						SET ARR_MXCT=0;
						
						#得到出勤方案
						CALL SP_DPT_GET_SETTINGID(MY_EMPID,BGDT,7,ATTID_STR);
						SET MY_ATTID = LEFT(ATTID_STR,LOCATE(':',ATTID_STR)-1);
						SET ATTSET_ATTRULE = RIGHT(ATTID_STR,LENGTH(ATTID_STR)-LOCATE(':',ATTID_STR));
						
						IF ATTSET_ATTRULE = 1 THEN
							SET ATTSET_MST=NULL,ATTSET_MET=NULL,ATTSET_AST=NULL,ATTSET_AET=NULL;
							SET THIS_MST=NULL,THIS_MET=NULL,THIS_AST=NULL,THIS_AET=NULL;
							
							SELECT A.morn_start_time,A.morn_end_time,A.aftn_start_time,A.aftn_end_time
								INTO ATTSET_MST,ATTSET_MET,ATTSET_AST,ATTSET_AET
							FROM att_set_schema_new A WHERE A.att_id=MY_ATTID;
	
							SET THIS_DTTYPE = FN_ATT_GET_DTTYPE(BGDT,MY_EMPID);
							IF THIS_DTTYPE IN (1,6) THEN
								#把轮到的工作日日期带入起始时间点
								SET THIS_MST = CONCAT(BGDT,' ',ATTSET_MST),
									 THIS_MET = CONCAT(BGDT,' ',ATTSET_MET),
									 THIS_AST = CONCAT(BGDT,' ',ATTSET_AST),
									 THIS_AET = CONCAT(BGDT,' ',ATTSET_AET);
								#当日期后推时，起点取当天0点
								IF BGDT <> DATE(MY_HOL_START_TIME) THEN
									SET MY_THIS_START_TIME = THIS_MST;
								#给出的日期就是工作日
								ELSE
									#在两个工作时间段中间
									IF (MY_HOL_START_TIME>=THIS_MST AND MY_HOL_START_TIME<=THIS_MET) OR (MY_HOL_START_TIME>=THIS_AST AND MY_HOL_START_TIME<=THIS_AET) THEN
										SET MY_THIS_START_TIME = MY_HOL_START_TIME;
									#在两个休息时间段中间
									ELSEIF MY_HOL_START_TIME>THIS_MET AND MY_HOL_START_TIME<THIS_AST THEN
										SET MY_THIS_START_TIME = THIS_AST;
									#比上午起点早
									ELSEIF MY_HOL_START_TIME < THIS_MST THEN
										SET MY_THIS_START_TIME = THIS_MST;
									#比下午终点晚,到下一个循环取
									ELSEIF MY_HOL_START_TIME > THIS_AET THEN
										SET MY_THIS_START_TIME = NULL;
									END IF;
								END IF;
							ELSE
								SET MY_THIS_START_TIME = NULL;
							END IF;
		########################################################################################################################################################################
		#	2.2 排班
		########################################################################################################################################################################
						ELSEIF ATTSET_ATTRULE = 3 THEN
							SET THIS_ARRST=NULL,THIS_ARRET=NULL;
							SELECT COUNT(*) INTO ARR_MXCT FROM att_arrange_schedual A WHERE A.emp_id=MY_EMPID AND A.dt=BGDT;
							IF ARR_MXCT > 0 THEN
								SET ARR_CT = 1 ;
								#按照当日班次进行循环读取和处理
								WHILE ARR_CT <= ARR_MXCT DO
									#读出本次起止点
									SELECT A.arr_start_time,A.arr_end_time INTO THIS_ARRST,THIS_ARRET 
									FROM att_arrange_schedual A WHERE A.emp_id=MY_EMPID AND A.dt=BGDT AND A.arr_no=ARR_CT;
									
									#只需要看 早于和在其中两种情况
									#比本次时间早
									IF MY_HOL_START_TIME < THIS_ARRST THEN
										SET MY_THIS_START_TIME = THIS_ARRST;
									#在时间段内
									ELSEIF MY_HOL_START_TIME >= THIS_ARRST AND MY_HOL_START_TIME <= THIS_ARRET THEN
										SET MY_THIS_START_TIME = MY_HOL_START_TIME;
									ELSE
										SET MY_THIS_START_TIME = NULL;
									END IF;
									
									#如果没在本次得到，到下一轮
		 							IF MY_THIS_START_TIME IS NULL THEN
										SET ARR_CT = ARR_CT + 1;
									#得到了就退出循环
									ELSE 
										SET ARR_CT = ARR_MXCT + 1;
									END IF;
									
								END WHILE;
							ELSE
								SET MY_THIS_START_TIME = NULL;
							END IF;							
						END IF;
						SET SAFE_COUNT = SAFE_COUNT + 1;
						SET BGDT = DATE_ADD(BGDT,INTERVAL 1 DAY);
					END WHILE;
	########################################################################################################################################################################
	#	3.按自然日
	########################################################################################################################################################################
			ELSEIF HOLSET_HOLRULE = 2 THEN
				SET ATTID_STR=NULL,MY_ATTID=NULL,ATTSET_ATTRULE=NULL;
				
				#得到出勤方案
				CALL SP_DPT_GET_SETTINGID(MY_EMPID,BGDT,7,ATTID_STR);
				SET MY_ATTID = LEFT(ATTID_STR,LOCATE(':',ATTID_STR)-1);
				SET ATTSET_ATTRULE = RIGHT(ATTID_STR,LENGTH(ATTID_STR)-LOCATE(':',ATTID_STR));

		########################################################################################################################################################################
		#	3.1 坐班
		########################################################################################################################################################################
				IF ATTSET_ATTRULE = 1 THEN
					SET ATTSET_MST=NULL,ATTSET_MET=NULL,ATTSET_AST=NULL,ATTSET_AET=NULL;
					SET THIS_MST=NULL,THIS_MET=NULL,THIS_AST=NULL,THIS_AET=NULL,TMR_MST=NULL;
			
					SELECT A.morn_start_time,A.morn_end_time,A.aftn_start_time,A.aftn_end_time
						INTO ATTSET_MST,ATTSET_MET,ATTSET_AST,ATTSET_AET
					FROM att_set_schema_new A WHERE A.att_id=MY_ATTID;

					SET THIS_MST = CONCAT(BGDT,' ',ATTSET_MST),
						 THIS_MET = CONCAT(BGDT,' ',ATTSET_MET),
						 THIS_AST = CONCAT(BGDT,' ',ATTSET_AST),
						 THIS_AET = CONCAT(BGDT,' ',ATTSET_AET);
					
					#在两个工作时间段中间
					IF ( MY_HOL_START_TIME >= THIS_MST AND MY_HOL_START_TIME <= THIS_MET ) OR ( MY_HOL_START_TIME >= THIS_AST AND MY_HOL_START_TIME <= THIS_AET ) THEN
						SET MY_THIS_START_TIME = MY_HOL_START_TIME;
					#在两个休息时间段中间
					ELSEIF MY_HOL_START_TIME > THIS_MET AND MY_HOL_START_TIME < THIS_AST THEN
						SET MY_THIS_START_TIME = THIS_AST;
					#比上午起点早
					ELSEIF MY_HOL_START_TIME < THIS_MST THEN
						SET MY_THIS_START_TIME = THIS_MST;
					#比下午终点晚
					ELSEIF MY_HOL_START_TIME > THIS_AET THEN
						CALL SP_DPT_GET_SETTINGID(MY_EMPID,DATE_ADD(BGDT,INTERVAL 1 DAY),7,TMR_ATTID_STR);
						SET MY_TMR_ATTID = LEFT(TMR_ATTID_STR,LOCATE(':',TMR_ATTID_STR)-1);
						SET TMR_ATTSET_ATTRULE = RIGHT(TMR_ATTID_STR,LENGTH(TMR_ATTID_STR)-LOCATE(':',TMR_ATTID_STR));
						IF MY_TMR_ATTID = MY_ATTID THEN
							SET MY_THIS_START_TIME = DATE_ADD(THIS_MST,INTERVAL 1 DAY);
						ELSE
							IF TMR_ATTSET_ATTRULE = 1 THEN
								SELECT CONCAT(DATE_ADD(BGDT,INTERVAL 1 DAY),' ',A.morn_start_time) INTO TMR_MST 
								FROM att_set_schema_new A WHERE A.att_id=MY_TMR_ATTID;
								
								SET MY_THIS_START_TIME = TMR_MST;
							ELSEIF TMR_ATTSET_ATTRULE = 3 THEN
								SET MY_THIS_START_TIME = CONCAT(DATE_ADD(BGDT,INTERVAL 1 DAY),' 00:00:00');
							END IF;
						END IF;
					END IF;
		########################################################################################################################################################################
		#	3.2 排班
		########################################################################################################################################################################
				ELSEIF ATTSET_ATTRULE = 3 THEN
					SET MY_THIS_START_TIME = MY_HOL_START_TIME;
				END IF;
			END IF;
		END IF;
	END IF;
RETURN MY_THIS_START_TIME;
END;

