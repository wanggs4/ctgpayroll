create procedure SP_ATT_MONTH_OVER_PAY_SINGLE(IN bgdt date, IN eddt date, IN emp bigint, IN stid bigint)
  comment '根据给出的时间段计算加班的钱数'
  BEGIN
DECLARE IS_LEFT_LOGS,THIS_DTTYPE,IEH,is_have_new_year_over,stat,o_is_left_rest,ct,mxct,o_is_sala_compute,max_enable_time,o_over_sala_compute_rule INT;
DECLARE THIS_APPLY_ID,OP_CT,OP_MXCT,i_emp,i_deptid,i_custid,MY_OT_ID BIGINT;
DECLARE THIS_OVER_HOUR,MY_WORKDAY_HOURS,MY_WEEKEND_HOURS,MY_HOLIDAY_HOURS,left_rest_hours,i_days,i_sala_hours,i_daily_hour,this_sala_hours,i_sala_prog,o_work_sala_day,o_work_sala_wkd,o_work_sala_hol,o_max_sala_hour,i_work_pay,left_max_sala_hour,i_rest_hours DECIMAL(12,2);
DECLARE i_version_code,o_sala_prog VARCHAR(50);
DECLARE i_bgdt DATE;
DECLARE ATTID_STR TEXT;
DECLARE ATTID BIGINT UNSIGNED;
SET i_version_code = UUID();

	#读出每个人的id
	SELECT emp_id,dept_id,cust_id INTO i_emp,i_deptid,i_custid FROM emp_base_info where emp_id=emp;
	
	IF i_emp IS NOT NULL THEN
		#把日报中范围内的发薪时数清零，重新计算
		UPDATE att_over_apply_day A 
		SET A.sala_hour = 0,A.pay_money=0
		WHERE A.emp_id = i_emp AND A.work_day between bgdt and eddt and A.date_repay_type=1 ;
		
		select MIN(A.ot_id),MIN(A.att_id) INTO MY_OT_ID,ATTID
		from att_over_apply_day A
		where A.emp_id=i_emp AND A.work_day between bgdt and eddt and A.date_repay_type=1 ;
		
		#读出加班设置
		SELECT B.max_sala_hour,
			IFNULL(B.workday_sala_rate,1),IFNULL(B.weekend_sala_rate,1),IFNULL(B.holiday_sala_rate,1),
			B.over_sala_compute_rule
			INTO 
				o_max_sala_hour,			#最大发薪时数
				o_work_sala_day,				#工作日x倍薪酬项目
				o_work_sala_wkd,				#周末x倍薪酬项目
				o_work_sala_hol,				#法定节假日x倍薪酬项目
				o_over_sala_compute_rule	#加班计薪顺序(1.以发生时间顺序计算加班费 2,以最高倍数最优先计算加班费 3.以最低倍数最优先计算加班费)
		FROM att_set_overtime_new B 
		WHERE B.ot_id=MY_OT_ID;
		
		
		# 得到薪酬项目的值
		CALL SP_ATT_GET_SALA_PROG(i_emp,eddt,4,MY_OT_ID,NULL,i_sala_prog);

		#计算 一天工作时长 
		SET i_daily_hour = FN_ATT_GET_WORKHOURS(ATTID);
		# 得到本周期工作天数 i_days
		SET i_days = FN_ATT_GET_WORKDAYS(bgdt,eddt,i_emp,1);
#select i_sala_prog,i_daily_hour,i_days;

#------>	加班计算规则逻辑开始
		IF o_over_sala_compute_rule = 1 THEN #按时间顺序计算加班
			#把当天该人置换方式为加班费的加班apply_id列表存起来循环处理
			INSERT INTO TMP_OVERPAY_APPLY_LIST (VERSION_CODE,APPLY_ID,dt)
				SELECT i_version_code,A.apply_id,A.work_day
				FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id=i_emp AND A.work_day BETWEEN bgdt AND eddt 
					AND A.date_repay_type=1 AND B.is_delete=0 AND B.state=1
				ORDER BY A.work_day,A.apply_id;
		ELSEIF o_over_sala_compute_rule = 2 THEN #以最高倍数最优先计算加班			
			#把当天该人置换方式为加班费的加班apply_id列表存起来循环处理
			#节假日
			INSERT INTO TMP_OVERPAY_APPLY_LIST (VERSION_CODE,APPLY_ID,dt)
				SELECT i_version_code,A.apply_id,A.work_day
				FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id=i_emp AND A.work_day BETWEEN bgdt AND eddt AND A.date_type=3
					AND A.date_repay_type=1 AND B.is_delete=0 AND B.state=1
				ORDER BY A.work_day,A.apply_id;
			#周末
			INSERT INTO TMP_OVERPAY_APPLY_LIST (VERSION_CODE,APPLY_ID,dt)
				SELECT i_version_code,A.apply_id,A.work_day
				FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id=i_emp AND A.work_day BETWEEN bgdt AND eddt AND A.date_type IN (2,4)
					AND A.date_repay_type=1 AND B.is_delete=0 AND B.state=1
				ORDER BY A.work_day,A.apply_id;
			#工作日
			INSERT INTO TMP_OVERPAY_APPLY_LIST (VERSION_CODE,APPLY_ID,dt)
				SELECT i_version_code,A.apply_id,A.work_day
				FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id=i_emp AND A.work_day BETWEEN bgdt AND eddt AND A.date_type IN (1,6)
					AND A.date_repay_type=1 AND B.is_delete=0 AND B.state=1
				ORDER BY A.work_day,A.apply_id;
		ELSEIF o_over_sala_compute_rule = 3 THEN	#以最低倍数最优先计算加班费
			#把当天该人置换方式为加班费的加班apply_id列表存起来循环处理
			#工作日
			INSERT INTO TMP_OVERPAY_APPLY_LIST (VERSION_CODE,APPLY_ID,dt)
				SELECT i_version_code,A.apply_id,A.work_day
				FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id=i_emp AND A.work_day BETWEEN bgdt AND eddt AND A.date_type IN (1,6)
					AND A.date_repay_type=1 AND B.is_delete=0 AND B.state=1
				ORDER BY A.work_day,A.apply_id;
			#周末
			INSERT INTO TMP_OVERPAY_APPLY_LIST (VERSION_CODE,APPLY_ID,dt)
				SELECT i_version_code,A.apply_id,A.work_day
				FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id=i_emp AND A.work_day BETWEEN bgdt AND eddt AND A.date_type IN (2,4)
					AND A.date_repay_type=1 AND B.is_delete=0 AND B.state=1
				ORDER BY A.work_day,A.apply_id;
			#节假日
			INSERT INTO TMP_OVERPAY_APPLY_LIST (VERSION_CODE,APPLY_ID,dt)
				SELECT i_version_code,A.apply_id,A.work_day
				FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id=i_emp AND A.work_day BETWEEN bgdt AND eddt AND A.date_type=3
					AND A.date_repay_type=1 AND B.is_delete=0 AND B.state=1
				ORDER BY A.work_day,A.apply_id;
		END IF;
		#初始化指针
		SET OP_CT  = NULL;
		SET OP_MXCT = NULL;
		SELECT MIN(ID),MAX(ID) INTO OP_CT,OP_MXCT FROM TMP_OVERPAY_APPLY_LIST WHERE VERSION_CODE=i_version_code;
		# 初始化发薪时数池
		SET left_max_sala_hour = o_max_sala_hour;
		#循环列表里的每一个按天的apply_id
		WHILE OP_CT<=OP_MXCT AND OP_CT>0 AND left_max_sala_hour > 0 DO
			#读出本次要计算的apply_id和日期
			SELECT APPLY_ID,dt INTO THIS_APPLY_ID,i_bgdt 
			FROM TMP_OVERPAY_APPLY_LIST 
			WHERE ID=OP_CT AND VERSION_CODE=i_version_code;
			
			#当apply_id存在时，再进行计算
			IF THIS_APPLY_ID IS NOT NULL THEN
				#进而得出当此加班时数
				SELECT A.work_hour INTO THIS_OVER_HOUR
				FROM att_over_apply_day A 
				WHERE A.apply_id=THIS_APPLY_ID AND A.work_day = i_bgdt;
				#得到当日的类型
				SET THIS_DTTYPE = FN_ATT_GET_DTTYPE(i_bgdt,i_emp);
				
			#计算时数和钱数
				#工作日加班
				IF THIS_DTTYPE IN (1,6) THEN
					#够扣时
					IF left_max_sala_hour >= THIS_OVER_HOUR THEN
						SET left_max_sala_hour = left_max_sala_hour - THIS_OVER_HOUR;							
					#不够扣时
					ELSEIF left_max_sala_hour < THIS_OVER_HOUR THEN
						SET THIS_OVER_HOUR = left_max_sala_hour;
						SET left_max_sala_hour = 0;
					END IF;
					
					SET i_work_pay = ROUND(i_sala_prog/i_days/i_daily_hour*THIS_OVER_HOUR*o_work_sala_day,2);
				#公休日加班
				ELSEIF THIS_DTTYPE IN (2,4) THEN
					#够扣时
					IF left_max_sala_hour >= THIS_OVER_HOUR THEN
						SET left_max_sala_hour = left_max_sala_hour - THIS_OVER_HOUR;
					#不够扣时
					ELSEIF left_max_sala_hour < THIS_OVER_HOUR THEN
						SET THIS_OVER_HOUR = left_max_sala_hour;
						SET left_max_sala_hour = 0;
					END IF;

					SET i_work_pay = ROUND(i_sala_prog/i_days/i_daily_hour*THIS_OVER_HOUR*o_work_sala_wkd,2);
				#法定节假日加班
				ELSEIF THIS_DTTYPE = 3 THEN
					#够扣时
					IF left_max_sala_hour >= THIS_OVER_HOUR THEN
						SET left_max_sala_hour = left_max_sala_hour - THIS_OVER_HOUR;
					#不够扣时
					ELSEIF left_max_sala_hour < THIS_OVER_HOUR THEN
						SET THIS_OVER_HOUR = left_max_sala_hour;
						SET left_max_sala_hour = 0;
					END IF;
					
					SET i_work_pay = ROUND(i_sala_prog/i_days/i_daily_hour*THIS_OVER_HOUR*o_work_sala_hol,2);
				END IF;
				
				IF i_work_pay IS NULL THEN SET i_work_pay = 0; END IF;

				UPDATE att_over_apply_day A 
				SET A.sala_hour = THIS_OVER_HOUR ,A.pay_money=i_work_pay
				WHERE A.apply_id = THIS_APPLY_ID AND A.work_day = i_bgdt;
			END IF;
			SET OP_CT = OP_CT + 1;
		END WHILE;
#<------	加班计算规则逻辑结束			
	END IF;
END;

