create procedure SP_ATT_MONTH_REPORT_ST_POOL(IN MY_STID bigint unsigned, IN MY_EMPID bigint unsigned)
  comment '假期池统计报表'
  BEGIN
DECLARE IS_HAVE_STID INT;
DECLARE CT,MXCT,MY_DEPTID BIGINT UNSIGNED;
DECLARE I_VERSION_CODE,MY_EMPCODE,MY_EMPNAME,MY_DEPTFULLNAME VARCHAR(500);
DECLARE MY_ENTRYDATE,MY_LEAVEDATE,MON_BGDT,MON_EDDT DATE;
DECLARE TMP_THIS_YEAR_HAVE,TMP_THIS_CREDIT_YEAR_HAVE,MY_THIS_YEAR_ALL_HAVE,MY_THIS_HOLIDAY_OVER_HAPPEND,MY_THIS_OVER_HAPPEND,MY_THIS_REST_HAPPEND,MY_THIS_YEAR_HAPPEND,MY_THIS_YEAR_HAVE,DO_HAVE,DO_USE,MY_THIS_CREDIT_USE,MY_LAST_YEAR_LEFT,MY_THIS_YEAR_LEFT,MY_ALL_YEAR_LEFT,MY_LAST_REST_LEFT,MY_THIS_REST_LEFT,MY_ALL_REST_LEFT DECIMAL(12,2);


	SET I_VERSION_CODE = UUID();
	
	SELECT COUNT(*),A.comp_start_time,A.comp_end_time 
		INTO IS_HAVE_STID,MON_BGDT,MON_EDDT 
	FROM att_st_month A 
	WHERE ST_ID = MY_STID;
	
	IF IS_HAVE_STID > 0 AND IS_HAVE_STID IS NOT NULL THEN
		IF MY_EMPID IS NULL THEN
			INSERT INTO tmp_att_month_st_pool_list (VERSION_CODE,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
				SELECT I_VERSION_CODE,A.emp_id,A.emp_code,A.emp_name,A.entry_date,A.leave_date,A.dept_id,A.dept_full_name
				FROM att_st_month_quick_view_icss A
				WHERE A.st_id=MY_STID;
		ELSEIF MY_EMPID IS NOT NULL THEN
			INSERT INTO tmp_att_month_st_pool_list (VERSION_CODE,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
				SELECT I_VERSION_CODE,A.emp_id,A.emp_code,A.emp_name,A.entry_date,A.leave_date,A.dept_id,A.dept_full_name
				FROM att_st_month_quick_view_icss A
				WHERE A.st_id=MY_STID AND A.emp_id = MY_EMPID;
		END IF;
		
		SET CT = 0 ,MXCT = 0;
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_att_month_st_pool_list WHERE VERSION_CODE = I_VERSION_CODE;
		WHILE CT <= MXCT AND CT > 0 DO
			SET MY_EMPID=NULL,MY_EMPCODE=NULL,MY_EMPNAME=NULL,MY_ENTRYDATE=NULL,MY_LEAVEDATE=NULL,MY_DEPTID=NULL,MY_DEPTFULLNAME=NULL;
			
			SELECT A.emp_id,A.emp_code,A.emp_name,A.entry_date,A.leave_date,A.dept_id,A.dept_full_name
				INTO MY_EMPID,MY_EMPCODE,MY_EMPNAME,MY_ENTRYDATE,MY_LEAVEDATE,MY_DEPTID,MY_DEPTFULLNAME
			FROM tmp_att_month_st_pool_list A
			WHERE A.id = CT AND A.VERSION_CODE = I_VERSION_CODE;
			
			IF MY_EMPID IS NOT NULL THEN
				SET TMP_THIS_YEAR_HAVE=0,TMP_THIS_CREDIT_YEAR_HAVE=0,MY_THIS_YEAR_ALL_HAVE=0,MY_THIS_HOLIDAY_OVER_HAPPEND=0,MY_THIS_OVER_HAPPEND=0,MY_THIS_REST_HAPPEND=0,MY_THIS_YEAR_HAPPEND=0,MY_THIS_YEAR_HAVE=0,DO_HAVE=0,DO_USE=0,MY_THIS_CREDIT_USE=0,MY_LAST_YEAR_LEFT=0,MY_THIS_YEAR_LEFT=0,MY_ALL_YEAR_LEFT=0,MY_LAST_REST_LEFT=0,MY_THIS_REST_LEFT=0,MY_ALL_REST_LEFT=0;
	#PART 1 年假--------------------------------------------------------------------------------------------------- 
			#截至到当月可休年假（小时）
				SELECT IFNULL(SUM(IFNULL(A.this_year_have,0)),0)*8
					INTO MY_THIS_YEAR_HAVE
				FROM att_hol_year A
				WHERE A.emp_id=MY_EMPID AND A.this_year = YEAR(MON_BGDT) AND A.is_delete=0;
				
				#得到往年have在月底之后的改动
				SET DO_HAVE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)*8
					INTO DO_HAVE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt > MON_EDDT AND A.pool_type=1 AND A.which_year = YEAR(MON_BGDT) AND A.op_type=1 AND A.is_erase=0;	
				
				SET MY_THIS_YEAR_HAVE = MY_THIS_YEAR_HAVE - DO_HAVE;
				
			#截止到当年可休年假（小时）
			#当年（2020年）的截止到6月底时，理论上全年的年假。
				SELECT IFNULL(SUM(IFNULL(A.this_year_have,0)),0)*8
					INTO TMP_THIS_YEAR_HAVE
				FROM att_hol_year A
				WHERE A.emp_id=MY_EMPID AND A.this_year = YEAR(MON_BGDT) AND A.is_delete=0;

/*
				#得到当年have在月底之后的改动
				SET DO_HAVE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)*8
					INTO DO_HAVE
				FROM att_st_icss_pool_log A
				WHERE A.emp_id=MY_EMPID AND A.dt > MON_EDDT AND A.pool_type=1 AND A.which_year = YEAR(MON_BGDT) AND A.op_type=1 AND A.is_erase=0;	

				SET TMP_THIS_YEAR_HAVE = IFNULL(TMP_THIS_YEAR_HAVE,0) - IFNULL(DO_HAVE,0);
*/

				SELECT IFNULL(SUM(IFNULL(A.this_year_have,0)),0)*8
					INTO TMP_THIS_CREDIT_YEAR_HAVE
				FROM att_hol_credit_year A
				WHERE A.emp_id=MY_EMPID AND A.this_year = YEAR(MON_BGDT) AND A.is_delete=0;
/*
				#得到当年have在月底之后的改动
				SET DO_HAVE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)*8
					INTO DO_HAVE
				FROM att_st_icss_pool_log A
				WHERE A.emp_id=MY_EMPID AND A.dt > MON_EDDT AND A.pool_type=3 AND A.which_year = YEAR(MON_BGDT) AND A.op_type=1 AND A.is_erase=0;	
				
				SET TMP_THIS_CREDIT_YEAR_HAVE = IFNULL(TMP_THIS_CREDIT_YEAR_HAVE,0) - IFNULL(DO_HAVE,0);
*/			
				SET MY_THIS_YEAR_ALL_HAVE = TMP_THIS_YEAR_HAVE + TMP_THIS_CREDIT_YEAR_HAVE;
#select TMP_THIS_YEAR_HAVE,TMP_THIS_CREDIT_YEAR_HAVE;
			#截至到上月非当年未休年假（小时）
			#非当年（2019年及以前）的年假池结余（截至到5月底）
				#得到往年当前剩余值
				SELECT IFNULL(SUM(IFNULL(A.this_year_left,0)),0)*8
					INTO MY_LAST_YEAR_LEFT
				FROM att_hol_year A
				WHERE A.emp_id=MY_EMPID AND A.this_year < YEAR(MON_BGDT) AND A.is_delete=0;
				
				#得到往年have在月底之后的改动
				SET DO_HAVE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)*8
					INTO DO_HAVE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= MON_EDDT AND A.pool_type=1 AND A.which_year < YEAR(MON_BGDT) AND A.op_type=1 AND A.is_erase=0;		

				#得到往年use在月底之后的改动
				SET DO_USE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)*8
					INTO DO_USE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= MON_BGDT AND A.pool_type=1 AND A.which_year < YEAR(MON_BGDT) AND A.op_type=2 AND A.is_erase=0;		

				#逆向计算后得到月底的剩余值
				SET MY_LAST_YEAR_LEFT = MY_LAST_YEAR_LEFT - DO_HAVE + DO_USE;
				
			#截至当月当年未休年假（小时）（已扣除截至上月已休）
			#此结果为综合预支的结余：截至5月底的年假池结余-截至5月底的预支年假池已用+6月份释放
				SELECT IFNULL(SUM(IFNULL(A.this_year_left,0)),0)*8
					INTO MY_THIS_YEAR_LEFT
				FROM att_hol_year A
				WHERE A.emp_id=MY_EMPID AND A.this_year = YEAR(MON_BGDT) AND A.is_delete=0;
				
				#得到当年have在月底之后的改动
				SET DO_HAVE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)*8
					INTO DO_HAVE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt > MON_EDDT AND A.pool_type=1 AND A.which_year = YEAR(MON_BGDT) AND A.op_type=1 AND A.is_erase=0;	

				#得到当年use在月底之后的改动
				SET DO_USE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)*8
					INTO DO_USE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= MON_BGDT AND A.pool_type=1 AND A.which_year = YEAR(MON_BGDT) AND A.op_type=2 AND A.is_erase=0;		

				#逆向计算后得到月底的剩余值
				SET MY_THIS_YEAR_LEFT = MY_THIS_YEAR_LEFT - DO_HAVE + DO_USE;
				
				#得到当年预支年假池的当前use
				SET MY_THIS_CREDIT_USE = 0;
				SELECT IFNULL(SUM(IFNULL(A.this_year_use,0)),0)*8
					INTO MY_THIS_CREDIT_USE
				FROM att_hol_credit_year A
				WHERE A.emp_id=MY_EMPID AND A.this_year = YEAR(MON_BGDT) AND A.is_delete=0;
				
				#得到当年use在月底之后的改动
				SET DO_USE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)*8
					INTO DO_USE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= MON_EDDT AND A.pool_type=3 AND A.which_year = YEAR(MON_BGDT) AND A.op_type=2 AND A.is_erase=0;	

				#逆向计算后得到月底的剩余值
				SET MY_THIS_CREDIT_USE = IFNULL(MY_THIS_CREDIT_USE,0) - IFNULL(DO_USE,0);
				
				#剩余减去预支已用
				SET MY_THIS_YEAR_LEFT = MY_THIS_YEAR_LEFT - MY_THIS_CREDIT_USE;
			
			#本月已休年假（小时）,本月新增法定加日加班小时数。（小时）,本月新增可补休数（小时）,本月已补休小时（小时）
				SELECT IFNULL(A.TYPE0002,0)*8,IFNULL(A.jrjbsc,0),IFNULL(A.byxzbxxs,0),IFNULL(A.TYPE0001,0)
					INTO MY_THIS_YEAR_HAPPEND,MY_THIS_HOLIDAY_OVER_HAPPEND,MY_THIS_OVER_HAPPEND,MY_THIS_REST_HAPPEND
				FROM att_st_month_quick_view_icss A
				WHERE A.st_id=	MY_STID AND A.emp_id= MY_EMPID;

/*
				select sum(a.hol_hours) into MY_THIS_YEAR_HAPPEND
				from att_hol_apply_day a 
					left join att_st_icss_pool_log b on a.apply_id=b.apply_id
					left join att_st_month c on a.hol_date <= c.comp_end_time and a.hol_date >= c.comp_start_time 
				where a.emp_id=MY_EMPID and b.is_erase=0 and c.st_id = MY_STID and b.dt <= c.comp_end_time and b.dt >= c.comp_start_time
					and b.pool_type=1 and b.op_type=2;
				
				select sum(a.hol_hours) into MY_THIS_HOLIDAY_OVER_HAPPEND
				from att_over_apply_day a 
					left join att_st_icss_pool_log b on a.apply_id=b.apply_id
					left join att_st_month c on a.hol_date <= c.comp_end_time and a.hol_date >= c.comp_start_time 
				where a.emp_id=MY_EMPID and b.is_erase=0 and c.st_id = MY_STID and b.dt <= c.comp_end_time and b.dt >= c.comp_start_time
					and b.pool_type=2 and b.op_type=1 and a.date_type = 3;
				
				select sum(a.hol_hours) into MY_THIS_OVER_HAPPEND
				from att_over_apply_day a 
					left join att_st_icss_pool_log b on a.apply_id=b.apply_id
					left join att_st_month c on a.hol_date <= c.comp_end_time and a.hol_date >= c.comp_start_time 
				where a.emp_id=MY_EMPID and b.is_erase=0 and c.st_id = MY_STID and b.dt <= c.comp_end_time and b.dt >= c.comp_start_time
					and b.pool_type=2 and b.op_type=1;
				
				select sum(a.hol_hours) into MY_THIS_REST_HAPPEND
				from att_hol_apply_day a 
					left join att_st_icss_pool_log b on a.apply_id=b.apply_id
					left join att_st_month c on a.hol_date <= c.comp_end_time and a.hol_date >= c.comp_start_time 
				where a.emp_id=MY_EMPID and b.is_erase=0 and c.st_id = MY_STID and b.dt <= c.comp_end_time and b.dt >= c.comp_start_time
					and b.pool_type=2 and b.op_type=2;
				
*/				
			#年假总结余（小时）	T7+T8。
			#如果统计结果为负数，负数为预支小时数	
				SET MY_ALL_YEAR_LEFT = MY_LAST_YEAR_LEFT + MY_THIS_YEAR_LEFT - MY_THIS_YEAR_HAPPEND;
			
	#PART 2 调休--------------------------------------------------------------------------------------------------- 
			#
			
			#上周期内补休结余（小时）
			#非当年（2019年及以前）的补休池池结余（截至到6月底）
				SELECT IFNULL(SUM(IFNULL(A.this_year_left,0)),0)
					INTO MY_LAST_REST_LEFT
				FROM att_hol_rest A
				WHERE A.emp_id=MY_EMPID AND A.this_year < YEAR(MON_BGDT) AND A.is_delete=0;
				
				#得到往年have在月底之后的改动
				SET DO_HAVE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)
					INTO DO_HAVE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= MON_BGDT AND A.pool_type=2 AND A.which_year < YEAR(MON_BGDT) AND A.op_type=1 AND A.is_erase=0;		

				#得到往年use在月底之后的改动
				SET DO_USE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)
					INTO DO_USE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= MON_BGDT AND A.pool_type=2 AND A.which_year < YEAR(MON_BGDT) AND A.op_type=2 AND A.is_erase=0;		

				#逆向计算后得到月底的剩余值
				SET MY_LAST_REST_LEFT = MY_LAST_REST_LEFT - DO_HAVE + DO_USE;
			#本周期内补休结余（小时）
			#当年（2020年）的补休池结余。如果统计结果为负数，负数为预支小时数（截至到6月底）	
				SELECT IFNULL(SUM(IFNULL(A.this_year_left,0)),0)
					INTO MY_THIS_REST_LEFT
				FROM att_hol_rest A
				WHERE A.emp_id=MY_EMPID AND A.this_year = YEAR(MON_BGDT) AND A.is_delete=0;
				
				#得到当年have在月底之后的改动
				SET DO_HAVE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)
					INTO DO_HAVE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= MON_BGDT AND A.pool_type=2 AND A.which_year = YEAR(MON_BGDT) AND A.op_type=1 AND A.is_erase=0;		

				#得到当年use在月底之后的改动
				SET DO_USE = 0;
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0)
					INTO DO_USE
				FROM att_st_icss_pool_log A
				WHERE A.apply_id<>4 AND A.emp_id=MY_EMPID AND A.dt >= MON_BGDT AND A.pool_type=2 AND A.which_year = YEAR(MON_BGDT) AND A.op_type=2 AND A.is_erase=0;		

				#逆向计算后得到月底的剩余值
				SET MY_THIS_REST_LEFT = MY_THIS_REST_LEFT - DO_HAVE + DO_USE;
				
				/*
				SELECT IFNULL(SUM(IFNULL(A.do_value,0)),0) + MY_THIS_OVER_HAPPEND
					INTO MY_THIS_OVER_HAPPEND
				FROM att_st_icss_pool_log A
				WHERE A.emp_id=MY_EMPID AND A.dt BETWEEN MON_BGDT AND MON_EDDT AND A.pool_type=2 AND A.which_year = YEAR(MON_BGDT) AND A.apply_id=4 AND A.op_type=1 AND A.is_erase=0;		
				*/
				
				
			#补休总结余(小时)	
			#T11+T12。如果统计结果为负数，负数为预支小时数	
				SET MY_ALL_REST_LEFT = MY_LAST_REST_LEFT + MY_THIS_REST_LEFT + MY_THIS_OVER_HAPPEND - MY_THIS_REST_HAPPEND;

				REPLACE INTO att_st_month_quick_view_st_pool 
					(emp_id,st_id,this_year_have,this_year_all_have,last_year_left,this_year_left,this_year_happend,all_year_left,
						this_holiday_over_happend,last_rest_left,this_rest_left,this_over_happend,this_rest_happend,all_rest_left,
						emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
				VALUES (MY_EMPID,MY_STID,MY_THIS_YEAR_HAVE,MY_THIS_YEAR_ALL_HAVE,MY_LAST_YEAR_LEFT,MY_THIS_YEAR_LEFT,MY_THIS_YEAR_HAPPEND,MY_ALL_YEAR_LEFT,
						MY_THIS_HOLIDAY_OVER_HAPPEND,MY_LAST_REST_LEFT,MY_THIS_REST_LEFT,MY_THIS_OVER_HAPPEND,MY_THIS_REST_HAPPEND,MY_ALL_REST_LEFT,
						MY_EMPCODE,MY_EMPNAME,MY_ENTRYDATE,MY_LEAVEDATE,MY_DEPTID,MY_DEPTFULLNAME);
				
				DELETE FROM tmp_att_month_st_pool_list WHERE ID=CT;
			END IF;
			SET CT = CT + 1;
		END WHILE;
	END IF;
END;

