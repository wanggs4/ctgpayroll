create function FN_PAYROLL_GET_NX(emp bigint unsigned)
  returns decimal(12, 2)
  comment '根据员工id得到他离职或者在职的工作年限'
  BEGIN
DECLARE MY_STAT INT;
DECLARE MY_NX DECIMAL(12,2);
DECLARE MY_EDT,MY_LDT DATE; 
SET MY_NX = 0;
	SELECT emp_state INTO MY_STAT FROM emp_base_info WHERE EMP_ID = emp AND is_delete = 0;
	IF (MY_STAT = 2) THEN	
		SELECT entry_date,leave_date INTO MY_EDT,MY_LDT FROM emp_post WHERE EMP_ID = emp;
		IF (MY_EDT IS NULL OR MY_LDT IS NULL) THEN			
			SET MY_NX = -1;	
		ELSE
			SET MY_NX = CEILING(DATEDIFF(MY_LDT,MY_EDT)/365);
		END IF;
	ELSE					
		SET MY_NX = 0;		
	END IF;
RETURN MY_NX;
END;

