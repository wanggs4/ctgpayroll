create procedure SP_ATT_MONTH_CONSTRAINT_DERATE_SINGLE(IN bgdt date, IN eddt date, IN emp bigint unsigned)
  comment '按月对迟到早退进行减免，修正日报中的数据。尽在月报时，于假期修正之后进行'
  BEGIN
DECLARE i_bgdt DATE;
DECLARE stat,ct,mxct,i_LATE_credit,i_LATE_credit_count_switch,i_LATE_credit_counts,i_LATE_credit_counts_exception,i_LATE_credit_mins,i_LATE_credit_mins_exception,i_EARLY_credit,i_early_credit_count_switch,i_EARLY_credit_counts,i_EARLY_credit_counts_exception,i_EARLY_credit_mins,i_EARLY_credit_mins_exception INT;
DECLARE THIS_DELM,THIS_DEEM,cd_jmcs,cd_jmfz,zt_jmcs,zt_jmfz,THIS_LM,THIS_EM,THIS_REAL_LM,THIS_REAL_EM,THIS_WORKTIME,THIS_ISOFF DECIMAL(12,2);
DECLARE i_emp,i_deptid,i_custid BIGINT;
DECLARE ATTID_STR TEXT;
DECLARE MY_ATTID BIGINT UNSIGNED;
	
	#得到该员工的各项id
	SELECT emp_id,dept_id,cust_id INTO i_emp,i_deptid,i_custid FROM emp_base_info WHERE emp_id=emp;
	
	CALL SP_DPT_GET_SETTINGID(i_emp,bgdt,1,ATTID_STR);
	SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);


	IF i_emp IS NOT NULL AND MY_ATTID IS NOT NULL THEN
		#初始化减免分钟数
		UPDATE att_emp_detail A SET A.derate_late_mins=0,A.derate_early_mins=0 WHERE EMP_ID=i_emp AND DT BETWEEN bgdt AND eddt;
		
		#读出迟到早退减免设置
		SELECT B.late_credit,B.late_credit_switch,
				B.late_credit_counts,B.late_credit_counts_exception,
				B.late_credit_mins,B.late_credit_mins_exception,
				B.early_credit,B.early_credit_count_switch,
				B.EARLY_credit_counts,B.EARLY_credit_counts_exception,
				B.EARLY_credit_mins,B.EARLY_credit_mins_exception
			INTO i_LATE_credit,i_LATE_credit_count_switch,						#迟到减免(0关 1开),  1减免迟到次数 2减免迟到时间
				i_LATE_credit_counts,i_LATE_credit_counts_exception,	#周期内减免次数,不享受减免的迟到分钟数
				i_LATE_credit_mins,i_LATE_credit_mins_exception,			#周期内减免分钟,不享受减免的迟到分钟数
				i_EARLY_credit,i_early_credit_count_switch,						#早退减免(0关 1开),  1减免早退次数 2减免早退时间
				i_EARLY_credit_counts,i_EARLY_credit_counts_exception,	#周期内减免次数,不享受减免的早退分钟数
				i_EARLY_credit_mins,i_EARLY_credit_mins_exception			#周期内减免分钟,不享受减免的早退分钟数
		FROM att_set_schema_new B 
		WHERE B.att_id=MY_ATTID;
#-------> 迟到减免计算			
		#有迟到减免
		IF i_LATE_credit = 1 THEN
			#按次数减免
			IF i_LATE_credit_count_switch = 1 THEN
				#合理化变量
				IF i_LATE_credit_counts IS NULL THEN SET i_LATE_credit_counts=0; END IF;
				IF i_LATE_credit_counts_exception IS NULL THEN SET i_LATE_credit_counts_exception=9999; END IF;
				SET cd_jmcs = i_LATE_credit_counts;
				SET i_bgdt = bgdt;
				WHILE (i_bgdt <= eddt AND cd_jmcs > 0) DO
					SET THIS_LM = 0;
					SET THIS_EM = 0;
					SET THIS_DELM = 0;
					SET THIS_WORKTIME = 0;
					#读出此次日报的迟到分钟、早退分钟、工作时长
					SELECT IFNULL(A.derate_late_mins,0),IF(A.late_mins IS NULL,0,A.late_mins),IF(A.early_mins IS NULL,0,A.early_mins),IF(A.work_interval IS NULL,0,A.work_interval)
						INTO THIS_DELM,THIS_LM,THIS_EM,THIS_WORKTIME
					FROM att_emp_detail A
					WHERE A.emp_id = i_emp AND A.dt = i_bgdt AND A.is_dayoff = 0;
					
					#当迟到分钟数，小于非减免分钟数时，可以进行减免
					IF THIS_LM < i_LATE_credit_counts_exception AND THIS_LM > 0 THEN
						SET cd_jmcs = cd_jmcs - 1;
						SET THIS_REAL_LM = 0;
						SET THIS_ISOFF = FN_ATT_GET_DAYOFF_STATUS(THIS_REAL_LM,THIS_EM,MY_ATTID);
						IF THIS_ISOFF IS NULL THEN SET THIS_ISOFF = 0 ; END IF;
						
						IF THIS_DELM = 0 THEN
							SET THIS_WORKTIME = THIS_WORKTIME + THIS_LM;
						END IF;
						
						#更新日报
						UPDATE att_emp_detail A
						SET A.derate_late_mins = THIS_LM, A.is_dayoff = THIS_ISOFF, A.work_interval = THIS_WORKTIME
						WHERE A.emp_id = i_emp AND A.dt = i_bgdt;
						
					END IF;
					SET i_bgdt = DATE_ADD(i_bgdt,INTERVAL 1 DAY);
				END WHILE;
			#按分钟数减免
			ELSEIF i_LATE_credit_count_switch = 2 THEN
				IF i_LATE_credit_mins IS NULL THEN SET i_LATE_credit_mins=0; END IF;
				IF i_LATE_credit_mins_exception IS NULL THEN SET i_LATE_credit_mins_exception=9999; END IF;
				SET cd_jmfz = i_LATE_credit_mins;
				WHILE (i_bgdt <= eddt AND cd_jmfz > 0) DO
					SET THIS_LM = 0;
					SET THIS_EM = 0;
					SET THIS_WORKTIME = 0;
					#读出此次日报的迟到分钟、早退分钟、工作时长
					SELECT IFNULL(A.derate_late_mins,0),IF(A.late_mins IS NULL,0,A.late_mins),IF(A.early_mins IS NULL,0,A.early_mins),IF(A.work_interval IS NULL,0,A.work_interval)
						INTO THIS_DELM,THIS_LM,THIS_EM,THIS_WORKTIME
					FROM att_emp_detail A
					WHERE A.emp_id = i_emp AND A.dt = i_bgdt AND A.is_dayoff = 0;
					
					#当迟到分钟数，小于非减免分钟数时，可以进行减免
					IF THIS_LM < i_LATE_credit_counts_exception AND THIS_LM > 0 THEN
						IF cd_jmfz >= THIS_LM-THIS_DELM THEN
							SET THIS_LM = cd_jmfz;
							SET cd_jmfz = cd_jmfz - THIS_LM + THIS_DELM;
							SET THIS_LM = THIS_LM-cd_jmfz;
							SET THIS_REAL_LM = 0;
							
						ELSEIF cd_jmfz < THIS_LM-THIS_DELM THEN
							SET THIS_REAL_LM = THIS_LM - THIS_DELM - cd_jmfz;
							SET THIS_LM = cd_jmfz;
							SET cd_jmfz = 0;
						END IF;
						
						SET THIS_ISOFF = FN_ATT_GET_DAYOFF_STATUS(THIS_REAL_LM,THIS_EM,MY_ATTID);
						IF THIS_ISOFF IS NULL THEN SET THIS_ISOFF = 0 ; END IF;
						SET THIS_WORKTIME = THIS_WORKTIME + THIS_LM;
						#更新日报
						UPDATE att_emp_detail A
						SET A.derate_late_mins = THIS_LM, A.is_dayoff = THIS_ISOFF, A.work_interval = THIS_WORKTIME
						WHERE A.emp_id = i_emp AND A.dt = i_bgdt;
						
					END IF;
					SET i_bgdt = DATE_ADD(i_bgdt,INTERVAL 1 DAY);
				END WHILE;
			END IF;
		END IF;
#<------  迟到减免计算结束



#>>>>>>>>>>>>>>>>> 早退减免计算
		#有早退减免
		IF i_EARLY_credit = 1 THEN
			#按次数减免
			IF i_early_credit_count_switch = 1 THEN
				#合理化变量
				IF i_EARLY_credit_counts IS NULL THEN SET i_EARLY_credit_counts=0; END IF;
				IF i_EARLY_credit_counts_exception IS NULL THEN SET i_EARLY_credit_counts_exception=999999; END IF;
				SET zt_jmcs = i_EARLY_credit_counts;
				SET i_bgdt = bgdt;
				WHILE (i_bgdt <= eddt AND zt_jmcs > 0) DO
					SET THIS_LM = 0;
					SET THIS_EM = 0;
					SET THIS_WORKTIME = 0;
					#读出此次日报的早退分钟、早退分钟、工作时长
					SELECT IFNULL(A.derate_early_mins,0),IF(A.late_mins IS NULL,0,A.late_mins),IF(A.early_mins IS NULL,0,A.early_mins),IF(A.work_interval IS NULL,0,A.work_interval)
						INTO THIS_DEEM,THIS_LM,THIS_EM,THIS_WORKTIME
					FROM att_emp_detail A
					WHERE A.emp_id = i_emp AND A.dt = i_bgdt AND A.is_dayoff = 0;
					
					#当早退分钟数，小于非减免分钟数时，可以进行减免
					IF THIS_EM < i_EARLY_credit_counts_exception AND THIS_EM > 0 THEN
						SET zt_jmcs = zt_jmcs - 1;
						SET THIS_REAL_EM = 0;
						SET THIS_ISOFF = FN_ATT_GET_DAYOFF_STATUS(THIS_LM,THIS_REAL_EM,MY_ATTID);
						IF THIS_ISOFF IS NULL THEN SET THIS_ISOFF = 0 ; END IF;
						IF THIS_DEEM = 0 THEN
							SET THIS_WORKTIME = THIS_WORKTIME + THIS_EM;
						END IF;
						#更新日报
						UPDATE att_emp_detail A
						SET A.derate_early_mins = THIS_EM, A.is_dayoff = THIS_ISOFF, A.work_interval = THIS_WORKTIME
						WHERE A.emp_id = i_emp AND A.dt = i_bgdt;
						
					END IF;
					SET i_bgdt = DATE_ADD(i_bgdt,INTERVAL 1 DAY);
				END WHILE;
			#按分钟数减免
			ELSEIF i_early_credit_count_switch = 2 THEN
				IF i_EARLY_credit_mins IS NULL THEN SET i_EARLY_credit_mins=0; END IF;
				IF i_EARLY_credit_mins_exception IS NULL THEN SET i_EARLY_credit_mins_exception=999999; END IF;
				SET zt_jmfz = i_EARLY_credit_mins;
				WHILE (i_bgdt <= eddt AND cd_jmfz > 0) DO
					SET THIS_LM = 0;
					SET THIS_EM = 0;
					SET THIS_WORKTIME = 0;
					#读出此次日报的早退分钟、早退分钟、工作时长
					SELECT IFNULL(A.derate_early_mins,0),IF(A.late_mins IS NULL,0,A.late_mins),IF(A.early_mins IS NULL,0,A.early_mins),IF(A.work_interval IS NULL,0,A.work_interval)
						INTO THIS_DEEM,THIS_LM,THIS_EM,THIS_WORKTIME
					FROM att_emp_detail A
					WHERE A.emp_id = i_emp AND A.dt = i_bgdt AND A.is_dayoff = 0;
					
					#当早退分钟数，小于非减免分钟数时，可以进行减免
					IF THIS_EM < i_EARLY_credit_mins_exception AND THIS_EM > 0 THEN
						IF zt_jmfz >= THIS_EM - THIS_DEEM THEN
							SET THIS_EM = zt_jmfz;
							SET zt_jmfz = zt_jmfz - THIS_EM + THIS_DEEM;
							SET THIS_EM = THIS_EM - zt_jmfz;
							SET THIS_REAL_EM = 0;
						ELSEIF zt_jmfz < THIS_EM - THIS_DEEM THEN
							SET THIS_REAL_EM = THIS_EM - THIS_DEEM - zt_jmfz;
							SET THIS_EM = zt_jmfz;
							SET zt_jmfz = 0;
						END IF;
						
						SET THIS_ISOFF = FN_ATT_GET_DAYOFF_STATUS(THIS_LM,THIS_REAL_EM,MY_ATTID);
						IF THIS_ISOFF IS NULL THEN SET THIS_ISOFF = 0 ; END IF;
						SET THIS_WORKTIME = THIS_WORKTIME + THIS_EM;
						#更新日报
						UPDATE att_emp_detail A
						SET A.derate_early_mins = THIS_EM, A.is_dayoff = THIS_ISOFF, A.work_interval = THIS_WORKTIME
						WHERE A.emp_id = i_emp AND A.dt = i_bgdt;
						
					END IF;
					SET i_bgdt = DATE_ADD(i_bgdt,INTERVAL 1 DAY);
				END WHILE;
			END IF;
		END IF;
#<<<<<<<<<<<<<<<<< 早退见面计算结束
	END IF;
END;

