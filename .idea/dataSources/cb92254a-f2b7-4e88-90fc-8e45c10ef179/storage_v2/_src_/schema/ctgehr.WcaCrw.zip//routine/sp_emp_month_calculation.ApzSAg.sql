create procedure SP_EMP_MONTH_CALCULATION(IN MAINID bigint)
  comment '花名册对应的其他计算项统计计算'
  BEGIN
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE MY_BAD_ATT,MY_OSD_DAYS,MY_WORK_YEAR,MY_COMPANY_YEAR,MY_NATIONAL_HOLIDAYS,MY_EDU,MY_WORK_DAYS,MY_AFTER_REGU_WORK_DAYS,MY_BEFORE_REGU_WORK_DAYS,IS_ENTRY,IS_LEAVE,IS_REGU,IS_ENTRY_LEAVE,MY_ADJID,MY_ATTRULE,MY_IEH,EMP_CT,EMP_MXCT,IS_HAVE_DATA,MY_EMPID,MY_DEPTID,MY_CUSTID,MY_PVERSION BIGINT;
DECLARE BGDT,EDDT,MY_REGUDATE,MY_ENTRYDATE,MY_LEAVEDATE,THIS_BGDT,THIS_EDDT,MY_FSTJOBTIME DATE;	
DECLARE MY_HOLIDAY_HOURS,MY_BASESALA,MY_POSSALA,MY_KPISALA,MY_HOURSALA,MY_TESTSALA,MY_RESALA,MY_BENEFIT DECIMAL(12,2);
DECLARE ATTID_STR TEXT;
DECLARE MY_ENABLETIME,ATTID BIGINT UNSIGNED;
DECLARE MY_CREATETIME DATETIME;
	SET I_VERSION_CODE = UUID();
	
	SELECT COUNT(*) INTO IS_HAVE_DATA FROM cust_period_emp_detail A WHERE A.main_id = MAINID;
	
	
	IF MAINID IS NOT NULL AND IS_HAVE_DATA > 0 THEN
		SELECT A.cust_id,A.emp_period_version INTO MY_CUSTID,MY_PVERSION FROM cust_period_emp_main A WHERE A.main_id = MAINID;
		
		DELETE FROM cust_period_emp_dict WHERE main_id=MAINID AND ori_table_name='cust_period_emp_detail_calculation';
		INSERT INTO cust_period_emp_dict (main_id,cust_id,emp_period_version,ori_table_name,ori_col_name,show_name,des_tb_name,des_col_name) VALUES 
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','BASESALA','基本工资[公式计算项]','cust_period_emp_detail_calculation','BASESALA'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','POSSALA','岗位工资[公式计算项]','cust_period_emp_detail_calculation','POSSALA'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','KPISALA','绩效工资[公式计算项]','cust_period_emp_detail_calculation','KPISALA'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','HOURSALA','小时薪[公式计算项]','cust_period_emp_detail_calculation','HOURSALA'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','TESTSALA','试用期工资[公式计算项]','cust_period_emp_detail_calculation','TESTSALA'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','RESALA','报销工资[公式计算项]','cust_period_emp_detail_calculation','RESALA'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','BENEFIT','津贴[公式计算项]','cust_period_emp_detail_calculation','BENEFIT'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','ENTRY_LEAVE','是否有入离职[公式计算项]','cust_period_emp_detail_calculation','ENTRY_LEAVE'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','REGU','是否转正[公式计算项]','cust_period_emp_detail_calculation','REGU'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','BEFORE_REGU_WORK_DAYS','转正前工作日天数[公式计算项]','cust_period_emp_detail_calculation','BEFORE_REGU_WORK_DAYS'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','AFTER_REGU_WORK_DAYS','转正后工作日天数[公式计算项]','cust_period_emp_detail_calculation','AFTER_REGU_WORK_DAYS'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','WORK_YEAR','工龄[公式计算项]','cust_period_emp_detail_calculation','WORK_YEAR'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','COMPANY_YEAR','司龄[公式计算项]','cust_period_emp_detail_calculation','COMPANY_YEAR'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','NATIONAL_HOLIDAYS','期间法定假日天数[公式计算项]','cust_period_emp_detail_calculation','NATIONAL_HOLIDAYS'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','WORK_DAYS','期间在职工作日天数[公式计算项]','cust_period_emp_detail_calculation','WORK_DAYS'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','HOLIDAY_HOURS','本月请假时数[公式计算项]','cust_period_emp_detail_calculation','HOLIDAY_HOURS'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','BAD_ATT','本月考勤异常次数[公式计算项]','cust_period_emp_detail_calculation','BAD_ATT'),
			(MAINID,MY_CUSTID,MY_PVERSION,'cust_period_emp_detail_calculation','OSD_DAYS','外勤天数[公式计算项]','cust_period_emp_detail_calculation','OSD_DAYS'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','cd','迟到（小时）','att_st_month_quick_view','cd'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','cdcs','迟到次数','att_st_month_quick_view','cdcs'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','zt','早退（小时）','att_st_month_quick_view','zt'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','ztcs','早退次数','att_st_month_quick_view','ztcs'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','kgcs','旷工次数','att_st_month_quick_view','kgcs'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','half_kg','半天旷工（次）','att_st_month_quick_view','half_kg'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','all_kg','整天旷工（次）','att_st_month_quick_view','all_kg'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','kqkx','考勤扣薪合计','att_st_month_quick_view','kqkx'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','ycqts','应出勤天数','att_st_month_quick_view','ycqts'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','sjcqts','实际出勤天数','att_st_month_quick_view','sjcqts'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','jbsc','加班时长（小时）','att_st_month_quick_view','jbsc'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','prjbsc','平日加班时长（小时）','att_st_month_quick_view','prjbsc'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','gxjbsc','公休加班时长（小时）','att_st_month_quick_view','gxjbsc'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','jrjbsc','节日加班时长（小时）','att_st_month_quick_view','jrjbsc'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','jxjbsc','计薪加班时长','att_st_month_quick_view','jxjbsc'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','jbf','加班费合计','att_st_month_quick_view','jbf'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','bsjhj','病事假合计','att_st_month_quick_view','bsjhj'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','ycqsc','应出勤时长','att_st_month_quick_view','ycqsc'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','sjcqsc','实际出勤时长','att_st_month_quick_view','sjcqsc'),
		   (MAINID,MY_CUSTID,MY_PVERSION,'att_st_month_quick_view','qjkx','假期扣薪合计','att_st_month_quick_view','qjkx');
		


		DELETE FROM cust_period_emp_detail_calculation WHERE MAIN_ID = MAINID;
		
		SELECT B.begin_date,B.end_date INTO BGDT,EDDT
		FROM cust_period_emp_main A LEFT JOIN cust_period_schedule B ON A.cust_id=B.cust_id AND A.emp_period_version=B.year_mon AND B.period_type=3
		WHERE A.main_id = MAINID;
		
		
		INSERT INTO tmp_period_emp_caculation (version_code,emp_id,emp_period_version,cust_id,dept_id)
			SELECT I_VERSION_CODE,emp_id,emp_period_version,cust_id,dept_id FROM cust_period_emp_detail A WHERE A.main_id = MAINID;
		
		SELECT MIN(ID),MAX(ID) INTO EMP_CT,EMP_MXCT FROM tmp_period_emp_caculation WHERE VERSION_CODE=I_VERSION_CODE;
		
		
		WHILE EMP_CT<=EMP_MXCT AND EMP_CT>0 DO
			
			SELECT emp_id,dept_id
				INTO MY_EMPID,MY_DEPTID
			FROM tmp_period_emp_caculation 
			WHERE ID = EMP_CT AND VERSION_CODE = I_VERSION_CODE;
			
			IF MY_EMPID IS NOT NULL THEN
				
				SELECT B.att_rule,B.is_exp_hol
					INTO MY_ATTRULE,MY_IEH
				FROM att_rel_schema_dept A LEFT JOIN att_set_schema_new B ON A.schema_id=B.att_id
				WHERE A.dept_id=MY_DEPTID AND B.is_delete=0 AND B.`status`=1 LIMIT 1;
				
				IF MY_ATTRULE = 3 OR MY_IEH IS NULL THEN
					SET MY_IEH = 0;
				END IF;
				
				SET MY_ENABLETIME = NULL,MY_CREATETIME = NULL ,MY_ADJID = NULL;
				
				SELECT MAX(A.enable_time) INTO MY_ENABLETIME FROM emp_salary_adj A WHERE A.emp_id=MY_EMPID AND A.is_delete=0 AND A.enable_time <= CAST(REPLACE(EDDT,'-','') AS UNSIGNED);
				SELECT MAX(A.create_time) INTO MY_CREATETIME FROM emp_salary_adj A WHERE A.emp_id=MY_EMPID AND A.is_delete=0 AND A.enable_time = MY_ENABLETIME;
				SELECT MAX(A.adj_id) INTO MY_ADJID FROM emp_salary_adj A WHERE A.emp_id=MY_EMPID AND A.is_delete=0 AND A.enable_time = MY_ENABLETIME AND A.create_time=MY_CREATETIME;
				
				SET MY_BASESALA=0,MY_POSSALA=0,MY_KPISALA=0,MY_HOURSALA=0,MY_TESTSALA=0,MY_RESALA=0,MY_BENEFIT=0;
				SELECT A.base_sala,A.pos_sala,A.kpi_sala,A.hour_sala,A.test_sala,A.re_sala,A.benefit
					INTO MY_BASESALA,MY_POSSALA,MY_KPISALA,MY_HOURSALA,MY_TESTSALA,MY_RESALA,MY_BENEFIT
				FROM emp_salary_adj A 
				WHERE A.adj_id = MY_ADJID;
				
				SET IS_ENTRY_LEAVE = 0;
				SELECT COUNT(*) INTO IS_ENTRY FROM emp_post A WHERE A.emp_id=MY_EMPID AND A.entry_date <= EDDT AND A.entry_date>=BGDT;
				IF IS_ENTRY IS NULL THEN SET IS_ENTRY = 0 ; END IF;
				SELECT COUNT(*) INTO IS_LEAVE FROM emp_post A WHERE A.emp_id=MY_EMPID AND A.leave_date <= EDDT AND A.leave_date>=BGDT;
				IF IS_LEAVE IS NULL THEN SET IS_LEAVE = 0; END IF;
				
				SET IS_ENTRY_LEAVE = IS_ENTRY + IS_LEAVE;
				
				
				
				
				SET IS_REGU = 0;
				SELECT COUNT(*) INTO IS_REGU FROM emp_post A WHERE A.emp_id=MY_EMPID AND A.regu_date <= EDDT AND A.regu_date>=BGDT;
				IF IS_REGU IS NULL THEN SET IS_REGU = 0; END IF;
				
				
				SELECT REGU_DATE,ENTRY_DATE,LEAVE_DATE,A.fst_job_time INTO MY_REGUDATE,MY_ENTRYDATE,MY_LEAVEDATE,MY_FSTJOBTIME FROM emp_post A WHERE A.emp_id=MY_EMPID;
				
				IF MY_ENTRYDATE >= BGDT AND MY_ENTRYDATE <= EDDT THEN
					SET THIS_BGDT = MY_ENTRYDATE;
				ELSE
					SET THIS_BGDT = BGDT;
				END IF;
				
				IF MY_LEAVEDATE >= BGDT AND MY_LEAVEDATE <= EDDT THEN
					SET THIS_EDDT = MY_LEAVEDATE;
				ELSE
					SET THIS_EDDT = EDDT;
				END IF;
				
				IF MY_ATTRULE = 1 THEN
					
					IF MY_REGUDATE > THIS_BGDT AND MY_REGUDATE <= THIS_EDDT THEN
						SET MY_BEFORE_REGU_WORK_DAYS = FN_ATT_GET_WORKDAYS(THIS_BGDT,DATE_ADD(MY_REGUDATE,INTERVAL -1 DAY),MY_EMPID,1);
						SET MY_AFTER_REGU_WORK_DAYS = FN_ATT_GET_WORKDAYS(MY_REGUDATE,THIS_EDDT,MY_EMPID,1);
					
					ELSEIF MY_REGUDATE <= THIS_BGDT THEN
						SET MY_BEFORE_REGU_WORK_DAYS = 0;
						SET MY_AFTER_REGU_WORK_DAYS = FN_ATT_GET_WORKDAYS(THIS_BGDT,THIS_EDDT,MY_EMPID,1);	
					
					ELSEIF MY_REGUDATE > THIS_EDDT THEN
						SET MY_BEFORE_REGU_WORK_DAYS = FN_ATT_GET_WORKDAYS(THIS_BGDT,THIS_EDDT,MY_EMPID,1);
						SET MY_AFTER_REGU_WORK_DAYS = 0;
					END IF; 
					
				ELSEIF MY_ATTRULE = 3 THEN
					
					IF MY_REGUDATE > THIS_BGDT AND MY_REGUDATE <= THIS_EDDT THEN
						SELECT COUNT(DISTINCT DT) INTO MY_BEFORE_REGU_WORK_DAYS FROM att_arrange_schedual A WHERE A.emp_id = MY_EMPID AND A.dt BETWEEN THIS_BGDT AND DATE_ADD(MY_REGUDATE,INTERVAL -1 DAY);
						SELECT COUNT(DISTINCT DT) INTO MY_AFTER_REGU_WORK_DAYS FROM att_arrange_schedual A WHERE A.emp_id = MY_EMPID AND A.dt BETWEEN MY_REGUDATE AND THIS_EDDT;
					
					ELSEIF MY_REGUDATE <= THIS_BGDT THEN
						SET MY_BEFORE_REGU_WORK_DAYS = 0;
						SELECT COUNT(DISTINCT DT) INTO MY_BEFORE_REGU_WORK_DAYS FROM att_arrange_schedual A WHERE A.emp_id = MY_EMPID AND A.dt BETWEEN THIS_BGDT AND THIS_EDDT;
					
					ELSEIF MY_REGUDATE > THIS_EDDT THEN
						SELECT COUNT(DISTINCT DT) INTO MY_BEFORE_REGU_WORK_DAYS FROM att_arrange_schedual A WHERE A.emp_id = MY_EMPID AND A.dt BETWEEN THIS_BGDT AND THIS_EDDT;
						SET MY_AFTER_REGU_WORK_DAYS = 0;
					END IF; 
				END IF;
				
				SET MY_WORK_YEAR = FLOOR(DATEDIFF(THIS_EDDT,MY_FSTJOBTIME)/365);
				
				SET MY_COMPANY_YEAR = FLOOR(DATEDIFF(THIS_EDDT,MY_ENTRYDATE)/365);
				
				SET MY_NATIONAL_HOLIDAYS = FN_ATT_GET_HOLIDAY_NUMS(THIS_BGDT,THIS_EDDT,1,MY_EMPID);
				
				SELECT MAX(A.education) INTO MY_EDU FROM emp_edu A WHERE A.emp_id=MY_EMPID AND A.education <>11;
				
				IF MY_ATTRULE = 1 THEN
					SET MY_WORK_DAYS = FN_ATT_GET_WORKDAYS(THIS_BGDT,THIS_EDDT,MY_EMPID,1);
				ELSEIF MY_ATTRULE = 3 THEN
					SELECT COUNT(DISTINCT DT) INTO MY_WORK_DAYS FROM att_arrange_schedual A WHERE A.emp_id = MY_EMPID AND A.DT BETWEEN THIS_BGDT AND THIS_EDDT;
				END IF;
				
				CALL SP_DPT_GET_SETTINGID(MY_EMPID,THIS_BGDT,1,ATTID_STR);
				SET ATTID = CAST(ATTID_STR AS UNSIGNED);
				SELECT ROUND(SUM(IF(A.hol_hours IS NULL,0,A.hol_hours))/FN_ATT_GET_WORKHOURS(ATTID),2) INTO MY_HOLIDAY_HOURS FROM att_hol_apply_day A WHERE A.emp_id = MY_EMPID AND A.hol_date BETWEEN THIS_BGDT AND THIS_EDDT;
				
				SELECT COUNT(*) INTO MY_BAD_ATT FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt BETWEEN THIS_BGDT AND THIS_EDDT AND A.late_mins + A.early_mins > 0 AND A.is_dayoff=0;
				
				SELECT COUNT(*) INTO MY_OSD_DAYS FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt BETWEEN THIS_BGDT AND THIS_EDDT AND A.check_osd_times>0;
							
					
				REPLACE INTO cust_period_emp_detail_calculation (`main_id`,`emp_id`,`emp_period_version`,`cust_id`,`dept_id`,`BASESALA`,`POSSALA`,`KPISALA`,`HOURSALA`,`TESTSALA`,`RESALA`,`BENEFIT`,`ENTRY_LEAVE`,`REGU`,`BEFORE_REGU_WORK_DAYS`,`AFTER_REGU_WORK_DAYS`,`WORK_YEAR`,`COMPANY_YEAR`,`NATIONAL_HOLIDAYS`,`WORK_DAYS`,`HOLIDAY_HOURS`,`BAD_ATT`,`OSD_DAYS`) 
					VALUES (MAINID,MY_EMPID,MY_PVERSION,MY_CUSTID,MY_DEPTID,IFNULL(MY_BASESALA,0),IFNULL(MY_POSSALA,0),IFNULL(MY_KPISALA,0),IFNULL(MY_HOURSALA,0),IFNULL(MY_TESTSALA,0),IFNULL(MY_RESALA,0),IFNULL(MY_BENEFIT,0),IFNULL(IS_ENTRY_LEAVE,0),IFNULL(IS_REGU,0),IFNULL(MY_BEFORE_REGU_WORK_DAYS,0),IFNULL(MY_AFTER_REGU_WORK_DAYS,0),IFNULL(MY_WORK_YEAR,0),IFNULL(MY_COMPANY_YEAR,0),IFNULL(MY_NATIONAL_HOLIDAYS,0),IFNULL(MY_WORK_DAYS,0),IFNULL(MY_HOLIDAY_HOURS,0),IFNULL(MY_BAD_ATT,0),IFNULL(MY_OSD_DAYS,0));
					
				DELETE FROM tmp_period_emp_caculation WHERE ID=EMP_CT;
			END IF;
			SET EMP_CT = EMP_CT + 1;
		END WHILE;
	END IF;
	
END;

