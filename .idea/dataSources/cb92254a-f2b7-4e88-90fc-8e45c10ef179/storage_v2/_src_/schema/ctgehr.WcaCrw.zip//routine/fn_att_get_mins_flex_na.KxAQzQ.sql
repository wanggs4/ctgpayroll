create procedure FN_ATT_GET_MINS_FLEX_NA(IN  chkin_time      time, IN chkout_time time, IN ATTID bigint unsigned,
                                         OUT my_late_minutes decimal(12, 2), OUT my_early_minutes decimal(12, 2))
  comment '根据给出的上下班打卡时间和部门id，计算弹性考勤下的迟到和早退分钟数'
  BEGIN
#输入参数
#chkin_time 上班打卡时间
#chkout_time 下班打卡时间
#deptid 部门id
#输出参数
#my_late_minutes		迟到分钟数
#my_early_minutes		早退分钟数
DECLARE is_have_att,i_att_rule,flag,i_flex_hour,i_min_unit INT;
DECLARE mst,met,ast,aet TIME;
DECLARE my_diff_time DECIMAL(12,2);
	set my_late_minutes = 0;
	set my_early_minutes = 0;
	SET chkin_time = FN_SYS_TMFMT_PURGE_SECOND(chkin_time);
	SET chkout_time = FN_SYS_TMFMT_PURGE_SECOND(chkout_time);
	#检查该部门有没有相应的出勤规则
	SELECT COUNT(*) INTO is_have_att 
	FROM att_set_schema_new b 
	WHERE b.att_id=ATTID AND b.att_rule=2;
	
	IF ( is_have_att > 0 and chkin_time < chkout_time) THEN
		set my_late_minutes = 0;
		set my_early_minutes = 0;
	END IF;
END;

