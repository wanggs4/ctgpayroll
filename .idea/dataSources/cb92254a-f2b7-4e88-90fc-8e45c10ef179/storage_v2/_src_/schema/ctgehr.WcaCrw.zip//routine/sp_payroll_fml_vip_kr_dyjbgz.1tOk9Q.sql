create procedure SP_PAYROLL_FML_VIP_KR_DYJBGZ(IN  my_emp    bigint unsigned, IN bgdt date, IN eddt date,
                                              OUT my_salary decimal(13, 3), IN is_att int, IN archid bigint,
                                              IN  schemaid  bigint, IN setid bigint)
  comment '薪酬部分公式定制化计算-科瑞-当月基本工资'
  BEGIN
DECLARE my_entry_date,my_leave_date,my_regu_date,this_enable_time,last_enable_time DATE;
DECLARE my_opr_time DATETIME;
DECLARE adj_ct,adj_mxct,my_enabletime INT;
DECLARE my_deptid,my_custid BIGINT;
DECLARE my_full_att_days,my_real_att_days,this_base_sala,this_pos_sala,this_salary,last_pos_sala,last_base_sala,bf_adj_days,aft_adj_days DECIMAL(13,3);
DECLARE my_real_att_string ,this_real_att_string varchar(50);
 DECLARE i_version_code VARCHAR(50);
 SET i_version_code = UUID();
 SET @i_version_code = i_version_code;
	
	SET my_salary = 0;
	
	
	SELECT dept_id,cust_id 	INTO my_deptid,my_custid FROM EMP_BASE_INFO WHERE EMP_ID = my_emp;
	
	
	SELECT entry_date,leave_date,regu_date INTO my_entry_date,my_leave_date,my_regu_date FROM emp_post WHERE emp_id = my_emp;
	
	
	SET my_full_att_days = FN_ATT_GET_WORKDAYS(bgdt,eddt,my_emp,1);

	
	
	SELECT DES_TB_NAME,DES_COL_NAME into @tb_jbgz,@col_jbgz FROM payroll_set_sala_schema_item WHERE SCHEMA_ID=42862561185792 AND ITEM_NAME='基本工资';
	SELECT DES_TB_NAME,DES_COL_NAME into @tb_gwgz,@col_gwgz FROM payroll_set_sala_schema_item WHERE SCHEMA_ID=42862561185792 AND ITEM_NAME='岗位工资';
	
	delete from  TMP_FML_VIP_VALUE  where version_code = i_version_code;	
	SET @setid = setid;
	SET @my_emp = my_emp;
	SET @SQL_JBGZ = CONCAT('INSERT INTO TMP_FML_VIP_VALUE SELECT ''',@i_version_code,''',`',@col_jbgz,'` FROM `',@tb_jbgz,'` WHERE SET_ID = ',@setid,' AND emp_id=',@my_emp,';');
	PREPARE stmt_jbgz FROM @SQL_JBGZ;
	EXECUTE stmt_jbgz;
	DEALLOCATE PREPARE stmt_jbgz;
	SELECT COL_VALUE INTO this_base_sala FROM TMP_FML_VIP_VALUE where version_code = i_version_code;
	IF this_base_sala IS NULL THEN SET this_base_sala = 0; END IF;
	
	delete from  TMP_FML_VIP_VALUE  where version_code = i_version_code;	
	SET @SQL_GWSE = CONCAT('INSERT INTO TMP_FML_VIP_VALUE SELECT ''',@i_version_code,''',`',@col_gwgz,'` FROM `',@tb_gwgz,'` WHERE SET_ID = ',@setid,' AND emp_id=',@my_emp,';');
	PREPARE stmt_gwgz FROM @SQL_GWSE;
	EXECUTE stmt_gwgz;
	DEALLOCATE PREPARE stmt_gwgz;
	SELECT COL_VALUE INTO this_pos_sala FROM TMP_FML_VIP_VALUE where version_code = i_version_code;
	IF this_pos_sala IS NULL THEN SET this_pos_sala = 0; END IF;	
	
	delete from  TMP_FML_VIP_SADJ where version_code = i_version_code;
	
	SELECT MAX(ENABLE_TIME) INTO my_enabletime
	FROM EMP_SALARY_ADJ 
	WHERE EMP_ID = my_emp AND IS_ENABLE=1 AND ENABLE_TIME <= CAST(REPLACE(eddt,'-','') AS UNSIGNED);
		
	SELECT MAX(OPR_TIME) INTO my_opr_time
	FROM EMP_SALARY_ADJ 
	WHERE EMP_ID = my_emp AND IS_ENABLE=1 AND ENABLE_TIME = my_enabletime;


	IF my_opr_time IS NOT NULL  AND (this_pos_sala + this_base_sala = 0 ) THEN
		INSERT INTO TMP_FML_VIP_SADJ (version_code,base_sala,pos_sala,enable_time) 
			SELECT i_version_code,base_sala,pos_sala,concat(left(enable_time,4),'-',mid(enable_time,5,2),'-',right(enable_time,2))
			FROM emp_salary_adj 
			WHERE emp_id = my_emp AND OPR_TIME = my_opr_time AND IS_ENABLE=1;	
		
		INSERT INTO TMP_FML_VIP_SADJ (version_code,base_sala,pos_sala,enable_time) 
			SELECT i_version_code,base_sala,pos_sala,enable_time 
			FROM emp_salary_adj 
			WHERE emp_id = my_emp AND ENABLE_TIME BETWEEN CAST(REPLACE(bgdt,'-','') AS UNSIGNED) and CAST(REPLACE(eddt,'-','') AS UNSIGNED);

		SELECT MIN(ID),MAX(ID) INTO adj_ct,adj_mxct FROM TMP_FML_VIP_SADJ  where version_code = i_version_code;
	
	
	
	
	
		
		WHILE (adj_ct<=adj_mxct and adj_ct>0 AND is_att<>4) DO
			SET this_base_sala=NULL;
			SET this_pos_sala=NULL;
			SET this_enable_time=NULL;
			
			SELECT base_sala,pos_sala,enable_time INTO this_base_sala,this_pos_sala,this_enable_time FROM TMP_FML_VIP_SADJ WHERE ID = adj_ct and version_code = i_version_code;
			
			
			IF this_base_sala IS NULL THEN SET this_base_sala = 0; END IF;
			IF this_pos_sala IS NULL THEN SET this_pos_sala = 0; END IF;
			
			
			IF (adj_mxct=1 and this_enable_time<bgdt) THEN
				IF my_leave_date>eddt OR my_leave_date IS NULL THEN
					SET this_salary = this_base_sala + this_pos_sala;
				ELSE
					IF is_att=3 THEN
						SET my_real_att_days = FN_ATT_GET_WORKDAYS(bgdt,my_leave_date,my_emp,1);
					ELSEIF is_att IN (1,2) THEN
						SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt BETWEEN bgdt AND my_leave_date AND is_dayoff=0 AND date_type=1;
	
	
					END IF;
					SET this_salary = (this_base_sala + this_pos_sala)/my_full_att_days*my_real_att_days;
				END IF;

			
			ELSEIF (adj_mxct=1 and this_enable_time between bgdt and eddt and (my_leave_date>eddt OR my_leave_date IS NULL) ) THEN
				
				IF is_att=3 THEN
					SET my_real_att_days = FN_ATT_GET_WORKDAYS(this_enable_time,eddt,my_emp,1);
				ELSEIF is_att IN (1,2) THEN
					SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt BETWEEN this_enable_time AND eddt AND is_dayoff=0 AND date_type=1;
	
	
				END IF;
				SET this_salary = (this_base_sala + this_pos_sala)/my_full_att_days*my_real_att_days;
			

			ELSEIF (adj_mxct=1 and this_enable_time between bgdt and eddt and my_leave_date<=eddt) THEN
				IF is_att=3 THEN
					SET my_real_att_days = FN_ATT_GET_WORKDAYS(this_enable_time,my_leave_date,my_emp,1);
				ELSEIF is_att IN (1,2) THEN
					
					SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt BETWEEN this_enable_time AND my_leave_date AND is_dayoff=0 AND date_type=1;
	
	
				END IF;
				SET this_salary = (this_base_sala + this_pos_sala)/my_full_att_days*my_real_att_days;

			ELSE
				IF (adj_ct=1) THEN				
					IF this_enable_time>=bgdt THEN
						SET my_real_att_days = 0;		
					ELSE
						SET my_real_att_days = 0;
						SET this_enable_time = bgdt;
					END IF;
					SET last_base_sala=this_base_sala;
					SET last_pos_sala=this_pos_sala;
					
					SET last_enable_time = this_enable_time;
					SET this_salary = 0;
				ELSEIF (adj_ct=adj_mxct) THEN	
					IF is_att=3 THEN
						SET my_real_att_days = FN_ATT_GET_WORKDAYS(last_enable_time,DATE_ADD(this_enable_time,INTERVAL -1 DAY),my_emp,1);
					ELSEIF is_att IN (1,2) THEN
						
						SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt >= last_enable_time AND  dt < this_enable_time AND is_dayoff=0 AND date_type=1;
	
	
					END IF;
					SET this_salary = (last_base_sala + last_pos_sala)/my_full_att_days*my_real_att_days;

					
					IF	(my_leave_date>eddt or my_leave_date is null) THEN
						IF is_att=3 THEN
							SET my_real_att_days = FN_ATT_GET_WORKDAYS(this_enable_time,eddt,my_emp,1);
						ELSEIF is_att IN (1,2) THEN
							
							SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt >= this_enable_time AND  dt <= eddt AND is_dayoff=0 AND date_type=1;
	
	
						END IF;
						SET this_salary = this_salary+((this_base_sala + this_pos_sala)/my_full_att_days*my_real_att_days);
					END IF;

				ELSE							
					IF is_att=3 THEN
						SET my_real_att_days = FN_ATT_GET_WORKDAYS(last_enable_time,DATE_ADD(this_enable_time,INTERVAL -1 DAY),my_emp,1);
					ELSEIF is_att IN (1,2) THEN
						
						SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt >= last_enable_time AND  dt < this_enable_time AND is_dayoff=0 AND date_type=1;
	
	
					END IF;
					SET this_salary = (last_base_sala + last_pos_sala)/my_full_att_days*my_real_att_days;
					
					
					SET last_base_sala=this_base_sala;
					SET last_pos_sala=this_pos_sala;				
					SET last_enable_time = this_enable_time;
					

				END IF;
			END IF;		

			SET my_salary = my_salary + this_salary ;
			SET adj_ct = adj_ct + 1;
		END WHILE;
	
		
		IF is_att=4 AND archid IS NOT NULL THEN
			SELECT base_sala,pos_sala,enable_time INTO this_base_sala,this_pos_sala,this_enable_time FROM TMP_FML_VIP_SADJ WHERE ID = adj_mxct;
			IF this_base_sala IS NULL THEN SET this_base_sala = 0; END IF;
			IF this_pos_sala IS NULL THEN SET this_pos_sala = 0; END IF;
			
			
			SELECT cast(st_value as DECIMAL)
				INTO bf_adj_days
			FROM att_st_month_arch_items
			WHERE ARCH_ID=archid AND EMP_ID=my_emp AND ST_KEY='xctzqts';
			
			
			SELECT cast(st_value as DECIMAL)
				INTO aft_adj_days
			FROM att_st_month_arch_items
			WHERE ARCH_ID=archid AND EMP_ID=my_emp AND ST_KEY='xctzhts';
			
			
			SET my_real_att_days = bf_adj_days+aft_adj_days;
			
			SET my_salary = (this_base_sala + this_pos_sala)/my_full_att_days*my_real_att_days;
		END IF;
	ELSE
		IF my_leave_date is not null and my_leave_date>=bgdt AND my_entry_date<=bgdt THEN
			IF is_att=3 THEN
				SET my_real_att_days = FN_ATT_GET_WORKDAYS(bgdt,eddt,my_emp,1);
			ELSEIF is_att IN (1,2) THEN
				SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt BETWEEN bgdt AND eddt AND is_dayoff=0 AND date_type=1;
			END IF;
		ELSEIF my_leave_date is not null and my_leave_date>=bgdt AND my_entry_date>bgdt THEN
			IF is_att=3 THEN
				SET my_real_att_days = FN_ATT_GET_WORKDAYS(my_entry_date,eddt,my_emp,1);
			ELSEIF is_att IN (1,2) THEN
				SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt BETWEEN my_entry_date AND eddt AND is_dayoff=0 AND date_type=1;
			END IF;
		ELSEIF my_leave_date is not null and my_leave_date<bgdt AND my_entry_date<=bgdt THEN
			IF is_att=3 THEN
				SET my_real_att_days = FN_ATT_GET_WORKDAYS(bgdt,my_leave_date,my_emp,1);
			ELSEIF is_att IN (1,2) THEN
				SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt BETWEEN bgdt AND my_leave_date AND is_dayoff=0 AND date_type=1;
			END IF;
		ELSEIF my_leave_date is  null AND  my_entry_date<=bgdt THEN
			IF is_att=3 THEN
				SET my_real_att_days = FN_ATT_GET_WORKDAYS(bgdt,eddt,my_emp,1);
			ELSEIF is_att IN (1,2) THEN
				SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt BETWEEN bgdt AND eddt AND is_dayoff=0 AND date_type=1;
			END IF;
			
		ELSEIF my_leave_date is  null AND  my_entry_date>bgdt THEN
			IF is_att=3 THEN
				SET my_real_att_days = FN_ATT_GET_WORKDAYS(my_entry_date,eddt,my_emp,1);
			ELSEIF is_att IN (1,2) THEN
				SELECT COUNT(*) INTO my_real_att_days FROM att_emp_detail WHERE EMP_ID = my_emp AND dt BETWEEN my_entry_date AND eddt AND is_dayoff=0 AND date_type=1;
			END IF;
		
		END IF;

		SET my_salary = (this_base_sala + this_pos_sala)/my_full_att_days*my_real_att_days;

	END IF;

	
	delete from  TMP_FML_VIP_SADJ where version_code = i_version_code;
	delete from  TMP_FML_VIP_VALUE where version_code = i_version_code;

END;

