create procedure SP_ICSS_ST_EMP_37(IN MY_BGDT date, IN MY_EMP bigint unsigned)
  comment '三期员工信息表'
  BEGIN
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE CT,MXCT,MY_EMP_ID,MY_DEPT_ID BIGINT UNSIGNED;
DECLARE MY_STAT,THIS_STAT,MY_DEPT_FULL_NAME,MY_EMP_CODE,MY_EMP_NAME,MY_DETAIL VARCHAR(500);
DECLARE MY_ENTRY_DATE,MY_LEAVE_DATE,MY_EDDT,MY_YCQ DATE;
DECLARE MY_C_ST,MY_C_ET,MY_BR_ST,MY_BR_ET DATETIME;
DECLARE MY_THIS_YEAR,THIS_YEAR_MON,MY_YEAR_MON_BG,THIS_YM_BG,IS_YUN,IS_CHAN,IS_BURU,IS_SHOUGONG INT;


	SET I_VERSION_CODE = UUID();
	SET MY_EDDT = DATE(DATE_ADD(NOW(),INTERVAL -2 DAY));
	SET MY_THIS_YEAR = YEAR(MY_EDDT);
	
	#入参MY_BGDT 校验
	#1.如果为空，设为前天的同年一月一日
	IF MY_BGDT IS NULL THEN
		SET MY_BGDT = CONCAT(YEAR(MY_EDDT),'-01-01');
	ELSE
		#2.如果不为空，但是年分和前天的年份不一致，改为前天同年的一月一日
		IF YEAR(MY_BGDT) <> MY_THIS_YEAR THEN
			SET MY_BGDT = CONCAT(YEAR(MY_EDDT),'-01-01');
		END IF;
	END IF;
	
	SET MY_YEAR_MON_BG = CAST(LEFT(REPLACE(MY_BGDT,'-',''),6) AS UNSIGNED);
	SET THIS_YEAR_MON = CAST(LEFT(REPLACE(MY_EDDT,'-',''),6) AS UNSIGNED);

	IF MY_EMP IS NULL THEN
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
				LEFT JOIN att_hol_apply_day D ON A.emp_id=D.emp_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT)
				AND D.is_year_hol IN (5,7,9) AND D.hol_date BETWEEN MY_BGDT AND MY_EDDT AND D.hol_hours>0;
	
	ELSE
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
				LEFT JOIN att_hol_apply_day D ON A.emp_id=D.emp_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT)
				AND A.emp_id=MY_EMP AND D.is_year_hol IN (5,7,9) AND D.hol_date BETWEEN MY_BGDT AND MY_EDDT AND D.hol_hours>0;
	END IF;			
	SET CT = 0, MXCT = 0;
	
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_icss_st_emp_list A WHERE A.version_code = I_VERSION_CODE;
	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_EMP_ID=NULL,MY_DEPT_ID=NULL,MY_DEPT_FULL_NAME=NULL,MY_EMP_CODE=NULL,MY_EMP_NAME=NULL,MY_ENTRY_DATE=NULL,MY_LEAVE_DATE=NULL;

		SELECT A.emp_id,A.emp_code,A.emp_name,A.entry_date,A.leave_date,A.dept_id,A.dept_full_name
			INTO MY_EMP_ID,MY_EMP_CODE,MY_EMP_NAME,MY_ENTRY_DATE,MY_LEAVE_DATE,MY_DEPT_ID,MY_DEPT_FULL_NAME
		FROM tmp_icss_st_emp_list A 
		WHERE A.version_code = I_VERSION_CODE AND A.id=CT; 

		IF MY_EMP_ID IS NOT NULL THEN
			DELETE A.* 
			FROM icss_st_emp_37 A 
			WHERE A.emp_id=MY_EMP_ID AND A.this_yearmon BETWEEN MY_YEAR_MON_BG AND THIS_YEAR_MON;
			
			SET THIS_YM_BG = MY_YEAR_MON_BG ;
			WHILE THIS_YM_BG <= THIS_YEAR_MON DO
				SET MY_STAT = '',MY_DETAIL = '';
				
				SET IS_YUN=0,IS_CHAN=0,IS_BURU=0,IS_SHOUGONG=0,MY_YCQ=NULL,MY_C_ST=NULL,MY_C_ET=NULL,MY_BR_ST=NULL,MY_BR_ET=NULL;
				
				SELECT COUNT(*) INTO IS_YUN
				FROM att_hol_apply_day A
				WHERE A.emp_id=MY_EMP_ID AND A.hol_date LIKE CONCAT(LEFT(THIS_YM_BG,4),'-',RIGHT(THIS_YM_BG,2),'%')
					AND A.is_year_hol=5 AND A.hol_hours>0;
				
				SELECT COUNT(*) INTO IS_CHAN
				FROM att_hol_apply_day A
				WHERE A.emp_id=MY_EMP_ID AND A.hol_date LIKE CONCAT(LEFT(THIS_YM_BG,4),'-',RIGHT(THIS_YM_BG,2),'%')
					AND A.is_year_hol=7 AND A.hol_hours>0;
				
				SELECT COUNT(*) INTO IS_BURU
				FROM att_hol_apply_day A
				WHERE A.emp_id=MY_EMP_ID AND A.hol_date LIKE CONCAT(LEFT(THIS_YM_BG,4),'-',RIGHT(THIS_YM_BG,2),'%')
					AND A.is_year_hol=9 AND A.hol_hours>0;
				
				SELECT COUNT(*) INTO IS_SHOUGONG
				FROM att_st_month_quick_view_icss A
					LEFT JOIN att_st_month B ON A.st_id=B.st_id
				WHERE A.emp_id=MY_EMP_ID AND B.`version`=THIS_YM_BG  AND A.report_type=2;
#SELECT MY_EMP_ID,THIS_YM_BG,IS_YUN,IS_CHAN,IS_BURU,IS_SHOUGONG;
				#手工考勤
				IF IS_SHOUGONG = 1 AND IS_SHOUGONG IS NOT NULL THEN
					SET MY_STAT = '手工考勤';
					SET MY_DETAIL = '';
				#非手工考勤
				ELSE
					#孕期
					IF IS_YUN > 0 AND IS_YUN IS NOT NULL THEN
						SELECT B.child_birthday INTO MY_YCQ
						FROM att_hol_apply_day A
							LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
						WHERE A.emp_id=MY_EMP_ID AND A.hol_date LIKE CONCAT(LEFT(THIS_YM_BG,4),'-',RIGHT(THIS_YM_BG,2),'%')
							AND A.is_year_hol=5 AND A.hol_hours>0
						LIMIT 1;
						
						IF MY_STAT = '' AND MY_STAT IS NOT NULL THEN
							SET MY_STAT = '孕期';
							SET MY_DETAIL = CONCAT('预产期:',IFNULL(MY_YCQ,'没有填写'));
						ELSE
							SET MY_STAT = CONCAT(MY_STAT,',孕期');
							SET MY_DETAIL = CONCAT(MY_DETAIL,',预产期:',IFNULL(MY_YCQ,'没有填写'));
						END IF;
					END IF;
					#产期
					IF IS_CHAN > 0 AND IS_CHAN IS NOT NULL THEN
						SELECT B.start_time,B.end_time INTO MY_C_ST,MY_C_ET
						FROM att_hol_apply_day A
							LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
						WHERE A.emp_id=MY_EMP_ID AND A.hol_date LIKE CONCAT(LEFT(THIS_YM_BG,4),'-',RIGHT(THIS_YM_BG,2),'%')
							AND A.is_year_hol=7 AND A.hol_hours>0
						LIMIT 1;

						IF MY_STAT = '' AND MY_STAT IS NOT NULL THEN
							SET MY_STAT = '产期';
							SET MY_DETAIL = CONCAT('产假开始日期:',IFNULL(MY_C_ST,'没有填写'),' 产假结束日期:',IFNULL(MY_C_ET,'没有填写'));
						ELSE
							SET MY_STAT = CONCAT(MY_STAT,',产期');
							SET MY_DETAIL = CONCAT(MY_DETAIL,',产假开始日期:',IFNULL(MY_C_ST,'没有填写'),' 产假结束日期:',IFNULL(MY_C_ET,'没有填写'));
						END IF;
					END IF;
					#哺乳期
					IF IS_BURU > 0 AND IS_BURU IS NOT NULL THEN
						SELECT B.start_time,B.end_time INTO MY_BR_ST,MY_BR_ET
						FROM att_hol_apply_day A
							LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
						WHERE A.emp_id=MY_EMP_ID AND A.hol_date LIKE CONCAT(LEFT(THIS_YM_BG,4),'-',RIGHT(THIS_YM_BG,2),'%')
							AND A.is_year_hol=9 AND A.hol_hours>0
						LIMIT 1;

						IF MY_STAT = '' AND MY_STAT IS NOT NULL THEN
							SET MY_STAT = '哺乳期';
							SET MY_DETAIL = CONCAT('哺乳假开始日期:',IFNULL(MY_BR_ST,'没有填写'),' 哺乳结束日期:',IFNULL(MY_BR_ET,'没有填写'));
						ELSE
							SET MY_STAT = CONCAT(MY_STAT,',哺乳期');
							SET MY_DETAIL = CONCAT(MY_DETAIL,',哺乳假开始日期:',IFNULL(MY_BR_ST,'没有填写'),' 哺乳假结束日期:',IFNULL(MY_BR_ET,'没有填写'));
						END IF;
					END IF;
				END IF;
				
				IF MY_STAT IS NOT NULL AND MY_STAT <> '' THEN
					INSERT INTO icss_st_emp_37 
						(emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name,
							this_yearmon,state,remark)
					VALUES 
						(MY_EMP_ID,MY_EMP_CODE,MY_EMP_NAME,MY_ENTRY_DATE,MY_LEAVE_DATE,MY_DEPT_ID,MY_DEPT_FULL_NAME,
							THIS_YM_BG,MY_STAT,MY_DETAIL);
				END IF;	
					
				SET THIS_YM_BG = THIS_YM_BG + 1;
			END WHILE;
			
		END IF;
		SET CT = CT + 1;
	END WHILE;
END;

