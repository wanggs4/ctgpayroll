create procedure SP_ATT_EMP_MONTH_DETAIL(IN BGDT  date, IN CUSTID bigint unsigned, IN DEPTID bigint unsigned,
                                         IN EMPID bigint unsigned, IN DEPTTYPE int)
  comment '单人按月的每天统计数据'
  BEGIN
DECLARE MY_SPDAYNAME,MY_COL_NAME,MY_COL_VALUE,MY_HOLNAME,MY_ATT_DETAIL,I_VERSION_CODE VARCHAR(100);
DECLARE MY_STID,EMP_CT,EMP_MXCT,MY_EMPID,MY_DEPTID,MY_CUSTID BIGINT UNSIGNED;
DECLARE IS_OVER,IS_ARRANGED,MY_ATTRULE,IS_HAVE_DETAIL,MY_DAYNUM,SINGLE_FLAG,MY_DTTYPE,IS_LATE,IS_EARLY,IS_HALF_DAYOFF,IS_DAYOFF,IS_SPECIAL INT;
DECLARE MY_ENTRYDATE,MY_LEAVEDATE,MY_BGDT,MY_EDDT DATE;
DECLARE ATTID_STR TEXT;
DECLARE MY_ATTID BIGINT UNSIGNED;


	SET I_VERSION_CODE = UUID();
	#根据参数选取人员列表
	#按员工
	IF EMPID IS NOT NULL THEN
		INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.emp_id=EMPID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
	#按部门
	ELSEIF EMPID IS NULL AND DEPTID IS NOT NULL AND DEPTTYPE IS NOT NULL THEN
		CASE DEPTTYPE
		WHEN 1 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.DEPT_ID=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 2 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.prgm_id=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 3 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.jrdc_id=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 4 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.dms_id4=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 5 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.dms_id5=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 6 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.dms_id6=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 7 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.dms_id7=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 8 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.dms_id8=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 9 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.dms_id9=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		WHEN 10 THEN
			INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.dms_id10=DEPTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
		END CASE;
	#按公司
	ELSEIF EMPID IS NULL AND DEPTID IS NULL AND CUSTID IS NOT NULL THEN
		INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.CUST_ID=CUSTID AND A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
	#所有人
	ELSEIF EMPID IS NULL AND DEPTID IS NULL AND CUSTID IS NULL THEN
		INSERT INTO tmp_att_emp_month_detail (VERSION_CODE,EMP_ID,DEPT_ID,CUST_ID)
			SELECT DISTINCT I_VERSION_CODE,A.emp_id,A.DEPT_ID,A.CUST_ID
			FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
			WHERE A.is_delete=0 AND A.emp_state IS NOT NULL AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT);
	END IF;


	SET EMP_CT=0,EMP_MXCT=0;
	SELECT MIN(ID),MAX(ID) INTO EMP_CT,EMP_MXCT FROM tmp_att_emp_month_detail A WHERE A.version_code=I_VERSION_CODE;
	WHILE EMP_CT <= EMP_MXCT AND EMP_CT > 0 DO
		SET MY_EMPID=NULL,MY_DEPTID=NULL,MY_CUSTID=NULL,MY_ATTRULE=NULL,ATTID_STR=NULL,MY_ATTID=NULL;
		SELECT emp_id,DEPT_ID,CUST_ID,att_rule 
			INTO MY_EMPID,MY_DEPTID,MY_CUSTID,MY_ATTRULE
		FROM tmp_att_emp_month_detail A 
		WHERE A.version_code=I_VERSION_CODE AND ID = EMP_CT;
		
		CALL SP_DPT_GET_SETTINGID(MY_EMPID,BGDT,1,ATTID_STR);
		SET MY_ATTID = CAST(REPLACE(ATTID_STR,',','') AS UNSIGNED);

		
		IF MY_EMPID IS NOT NULL AND MY_ATTID IS NOT NULL THEN
			
			SET MY_STID = NULL,MY_BGDT = NULL,MY_ATTRULE=NULL;
			
			SELECT MAX(A.st_id) INTO MY_STID
			FROM att_st_month A
			WHERE A.cust_id=MY_CUSTID AND A.comp_start_time<=BGDT AND A.comp_end_time>=BGDT;
			
			SELECT A.comp_start_time INTO MY_BGDT
			FROM att_st_month A
			WHERE A.st_id=MY_STID;
			
			SELECT A.att_rule INTO MY_ATTRULE FROM att_set_schema_new A WHERE A.att_id=MY_ATTID;
			
			SET MY_EDDT = BGDT;
			IF MY_STID IS NOT NULL THEN
				SET @UPDT_SQL_1 = CONCAT('UPDATE att_st_emp_month_detail SET ');
				SET @UPDT_SQL_2 = CONCAT('WHERE emp_id=',MY_EMPID,' AND st_id = ',MY_STID,';');
				
				SET @INST_SQL_1 = CONCAT('INSERT INTO att_st_emp_month_detail (EMP_ID,ST_ID,');
				SET @INST_SQL_2 = CONCAT('VALUES (',MY_EMPID,',',MY_STID,',');
				SET IS_HAVE_DETAIL = 0;
				#看看有没有明细
				SELECT COUNT(*) INTO IS_HAVE_DETAIL FROM att_st_emp_month_detail A WHERE A.emp_id=MY_EMPID AND A.st_id = MY_STID;
				SET MY_DAYNUM = 1;
				SET SINGLE_FLAG = 0;
				
				IF MY_BGDT = MY_EDDT THEN 
					SET SINGLE_FLAG = 1 ;
				END IF;
				#循环每一天
				WHILE MY_BGDT <= MY_EDDT AND MY_BGDT IS NOT NULL DO
					#坐班考勤	
					IF MY_ATTRULE = 1 THEN			
						SET MY_DTTYPE = NULL,IS_ARRANGED=NULL;
						#明细内容获取
						SET MY_DTTYPE = FN_ATT_GET_DTTYPE(MY_BGDT,MY_EMPID);
						SELECT COUNT(*) INTO IS_ARRANGED FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT;
						IF IS_ARRANGED > 0 THEN
							SET IS_LATE=0,IS_EARLY=0,IS_HALF_DAYOFF=0,IS_DAYOFF=0,IS_OVER=0,MY_HOLNAME='',IS_SPECIAL=0,MY_ATT_DETAIL='',MY_SPDAYNAME='';
							#迟到、早退、旷工
							SELECT COUNT(*) INTO IS_LATE FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT AND A.is_dayoff =0 AND A.late_mins-A.hol_mins>0;
							SELECT COUNT(*) INTO IS_EARLY FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT AND A.is_dayoff =0 AND A.early_mins-A.hol_mins>0;
							SELECT COUNT(*) INTO IS_HALF_DAYOFF FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT AND A.is_dayoff =2 ;
							SELECT COUNT(*) INTO IS_DAYOFF FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT AND A.is_dayoff =1 ;
							#请假
							SELECT GROUP_CONCAT(CASE B.is_year_hol WHEN 1 THEN '年' WHEN 2 THEN '调' WHEN 3 THEN '病' WHEN 4 THEN '哺' WHEN 5 THEN '检' WHEN 6 THEN '婚' WHEN 7 THEN '产' WHEN 8 THEN '事' WHEN 9 THEN '哺' ELSE B.hol_name END) 
								INTO MY_HOLNAME
							FROM att_hol_apply_day A LEFT JOIN att_set_holiday B ON A.hol_id=B.hol_id AND A.son_ver=B.son_ver
							WHERE A.emp_id=MY_EMPID AND A.hol_date=MY_BGDT AND A.apply_id IS NOT NULL AND A.apply_id>0 AND A.hol_hours>0
							GROUP BY A.emp_id;
							#特殊节假日
							SELECT COUNT(*) INTO IS_SPECIAL
							FROM att_hol_apply_day A LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id AND A.hol_hours>0
							WHERE A.emp_id=MY_EMPID AND A.hol_date=MY_BGDT AND A.sp_day_id IS NOT NULL AND A.sp_day_id>0;
							IF IS_SPECIAL > 0 THEN
								SELECT GROUP_CONCAT(B.sp_day_name) INTO MY_SPDAYNAME
								FROM att_hol_apply_day A LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
								WHERE A.emp_id=MY_EMPID AND A.hol_date=MY_BGDT AND A.sp_day_id IS NOT NULL AND A.sp_day_id>0 AND A.hol_hours>0
								GROUP BY A.emp_id;
							END IF;
							#加班
							SELECT COUNT(*) INTO IS_OVER
							FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
							WHERE A.emp_id=MY_EMPID AND A.work_day=MY_BGDT AND B.state=1 AND A.work_hour>0;
							
							#组装状态值
							IF IS_LATE > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'迟 ');
							END IF;
							IF IS_EARLY > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'退 ');
							END IF;
							IF IS_HALF_DAYOFF > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'旷 ');
							END IF;
							IF IS_DAYOFF > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'旷 ');
							END IF;
							IF MY_HOLNAME <> '' THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,REPLACE(MY_HOLNAME,',',' '),' ');
							END IF;
							IF IS_SPECIAL > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,REPLACE(MY_SPDAYNAME,',',' '),' ');
							END IF;
							IF IS_OVER > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'加 ');
							END IF;
							
							IF MY_ATT_DETAIL='' THEN
								SET MY_ATT_DETAIL = '——';
							END IF;
							
						ELSE
							SET MY_ATT_DETAIL = '';
						END IF;
					#排班
					ELSEIF MY_ATTRULE = 3 THEN
						SET IS_ARRANGED = NULL;
						SELECT COUNT(*) INTO IS_ARRANGED FROM att_arrange_schedual A WHERE A.emp_id=MY_EMPID AND A.dt = MY_BGDT;
						IF IS_ARRANGED > 0 THEN
							SET IS_LATE=0,IS_EARLY=0,IS_HALF_DAYOFF=0,IS_DAYOFF=0,IS_OVER=0,MY_HOLNAME='',IS_SPECIAL=0,MY_ATT_DETAIL='',MY_SPDAYNAME='';
							#迟到、早退、旷工
							SELECT COUNT(*) INTO IS_LATE FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT AND A.is_dayoff =0 AND A.late_mins-A.hol_mins>0;
							SELECT COUNT(*) INTO IS_EARLY FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT AND A.is_dayoff =0 AND A.early_mins-A.hol_mins>0;
							SELECT COUNT(*) INTO IS_HALF_DAYOFF FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT AND A.is_dayoff =2 ;
							SELECT COUNT(*) INTO IS_DAYOFF FROM att_emp_detail A WHERE A.emp_id=MY_EMPID AND A.dt=MY_BGDT AND A.is_dayoff =1 ;
							#请假
							SELECT GROUP_CONCAT(CASE B.is_year_hol WHEN 1 THEN '年' WHEN 2 THEN '调' WHEN 3 THEN '病' WHEN 4 THEN '哺' WHEN 5 THEN '检' WHEN 6 THEN '婚' WHEN 7 THEN '产' WHEN 8 THEN '事' WHEN 9 THEN '哺' END) 
								INTO MY_HOLNAME
							FROM att_hol_apply_day A LEFT JOIN att_set_holiday B ON A.hol_id=B.hol_id AND A.son_ver=B.son_ver
							WHERE A.emp_id=MY_EMPID AND A.hol_date=MY_BGDT AND A.apply_id IS NOT NULL AND A.apply_id>0 AND A.hol_hours>0
							GROUP BY A.emp_id;
							#特殊节假日
							SELECT COUNT(*) INTO IS_SPECIAL
							FROM att_hol_apply_day A LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id AND A.hol_hours>0
							WHERE A.emp_id=MY_EMPID AND A.hol_date=MY_BGDT AND A.sp_day_id IS NOT NULL AND A.sp_day_id>0;
							IF IS_SPECIAL > 0 THEN
								SELECT GROUP_CONCAT(B.sp_day_name) INTO MY_SPDAYNAME
								FROM att_hol_apply_day A LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
								WHERE A.emp_id=MY_EMPID AND A.hol_date=MY_BGDT AND A.sp_day_id IS NOT NULL AND A.sp_day_id>0 AND A.hol_hours>0
								GROUP BY A.emp_id;
							END IF;
							#加班
							SELECT COUNT(*) INTO IS_OVER
							FROM att_over_apply_day A LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
							WHERE A.emp_id=MY_EMPID AND A.work_day=MY_BGDT AND B.state=1 AND A.work_hour>0;
							
							#组装状态值
							IF IS_LATE > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'迟 ');
							END IF;
							IF IS_EARLY > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'退 ');
							END IF;
							IF IS_HALF_DAYOFF > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'旷 ');
							END IF;
							IF IS_DAYOFF > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'旷 ');
							END IF;
							IF MY_HOLNAME <> '' THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,REPLACE(MY_HOLNAME,',',' '),' ');
							END IF;
							IF IS_SPECIAL > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,REPLACE(MY_SPDAYNAME,',',' '),' ');
							END IF;
							IF IS_OVER > 0 THEN
								SET MY_ATT_DETAIL = CONCAT(MY_ATT_DETAIL,'加 ');
							END IF;
							
							IF MY_ATT_DETAIL='' THEN
								SET MY_ATT_DETAIL = '——';
							END IF;
							
						#不上班
						ELSE
							SET MY_ATT_DETAIL = '';
						END IF;
					END IF;
						
					SET MY_COL_VALUE = CONCAT(MY_BGDT,'|',MY_ATT_DETAIL);	
					IF MY_DAYNUM < 10 THEN
						SET MY_COL_NAME = CONCAT('DAY0',MY_DAYNUM);
					ELSE
						SET MY_COL_NAME = CONCAT('DAY',MY_DAYNUM);
					END IF;
					#有明细，更新
					IF IS_HAVE_DETAIL > 0 THEN
						IF SINGLE_FLAG = 1 OR (MY_BGDT = MY_EDDT AND SINGLE_FLAG = 0) OR MY_DAYNUM=31 THEN
							SET @UPDT_SQL_1 = CONCAT(@UPDT_SQL_1,MY_COL_NAME,'=''',MY_COL_VALUE,''' ');
						ELSE
							SET @UPDT_SQL_1 = CONCAT(@UPDT_SQL_1,MY_COL_NAME,'=''',MY_COL_VALUE,''',');
						END IF;
					#没明细，insert
					ELSE
						IF SINGLE_FLAG = 1 OR (MY_BGDT = MY_EDDT AND SINGLE_FLAG = 0) OR MY_DAYNUM=31 THEN
							SET @INST_SQL_1 = CONCAT(@INST_SQL_1,MY_COL_NAME,')');
							SET @INST_SQL_2 = CONCAT(@INST_SQL_2,'''',MY_COL_VALUE,''');');
						ELSE
							SET @INST_SQL_1 = CONCAT(@INST_SQL_1,MY_COL_NAME,',');
							SET @INST_SQL_2 = CONCAT(@INST_SQL_2,'''',MY_COL_VALUE,''',');
						END IF;
					END IF;
#SELECT @UPDT_SQL_1,@UPDT_SQL_2,@INST_SQL_1,@INST_SQL_2;			
					SET MY_DAYNUM = MY_DAYNUM + 1;	
					SET MY_BGDT = DATE_ADD(MY_BGDT,INTERVAL 1 DAY);
				END WHILE;
				#有明细，更新
				IF IS_HAVE_DETAIL > 0 THEN
					SET @DO_SQL = CONCAT(@UPDT_SQL_1,' ',@UPDT_SQL_2);
				#无明细，insert
				ELSE
					SET @DO_SQL = CONCAT(@INST_SQL_1,' ',@INST_SQL_2);
				END IF;
				
				PREPARE stmt1 FROM @DO_SQL;
				EXECUTE stmt1;
				DEALLOCATE PREPARE stmt1;
			END IF;
		END IF;
		DELETE FROM tmp_att_emp_month_detail WHERE VERSION_CODE=I_VERSION_CODE AND ID=EMP_CT;
		SET EMP_CT = EMP_CT + 1;
	END WHILE;
END;

