create function FN_ATT_GET_DTTYPE_DEPTID(bgdt date, deptid bigint unsigned)
  returns int
  comment '得到某一天的类型（1工作日 2周末 3法定节假日 4法定节假日调整的周末 5特殊节假日 6特殊工作日）'
  BEGIN
DECLARE ATTID BIGINT UNSIGNED;
DECLARE dttype,do_have_att,is_have_emp,ieh INT;
DECLARE workday VARCHAR(20);
DECLARE ATTID_STR,IS_TODAY_SPECIAL_WORKDAY TEXT;

 	#首先验证参数的有效性
	SELECT COUNT(*) into is_have_emp FROM dept_info WHERE dept_id = deptid;
	
	IF is_have_emp >= 0 THEN		#如果有部门时间时才开始计算
		select b.att_id into ATTID
		from att_rel_schema_dept a 
			left join att_set_schema_new b on a.schema_id=b.att_id
			left join log_attsetting_change c on b.att_id=c.setting_id
		where a.dept_id=deptid and b.is_delete=0 and c.on_time<= bgdt and (c.off_time is null or c.off_time >= bgdt) 
		order by c.on_time 
		limit 1;			
		#查看是否有出勤方案
		IF ATTID IS NOT NULL THEN				#如果有出勤方案
			#1首先获得该公司考勤设置的内容
			select if(work_day is null,'1,2,3,4,5,',concat(work_day,',')),is_exp_hol into workday,ieh			#工作日（周一到周五举例：1,2,3,4,5,）
			from att_set_schema_new WHERE ATT_ID=ATTID;
			
			IF ieh IS NULL OR ieh NOT IN (0,1) THEN SET ieh = 0 ; END IF;
		ELSE
			SET workday = '1,2,3,4,5,';
			SET ieh = 0;
		END IF;
		
		#日期判定 首先看法定节假日是否生效，如果生效，先从节假日表读出节假日的类型，剩下的再从工作日中辨别
		IF ieh = 1 THEN		
			#判断特殊工作日
			IF dttype IS NULL THEN
				select count(*) into IS_TODAY_SPECIAL_WORKDAY
				from att_rel_special_workday_dept a left join att_set_special_workday b on a.sp_workday_id=b.sp_workday_id
				where a.dept_id=deptid and b.is_enable=1 and b.is_delete=0 and b.begin_date<= bgdt and b.end_date>=bgdt;
				IF IS_TODAY_SPECIAL_WORKDAY > 0 THEN
					SET dttype = 6;
				END IF;
			END IF;
			
			#先判断法定节假日
			IF dttype IS NULL THEN
				select date_type into dttype from dict_hol_date where dt=bgdt;
			END IF;
			#最后走正常的日期
			if dttype is null then
				#判断是否工作日，weekday 周一起点 依次0-6
				if (locate(concat(weekday(bgdt)+1,','),workday)>0) then 	#if2
					set dttype=1;
				else
					set dttype=2;
				end if;																	#if2	
			end if;
		#如果法定节假日不生效，不再从节假日表中读取，直接从工作日中辨别
		ELSE
			if (locate(concat(weekday(bgdt)+1,','),workday)>0) then 	#if2
				set dttype=1;
			else
				set dttype=2;
			end if;				
		END IF;
	ELSE		
		#日期判定 是否为涉及到节假日的日期,如果不是，则根据出勤设置的工作日判断工作日还是周末
		SET workday = '1,2,3,4,5,';	
		SET ieh = 0;	
		#日期判定 首先看法定节假日是否生效，如果生效，先从节假日表读出节假日的类型，剩下的再从工作日中辨别
		#判断是否工作日，weekday 周一起点 依次0-6

		#判断特殊工作日
		IF dttype IS NULL THEN
			
			select count(*) into IS_TODAY_SPECIAL_WORKDAY
			from att_rel_special_dept a left join att_set_special_day b on a.sp_day_id=b.sp_day_id
			where a.dept_id=deptid and b.is_enable=1 and b.is_delete=0 and b.begin_date<= bgdt and b.end_date>=bgdt;
			
			IF IS_TODAY_SPECIAL_WORKDAY > 0 THEN
				SET dttype = 6;
			END IF;
		END IF;
		
		IF dttype IS NULL THEN
			if (locate(concat(weekday(bgdt)+1,','),workday)>0) then 	#if2
				set dttype=1;
			else
				set dttype=2;
			end if;																	#if2	
		END IF;
	END IF;
	
	
	RETURN dttype;
END;

