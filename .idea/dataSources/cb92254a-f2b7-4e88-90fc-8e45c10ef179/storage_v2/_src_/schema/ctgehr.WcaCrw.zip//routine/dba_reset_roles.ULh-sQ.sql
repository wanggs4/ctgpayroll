create procedure DBA_RESET_ROLES()
  comment '重置所有的超级权限'
  BEGIN
	delete a.*
	from au_rel_role_menu a ,au_menus b
	where a.menu_id=b.menu_id and b.is_must=1;
	
	insert into au_rel_role_menu 
		select a.role_id,b.menu_id
		from au_roles a,au_menus b
		where b.is_must=1;
		
	
END;

