create procedure SP_ATT_IMPORT_OMP_CHECK_DISTINCT(IN BGDT date, IN EDDT date)
  comment 'OMP导入打卡去重入表操作(只针对上月和本月的数据有效)'
  BEGIN
DECLARE TODAY DATE;
DECLARE BGDTTM,EDDTTM DATETIME;
	SET TODAY = DATE(NOW());

	IF BGDT IS NULL AND EDDT IS NULL THEN
		SELECT A.begin_date INTO BGDT
		FROM cust_period_schedule A
		WHERE A.cust_id=2162554862743552 AND A.period_type=1 AND A.begin_date <= DATE_ADD(TODAY,INTERVAL -1 MONTH) AND A.end_date >= DATE_ADD(TODAY,INTERVAL -1 MONTH);
		
		SELECT A.end_date INTO EDDT
		FROM cust_period_schedule A
		WHERE A.cust_id=2162554862743552 AND A.period_type=1 AND A.begin_date <= TODAY AND A.end_date >= TODAY;
	END IF;
		
	SET BGDTTM = CONCAT(BGDT,' 05:00:00');
	SET EDDTTM = CONCAT(DATE_ADD(EDDT,INTERVAL 1 DAY),' 04:59:59');
	
	#得到去重的打卡表数据
	#具体根据实际效率选择方案
	#TRUNCATE TABLE att_import_emp_log_ori;
	#REPLACE INTO att_import_emp_log_ori 
	#SELECT emp_id,check_time,IFNULL(data_source,0) FROM att_emp_log A WHERE A.cust_id=2162554862743552 AND A.check_time BETWEEN BGDTTM AND EDDTTM;
	
	TRUNCATE TABLE att_import_emp_log_ori;
	INSERT INTO att_import_emp_log_ori 
		SELECT DISTINCT emp_id,check_time,IFNULL(data_source,0) 
		FROM att_emp_log A 
		WHERE A.cust_id=2162554862743552 AND A.check_time BETWEEN BGDTTM AND EDDTTM;
		
	#删除掉已有的OMP导入打卡数据
	DELETE A.* 
	FROM att_import_emp_log A,att_import_emp_log_ori B 
	WHERE A.emp_id=B.emp_id AND A.check_time=B.check_time AND A.data_source=B.data_source;
	
	#处理导入打卡的日报列表
	
	#再根据增量的打卡，写入的日报列表
	INSERT INTO att_import_emp_daily_check (EMP_ID,DR_BGDT,DR_EDDT,VERSION_CODE) 
		SELECT DISTINCT A.emp_id,
			IF(TIME(A.check_time)>='05:00:00',DATE(A.check_time),DATE_ADD(DATE(A.check_time),INTERVAL -1 DAY)),
			IF(TIME(A.check_time)>='05:00:00',DATE(A.check_time),DATE_ADD(DATE(A.check_time),INTERVAL -1 DAY)),
			CAST(LEFT(REPLACE(REPLACE(REPLACE(NOW(),'-',''),':',''),' ',''),12) AS UNSIGNED)
		FROM att_import_emp_log A;
	
	#剩下的增量数据导入到打卡表中
	REPLACE INTO att_emp_log 
			(att_log_id,cust_id,dept_id,emp_id,position_level_id,check_type,check_time,loc_set_id,loc_set_name,
			longitude,latitude,check_add,device_id,dkj_device_id,pic_url,remark,wifi_name,wifi_mac,data_source,create_time,is_middle_data)
		SELECT A.att_log_id,A.cust_id,A.dept_id,A.emp_id,A.position_level_id,A.check_type,A.check_time,A.loc_set_id,A.loc_set_name,
			A.longitude,A.latitude,A.check_add,A.device_id,A.dkj_device_id,A.pic_url,A.remark,A.wifi_name,A.wifi_mac,A.data_source,A.create_time,A.is_middle_data
		FROM att_import_emp_log A ;
	
END;

