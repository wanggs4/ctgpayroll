create procedure SP_TMP_YEAR_POOL_COMPUTE()
  comment '处理中软提供的年假池数据，按照往年、今年和预支的顺序扣减，转化成ehr的格式'
  BEGIN
declare CT,MXCT,MY_EMP BIGINT UNSIGNED;
DECLARE MY_TOTAL_USE,MY_LAST_HAVE,MY_LAST_USE,MY_LAST_LEFT,MY_THIS_HAVE,MY_THIS_USE,MY_THIS_LEFT,MY_CREDIT_HAVE,MY_CREDIT_USE,MY_CREDIT_LEFT DECIMAL(7,4);
	DROP TABLE IF EXISTS tmp_emp_list;
	CREATE TABLE `tmp_emp_list` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`emp_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL COMMENT '员工id',
		PRIMARY KEY (`id`)
	)
	COLLATE='utf8mb4_general_ci'
	ENGINE=InnoDB;
	INSERT INTO tmp_emp_list (emp_id) SELECT DISTINCT EMP_ID FROM att_hol_year_import;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_emp_list;
	
	WHILE CT <= MXCT DO
		SELECT EMP_ID INTO MY_EMP FROM tmp_emp_list WHERE ID=CT;
		IF MY_EMP IS NOT NULL THEN
			SET MY_TOTAL_USE=0,MY_LAST_HAVE=0,MY_LAST_USE=0,MY_LAST_LEFT=0,MY_THIS_HAVE=0,MY_THIS_USE=0,MY_THIS_LEFT=0,MY_CREDIT_HAVE=0,MY_CREDIT_USE=0,MY_CREDIT_LEFT=0;
			SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_use,0),IFNULL(A.this_year_left,0)
				INTO MY_LAST_HAVE,MY_LAST_USE,MY_LAST_LEFT
			FROM att_hol_year_import A
			WHERE A.emp_id=MY_EMP AND A.is_delete=0 AND A.this_year=2019 LIMIT 1;
		
			SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_use,0),IFNULL(A.this_year_left,0)
				INTO MY_THIS_HAVE,MY_THIS_USE,MY_THIS_LEFT
			FROM att_hol_year_import A
			WHERE A.emp_id=MY_EMP AND A.is_delete=0 AND A.this_year=2020 LIMIT 1;
			
			SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_use,0),IFNULL(A.this_year_left,0)
				INTO MY_CREDIT_HAVE,MY_CREDIT_USE,MY_CREDIT_LEFT
			FROM att_hol_credit_year A
			WHERE A.emp_id=MY_EMP AND A.is_delete=0 AND A.this_year=2020 LIMIT 1;
			
			SET MY_TOTAL_USE = IFNULL(MY_LAST_USE,0) + IFNULL(MY_THIS_USE,0);
			
			IF MY_TOTAL_USE > 0 THEN
				#去年
				IF MY_LAST_HAVE - MY_TOTAL_USE >= 0 THEN
					SET MY_LAST_LEFT = MY_LAST_HAVE - MY_TOTAL_USE;
					SET MY_LAST_USE = MY_TOTAL_USE;
					SET MY_TOTAL_USE = 0;
				ELSE
					SET MY_LAST_LEFT = 0;
					SET MY_LAST_USE = MY_LAST_HAVE;
					SET MY_TOTAL_USE = MY_TOTAL_USE - MY_LAST_HAVE;
				END IF;
				
				UPDATE att_hol_year_import A 
				SET A.this_year_have=MY_LAST_HAVE,A.this_year_use=MY_LAST_USE,A.this_year_left=MY_LAST_LEFT
				WHERE A.emp_id=MY_EMP AND A.this_year=2019 AND A.is_delete=0;
				
				#今年
				IF MY_TOTAL_USE > 0 THEN
					IF MY_THIS_HAVE - MY_TOTAL_USE >= 0 THEN
						SET MY_THIS_LEFT = MY_THIS_HAVE - MY_TOTAL_USE;
						SET MY_THIS_USE = MY_TOTAL_USE;
						SET MY_TOTAL_USE = 0;
					ELSE
						SET MY_THIS_LEFT = 0;
						SET MY_THIS_USE = MY_THIS_HAVE;
						SET MY_TOTAL_USE = MY_TOTAL_USE - MY_THIS_HAVE;
					END IF;
				ELSE
					SET MY_THIS_USE = 0;
					SET MY_THIS_LEFT = MY_THIS_HAVE;
				END IF;
				UPDATE att_hol_year_import A 
				SET A.this_year_have=MY_THIS_HAVE,A.this_year_use=MY_THIS_USE,A.this_year_left=MY_THIS_LEFT
				WHERE A.emp_id=MY_EMP AND A.this_year=2020 AND A.is_delete=0;
				
				#预支
				IF MY_TOTAL_USE > 0 THEN
					IF MY_CREDIT_HAVE - MY_TOTAL_USE >= 0 THEN
						SET MY_CREDIT_LEFT = MY_CREDIT_HAVE - MY_TOTAL_USE;
						SET MY_CREDIT_USE = MY_TOTAL_USE;
						SET MY_TOTAL_USE = 0;
					ELSE
						SET MY_CREDIT_LEFT = 0;
						SET MY_CREDIT_USE = MY_CREDIT_HAVE;
						SET MY_TOTAL_USE = MY_TOTAL_USE - MY_CREDIT_HAVE;
					END IF;
					UPDATE att_hol_credit_year A 
					SET A.this_year_have=MY_CREDIT_HAVE,A.this_year_use=MY_CREDIT_USE,A.this_year_left=MY_CREDIT_LEFT
					WHERE A.emp_id=MY_EMP AND A.this_year=2020 AND A.is_delete=0;

				END IF;			
			END IF;
		END IF;
		SET CT = CT + 1;
	END WHILE;
END;

