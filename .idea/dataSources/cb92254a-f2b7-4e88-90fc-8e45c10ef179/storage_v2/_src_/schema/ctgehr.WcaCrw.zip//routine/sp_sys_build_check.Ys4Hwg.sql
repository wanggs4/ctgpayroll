create procedure SP_SYS_BUILD_CHECK(IN MY_CHECK_TIME datetime, IN CUSTID bigint unsigned, IN DEPTID bigint unsigned,
                                    IN EMPID         bigint unsigned)
  comment '为某个公司、部门or个人增加一条打卡记录'
  BEGIN
DECLARE STAT,ID_BASE,BUILD_NUM BIGINT;
	DROP TABLE IF EXISTS `tmp_build_check`;
	CREATE TEMPORARY TABLE `tmp_build_check` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT ,
		`cust_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL COMMENT '客户id',
		`dept_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL COMMENT '部门id',
		`emp_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL COMMENT '员工id',
		`position_level_id` BIGINT(20) NULL DEFAULT NULL,
		PRIMARY KEY (`id`)
	)
	COLLATE='utf8_general_ci'
	ENGINE=MEMORY;
	
	if (CUSTID is null and DEPTID is null and EMPID is null) then
		set STAT=4;
	elseif (CUSTID is not null and DEPTID is null and EMPID is null) then
		set STAT=3;
	elseif (DEPTID is not null and EMPID is null) then
		set STAT=2;
	elseif (EMPID is not null) then
		set STAT=1;
	end if;
	
	IF STAT = 4 THEN
		INSERT INTO tmp_build_check (cust_id,dept_id,emp_id,position_level_id)
			SELECT DISTINCT A.cust_id,A.dept_id,A.emp_id,B.position_level_id
			FROM emp_base_info A 
				left join emp_post B on a.emp_id=b.emp_id
			WHERE A.is_delete=0 AND A.emp_state IS NOT NULL 
				AND (
					(B.entry_date IS NOT NULL AND B.entry_date<=DATE(MY_CHECK_TIME)) 	
					OR (B.leave_date IS NULL OR B.leave_date>=DATE(MY_CHECK_TIME))
					);
	ELSEIF STAT = 3 THEN
		INSERT INTO tmp_build_check (cust_id,dept_id,emp_id,position_level_id)
			SELECT DISTINCT A.cust_id,A.dept_id,A.emp_id,B.position_level_id
			FROM emp_base_info A 
				left join emp_post B on a.emp_id=b.emp_id
			WHERE A.is_delete=0 AND A.emp_state IS NOT NULL 
				AND (
					(B.entry_date IS NOT NULL AND B.entry_date<=DATE(MY_CHECK_TIME)) 	
					OR (B.leave_date IS NULL OR B.leave_date>=DATE(MY_CHECK_TIME))
					)
				AND A.cust_id=CUSTID;
	ELSEIF STAT = 2 THEN
		INSERT INTO tmp_build_check (cust_id,dept_id,emp_id,position_level_id)
			SELECT DISTINCT A.cust_id,A.dept_id,A.emp_id,B.position_level_id
			FROM emp_base_info A 
				left join emp_post B on a.emp_id=b.emp_id
			WHERE A.is_delete=0 AND A.emp_state IS NOT NULL 
				AND (
					(B.entry_date IS NOT NULL AND B.entry_date<=DATE(MY_CHECK_TIME)) 	
					OR (B.leave_date IS NULL OR B.leave_date>=DATE(MY_CHECK_TIME))
					)
				AND A.dept_id=DEPTID;
	ELSEIF STAT = 1 THEN
		INSERT INTO tmp_build_check (cust_id,dept_id,emp_id,position_level_id)
			SELECT DISTINCT A.cust_id,A.dept_id,A.emp_id,B.position_level_id
			FROM emp_base_info A 
				left join emp_post B on a.emp_id=b.emp_id
			WHERE A.is_delete=0 AND A.emp_state IS NOT NULL 
				AND (
					(B.entry_date IS NOT NULL AND B.entry_date<=DATE(MY_CHECK_TIME)) 	
					OR (B.leave_date IS NULL OR B.leave_date>=DATE(MY_CHECK_TIME))
					)
				AND A.emp_id=EMPID;		
	END IF;
	
	SELECT IFNULL(MAX(att_log_id),0) INTO ID_BASE FROM att_emp_log A WHERE A.att_log_id<200000000;
	SELECT IFNULL(MAX(ID),0) INTO BUILD_NUM FROM tmp_build_check;
	
	IF ID_BASE + BUILD_NUM <= 200000000 THEN
		INSERT INTO att_emp_log(att_log_id,cust_id,dept_id,emp_id,position_level_id,check_type,check_time)
			SELECT ID+ID_BASE,CUST_ID,DEPT_ID,EMP_ID,position_level_id,1,MY_CHECK_TIME FROM tmp_build_check;
	ELSE
		SELECT '主键范围超出预期！';
	END IF;
	
	DROP TABLE IF EXISTS tmp_build_check;
END;

