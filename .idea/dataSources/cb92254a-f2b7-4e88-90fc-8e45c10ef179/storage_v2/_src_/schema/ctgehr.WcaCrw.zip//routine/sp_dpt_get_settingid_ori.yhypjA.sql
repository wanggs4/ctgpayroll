create procedure SP_DPT_GET_SETTINGID_ORI(IN  EMPID     bigint unsigned, IN BGDT date, IN SETTINGTYPE int,
                                          OUT SETTINGID text)
  comment '得到单独时间段内某个人某个设定的id'
  BEGIN
/*
SETTINGTYPE
1	考勤		att_rel_schema_dept
2	加班		att_rel_overtime_dept
3	请假		att_rel_holiday_depts
4	特殊假日	att_rel_special_dept
5	特殊工作日	att_rel_special_workday_dept
6	打卡地点	att_rel_location_depts
*/
DECLARE IS_HAVE_EMP,CT,MXCT INT;
DECLARE THIS_ATTRULE,THIS_ATTID BIGINT UNSIGNED;
SET SETTINGID = NULL;
	SELECT COUNT(*) INTO IS_HAVE_EMP FROM emp_base_info A WHERE A.emp_id=EMPID;
	IF IS_HAVE_EMP > 0 AND BGDT IS NOT NULL AND SETTINGTYPE IN (1,2,4,5,6,7,301,302,303,304,305,306,307,308,309,310) THEN
		CASE SETTINGTYPE
		WHEN 1 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				
				SELECT A.schema_id INTO SETTINGID
				FROM att_rel_schema_dept A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id 
					LEFT JOIN log_attsetting_change C ON A.schema_id=C.setting_id AND C.setting_type=1
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT
				LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
				
			END WHILE;

			SET SETTINGID = CONCAT(SETTINGID,',');
			SET SETTINGID = LEFT(SETTINGID,LOCATE(',',SETTINGID)-1);
			
		WHEN 2 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				
				SELECT A.ot_id INTO SETTINGID
				FROM att_rel_overtime_dept A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id 
					LEFT JOIN log_attsetting_change C ON A.ot_id=C.setting_id AND C.setting_type=2
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT
				LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
				
			END WHILE;

			SET SETTINGID = CONCAT(SETTINGID,',');
			SET SETTINGID = LEFT(SETTINGID,LOCATE(',',SETTINGID)-1);
			
		WHEN 4 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT  GROUP_CONCAT(DISTINCT A.sp_day_id) INTO SETTINGID
				FROM att_rel_special_dept A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id 
					LEFT JOIN log_attsetting_change C ON A.sp_day_id=C.setting_id AND C.setting_type=4
					LEFT JOIN att_set_special_day D ON C.setting_id=D.sp_day_id
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT
					AND D.begin_date <= BGDT AND D.end_date >= BGDT;
					
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
				
			END WHILE;
		WHEN 5 THEN			
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT  A.sp_workday_id INTO SETTINGID
				FROM att_rel_special_workday_dept A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id 
					LEFT JOIN log_attsetting_change C ON A.sp_workday_id=C.setting_id AND C.setting_type=5
					LEFT JOIN att_set_special_workday D ON C.setting_id=D.sp_workday_id
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT
					AND D.begin_date <= BGDT AND D.end_date >= BGDT
				LIMIT 1;
			
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
			
			SET SETTINGID = CONCAT(SETTINGID,',');
			SET SETTINGID = LEFT(SETTINGID,LOCATE(',',SETTINGID)-1);
		WHEN 6 THEN
				
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT  GROUP_CONCAT(DISTINCT A.location_id) INTO SETTINGID
				FROM att_rel_location_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id 
					LEFT JOIN log_attsetting_change C ON A.location_id = C.setting_id AND C.setting_type=6
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 7 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				
				SELECT A.schema_id INTO SETTINGID
				FROM att_rel_schema_dept A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id 
					LEFT JOIN log_attsetting_change C ON A.schema_id=C.setting_id AND C.setting_type=1
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT
				LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
				
			END WHILE;

			SET SETTINGID = CONCAT(SETTINGID,',');
			SET SETTINGID = LEFT(SETTINGID,LOCATE(',',SETTINGID)-1);
			
			SET THIS_ATTID = CAST(SETTINGID AS UNSIGNED);

			SELECT IFNULL(A.att_rule,0) INTO THIS_ATTRULE FROM att_set_schema_new A WHERE A.att_id=THIS_ATTID;
			
			SET SETTINGID = CONCAT(THIS_ATTID,':',THIS_ATTRULE);
		WHEN 301 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=1 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 302 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0 
					AND D.is_year_hol=2 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 303 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=3 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 304 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=4 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 305 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=5 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 306 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=6 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 307 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=7 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 308 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=8 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 309 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=9 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		WHEN 310 THEN
			SET CT=10,MXCT=1;
			WHILE CT >= MXCT AND SETTINGID IS NULL DO
				SELECT CONCAT(A.hol_id,':',A.son_ver) INTO SETTINGID
				FROM att_rel_holiday_depts A 
					LEFT JOIN log_emp_dept_change B ON A.dept_id=B.dept_id
					LEFT JOIN log_attsetting_change C ON A.hol_id=C.setting_id AND C.setting_type=3
					LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
				WHERE B.emp_id=EMPID AND B.entry_date<=BGDT AND (B.leave_date IS NULL OR B.leave_date>=BGDT)
					AND C.on_time<= BGDT  AND (C.off_time >= BGDT OR C.off_time IS NULL)  AND A.dept_type=CT AND D.is_delete=0
					AND D.is_year_hol=10 LIMIT 1;
				
				IF SETTINGID IS NULL THEN
					SET CT = CT - 1;
				ELSE
					SET CT = 0;
				END IF;
			END WHILE;
		END CASE;
	END IF;
END;

