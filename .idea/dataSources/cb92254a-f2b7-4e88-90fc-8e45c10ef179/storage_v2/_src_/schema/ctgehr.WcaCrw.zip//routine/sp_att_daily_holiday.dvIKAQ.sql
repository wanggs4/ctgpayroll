create procedure SP_ATT_DAILY_HOLIDAY(IN bgdt date, IN eddt date, IN custid bigint unsigned, IN deptid bigint unsigned,
                                      IN emp  bigint unsigned, IN depttype int)
  comment '请假日报汇总计算'
  BEGIN
	#声明变量
	DECLARE THIS_IYH,MY_ORI_HOLID,THIS_YEAR_HOL_ID,MY_HOLID,MY_ATTID,sonver,MY_OVER_APPLY_ID,apid,i_custid,i_deptid,i_emp,i_holid,i_applyid bigint UNSIGNED;
	DECLARE THIS_HOL_TYPE,THIS_CREDITORDER,MY_SONVER,hol_ct,hol_mxct,IS_TODAY_HAVE_HOL,IS_IN_SPECIAL,h_st_unit,i_flex_hour,arr_ct,arr_mxct,ct,mxct,ctn,mxctn,MY_FLEX_HOUR bigint;
	DECLARE is_have_pay_rest,is_have_year,is_have_credit_year,is_have_sick,is_have_rest,MY_HALF_FLAG,i_child_number,THIS_DTTYPE,REST_CT,REST_MXCT,IS_HAVE_OVERREST_LOG,THIS_CT,THIS_MXCT,i_hol_duration,i_att_rule,h_rule,s_rate,dttype,attrule,is_att,h_unit,stat,IEH,do_recycle,hol_flag,is_have_year_log,is_have_rest_log,i_seed,IS_HAVE_SICK_LOG,MY_THIS_YEAR,MY_FINAL_YEAR INT;
	DECLARE THIS_HOL_BREIF,MY_HOLIDAY_BREIF,workday,i_deptn,i_empn,i_holn,i_version_code,THIS_VER VARCHAR(2000);
	DECLARE APPLY_END_TIME,MY_HOL_BEGIN_TIME,MY_HOL_END_TIME,st,et,MAX_LOG_TIME,THIS_ARR_BG_TIME,	THIS_ARR_ED_TIME,i_milk_start_time,THIS_MST,THIS_AET datetime;
	DECLARE FREE_BGDT,FREE_EDDT,MY_HOL_BGDT,MY_HOL_EDDT,HOL_BGDT,HOL_EDDT,I_BGDT,PB_BGDT,PB_EDDT,THIS_BGDT,MY_BGDT,MY_EDDT,sd,ed,i_hol_milk_exp_date,MY_HOL_DATE,i_sd date;
	DECLARE MY_APPLY_END_TIME,MST,MET,AST,AET,this_start_time,this_end_time TIME;
	DECLARE THIS_WCBZCS,MY_CONFLICT_TIME,THIS_DECUCTION,THIS_HOUR,PB_HOL_HOURS,PB_HOL_YEAR_DAY,DAYS,THIS_DAYS,MY_LEFT_REST_HOUR,THIS_HOL_HOUR,o_hour,h_hour,ih_hour,d_hour,i_ori_value,i_mod_value,last_mod_value,onday_ori_value,onday_do_value,this_do_value,MY_LAST_LEFT_SICK,MY_THIS_LEFT_SICK, MY_LAST_DECUCTION,ORI_MY_THIS_DECUCTION,MY_THIS_DECUCTION,MY_HOL_DAYS DECIMAL(10,5);
	DECLARE MY_HOL_STR,ATTID_STR,my_apply_id_list,this_apply_id_list TEXT;
	DECLARE MY_THIS_HOL_DAYS DECIMAL(15,5);
		
	SET I_BGDT = bgdt;
	set sql_mode='';
	/*判断输入的参数
		stat 1 emp		emp is not null 按员工查						
		stat 2 detp		deptid is not null and emp is null 按部门查
		stat 3 custid  custid is not null and deptid is null and emp is null; 按公司查
		stat 4 all		custid is null and deptid is null and emp is null  全局查
	*/
	if (custid is null and deptid is null and depttype is null and emp is null) then
		set stat=4;
	elseif (custid is not null and deptid is null and depttype is null  and emp is null) then
		set stat=3;
	elseif (deptid is not null and depttype between 1 and 10 and emp is null) then
		set stat=2;
	elseif (emp is not null) then
		set stat=1;
	end if;

	set my_apply_id_list='';
	#第一层循环 按日期
	while (bgdt<=eddt) do 										#loop1		
		#初始化循环变量
		SET ct = 0;
		SET mxct = 0;
		set i_version_code = uuid();
		#得到当天通过的请假                         
		#delete from  tmp_att_hol_list;
		#delete from  tmp_att_hol_list_no;
		#因为程序调用时，需要审批的给的时间时审批通过时间；不需要审批的给的是当天，所以不需要审批的时间字段，应该是apply_time
		case stat
		when 1 then
			#通过 
			insert into tmp_att_hol_list (version_code,apply_id)
				select distinct i_version_code,apply_id 
				from att_hol_apply a
				where emp_id=emp and state=1 and dept_id is not null 
					and start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');

			#驳回 & 撤销 
			insert into tmp_att_hol_list_no (version_code,apply_id)
				select distinct i_version_code,apply_id 
				from att_hol_apply b
				where emp_id=emp and state in (3,4) and dept_id is not null 
					and start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
		when 2 then
			CASE depttype
			WHEN 1 THEN
				#通过 
				insert into tmp_att_hol_list (version_code,apply_id)
					select distinct i_version_code,apply_id 
					from att_hol_apply a 
					where dept_id=deptid and state=1 and dept_id is not null 
						and start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
				#驳回 & 撤销 
				insert into tmp_att_hol_list_no (version_code,apply_id)
					select distinct i_version_code,apply_id 
					from att_hol_apply b
					where dept_id=deptid and state in (3,4) and dept_id is not null 
						and start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			END CASE;
		when 3 then
			#通过 
			insert into tmp_att_hol_list (version_code,apply_id)
				select distinct i_version_code,apply_id 
				from att_hol_apply a 
				where cust_id=custid and state=1 and dept_id is not null 
					and start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			#驳回 & 撤销 
			insert into tmp_att_hol_list_no (version_code,apply_id)
				select distinct i_version_code,apply_id 
				from att_hol_apply b 
				where cust_id=custid and state in (3,4) and dept_id is not null 
					and start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
		when 4 then
			#通过 
			insert into tmp_att_hol_list (version_code,apply_id)
				select distinct i_version_code,apply_id 
				from att_hol_apply a 
				where state=1 and dept_id is not null 
					and start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
			#驳回 & 撤销 
			insert into tmp_att_hol_list_no (version_code,apply_id)
				select distinct i_version_code,apply_id 
				from att_hol_apply b 
				where state in (3,4) and dept_id is not null 
					and start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59');
		end case;
		
		#虚拟角色、免核算人员不计算假期
		DELETE A.*
		FROM tmp_att_hol_list A 
			LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			LEFT JOIN emp_base_info D ON B.emp_id=D.emp_id
		WHERE A.VERSION_CODE=i_version_code AND D.boss_level in (1,3) AND D.boss_level IS NOT NULL;
		
		DELETE A.*
		FROM tmp_att_hol_list_no A 
			LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			LEFT JOIN emp_base_info D ON B.emp_id=D.emp_id
		WHERE A.VERSION_CODE=i_version_code AND D.boss_level in (1,3) AND D.boss_level IS NOT NULL;
		
##########################################################################################################################################################
# 1. 对审核驳回和撤销的申请进行计算和日报归档							
##########################################################################################################################################################
		SET ctn = 0, mxctn = 0;

		SELECT IF(min(ID) IS NULL,0,min(ID)),IF(max(ID) IS NULL,0,max(ID)) INTO ctn,mxctn 
		FROM tmp_att_hol_list_no 
		WHERE version_code= i_version_code;
		WHILE (ctn <= mxctn AND ctn>0) DO									#LOOP5	
			#初始化循环变量
			SET i_emp = NULL,i_deptid = NULL,i_custid = NULL, hol_ct=NULL,hol_mxct=NULL, i_applyid = NULL;
			#得到apply_id
			select apply_id into i_applyid from tmp_att_hol_list_no where id = ctn and version_code= i_version_code;
			if i_applyid is not null then
				#先看看日表中有没有这条申请的记录，如果有，做回滚操作，如果没有，不用做任何事情
				select count(*) into do_recycle from att_hol_apply_day where apply_id = i_applyid;
				if ( do_recycle >0 ) then						#if99
					#读出本条申请的信息
					select emp_id,YEAR(START_TIME) ,dept_id,cust_id
						into i_emp,MY_THIS_YEAR ,i_deptid,i_custid
					from att_hol_apply a where apply_id = i_applyid;
						
					select min(a.credit_order),max(a.credit_order) into hol_ct,hol_mxct 
					from att_hol_apply_day a where a.apply_id=i_applyid;
					
	
					while hol_ct <= hol_mxct AND hol_ct > 0 do 
						SET hol_flag = NULL, i_holid = NULL,sd = NULL,ed = NULL,h_rule = NULL,h_unit = NULL;
						
						select min(A.hol_id) INTO i_holid
						from att_hol_apply_day A WHERE A.apply_id=i_applyid and A.credit_order=hol_ct;
					
						#得到本次申请假期的类型
						select is_year_hol into hol_flag from att_set_holiday_main where hol_id= i_holid;
											
						if hol_flag=1 then
							#将本次的修改记录到池子表的修改记录中
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,1,2,0);
						elseif hol_flag=11 then	#预支年假
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,3,2,0);
						elseif hol_flag IN (12) then	#预支年假
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,5,2,0);
						elseif hol_flag IN (13) then	#预支年假
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,6,2,0);
						elseif hol_flag=2 then	#调休
							SET IS_HAVE_OVERREST_LOG = NULL;
							SET THIS_VER = NULL;
							#首先看是否这个调休已经占用了加班时数
							SELECT COUNT(*) INTO IS_HAVE_OVERREST_LOG FROM att_over_apply_log  WHERE rest_apply_id = i_applyid;
							#如果有才开始计算
							IF IS_HAVE_OVERREST_LOG > 0 THEN
								SET REST_MXCT = NULL;
								SET REST_CT = NULL;
								SET MY_OVER_APPLY_ID = NULL;
								SET THIS_VER = UUID();
								
								
								#把这个调休锁占用的加班申请id找出来，然后循环归0
								INSERT INTO tmp_att_hol_rest_overapplyid_list (VERSION_CODE,OVER_APPLY_ID)
									SELECT DISTINCT THIS_VER,over_apply_id 
									FROM att_over_apply_log  
									WHERE rest_apply_id = i_applyid 
									order by op_seq desc;
									
								SELECT MIN(ID),MAX(ID) INTO REST_CT,REST_MXCT FROM tmp_att_hol_rest_overapplyid_list WHERE VERSION_CODE = THIS_VER;
	
								WHILE REST_CT <= REST_MXCT AND REST_CT > 0 DO
									SELECT OVER_APPLY_ID INTO MY_OVER_APPLY_ID FROM tmp_att_hol_rest_overapplyid_list WHERE VERSION_CODE = THIS_VER AND ID = REST_CT;
	
									IF MY_OVER_APPLY_ID IS NOT NULL THEN
										CALL SP_ATT_REST_OVER_OPERATE(i_applyid,MY_OVER_APPLY_ID,0,@overflow,1);
	
			#							DELETE FROM tmp_att_hol_rest_overapplyid_list WHERE VERSION_CODE = i_version_code AND ID = REST_CT;
									END IF;
								
									SET REST_CT = REST_CT + 1;
								END WHILE;
							END IF;
							#将本次的修改记录到池子表的修改记录中
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,2,2,0);
	
						elseif hol_flag=3 then
							#将本次的修改记录到池子表的修改记录中
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,4,2,0);
						end if;
					
						SET HOL_BGDT=NULL,HOL_EDDT=NULL,i_emp=NULL;
						#删除日表中的数据
						select min(a.hol_date),max(a.hol_date),MIN(a.emp_id) 
							into HOL_BGDT,HOL_EDDT,i_emp 
						from att_hol_apply_day a where a.apply_id = i_applyid AND a.credit_order = hol_ct;
						
						#删除撤销的假期日报
						delete from att_hol_apply_day where apply_id = i_applyid AND credit_order = hol_ct;
					
						#重新计算被删除的假期期间内的是否请假，并更新到考勤日报里
						WHILE HOL_BGDT <= HOL_EDDT DO
							SET IS_TODAY_HAVE_HOL=NULL;
							
							SELECT SUM(A.hol_hours) INTO IS_TODAY_HAVE_HOL
							FROM att_hol_apply_day A
							WHERE A.emp_id=i_emp AND hol_date = HOL_BGDT AND A.apply_id IS NOT NULL AND A.apply_id <> 0;
							
							IF IS_TODAY_HAVE_HOL IS NULL OR IS_TODAY_HAVE_HOL < 0 THEN
								SET IS_TODAY_HAVE_HOL = 0;
							ELSEIF IS_TODAY_HAVE_HOL > 0 THEN
								SET IS_TODAY_HAVE_HOL = 1;
							END IF;
							
							IF hol_flag = 10 THEN
								SET IS_TODAY_HAVE_HOL = 0;
							END IF;
							
							UPDATE att_emp_detail A
							SET A.is_have_hol = IS_TODAY_HAVE_HOL
							WHERE A.emp_id=i_emp AND A.dt=HOL_BGDT;
							
							CALL SP_ATT_COMPUTE_CHECK_WORK_HOURS(HOL_BGDT,HOL_BGDT,i_emp);
							
							SET HOL_BGDT = DATE_ADD(HOL_BGDT,INTERVAL 1 DAY);
						END WHILE;
						set hol_ct = hol_ct + 1;
					end while;

				end if;												#if99
				#delete from tmp_att_hol_list_no where id=ctn AND version_code = i_version_code;
			END IF;
			SET ctn = ctn + 1;
		END WHILE;													#LOOP5
		
		
##########################################################################################################################################################
# 2. 计算假期日报
##########################################################################################################################################################

		select IF(min(id) IS NULL,0,min(id)),IF(max(id) IS NULL,0,max(id)) into ct,mxct 
		from tmp_att_hol_list where version_code = i_version_code;
		#第二重循环 遍历当天通过的请假					    loop2
		while (ct<=mxct and ct>0) do
			#初始化循环变量
			SET APPLY_END_TIME=NULL,i_custid = NULL,i_deptid = NULL,i_deptn = NULL,i_emp = NULL,i_empn = NULL,i_holid = NULL,i_holn = NULL,st = NULL,et = NULL,sd = NULL,ed = NULL,o_hour = NULL,h_hour = NULL,THIS_IYH = NULL,h_rule = NULL,h_unit = NULL,MST = NULL,MET = NULL,AST = NULL,AET = NULL,IEH = NULL,is_att = NULL,apid = NULL,dttype = NULL;
			SET THIS_WCBZCS = 0;
			#得到apply_id
			select apply_id into apid from tmp_att_hol_list where id=ct and version_code=i_version_code;
			IF apid IS NOT NULL THEN
				SET MY_HOLIDAY_BREIF = NULL;
				#读出本次申请的相应信息
				select a.`cust_id`,a.`dept_id`,a.`dept_name`,a.`emp_id`,a.`emp_name`,
						a.`hol_id`,a.son_ver,a.credit_detail_code,b.is_year_hol,
						a.`start_time`,a.`end_time`,a.END_TIME
					into i_custid,i_deptid,i_deptn,i_emp,i_empn,
						MY_HOLID,MY_SONVER,MY_HOLIDAY_BREIF,THIS_IYH,
						MY_HOL_BEGIN_TIME,MY_HOL_END_TIME,APPLY_END_TIME
				from att_hol_apply a left join att_set_holiday_main b on a.hol_id=b.hol_id
				where apply_id=apid and a.is_delete=0 and b.is_delete=0;
				
				IF (THIS_IYH NOT IN (4,9) AND MY_HOL_BEGIN_TIME < MY_HOL_END_TIME) OR THIS_IYH IN (4,9) THEN
					#有池子扣减的，先归零，再删除日报
					set is_have_year=0,is_have_credit_year=0,is_have_sick=0,is_have_rest=0;
					
					SET MY_THIS_YEAR = YEAR(MY_HOL_BEGIN_TIME);
					
					select count(*) into is_have_year from att_hol_year_log where apply_id = apid;
					if is_have_year > 0 then
						CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,1,2,0);
					end if;
					
					SET THIS_HOL_TYPE = NULL;
					select count(*),MIN(A.pool_type) into is_have_pay_rest,THIS_HOL_TYPE from att_hol_pay_rest_log A where apply_id = apid;
					if is_have_pay_rest > 0 then
						IF THIS_HOL_TYPE = 12 THEN
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,5,2,0);
						ELSEIF THIS_HOL_TYPE = 13 THEN
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,6,2,0);
						END IF;
					end if;
					
					select count(*) into is_have_credit_year from att_hol_credit_year_log where apply_id = apid;
					if is_have_credit_year > 0 then
						CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,3,2,0);
					end if;
					
					select count(*) into is_have_sick from att_hol_sick_log where apply_id = apid;
					if is_have_sick > 0 then
						CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,4,2,0);
					end if;
	
					select count(*) into is_have_rest from att_hol_rest_log where apply_id = apid;
					if is_have_rest > 0 then
						CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,2,2,0);
					end if;
					
					delete from att_hol_apply_day where emp_id=i_emp and apply_id=apid ;
						
					
	#select i_custid,i_deptid,i_deptn,i_emp,i_empn,MY_HOLID,MY_SONVER,MY_HOL_BEGIN_TIME,MY_HOL_END_TIME,MY_HOL_BGDT,MY_HOL_EDDT;
									
					select dept_id,cust_id,emp_name into i_deptid,i_custid,i_empn from emp_base_info where emp_id=i_emp;
					select dept_name into i_deptn from dept_info where dept_id=i_deptid;
					
					#--------对于单个请假进行分析									part2
			
	
					IF THIS_IYH NOT IN (4,9) AND MY_HOLIDAY_BREIF IS NULL THEN
						SET MY_HOLIDAY_BREIF = FN_ATT_GET_HOL_TRANSFORM(MY_HOL_BEGIN_TIME,MY_HOL_END_TIME,MY_HOLID,MY_SONVER,i_emp,2);
					END IF;

					IF THIS_IYH IN (4,9) THEN
						SET MY_HOLIDAY_BREIF = CONCAT(MY_HOLID,'|',MY_SONVER,'|',MY_HOL_BEGIN_TIME,'|',MY_HOL_END_TIME,'|1.00|1,'); 
					END IF;
		##########################################################################################################################################################
		# 2.1. 根据计算出的假期扣减计划（如果没有顺序扣减的设定，只有1次循环）来循环计算每个细分假期的详细时长
		##########################################################################################################################################################
#SELECT apid,MY_HOLIDAY_BREIF;
					WHILE LOCATE(',',MY_HOLIDAY_BREIF) <= LENGTH(MY_HOLIDAY_BREIF) AND LOCATE(',',MY_HOLIDAY_BREIF) > 2 DO
						SET THIS_CREDITORDER = NULL, h_hour = NULL, et = NULL, st = NULL, sonver = NULL, i_holid = NULL, THIS_HOL_BREIF = NULL;
						
						SET THIS_HOL_BREIF = CONCAT(LEFT(MY_HOLIDAY_BREIF,LOCATE(',',MY_HOLIDAY_BREIF)-1),'|');
						
						SET i_holid = LEFT(THIS_HOL_BREIF,LOCATE('|',THIS_HOL_BREIF)-1);
							SET THIS_HOL_BREIF = RIGHT(THIS_HOL_BREIF,LENGTH(THIS_HOL_BREIF)-LOCATE('|',THIS_HOL_BREIF));

						SET sonver = LEFT(THIS_HOL_BREIF,LOCATE('|',THIS_HOL_BREIF)-1);
							SET THIS_HOL_BREIF = RIGHT(THIS_HOL_BREIF,LENGTH(THIS_HOL_BREIF)-LOCATE('|',THIS_HOL_BREIF));

						SET st = LEFT(THIS_HOL_BREIF,LOCATE('|',THIS_HOL_BREIF)-1);
							SET THIS_HOL_BREIF = RIGHT(THIS_HOL_BREIF,LENGTH(THIS_HOL_BREIF)-LOCATE('|',THIS_HOL_BREIF));

						SET et = LEFT(THIS_HOL_BREIF,LOCATE('|',THIS_HOL_BREIF)-1);
							SET THIS_HOL_BREIF = RIGHT(THIS_HOL_BREIF,LENGTH(THIS_HOL_BREIF)-LOCATE('|',THIS_HOL_BREIF));

						SET h_hour = LEFT(THIS_HOL_BREIF,LOCATE('|',THIS_HOL_BREIF)-1);
							SET THIS_HOL_BREIF = RIGHT(THIS_HOL_BREIF,LENGTH(THIS_HOL_BREIF)-LOCATE('|',THIS_HOL_BREIF));

						SET THIS_CREDITORDER = LEFT(THIS_HOL_BREIF,LOCATE('|',THIS_HOL_BREIF)-1);
#select apid,i_holid,sonver,st,et,h_hour;
						SET sd = NULL, ed = NULL,  o_hour = NULL, dttype = NULL, ATTID_STR = NULL, MY_ATTID = NULL, i_att_rule = NULL;					
						SET hol_flag = NULL, h_rule = NULL, h_unit = NULL, h_st_unit = NULL;
						SET this_end_time = NULL, this_start_time = NULL ,MY_APPLY_END_TIME=NULL;
						
						select is_year_hol,hol_rule,hol_unit,st_unit into hol_flag,h_rule,h_unit,h_st_unit 
						from att_set_holiday_main A 
						where hol_id=i_holid;

						SET sd = DATE(if(time(st) >= '05:00:00',st,date_add(st,interval -1 day)));
						SET ed = DATE(if(time(et) >= '05:00:00',et,date_add(et,interval -1 day)));
						
#select apid,sd,ed;
						set o_hour=h_hour;
						set dttype = FN_ATT_GET_DTTYPE(sd,i_emp);
						#读取考勤方案
						CALL SP_DPT_GET_SETTINGID(i_emp,sd,1,ATTID_STR);
						SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);
#select sd,i_emp;			
						IF MY_ATTID IS NOT NULL THEN	#如果有考勤设置						if 1.5
							#1 获得出勤规则
							select b.att_rule into i_att_rule				#自动扣除法定假期（0否 1是）
							from att_set_schema_new b where b.att_id=MY_ATTID;
	#select i_att_rule;
			##########################################################################################################################################################
			# 2.1.1. 坐班规则下的假期计算
			##########################################################################################################################################################
							#2 根据不同的考勤规则来读取相应的设置信息
							IF i_att_rule = 1 THEN
								#2 获得该公司考勤设置的内容
								select b.is_exp_hol,b.morn_start_time,b.morn_end_time,b.aftn_start_time,b.aftn_end_time,
										b.flex_hour
									into IEH,MST,MET,AST,AET,				#自动扣除法定假期（0否 1是）
										i_flex_hour
								from att_set_schema_new b 
								where b.att_id=MY_ATTID;
								
								IF i_flex_hour IS NULL THEN SET i_flex_hour = 0 ; END IF;
				##########################################################################################################################################################
				# 2.1.1.1. 坐班-非哺乳假，按照正常计算
				##########################################################################################################################################################
#select hol_flag;
								IF hol_flag IS NOT NULL AND hol_flag NOT IN (4,9) THEN
									IF hol_flag = 11 THEN
										SET THIS_YEAR_HOL_ID = NULL;
										CALL SP_DPT_GET_SETTINGID(i_emp,DATE(st),301,MY_HOL_STR);
										IF MY_HOL_STR IS NOT NULL THEN
											SET THIS_YEAR_HOL_ID = LEFT(MY_HOL_STR,LOCATE(':',MY_HOL_STR)-1);
											SET sonver = RIGHT(MY_HOL_STR,LENGTH(MY_HOL_STR)-LOCATE(':',MY_HOL_STR));
											SET MY_ORI_HOLID = i_holid;
											SET i_holid = THIS_YEAR_HOL_ID;
			 							END IF;
									ELSEIF hol_flag IN (12,13) THEN
										SET sonver = 1;
									END IF;
									
									#part2.step 2 判断天数
									IF (sd = ed) THEN	#当sd和ed处于同一天时							
										#请假规则按工作日+不扣除法定节假日+工作日和节假日 或 请假规则按工作日+扣法节+工作日 或 请假规则按自然日 三种情况下计薪 if6
										IF h_rule = 1 THEN
											IF dttype in (1,6) THEN
												IF h_unit = 4 THEN
													CALL FN_ATT_GET_HOL_HALFDAY_TIME(time(st),time(et),MY_ATTID,this_start_time,this_end_time,MY_HALF_FLAG);
													IF MY_HALF_FLAG = 0 THEN
														SET ih_hour = 0;
													ELSEIF MY_HALF_FLAG IN (1,2) AND h_st_unit = 1 THEN
														SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
													ELSEIF MY_HALF_FLAG = 3 AND h_st_unit = 1 THEN
														SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
													ELSE
														SET ih_hour = ROUND(TIME_TO_SEC(TIMEDIFF(this_end_time,this_start_time))/60/60,2);
														IF ih_hour > FN_ATT_GET_WORKHOURS(MY_ATTID) THEN
															SET ih_hour = FN_ATT_GET_WORKHOURS(MY_ATTID);
														END IF;
													END IF;
													SET IS_IN_SPECIAL=0,MY_CONFLICT_TIME=0;
													SET IS_IN_SPECIAL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(sd,MY_HALF_FLAG,i_emp,NULL,NULL),0);
													IF IS_IN_SPECIAL = 1 THEN
														SET MY_CONFLICT_TIME = IFNULL(FN_ATT_GET_SPHOLDAYS(st,et,i_emp,2),0);
														SET ih_hour = ih_hour - MY_CONFLICT_TIME;
														IF ih_hour < 0 THEN SET ih_hour = 0; END IF;
													END IF;
												ELSE
													set this_start_time = time(st);
													set this_end_time = time(et);
													SET MY_HALF_FLAG = 0 ;
													set ih_hour = o_hour;
												END IF;
											ELSE
												set ih_hour = 0;
												SET MY_HALF_FLAG = 0 ;
											END IF;
										ELSEIF h_rule = 2 THEN
											IF h_unit = 4 THEN
												CALL FN_ATT_GET_HOL_HALFDAY_TIME(time(st),time(et),MY_ATTID,this_start_time,this_end_time,MY_HALF_FLAG);
		
												IF MY_HALF_FLAG = 0 THEN
													SET ih_hour = 0;
												ELSEIF MY_HALF_FLAG IN (1,2) AND h_st_unit = 1 THEN
													SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
												ELSEIF MY_HALF_FLAG = 3 AND h_st_unit = 1 THEN
													SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
												ELSE
													SET ih_hour = ROUND(TIME_TO_SEC(TIMEDIFF(this_end_time,this_start_time))/60/60,2);
												END IF;
												SET IS_IN_SPECIAL=0,MY_CONFLICT_TIME=0;
												SET IS_IN_SPECIAL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(sd,MY_HALF_FLAG,i_emp,NULL,NULL),0);
												IF IS_IN_SPECIAL = 1 THEN
													SET MY_CONFLICT_TIME = IFNULL(FN_ATT_GET_SPHOLDAYS(st,et,i_emp,2),0);
													SET ih_hour = ih_hour - MY_CONFLICT_TIME;
													IF ih_hour < 0 THEN SET ih_hour = 0; END IF;
												END IF;
											ELSE
												set this_start_time = time(st);
												set this_end_time = time(et);
												SET MY_HALF_FLAG = 0 ;
												set ih_hour = o_hour;
											END IF;
										END IF;
		
										SET MY_THIS_HOL_DAYS = 0;
										SET MY_THIS_HOL_DAYS = FN_ATT_GET_HOLDAYS(i_emp,MY_ATTID,i_att_rule,sd,ih_hour);
										CALL FN_ATT_HOL_MODIFY_FLEX_TIMEPOINT(i_emp,sd,this_start_time,this_end_time);
										IF hol_flag = 11 THEN
											SET i_holid = MY_ORI_HOLID;
										END IF;
										SET MY_APPLY_END_TIME = TIME(APPLY_END_TIME);

										#公出最后一天算晚补
										IF hol_flag = 10 THEN
											SET THIS_WCBZCS = FN_ATT_GET_DINNER_SUBSIDY_COUNT_HOL(sd,i_emp,MY_APPLY_END_TIME);
										END IF;
#select 1,apid,sd,ih_hour;
										#写入day表
										replace into att_hol_apply_day
											(wcbzcs,apply_end_time,emp_id,hol_date,apply_id,hol_id,son_ver,credit_order,
												cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,att_id,dept_name,
												emp_name,hol_name,is_year_hol,hol_days,
												date_type,start_time,end_time,hol_hours,partition_code,half_day_flag,min_unit) 
										SELECT THIS_WCBZCS,MY_APPLY_END_TIME,i_emp,sd,apid,i_holid,sonver,THIS_CREDITORDER,
												i_custid,i_deptid,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,MY_ATTID,i_deptn,
												i_empn, i_holn,hol_flag,MY_THIS_HOL_DAYS,
												dttype,this_start_time,this_end_time,ih_hour,md5(concat(i_emp,sd,apid)),MY_HALF_FLAG,h_unit
										from EMP_BASE_INFO a WHERE a.emp_id = i_emp ;
										
										#更新考勤日报是否请假
										SET IS_TODAY_HAVE_HOL=NULL;
										SELECT SUM(A.hol_hours) INTO IS_TODAY_HAVE_HOL
										FROM att_hol_apply_day A
										WHERE A.emp_id=i_emp AND hol_date = sd AND A.apply_id IS NOT NULL AND A.apply_id <> 0 AND A.is_year_hol<>10;
										
										IF IS_TODAY_HAVE_HOL IS NULL OR IS_TODAY_HAVE_HOL < 0 THEN
											SET IS_TODAY_HAVE_HOL = 0;
										ELSEIF IS_TODAY_HAVE_HOL > 0 THEN
											SET IS_TODAY_HAVE_HOL = 1;
										END IF;
										
										UPDATE att_emp_detail A
										SET A.is_have_hol = IS_TODAY_HAVE_HOL
										WHERE A.emp_id=i_emp AND A.dt=sd;
										
										CALL SP_ATT_COMPUTE_CHECK_WORK_HOURS(sd,sd,i_emp);
		
									ELSE		#当sd和ed不在同一天时
										#part2.step 3 计算每天时长
										SET i_sd = sd;
										while (sd<=ed) do										#每天分析 loop3
											SET dttype = NULL;
											SET ih_hour = NULL;
											SET THIS_MST = NULL;
											SET THIS_AET = NULL;
											SET MY_FLEX_HOUR = NULL;
											
											#判断是否节假日相关
											SET dttype = FN_ATT_GET_DTTYPE(sd,i_emp);				
											if (sd=date(st)) then			#第一天					if 3.1
												#请假规则按工作日+不扣除法定节假日+工作日和节假日 或 请假规则按工作日+扣法节+工作日 或 请假规则按自然日 三种情况下计薪 if6
											
												SET THIS_MST = CONCAT(date(st),' ',MST);
												SET THIS_AET = CONCAT(date(st),' ',AET);
											
												IF h_rule = 1 THEN
													IF dttype in (1,6) OR (dttype=3 AND IEH=0) THEN
														IF h_unit = 4 THEN
															CALL FN_ATT_GET_HOL_HALFDAY_TIME(time(st),time(THIS_AET),MY_ATTID,this_start_time,this_end_time,MY_HALF_FLAG);
	#SELECT 3,time(st),time(THIS_AET),i_deptid,this_start_time,this_end_time,MY_HALF_FLAG;
															IF MY_HALF_FLAG = 0 THEN
																SET ih_hour = 0;
															ELSEIF MY_HALF_FLAG IN (1,2) AND h_st_unit = 1 THEN
																SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
															ELSEIF MY_HALF_FLAG = 3 AND h_st_unit = 1 THEN
																SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
															ELSE
																SET ih_hour = ROUND(TIME_TO_SEC(TIMEDIFF(this_end_time,this_start_time))/60/60,2);
																IF ih_hour > FN_ATT_GET_WORKHOURS(MY_ATTID) THEN
																	SET ih_hour = FN_ATT_GET_WORKHOURS(MY_ATTID);
																END IF;
															END IF;
	#SELECT 1,ih_hour,h_st_unit,MY_HALF_FLAG;
															SET IS_IN_SPECIAL=0,MY_CONFLICT_TIME=0;
															SET IS_IN_SPECIAL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(sd,MY_HALF_FLAG,i_emp,NULL,NULL),0);
															IF IS_IN_SPECIAL = 1 THEN
																SET MY_CONFLICT_TIME = IFNULL(FN_ATT_GET_SPHOLDAYS(st,CONCAT(sd,' 23:59:59'),i_emp,2),0);
																SET ih_hour = ih_hour - MY_CONFLICT_TIME;
																IF ih_hour < 0 THEN SET ih_hour = 0; END IF;
															END IF;
	#SELECT 2,ih_hour,h_st_unit;
														ELSE
															set this_start_time = time(st);
															set this_end_time =time(THIS_AET);
															SET MY_HALF_FLAG = 0 ;
															set ih_hour = FN_ATT_GET_REAL_HOLIDAY_HOURS(this_start_time,this_end_time,i_holid,sonver,i_emp,MY_ATTID,sd,99);
	#SELECT 1,this_start_time,this_end_time,i_holid,sonver,i_emp,MY_ATTID,sd,99;
														END IF;
													ELSEIF dttype IN (2,4,5) OR (dttype=3 AND IEH=1) THEN
														set ih_hour = 0;
														SET MY_HALF_FLAG = 0 ;
													END IF;
												ELSEIF h_rule = 2 THEN
													IF h_unit = 4 THEN
														CALL FN_ATT_GET_HOL_HALFDAY_TIME(time(st),time(THIS_AET),MY_ATTID,this_start_time,this_end_time,MY_HALF_FLAG);
														IF MY_HALF_FLAG = 0 THEN
															SET ih_hour = 0;
														ELSEIF MY_HALF_FLAG IN (1,2) AND h_st_unit = 1 THEN
															SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
														ELSEIF MY_HALF_FLAG = 3 AND h_st_unit = 1 THEN
															SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
														ELSE
															SET ih_hour = ROUND(TIME_TO_SEC(TIMEDIFF(this_end_time,this_start_time))/60/60,2);
														END IF;
														SET IS_IN_SPECIAL=0,MY_CONFLICT_TIME=0;
														SET IS_IN_SPECIAL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(sd,MY_HALF_FLAG,i_emp,NULL,NULL),0);
														IF IS_IN_SPECIAL = 1 THEN
															SET MY_CONFLICT_TIME = IFNULL(FN_ATT_GET_SPHOLDAYS(st,CONCAT(sd,' 23:59:59'),i_emp,2),0);
															SET ih_hour = ih_hour - MY_CONFLICT_TIME;
															IF ih_hour < 0 THEN SET ih_hour = 0; END IF;
														END IF;
													ELSE
														set this_start_time = time(st);
														set this_end_time =time(THIS_AET);
														SET MY_HALF_FLAG = 0 ;
														set ih_hour = FN_ATT_GET_REAL_HOLIDAY_HOURS_WITHOUT_FLEX(this_start_time,this_end_time,i_holid,sonver,i_emp,MY_ATTID,sd,99);
	#SELECT 2,this_start_time,this_end_time,i_holid,sonver,i_emp,MY_ATTID,sd,99;
													END IF;
													
												END IF;
												SET MY_APPLY_END_TIME = this_end_time;
											elseif (sd=date(et)) then		#最后一天						
												#请假规则按工作日+不扣除法定节假日+工作日和节假日 或 请假规则按工作日+扣法节+工作日 或 请假规则按自然日 三种情况下计薪 if6
												IF h_rule = 1 THEN
													IF dttype in (1,6) OR (dttype=3 AND IEH=0) THEN
														IF h_unit = 4 THEN
															CALL FN_ATT_GET_HOL_HALFDAY_TIME(MST,time(et),MY_ATTID,this_start_time,this_end_time,MY_HALF_FLAG);
															IF MY_HALF_FLAG = 0 THEN
																SET ih_hour = 0;
															ELSEIF MY_HALF_FLAG IN (1,2) AND h_st_unit=1 THEN
																SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
															ELSEIF MY_HALF_FLAG = 3 AND h_st_unit=1 THEN
																SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
															ELSE
																SET ih_hour = ROUND(TIME_TO_SEC(TIMEDIFF(this_end_time,this_start_time))/60/60,2);
																IF ih_hour > FN_ATT_GET_WORKHOURS(MY_ATTID) THEN
																	SET ih_hour = FN_ATT_GET_WORKHOURS(MY_ATTID);
																END IF;
															END IF;
															SET IS_IN_SPECIAL=0,MY_CONFLICT_TIME=0;
															SET IS_IN_SPECIAL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(sd,MY_HALF_FLAG,i_emp,NULL,NULL),0);
															IF IS_IN_SPECIAL = 1 THEN
																SET MY_CONFLICT_TIME = IFNULL(FN_ATT_GET_SPHOLDAYS(CONCAT(sd,' 00:00:00'),et,i_emp,2),0);
																SET ih_hour = ih_hour - MY_CONFLICT_TIME;
																IF ih_hour < 0 THEN SET ih_hour = 0; END IF;
															END IF;
														ELSE
															set this_start_time = MST;
															set this_end_time =time(et);
															SET MY_HALF_FLAG = 0 ;
															set ih_hour = o_hour;
	#SELECT 3,this_start_time,this_end_time,i_holid,sonver,i_emp,MY_ATTID,sd,99;
														END IF;
		
													ELSEIF dttype IN (2,4,5) OR (dttype=3 AND IEH=1) THEN
														set ih_hour = 0;
														SET MY_HALF_FLAG = 0 ;
													END IF;
												ELSEIF h_rule = 2 THEN
													IF h_unit = 4 THEN
														CALL FN_ATT_GET_HOL_HALFDAY_TIME(MST,time(et),MY_ATTID,this_start_time,this_end_time,MY_HALF_FLAG);
														IF MY_HALF_FLAG = 0 THEN
															SET ih_hour = 0;
														ELSEIF MY_HALF_FLAG IN (1,2) AND h_st_unit=1 THEN
															SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
														ELSEIF MY_HALF_FLAG = 3 AND h_st_unit=1 THEN
															SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
														ELSE
															SET ih_hour = ROUND(TIME_TO_SEC(TIMEDIFF(this_end_time,this_start_time))/60/60,2);
														END IF;
															SET IS_IN_SPECIAL=0,MY_CONFLICT_TIME=0;
															SET IS_IN_SPECIAL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(sd,MY_HALF_FLAG,i_emp,NULL,NULL),0);
															IF IS_IN_SPECIAL = 1 THEN
																SET MY_CONFLICT_TIME = IFNULL(FN_ATT_GET_SPHOLDAYS(CONCAT(sd,' 00:00:00'),et,i_emp,2),0);
																SET ih_hour = ih_hour - MY_CONFLICT_TIME;
																IF ih_hour < 0 THEN SET ih_hour = 0; END IF;
															END IF;
													ELSE
														set this_start_time = MST;
														set this_end_time =time(et);
														SET MY_HALF_FLAG = 0 ;
														set ih_hour = o_hour;
													END IF;
													
												END IF;																													#if7
												SET MY_APPLY_END_TIME = TIME(APPLY_END_TIME);
												#公出最后一天算晚补
												IF hol_flag = 10 THEN
													SET THIS_WCBZCS = FN_ATT_GET_DINNER_SUBSIDY_COUNT_HOL(sd,i_emp,MY_APPLY_END_TIME);
#SELECT sd,i_emp,MY_APPLY_END_TIME,THIS_WCBZCS;
												END IF;
		
											else									#其余天				
												#请假规则按工作日+不扣除法定节假日+工作日和节假日 或 请假规则按工作日+扣法节+工作日 或 请假规则按自然日 三种情况下计薪 if6						
												IF h_rule = 1 THEN
													IF dttype in (1,6) OR (dttype=3 AND IEH=0) THEN
														IF h_unit = 4 THEN
															CALL FN_ATT_GET_HOL_HALFDAY_TIME(MST,AET,MY_ATTID,this_start_time,this_end_time,MY_HALF_FLAG);
															IF MY_HALF_FLAG = 0 THEN
																SET ih_hour = 0;
															ELSEIF MY_HALF_FLAG IN (1,2) AND h_st_unit=1 THEN
																SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
															ELSEIF MY_HALF_FLAG = 3 AND h_st_unit=1 THEN
																SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
															ELSE
																SET ih_hour = ROUND(TIME_TO_SEC(TIMEDIFF(this_end_time,this_start_time))/60/60,2);
																IF ih_hour > FN_ATT_GET_WORKHOURS(MY_ATTID) THEN
																	SET ih_hour = FN_ATT_GET_WORKHOURS(MY_ATTID);
																END IF;
															END IF;
															SET IS_IN_SPECIAL=0,MY_CONFLICT_TIME=0;
															SET IS_IN_SPECIAL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(sd,MY_HALF_FLAG,i_emp,NULL,NULL),0);
															IF IS_IN_SPECIAL = 1 THEN
																SET MY_CONFLICT_TIME = IFNULL(FN_ATT_GET_SPHOLDAYS(CONCAT(sd,' 00:00:00'),CONCAT(sd,' 23:59:59'),i_emp,2),0);
																SET ih_hour = ih_hour - MY_CONFLICT_TIME;
																IF ih_hour < 0 THEN SET ih_hour = 0; END IF;
															END IF;
														ELSE
															set this_start_time = MST;
															set this_end_time = AET;
															SET MY_HALF_FLAG = 0 ;
															set ih_hour = FN_ATT_GET_REAL_HOLIDAY_HOURS_WITHOUT_FLEX(this_start_time,this_end_time,i_holid,sonver,i_emp,MY_ATTID,sd,99);
														END IF;
		
														
													ELSEIF dttype IN (2,4,5) OR (dttype=3 AND IEH=1) THEN
														set ih_hour = 0;
														SET MY_HALF_FLAG = 0 ;
													END IF;
												ELSEIF h_rule = 2 THEN
													IF h_unit = 4 THEN
														CALL FN_ATT_GET_HOL_HALFDAY_TIME(MST,AET,MY_ATTID,this_start_time,this_end_time,MY_HALF_FLAG);
														IF MY_HALF_FLAG = 0 THEN
															SET ih_hour = 0;
														ELSEIF MY_HALF_FLAG IN (1,2) AND h_st_unit=1 THEN
															SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
														ELSEIF MY_HALF_FLAG = 3 AND h_st_unit=1 THEN
															SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
														ELSE
															SET ih_hour = ROUND(TIME_TO_SEC(TIMEDIFF(this_end_time,this_start_time))/60/60,2);
														END IF;
														SET IS_IN_SPECIAL=0,MY_CONFLICT_TIME=0;
														SET IS_IN_SPECIAL = IFNULL(FN_ATT_IS_THISDAY_IN_SPHOL(sd,MY_HALF_FLAG,i_emp,NULL,NULL),0);
														IF IS_IN_SPECIAL = 1 THEN
															SET MY_CONFLICT_TIME = IFNULL(FN_ATT_GET_SPHOLDAYS(CONCAT(sd,' 00:00:00'),CONCAT(sd,' 23:59:59'),i_emp,2),0);
															SET ih_hour = ih_hour - MY_CONFLICT_TIME;
															IF ih_hour < 0 THEN SET ih_hour = 0; END IF;
														END IF;
													ELSE
														set this_start_time = MST;
														set this_end_time = AET;
														SET MY_HALF_FLAG = 0 ;
														set ih_hour = FN_ATT_GET_REAL_HOLIDAY_HOURS_WITHOUT_FLEX(this_start_time,this_end_time,i_holid,sonver,i_emp,MY_ATTID,sd,99);
													END IF;
												END IF;	#if6
												SET MY_APPLY_END_TIME = this_end_time;
											end if;																#if 3.1
															
		
											SET MY_THIS_HOL_DAYS = 0;
											SET MY_THIS_HOL_DAYS = FN_ATT_GET_HOLDAYS(i_emp,MY_ATTID,i_att_rule,sd,ih_hour);
	#select 2,MY_THIS_HOL_DAYS,i_emp,MY_ATTID,i_att_rule,sd,ih_hour;
											IF hol_flag = 11 THEN
												SET i_holid = MY_ORI_HOLID;
											END IF;
											CALL FN_ATT_HOL_MODIFY_FLEX_TIMEPOINT(i_emp,sd,this_start_time,this_end_time);
#IF apid = 331924536721408 THEN
#select 2,apid,sd,ih_hour;
#END IF;
											replace into att_hol_apply_day
												(WCBZCS,APPLY_END_TIME,emp_id,hol_date,apply_id,hol_id,son_ver,credit_order,
													cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,att_id,dept_name,
													emp_name,hol_name,is_year_hol,hol_days,
													date_type,start_time,end_time,hol_hours,partition_code,half_day_flag,min_unit) 
											SELECT THIS_WCBZCS,MY_APPLY_END_TIME,i_emp,sd,apid,i_holid,sonver,THIS_CREDITORDER,
													i_custid,i_deptid,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,MY_ATTID,i_deptn,
													i_empn, i_holn,hol_flag,MY_THIS_HOL_DAYS,
													dttype,this_start_time,this_end_time,ih_hour,md5(concat(i_emp,sd,apid)),MY_HALF_FLAG,h_unit
											from EMP_BASE_INFO a WHERE a.emp_id = i_emp ;
											
											#更新考勤日报是否请假
											SET IS_TODAY_HAVE_HOL=NULL;
											SELECT SUM(A.hol_hours) INTO IS_TODAY_HAVE_HOL
											FROM att_hol_apply_day A
											WHERE A.emp_id=i_emp AND hol_date = sd AND A.apply_id IS NOT NULL AND A.apply_id <> 0 AND A.is_year_hol<>10;
											
											IF IS_TODAY_HAVE_HOL IS NULL OR IS_TODAY_HAVE_HOL < 0 THEN
												SET IS_TODAY_HAVE_HOL = 0;
											ELSEIF IS_TODAY_HAVE_HOL > 0 THEN
												SET IS_TODAY_HAVE_HOL = 1;
											END IF;
											
											UPDATE att_emp_detail A
											SET A.is_have_hol = IS_TODAY_HAVE_HOL
											WHERE A.emp_id=i_emp AND A.dt=sd;
											
											CALL SP_ATT_COMPUTE_CHECK_WORK_HOURS(sd,sd,i_emp);
											
											set o_hour = o_hour - ih_hour;
											set sd=date_add(sd,interval 1 day);
										end while;												#loop3
									END IF;
				##########################################################################################################################################################
				# 2.1.1.2. 坐班-哺乳假
				##########################################################################################################################################################
								ELSEIF hol_flag=4 THEN
									#读出哺乳假的特殊设置
									SELECT start_time,hol_duration,hol_milk_exp_date
										INTO i_milk_start_time,i_hol_duration,i_hol_milk_exp_date
										#开始日期，哺乳假请假时长（1每天1小时  2每月2.5天），哺乳假截止日期
									FROM att_hol_apply A
									WHERE A.apply_id = apid;
									#当设置有效时才开始计算
									IF i_milk_start_time IS NOT NULL AND i_hol_milk_exp_date IS NOT NULL AND i_hol_milk_exp_date > DATE(i_milk_start_time) THEN
										SET MY_BGDT = DATE(i_milk_start_time);
										SET MY_EDDT = i_hol_milk_exp_date;
										
										WHILE (MY_BGDT <= MY_EDDT) DO
											#每天1小时
											IF i_hol_duration = 1 THEN
												SET dttype = FN_ATT_GET_DTTYPE(MY_BGDT,i_emp);
												SET this_end_time = CONCAT(MY_BGDT,' ',AET);
												SET this_start_time = DATE_ADD(this_end_time,INTERVAL -1 HOUR);
												IF h_rule = 1 THEN
													IF dttype in (1,6) OR (IEH=0 AND dttype=3) THEN
														SET ih_hour = 1;
													ELSEIF dttype in (2,4,5) OR (IEH=1 and dttype=3) THEN
														SET ih_hour = 0;
													END IF;
												ELSEIF h_rule = 2 THEN
													SET ih_hour = 1;
												END IF;
												SET MY_THIS_HOL_DAYS = 0;
												SET MY_THIS_HOL_DAYS = FN_ATT_GET_HOLDAYS(i_emp,MY_ATTID,i_att_rule,MY_BGDT,ih_hour);
												CALL FN_ATT_HOL_MODIFY_FLEX_TIMEPOINT(i_emp,MY_BGDT,this_start_time,this_end_time);
#select 3,MY_THIS_HOL_DAYS;
												#写入day表
												replace into att_hol_apply_day
													(emp_id,hol_date,apply_id,hol_id,son_ver,credit_order,
														cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,att_id,dept_name,
														emp_name,hol_name,is_year_hol,HOL_DAYS,
														date_type,start_time,end_time,hol_hours,partition_code) 
												select i_emp,MY_BGDT,apid,i_holid,sonver,THIS_CREDITORDER,
														i_custid,i_deptid,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,MY_ATTID,i_deptn,
														i_empn,i_holn,hol_flag,MY_THIS_HOL_DAYS,
														dttype,this_start_time,this_end_time,ih_hour,md5(concat(i_emp,MY_BGDT,apid))
												from emp_base_info a where a.emp_id=i_emp;	
																				
												
												#更新考勤日报是否请假
												SET IS_TODAY_HAVE_HOL=NULL;
												SELECT SUM(A.hol_hours) INTO IS_TODAY_HAVE_HOL
												FROM att_hol_apply_day A
												WHERE A.emp_id=i_emp AND hol_date = MY_BGDT AND A.apply_id IS NOT NULL AND A.apply_id <> 0 AND A.is_year_hol<>10;
												
												IF IS_TODAY_HAVE_HOL IS NULL OR IS_TODAY_HAVE_HOL < 0 THEN
													SET IS_TODAY_HAVE_HOL = 0;
												ELSEIF IS_TODAY_HAVE_HOL > 0 THEN
													SET IS_TODAY_HAVE_HOL = 1;
												END IF;
												
												UPDATE att_emp_detail A
												SET A.is_have_hol = IS_TODAY_HAVE_HOL
												WHERE A.emp_id=i_emp AND A.dt=MY_BGDT;
		
												CALL SP_ATT_COMPUTE_CHECK_WORK_HOURS(MY_BGDT,MY_BGDT,i_emp);
												
												SET MY_BGDT = DATE_ADD(MY_BGDT,INTERVAL 1 DAY);
												
											#每月2.5天(an自然月的最后2.5天扣)
											ELSEIF i_hol_duration = 2 THEN
												#得到当月最后三天的日期
												SET THIS_BGDT = DATE_ADD(CONCAT(YEAR(DATE_ADD(MY_BGDT,INTERVAL 1 MONTH)),'-',MONTH(DATE_ADD(MY_BGDT,INTERVAL 1 MONTH)),'-01'),INTERVAL -1 DAY);
												SET DAYS = 2.5;
												#倒数三天
												WHILE (DAYS > 0) DO
													SET THIS_DTTYPE=FN_ATT_GET_DTTYPE(THIS_BGDT,i_emp);
													IF THIS_DTTYPE IN (1,6)  THEN
														#当最后的一天时，扣0.5天
														IF DAYS = 0.5 THEN
															SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID)/2,2);
															SET this_end_time = AET;
															SET this_start_time = DATE_ADD(this_end_time,INTERVAL -ih_hour HOUR);
															SET THIS_DAYS = 0.5;
														ELSE
															SET ih_hour = ROUND(FN_ATT_GET_WORKHOURS(MY_ATTID),2);
															SET this_end_time = AET;
															SET this_start_time = MST;
															SET THIS_DAYS = 1;
														END IF;
		
														SET MY_THIS_HOL_DAYS = 0;
														SET MY_THIS_HOL_DAYS = FN_ATT_GET_HOLDAYS(i_emp,MY_ATTID,i_att_rule,MY_BGDT,ih_hour);
														CALL FN_ATT_HOL_MODIFY_FLEX_TIMEPOINT(i_emp,THIS_BGDT,this_start_time,this_end_time);
#select 4,MY_THIS_HOL_DAYS;
														#写入day表
														replace into att_hol_apply_day
															(emp_id,hol_date,apply_id,hol_id,son_ver,credit_order,
																cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,att_id,dept_name,
																emp_name,hol_name,is_year_hol,HOL_DAYS,
																date_type,start_time,end_time,hol_hours,partition_code) 
														select i_emp,THIS_BGDT,apid,i_holid,sonver,THIS_CREDITORDER,
																i_custid,i_deptid,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,MY_ATTID,i_deptn,
																i_empn,  i_holn,hol_flag,MY_THIS_HOL_DAYS,
																	dttype,this_start_time,this_end_time,ih_hour,md5(concat(i_emp,MY_BGDT,apid))
														from emp_base_info a where a.emp_id=i_emp;
		
														#更新考勤日报是否请假
														SET IS_TODAY_HAVE_HOL=NULL;
														SELECT SUM(A.hol_hours) INTO IS_TODAY_HAVE_HOL
														FROM att_hol_apply_day A
														WHERE A.emp_id=i_emp AND hol_date = THIS_BGDT AND A.apply_id IS NOT NULL AND A.apply_id <> 0 AND A.is_year_hol<>10;
																		
														IF IS_TODAY_HAVE_HOL IS NULL OR IS_TODAY_HAVE_HOL < 0 THEN
															SET IS_TODAY_HAVE_HOL = 0;
														ELSEIF IS_TODAY_HAVE_HOL > 0 THEN
															SET IS_TODAY_HAVE_HOL = 1;
														END IF;
														
														UPDATE att_emp_detail A
														SET A.is_have_hol = IS_TODAY_HAVE_HOL
														WHERE A.emp_id=i_emp AND A.dt=THIS_BGDT;
														
														CALL SP_ATT_COMPUTE_CHECK_WORK_HOURS(THIS_BGDT,THIS_BGDT,i_emp);
		
													END IF;
													SET DAYS = DAYS - THIS_DAYS ;
													SET THIS_BGDT = DATE_ADD(THIS_BGDT,INTERVAL -1 DAY);
												END WHILE;
												SET MY_BGDT = DATE_ADD(MY_BGDT,INTERVAL 1 MONTH);
											ELSE
												SET MY_BGDT = DATE_ADD(MY_EDDT,INTERVAL 1 DAY);
											END IF;
										END WHILE;
									END IF;
				##########################################################################################################################################################
				# 2.1.1.3. 坐班-几个孩子每天几个小时的哺乳假
				##########################################################################################################################################################
								ELSEIF hol_flag=9 THEN
									#读出哺乳假的特殊设置
									SELECT start_time,child_number,hol_milk_exp_date
										INTO i_milk_start_time,i_child_number,i_hol_milk_exp_date
										#开始日期，哺乳假请假时长（1每天1小时  2每月2.5天），哺乳假截止日期
									FROM att_hol_apply A
									WHERE A.apply_id = apid;
#select apid,i_milk_start_time,i_hol_milk_exp_date;

									#当设置有效时才开始计算
									IF i_milk_start_time IS NOT NULL AND i_hol_milk_exp_date IS NOT NULL AND i_hol_milk_exp_date > DATE(i_milk_start_time) THEN
										SET MY_BGDT = DATE(i_milk_start_time);
										SET MY_EDDT = i_hol_milk_exp_date;
#select MY_BGDT,MY_EDDT;
										WHILE (MY_BGDT <= MY_EDDT) DO
											SET dttype = FN_ATT_GET_DTTYPE(MY_BGDT,i_emp);
											SET this_end_time = CONCAT(MY_BGDT,' ',AET);
											SET this_start_time = DATE_ADD(this_end_time,INTERVAL -i_child_number HOUR);
											IF h_rule = 1 THEN
												IF dttype in (1,6) THEN
													SET ih_hour = i_child_number;
												ELSEIF dttype in (2,4,5) OR (IEH=1 and dttype=3) THEN
													SET ih_hour = 0;
												END IF;
											ELSEIF h_rule = 2 THEN
												SET ih_hour = i_child_number;
											END IF;
		
											SET MY_THIS_HOL_DAYS = 0;
											SET MY_THIS_HOL_DAYS = FN_ATT_GET_HOLDAYS(i_emp,MY_ATTID,i_att_rule,MY_BGDT,ih_hour);
											CALL FN_ATT_HOL_MODIFY_FLEX_TIMEPOINT(i_emp,MY_BGDT,this_start_time,this_end_time);
#select 5,MY_THIS_HOL_DAYS;
											#写入day表
											replace into att_hol_apply_day
												(emp_id,hol_date,apply_id,hol_id,son_ver,credit_order,
													cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,att_id,dept_name,
													emp_name,hol_name,is_year_hol,HOL_DAYS,
													date_type,start_time,end_time,hol_hours,partition_code) 
											select i_emp,MY_BGDT,apid,i_holid,sonver,THIS_CREDITORDER,
													i_custid,i_deptid,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,MY_ATTID,i_deptn,
													i_empn,  i_holn,hol_flag,MY_THIS_HOL_DAYS,
														dttype,this_start_time,this_end_time,ih_hour,md5(concat(i_emp,MY_BGDT,apid))
											from emp_base_info a where a.emp_id=i_emp;
		
		
											#更新考勤日报是否请假
											SET IS_TODAY_HAVE_HOL=NULL;
											SELECT SUM(A.hol_hours) INTO IS_TODAY_HAVE_HOL
											FROM att_hol_apply_day A
											WHERE A.emp_id=i_emp AND hol_date = MY_BGDT AND A.apply_id IS NOT NULL AND A.apply_id <> 0;
											
											IF IS_TODAY_HAVE_HOL IS NULL OR IS_TODAY_HAVE_HOL < 0 THEN
												SET IS_TODAY_HAVE_HOL = 0;
											ELSEIF IS_TODAY_HAVE_HOL > 0 THEN
												SET IS_TODAY_HAVE_HOL = 1;
											END IF;
											
											UPDATE att_emp_detail A
											SET A.is_have_hol = IS_TODAY_HAVE_HOL
											WHERE A.emp_id=i_emp AND A.dt=MY_BGDT;
		
											CALL SP_ATT_COMPUTE_CHECK_WORK_HOURS(MY_BGDT,MY_BGDT,i_emp);
											
											SET MY_BGDT = DATE_ADD(MY_BGDT,INTERVAL 1 DAY);
										END WHILE;
									END IF;
								END IF;						
							END IF;
						END IF;																#if 1.5
						SET MY_HOLIDAY_BREIF = RIGHT(MY_HOLIDAY_BREIF,LENGTH(MY_HOLIDAY_BREIF)-LOCATE(',',MY_HOLIDAY_BREIF));
					END WHILE;
				
		##########################################################################################################################################################
		# 2.2. 修改池子表 
		##########################################################################################################################################################
					SET hol_ct = NULL, hol_mxct = NULL;
					SELECT MIN(A.credit_order),MAX(A.credit_order) INTO hol_ct,hol_mxct 
					FROM att_hol_apply_day A WHERE A.apply_id=apid;

					WHILE hol_ct <= hol_mxct AND hol_ct > 0 DO
						SET hol_flag = NULL,i_att_rule = NULL, MY_HOL_DATE = NULL, ATTID_STR = NULL, MY_ATTID = NULL, this_do_value = NULL, MY_LAST_LEFT_SICK = NULL, MY_THIS_LEFT_SICK = NULL, MY_LAST_DECUCTION = NULL, MY_THIS_DECUCTION = NULL, MY_HOL_DAYS = NULL, this_do_value = NULL;
						
						SELECT SUM(if(hol_hours is null,0,hol_hours)),MIN(HOL_DATE),MIN(is_year_hol) 
							INTO this_do_value,MY_HOL_DATE,hol_flag
						FROM att_hol_apply_day WHERE apply_id = apid and credit_order=hol_ct;
		
						#读取考勤方案
						CALL SP_DPT_GET_SETTINGID(i_emp,MY_HOL_DATE,1,ATTID_STR);
						SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);
		
						#根据不同的假期进行不同的操作
						#年假
						#1 获得出勤规则
						select b.att_rule into i_att_rule				#自动扣除法定假期（0否 1是）
						from att_set_schema_new b where b.att_id=MY_ATTID;
 
						if hol_flag=1 then
							#折算成天
		#************************************************************************
							#这里待确认排班的情况下，小时转换成天的方案
		#************************************************************************
		
							IF i_att_rule = 1 THEN
								SET this_do_value = this_do_value/FN_ATT_GET_WORKHOURS(MY_ATTID);
							ELSE
								SET this_do_value = 0;
								SELECT MIN(HOL_DATE),MAX(HOL_DATE) INTO PB_BGDT,PB_EDDT FROM att_hol_apply_day WHERE apply_id=apid;
								WHILE PB_BGDT <= PB_EDDT AND PB_BGDT IS NOT NULL DO
#*FLAG
									SELECT SUM(IF(A.hol_hours IS NULL,0,A.hol_hours)) INTO PB_HOL_HOURS 
									FROM att_hol_apply_day A
									WHERE A.apply_id=apid AND A.hol_date = PB_BGDT AND A.credit_order=hol_ct;
									
									IF PB_HOL_HOURS > 0 THEN
										SET PB_HOL_YEAR_DAY = ROUND(PB_HOL_HOURS/(FN_ATT_GET_ARR_WORKHOURS(i_emp,PB_BGDT)/60),5);				
										SET this_do_value = this_do_value + PB_HOL_YEAR_DAY;
									END IF;
									SET PB_BGDT = DATE_ADD(PB_BGDT,INTERVAL 1 DAY);
								END WHILE;
							END IF;

							IF this_do_value <> 0 THEN
								#将本次的修改记录到池子表的修改记录中
								CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,1,2,this_do_value);
#SELECT i_emp,apid,1,2,this_do_value;
							END IF;
						ELSEIF hol_flag=11 then #预支年假
							#折算成天
		
							IF i_att_rule = 1 THEN
								SET this_do_value = this_do_value/FN_ATT_GET_WORKHOURS(MY_ATTID);
							ELSE
								SET this_do_value = 0;
								SELECT MIN(HOL_DATE),MAX(HOL_DATE) INTO PB_BGDT,PB_EDDT FROM att_hol_apply_day WHERE apply_id=apid;
								WHILE PB_BGDT <= PB_EDDT AND PB_BGDT IS NOT NULL DO
#*FLAG
									SELECT SUM(IF(A.hol_hours IS NULL,0,A.hol_hours)) INTO PB_HOL_HOURS 
									FROM att_hol_apply_day A
									WHERE A.apply_id=apid AND A.hol_date = PB_BGDT AND A.credit_order=hol_ct;
									
									IF PB_HOL_HOURS > 0 THEN
										SET PB_HOL_YEAR_DAY = ROUND(PB_HOL_HOURS/(FN_ATT_GET_ARR_WORKHOURS(i_emp,PB_BGDT)/60),5);				
										SET this_do_value = this_do_value + PB_HOL_YEAR_DAY;
									END IF;
									SET PB_BGDT = DATE_ADD(PB_BGDT,INTERVAL 1 DAY);
								END WHILE;
							END IF;
	
							IF this_do_value <> 0 THEN
								#将本次的修改记录到池子表的修改记录中
								CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,3,2,this_do_value);
							END IF;
						#调休
						elseif hol_flag=2 then
							IF this_do_value <> 0 THEN
								#将调休和加班关联起来
								
								#剩余调休时数初始化
								SET MY_LEFT_REST_HOUR = this_do_value;
								
								#把置换方式为调休，且时数还没有消耗完的加班，按照加班结束时间正序的方式存入临时表，进行循环计算，直到剩余调休被安排完为止。
								INSERT INTO tmp_att_hol_rest_overapplyid_list (VERSION_CODE,OVER_APPLY_ID)
									SELECT DISTINCT i_version_code,OVER_APPLY_ID 
									FROM att_over_apply_log  
									WHERE rest_apply_id = apid 
									ORDER BY op_seq;
									
								INSERT INTO tmp_att_hol_rest_overapplyid_list (VERSION_CODE,OVER_APPLY_ID)
									SELECT DISTINCT i_version_code,A.apply_id 
									FROM att_over_apply A 
										LEFT JOIN att_over_apply_day B ON A.apply_id=B.apply_id
									WHERE A.emp_id = i_emp AND A.over_hours - A.rest_hours > 0 
										AND A.state=1 AND B.date_repay_type=2
									ORDER BY A.end_time ,(A.over_hours - A.rest_hours)  ;
								
								SELECT MIN(ID),MAX(ID) INTO REST_CT,REST_MXCT FROM tmp_att_hol_rest_overapplyid_list WHERE VERSION_CODE = i_version_code;
								WHILE (REST_CT <= REST_MXCT AND REST_CT>0 AND MY_LEFT_REST_HOUR > 0 ) DO
									SELECT OVER_APPLY_ID INTO MY_OVER_APPLY_ID FROM tmp_att_hol_rest_overapplyid_list WHERE ID = REST_CT AND VERSION_CODE = i_version_code;
									IF MY_OVER_APPLY_ID IS NOT NULL THEN
										CALL SP_ATT_REST_OVER_OPERATE(apid,MY_OVER_APPLY_ID,MY_LEFT_REST_HOUR,MY_LEFT_REST_HOUR,REST_CT);
									END IF;
									DELETE FROM tmp_att_hol_rest_overapplyid_list WHERE VERSION_CODE = i_version_code AND ID=REST_CT;
									SET REST_CT = REST_CT + 1;
								END WHILE;
								
								IF this_do_value<>0 THEN
									#将本次的修改记录到池子表的修改记录中
									CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,2,2,this_do_value);
								END IF;
							END IF;
						#付费调休
						elseif hol_flag IN (12,13) then
							IF this_do_value <> 0 THEN
								#剩余调休时数初始化
								SET MY_LEFT_REST_HOUR = this_do_value;
								
								IF this_do_value<>0 THEN
									#将本次的修改记录到池子表的修改记录中
									IF hol_flag = 12 THEN
										CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,5,2,this_do_value);
									ELSEIF hol_flag = 13 THEN
										CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,6,2,this_do_value);
									END IF;
								END IF;
							END IF;
						#（带薪）病假
						elseif hol_flag=3 then
							CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,4,2,0);			
							#先读出去年和今年池子中剩余值					
							SELECT SUM(IF(A.this_year_left IS NULL,0,A.this_year_left)) INTO MY_THIS_LEFT_SICK 
							FROM att_hol_sick A WHERE A.emp_id = i_emp AND IS_DELETE=0 ;
							
							#校正变量
							IF MY_THIS_LEFT_SICK IS NULL OR MY_THIS_LEFT_SICK < 0 THEN
								SET MY_THIS_LEFT_SICK = 0 ;
							END IF;
								
						
							IF i_att_rule = 1 THEN
								SET MY_THIS_LEFT_SICK = MY_THIS_LEFT_SICK * FN_ATT_GET_WORKHOURS(MY_ATTID);
								SET MY_HOL_DAYS = this_do_value;
								
								#计算有剩余
								IF MY_THIS_LEFT_SICK > 0 THEN
									#剩余够扣，扣除量就是 MY_HOL_DAYS - MY_LAST_DECUCTION
									IF MY_THIS_LEFT_SICK - MY_HOL_DAYS >= 0 THEN
										SET MY_THIS_DECUCTION = MY_HOL_DAYS;
										
									#剩余不够扣,扣除量就剩余
									ELSE
										SET MY_THIS_DECUCTION = MY_THIS_LEFT_SICK;
										
									END IF;
									
								#没剩余
								ELSE
									SET MY_THIS_DECUCTION = 0 ;
								END IF;
								SET FREE_BGDT=NULL,FREE_EDDT=NULL,ORI_MY_THIS_DECUCTION = MY_THIS_DECUCTION;
								SELECT MIN(A.hol_date),MAX(A.hol_date) INTO FREE_BGDT,FREE_EDDT 
								FROM att_hol_apply_day A WHERE A.emp_id=i_emp AND A.apply_id=apid and credit_order=hol_ct;
								#首先更新日报表
								WHILE MY_THIS_DECUCTION > 0 AND FREE_BGDT <= FREE_EDDT DO
									SET this_do_value = 0;
									
									SELECT A.hol_hours INTO this_do_value 
									FROM att_hol_apply_day A 
									WHERE A.emp_id=i_emp AND A.apply_id=apid AND A.hol_date=FREE_BGDT and credit_order=hol_ct;
#select apid,FREE_BGDT,this_do_value,MY_THIS_DECUCTION,ORI_MY_THIS_DECUCTION;
									IF this_do_value > 0 THEN
										IF MY_THIS_DECUCTION - this_do_value < 0 THEN
											SET this_do_value = MY_THIS_DECUCTION;
										END IF;
										
										UPDATE att_hol_apply_day A 
										SET A.free_hours = this_do_value 
										WHERE A.emp_id=i_emp AND A.hol_date = FREE_BGDT AND A.apply_id=apid and credit_order=hol_ct;
										
										SET MY_THIS_DECUCTION = MY_THIS_DECUCTION - this_do_value;
									END IF;
									SET FREE_BGDT = DATE_ADD(FREE_BGDT,INTERVAL 1 DAY);
								END WHILE;
								#再把值转成天
								SET ORI_MY_THIS_DECUCTION = ROUND(ORI_MY_THIS_DECUCTION / FN_ATT_GET_WORKHOURS(MY_ATTID) ,5);
								IF ORI_MY_THIS_DECUCTION <> 0 THEN
									#将本次的修改记录到池子表的修改记录中
									CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,4,2,ORI_MY_THIS_DECUCTION);			
								END IF;
							ELSEIF i_att_rule = 3 THEN
								SET this_do_value = 0;
								SELECT MIN(HOL_DATE),MAX(HOL_DATE) INTO PB_BGDT,PB_EDDT FROM att_hol_apply_day WHERE apply_id=apid and credit_order=hol_ct;
								WHILE PB_BGDT <= PB_EDDT AND PB_BGDT IS NOT NULL DO
#*FLAG 
									SELECT SUM(IF(A.hol_hours IS NULL,0,A.hol_hours)) INTO PB_HOL_HOURS 
									FROM att_hol_apply_day A
									WHERE A.apply_id=apid AND A.hol_date = PB_BGDT AND A.credit_order=hol_ct;
									
									IF PB_HOL_HOURS > 0 THEN
										SET PB_HOL_YEAR_DAY = ROUND(PB_HOL_HOURS/(FN_ATT_GET_ARR_WORKHOURS(i_emp,PB_BGDT)/60),5);				
										SET this_do_value = this_do_value + PB_HOL_YEAR_DAY;
									END IF;
									SET PB_BGDT = DATE_ADD(PB_BGDT,INTERVAL 1 DAY);
								END WHILE;
							
								SET MY_HOL_DAYS = this_do_value;
								
								#计算有剩余
								IF MY_THIS_LEFT_SICK > 0 THEN
									#剩余够扣，扣除量就是 MY_HOL_DAYS - MY_LAST_DECUCTION
									IF MY_THIS_LEFT_SICK - MY_HOL_DAYS >= 0 THEN
										SET MY_THIS_DECUCTION = MY_HOL_DAYS;
										
									#剩余不够扣,扣除量就剩余
									ELSE
										SET MY_THIS_DECUCTION = MY_THIS_LEFT_SICK;
										
									END IF;
									
								#没剩余
								ELSE
									SET MY_THIS_DECUCTION = 0 ;
								END IF;
								
								#本次操作的值就是去年扣除量+今年扣除量
								SET this_do_value = MY_THIS_DECUCTION;
								IF this_do_value <> 0 THEN
									#将本次的修改记录到池子表的修改记录中
									CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,apid,4,2,this_do_value);			
								END IF;
	
								#更新日报表
								#首先按照天数从头计算小时数
								SET this_do_value=0;
								SELECT MIN(HOL_DATE),MAX(HOL_DATE) INTO PB_BGDT,PB_EDDT 
								FROM att_hol_apply_day 
								WHERE apply_id=apid and credit_order=hol_ct;
								
								WHILE PB_BGDT<=PB_EDDT AND MY_THIS_DECUCTION>0 DO
									IF MY_THIS_DECUCTION < 1 THEN
										SET THIS_DECUCTION = MY_THIS_DECUCTION;
										SET THIS_HOUR = THIS_DECUCTION * (FN_ATT_GET_ARR_WORKHOURS(i_emp,PB_BGDT)/60);
										SET MY_THIS_DECUCTION = 0;
									ELSE
										SET THIS_DECUCTION = 1;
										SET THIS_HOUR = THIS_DECUCTION * (FN_ATT_GET_ARR_WORKHOURS(i_emp,PB_BGDT)/60);
										SET MY_THIS_DECUCTION = MY_THIS_DECUCTION - THIS_DECUCTION;
									END IF;
									UPDATE att_hol_apply_day A SET A.free_hours = THIS_HOUR WHERE A.emp_id=i_emp AND A.hol_date = PB_BGDT AND A.apply_id=apid;
									SET PB_BGDT = DATE_ADD(PB_BGDT,INTERVAL 1 DAY);
								END WHILE;
							END IF;
						END IF;
						
						SET hol_ct = hol_ct + 1;
					END WHILE;
				END IF;
			END IF;
			SET ct = ct + 1;
		end while;													#loop2

		set bgdt=date_add(bgdt,interval 1 day);
	end while;														#loop1
	
	SET bgdt = I_BGDT;
	CALL SP_ATT_DAILY_SPECIAL(bgdt,eddt,custid,deptid,emp,depttype);
END;

