create function FN_ATT_GET_RESTDAY_WORK_MINUTE(MY_EMPID bigint unsigned, BGDT date)
  returns decimal(12, 2)
  comment '计算休息日的打卡工时'
  BEGIN
DECLARE IS_OK INT;
DECLARE MY_CHECK_IN,MY_CHECK_OUT DATETIME;
DECLARE MY_WORK_MINUTE DECIMAL(12,2);
	#初始化
	SET MY_WORK_MINUTE = 0;
	#先检验人和日期是否合适
	SELECT COUNT(*) INTO IS_OK
	FROM emp_base_info A 
		LEFT JOIN emp_post B ON A.emp_id=B.emp_id
		LEFT JOIN att_emp_detail C ON A.emp_id=C.emp_id
	WHERE A.emp_id = MY_EMPID AND A.is_delete=0 AND A.emp_state IS NOT NULL 
		AND B.entry_date IS NOT NULL AND B.entry_date <= BGDT AND (B.leave_date IS NULL OR B.leave_date >= BGDT)
		AND C.dt=BGDT AND C.date_type NOT IN (1,6);
	
	IF IS_OK IS NOT NULL AND IS_OK > 0 THEN
		#优先外出加班
		SELECT IFNULL(SUM(IFNULL(A.work_hour,0))*60,0) INTO MY_WORK_MINUTE
		FROM att_over_apply_day A
			LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
		WHERE A.emp_id=MY_EMPID AND A.work_day = BGDT 
			AND B.is_outside_over=1 AND B.state=1;
		#没有外出加班才考虑打卡
		IF MY_WORK_MINUTE = 0 OR MY_WORK_MINUTE IS NULL THEN
			SELECT A.check_in,A.check_out INTO MY_CHECK_IN,MY_CHECK_OUT
			FROM att_emp_detail A
			WHERE A.emp_id=MY_EMPID AND A.dt=BGDT;
			
			IF MY_CHECK_IN IS NOT NULL THEN
				SET MY_WORK_MINUTE = IFNULL(TIME_TO_SEC(TIMEDIFF(MY_CHECK_OUT,MY_CHECK_IN))/60,0);
			ELSE
				SET MY_WORK_MINUTE = 0;
			END IF;
		END IF;
		
	END IF;
RETURN MY_WORK_MINUTE;
END;

