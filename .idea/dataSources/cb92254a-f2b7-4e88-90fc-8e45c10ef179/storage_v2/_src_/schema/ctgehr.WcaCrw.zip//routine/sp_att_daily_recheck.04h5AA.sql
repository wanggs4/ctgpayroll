create procedure SP_ATT_DAILY_RECHECK(IN bgdt date, IN eddt date, IN custid bigint unsigned, IN deptid bigint unsigned,
                                      IN emp  bigint unsigned, IN depttype int)
  comment '每日补签记录'
  BEGIN
#声明变量
DECLARE i_loc_set_id,i_dkj_device_id,i_loc_set_id_2,i_dkj_device_id_2,MY_APPLYID,MY_WCBZCS,i_is_month_period,i_is_full_attendance,i_is_leave_full_attendance,i_position_level_id,ct,mxct,apid,i_custid,i_deptid,i_emp,i_att_id bigint UNSIGNED;
DECLARE ck_osdtms,MY_BOSSLEVEL,MY_ATTGROUPNUMBER,IS_HAVE_OUT_CHECK,IS_HAVE_OUT_RECHECK,i_is_exp_hol,dttype,i_att_rule,stat,chk_type,is_exist,is_off INT;
DECLARE i_loc_set_name,i_loc_set_name_2,workday,i_deptn,i_empn,i_version_code VARCHAR(200);
DECLARE chk_time,ci,co,cosd,AET datetime;
DECLARE i_ck_workhours,lm,em,wki,i_month_period_hour DECIMAL(12,2);
declare i_bgdt,i_entry_date,i_leave_date,THIS_DATE date;
DECLARE MY_APPLYID_STR,ori_ck_ot,Olsn,MY_CKOSD_DETAIL,MY_RE_CKOSD_DETAIL,MY_CKOSD_RMK,MY_RE_CKOSD_RMK TEXT;
DECLARE DTSC1,DTSC2 INT;



 
	set sql_mode='';
	set i_bgdt = bgdt;
	#计算规则 自然日周期 1号到最后一天
	#-------------- 初始化
	/*判断输入的参数
		stat 1 emp		emp is not null 按员工查						
		stat 2 detp		deptid is not null and emp is null 按部门查
		stat 3 custid  custid is not null and deptid is null and emp is null; 按公司查
		stat 4 all		custid is null and deptid is null and emp is null  全局查
	*/

	if (custid is null and deptid is null and depttype is null and emp is null) then
		set stat=4;
	elseif (custid is not null and deptid is null and depttype is null  and emp is null) then
		set stat=3;
	elseif (deptid is not null and depttype between 1 and 10 and emp is null) then
		set stat=2;
	elseif (emp is not null) then
		set stat=1;
	end if;

	
	#第一层循环 按日期
	while (bgdt<=eddt) do 										#loop1					
		#初始化循环变量
		set i_version_code = UUID();
		SET ct = 0;
		SET mxct = 0;
		#得到当天通过的补签                         part 1
		#delete from  tmp_att_check_list WHERE version_code=i_version_code;
		case stat
			when 1 then
				insert into tmp_att_check_list (version_code,APPLY_ID) 
					select distinct i_version_code,a.apply_id  
					from att_check_apply a 
						left join att_set_schema_new c on a.att_id=c.att_id 
					where a.emp_id=emp and c.is_recheck=1  and a.state=1
						  and c.att_rule in (1,2)
						and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
			when 2 then
				CASE depttype 
				WHEN 1 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.dept_id=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 2 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.prgm_id=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 3 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.jrdc_id=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 4 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.dms_id4=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 5 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.dms_id5=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 6 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.dms_id6=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 7 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.dms_id7=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 8 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.dms_id8=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 9 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.dms_id9=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				WHEN 10 THEN
					insert into tmp_att_check_list (version_code,APPLY_ID) 
						select distinct i_version_code,a.apply_id  
						from att_check_apply a 
							left join att_set_schema_new c on a.att_id=c.att_id 
						where a.dms_id10=deptid and c.is_recheck=1  and a.state=1
							and c.att_rule in (1,2) 
							and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
				END CASE;
			when 3 then
				insert into tmp_att_check_list (version_code,APPLY_ID) 
					select distinct i_version_code,a.apply_id  
					from att_check_apply a 
						left join att_set_schema_new c on a.att_id=c.att_id 
					where a.cust_id=custid and c.is_recheck=1  and a.state=1
						and c.att_rule in (1,2) 
						and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
			when 4 then
				insert into tmp_att_check_list (version_code,APPLY_ID) 
					select distinct i_version_code,a.apply_id  
					from att_check_apply a 
						left join att_set_schema_new c on a.att_id=c.att_id 
					where c.is_recheck=1  and a.state=1
						and c.att_rule in (1,2) 
						and a.check_time between concat(bgdt,' 05:00:00') and CONCAT(DATE_ADD(bgdt,INTERVAL 1 DAY),' 04:59:59') and c.is_delete=0;
		end case;													#part 1
		
#SELECT * FROM tmp_att_check_list;
		select min(id),max(id) into ct,mxct from tmp_att_check_list where version_code = i_version_code;

		#第二重循环 遍历当天通过的补签					    loop2
		while (ct<=mxct AND ct>0) do
			#初始化循环变量
			SET apid = NULL,i_custid = NULL,i_deptid = NULL,i_deptn = NULL,i_emp = NULL,i_empn = NULL,chk_time = NULL,chk_type = NULL,i_att_rule = NULL,workday = NULL;
			SET dttype = NULL,is_exist = NULL,lm = NULL, em = NULL,wki = NULL,ci = NULL,co = NULL,cosd = NULL,AET=NULL;
			SET MY_WCBZCS = 0,i_ck_workhours=0;
			#得到申请id
			select apply_id into apid from tmp_att_check_list where id=ct and version_code = i_version_code;
			IF apid IS NOT NULL THEN
				#2读出本次申请的相应信息
				select `cust_id`,`dept_id`,`dept_name`,`emp_id`,`emp_name`,
							check_time,check_type,a.att_rule
					into i_custid,i_deptid,i_deptn,i_emp,i_empn,#申请id,公司id，部门id、名称，员工id、名称，假期id、名称
						 	chk_time,chk_type,i_att_rule				#签到时间，签到类型
				from att_check_apply a where apply_id=apid ;
				
				CALL SP_DPT_GET_SETTINGID(i_emp,bgdt,1,@attid);
				SET i_att_id = cast(@attid as unsigned);
				
				#读出职位id
				select position_level_id,entry_date,leave_date into i_position_level_id,i_entry_date,i_leave_date 
				from emp_post where emp_id=i_emp;
				
				select a.boss_level into MY_BOSSLEVEL from emp_base_info a where a.emp_id=i_emp;
				
					SET THIS_DATE = NULL;
				
				IF time(chk_time) < '05:00:00' THEN
					SET THIS_DATE = DATE_ADD(date(chk_time),INTERVAL -1 DAY);
				ELSE
					SET THIS_DATE = date(chk_time);
				END IF;
				
				select a.is_month_period,a.month_period_hour,a.is_full_attendance,a.is_leave_full_attendance,CONCAT(THIS_DATE,' ',a.aftn_end_time)
					into i_is_month_period,i_month_period_hour,i_is_full_attendance,i_is_leave_full_attendance,AET
				from att_set_schema_new a 
				where a.att_id=i_att_id;	
				
				#得到签到的日期类型
				set dttype=FN_ATT_GET_DTTYPE(THIS_DATE,i_emp);
				
				#出勤规则为坐班时
				IF i_att_rule = 1 THEN
	
					#5首先判断当天的信息是否在打卡日报里存在
					select count(*) into is_exist from  att_emp_detail where emp_id=i_emp and dt=THIS_DATE;
					set lm=0,em=0,wki=0;
					set ci = null,co = null,cosd = null;

					if is_exist >0 then		#如存在，将信息读出来
						#读出当天对应的打卡信息
						select late_mins,early_mins,work_interval,check_in,data_source,check_out,data_source_2,check_osd,
							a.loc_set_id,a.loc_set_name,a.dkj_device_id,a.loc_set_id_2,a.loc_set_name_2,a.dkj_device_id_2
							into lm,em,wki,ci,DTSC1,co,DTSC2,cosd,
							i_loc_set_id,i_loc_set_name,i_dkj_device_id,i_loc_set_id_2,i_loc_set_name_2,i_dkj_device_id_2
							#迟到分钟数、早退分钟数、工作时长、上班打卡、下班打卡、外勤打卡
						from att_emp_detail a
						where emp_id=i_emp and dt=THIS_DATE;
						
						
					else							#不存在，将当天信息写进去
						set lm=0;
						set em=0;
						set wki=0;
						set ci = null;
						set co = null;
						set cosd = null;
						SET DTSC1 = NULL;
						SET DTSC2 = NULL;
						set MY_ATTGROUPNUMBER = FN_ATT_GET_DAILY_GROUP_NUMBER(i_emp,i_att_id,date(chk_time));						
						SET MY_WCBZCS = FN_ATT_GET_DINNER_SUBSIDY_COUNT(THIS_DATE,i_emp);
#SELECT 1;						
						insert into att_emp_detail (WCBZCS,should_work_interval,emp_code,att_group_number,att_id,att_rule,position_level_id,cust_id,dept_id,prgm_id,jrdc_id,dms_id4,dms_id5,dms_id6,dms_id7,dms_id8,dms_id9,dms_id10,emp_id,dt,emp_name,
															`weekday`,date_type,work_interval,
															late_mins,early_mins,partition_code)
											select MY_WCBZCS,FN_ATT_GET_WORKHOURS(i_att_id)*60,b.emp_code,MY_ATTGROUPNUMBER,i_att_id,i_att_rule,i_position_level_id,i_custid,i_deptid,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,i_emp,date(chk_time),i_empn,
															weekday(date(chk_time))+1,dttype,wki, 
															0,0,md5(concat(i_emp,date(chk_time)))
											from emp_base_info a left join emp_post b on a.emp_id=b.emp_id where a.emp_id=i_emp;
					end if;					

					#6 补签类型 （1上班  2下班  3外勤）
					IF chk_type IN (1,2) THEN
						SELECT COUNT(*) INTO IS_HAVE_OUT_CHECK FROM att_emp_log A WHERE A.emp_id=i_emp and check_time between concat(date(chk_time),' 05:00:00') and concat(DATE_ADD(date(chk_time),INTERVAL 1 DAY),' 04:59:59') AND A.check_type=3;
						SELECT COUNT(*) INTO IS_HAVE_OUT_RECHECK FROM att_check_apply A WHERE A.emp_id=i_emp and check_time between concat(date(chk_time),' 05:00:00') and concat(DATE_ADD(date(chk_time),INTERVAL 1 DAY),' 04:59:59') AND A.check_type=3;
						IF IS_HAVE_OUT_CHECK IS NULL THEN SET IS_HAVE_OUT_CHECK = 0; END IF;
						IF IS_HAVE_OUT_RECHECK IS NULL THEN SET IS_HAVE_OUT_RECHECK = 0; END IF;
				
						#打卡无外勤
						IF IS_HAVE_OUT_CHECK + IS_HAVE_OUT_RECHECK = 0 THEN
							#计算工作日和节假日不生效的情况
							IF dttype in (1,6) THEN
								#当补签时间比日报签到早，或者日报签到为空，该值被补签值取代。
								IF (chk_time <= ci and ci is not null) or ci is null then
									SET ci = chk_time;
									SET DTSC1 = 14;
									SET i_loc_set_id=NULL,i_loc_set_name=NULL,i_dkj_device_id=NULL;
								END IF;
								#当补签时间比日报签退晚，或者日报签退为空，该值被补签值取代。
								IF (chk_time >= co and co is not null) or co is null then
									SET co = chk_time;
									SET DTSC2 = 14;
									SET i_loc_set_id_2=NULL,i_loc_set_name_2=NULL,i_dkj_device_id_2=NULL;
								END IF;
								
								#只有当补签的时间成功替换了日报原有时间时才进行计算和更新
								IF ci=chk_time OR co=chk_time THEN
									#--计算迟到早退
									CALL FN_ATT_GET_MINS_FIXED_NA(ci,co,i_att_id,lm,em);
#select ci,co,i_att_id,lm,em;					
									#--计算工作时长
									IF i_month_period_hour > 0 THEN
										SET wki = FN_ATT_GET_MINUNIT_MINS_FLOOR(FN_ATT_GET_REAL_DAY_HOURS_WITH_ATTID(ci,co,i_att_id),i_att_id);
									ELSE
										set wki = FN_ATT_GET_WORKHOURS(i_att_id)*60 - lm - em;
									END IF;

									#--旷工
									set is_off = FN_ATT_GET_DAYOFF_STATUS(lm,em,i_att_id) ;

									SET i_ck_workhours = FN_ATT_GET_CHECK_WORK_HOURS(ci,co,i_att_id,i_emp);

									IF MY_BOSSLEVEL IN (2,3) AND MY_BOSSLEVEL IS NOT NULL THEN
										SET lm=0,em=0,is_off=0,wki=FN_ATT_GET_WORKHOURS(i_att_id)*60;
										SET i_ck_workhours = wki;
									END IF;
									
									#入离职全勤控制
									IF (i_is_full_attendance = 1 AND bgdt = i_entry_date) or (i_is_leave_full_attendance = 1 AND bgdt = i_leave_date ) THEN
						 				SET lm=0,em=0,is_off=0,wki=FN_ATT_GET_WORKHOURS(i_att_id)*60;
										SET i_ck_workhours = wki;
									END IF;
									SET MY_WCBZCS = FN_ATT_GET_DINNER_SUBSIDY_COUNT(THIS_DATE,i_emp);

#SELECT 2,THIS_DATE,MY_BOSSLEVEL,i_ck_workhours,ci,co,lm,em,wki,is_off,MY_WCBZCS,i_is_month_period,i_month_period_hour;

									update att_emp_detail a
									set a.check_work_interval=i_ck_workhours,check_in=ci,a.data_source=DTSC1,check_out=co,a.data_source_2=DTSC2,
										late_mins=lm,early_mins=em,work_interval=wki,is_dayoff=is_off,wcbzcs=MY_WCBZCS,
										a.loc_set_id=i_loc_set_id,a.loc_set_name=i_loc_set_name,a.dkj_device_id=i_dkj_device_id,
										a.loc_set_id_2=i_loc_set_id_2,a.loc_set_name_2=i_loc_set_name_2,a.dkj_device_id_2=i_dkj_device_id_2
									where emp_id=i_emp and dt=THIS_DATE;
								END IF;
							#非工作日
							ELSE
								#当补签时间比日报签到早，或者日报签到为空，该值被补签值取代。
								IF (chk_time <= ci and ci is not null) or ci is null then
									SET ci = chk_time;
									SET DTSC1 = 14;
									SET i_loc_set_id=NULL,i_loc_set_name=NULL,i_dkj_device_id=NULL;
								END IF;
								#当补签时间比日报签退晚，或者日报签退为空，该值被补签值取代。
								IF (chk_time >= co and co is not null) or co is null then
									SET co = chk_time;
									SET DTSC2 = 14;
									SET i_loc_set_id_2=NULL,i_loc_set_name_2=NULL,i_dkj_device_id_2=NULL;
								END IF;
								
								#只有当补签的时间成功替换了日报原有时间时才进行计算和更新
								IF ci=chk_time OR co=chk_time THEN
									#--迟到、早退、工时、旷工 都为0			
									set lm = 0;
									set em = 0;
									set wki = 0;
									set is_off = 0;
									
									
									SET MY_WCBZCS = FN_ATT_GET_DINNER_SUBSIDY_COUNT(THIS_DATE,i_emp);
#SELECT 3;
									
									SET i_ck_workhours = FN_ATT_GET_CHECK_WORK_HOURS(ci,co,i_att_id,i_emp);
									update att_emp_detail a
									set a.check_work_interval=i_ck_workhours,check_in=ci,a.data_source=DTSC1,check_out=co,a.data_source_2=DTSC2,late_mins=lm,early_mins=em,work_interval=wki,is_dayoff=is_off,WCBZCS=MY_WCBZCS,
									a.loc_set_id=i_loc_set_id,a.loc_set_name=i_loc_set_name,a.dkj_device_id=i_dkj_device_id,
									a.loc_set_id_2=i_loc_set_id_2,a.loc_set_name_2=i_loc_set_name_2,a.dkj_device_id_2=i_dkj_device_id_2
									where emp_id=i_emp and dt=THIS_DATE;	
								END IF;
							END IF;
						#打卡有外勤
						ELSE
							#当补签时间比日报签到早，或者日报签到为空，该值被补签值取代。
							IF (chk_time <= ci and ci is not null) or ci is null then
								SET ci = chk_time;
								SET DTSC1 = 14;
								SET i_loc_set_id=NULL,i_loc_set_name=NULL,i_dkj_device_id=NULL;
							END IF;
							#当补签时间比日报签退晚，或者日报签退为空，该值被补签值取代。
							IF (chk_time >= co and co is not null) or co is null then
								SET co = chk_time;
								SET DTSC2 = 14;
								SET i_loc_set_id_2=NULL,i_loc_set_name_2=NULL,i_dkj_device_id_2=NULL;
							END IF;
							#--迟到、早退、工时、旷工 都为0			
							set lm = 0;
							set em = 0;
							set is_off = 0;
							IF dttype IN (1,6) THEN
								set wki = FN_ATT_GET_WORKHOURS(i_att_id)*60;
							ELSE
								SET wki = 0;
							END IF;
							SET MY_WCBZCS = FN_ATT_GET_DINNER_SUBSIDY_COUNT(THIS_DATE,i_emp);
							
#select 4;
							SET i_ck_workhours = FN_ATT_GET_CHECK_WORK_HOURS(ci,co,i_att_id,i_emp);
							update att_emp_detail a
							set a.check_work_interval=i_ck_workhours,check_in=ci,a.data_source=DTSC1,check_out=co,a.data_source_2=DTSC2,late_mins=lm,early_mins=em,work_interval=wki,is_dayoff=is_off,WCBZCS=MY_WCBZCS,
								a.loc_set_id=i_loc_set_id,a.loc_set_name=i_loc_set_name,a.dkj_device_id=i_dkj_device_id,
								a.loc_set_id_2=i_loc_set_id_2,a.loc_set_name_2=i_loc_set_name_2,a.dkj_device_id_2=i_dkj_device_id_2
							where emp_id=i_emp and dt=THIS_DATE;	
						END IF;
					ELSEIF chk_type = 3 then	#外勤
						#--计算迟到早退
						SET lm = 0;
						SET em = 0;
						
						#--计算工时
						IF dttype in (1,6)  THEN
							SET wki = FN_ATT_GET_WORKHOURS(i_att_id);
						ELSE
							SET wki = 0;
						END IF;
						
						#--计算旷工
						SET is_off = 0;
						
						set ck_osdtms=0;
						#计算打卡和补签的外勤打卡次数
						SELECT IF(COUNT(*) IS NULL,0,COUNT(*)) INTO ck_osdtms from att_emp_log where check_time between concat(date(chk_time),' 05:00:00') and concat(DATE_ADD(date(chk_time),INTERVAL 1 DAY),' 04:59:59') and emp_id=i_emp and  check_type =3;
						SELECT IF(COUNT(*) IS NULL,0,COUNT(*)) + ck_osdtms INTO ck_osdtms FROM att_check_apply A WHERE check_time between concat(date(chk_time),' 05:00:00') and concat(DATE_ADD(date(chk_time),INTERVAL 1 DAY),' 04:59:59') and emp_id=i_emp and  check_type =3 AND STATE=1;

#select 5;
						SET Olsn=NULL,ori_ck_ot=NULL,MY_CKOSD_RMK=NULL,MY_RE_CKOSD_RMK=NULL,MY_CKOSD_DETAIL=NULL,MY_RE_CKOSD_DETAIL=NULL;
						#外勤明细
						SELECT GROUP_CONCAT(IFNULL(A.check_time,''),'/',IFNULL(A.check_add,'')) INTO MY_CKOSD_DETAIL FROM att_emp_log A WHERE A.check_time between concat(date(chk_time),' 05:00:00') and concat(DATE_ADD(date(chk_time),INTERVAL 1 DAY),' 04:59:59') and A.emp_id=i_emp and  A.check_type =3;
						SELECT GROUP_CONCAT(IFNULL(A.check_time,''),'/补签') INTO MY_RE_CKOSD_DETAIL FROM att_check_apply A WHERE A.emp_id=i_emp AND A.check_time between concat(date(chk_time),' 05:00:00') and concat(DATE_ADD(date(chk_time),INTERVAL 1 DAY),' 04:59:59') AND A.check_type=3 AND A.state=1 GROUP BY A.emp_id;
						IF MY_CKOSD_DETAIL IS NULL AND MY_RE_CKOSD_DETAIL IS NULL THEN
							SET ori_ck_ot = NULL;
						ELSEIF MY_CKOSD_DETAIL IS NOT NULL AND MY_RE_CKOSD_DETAIL IS NULL THEN 
							SET ori_ck_ot = MY_CKOSD_DETAIL;
						ELSEIF MY_CKOSD_DETAIL IS NULL AND MY_RE_CKOSD_DETAIL IS NOT NULL THEN 
							SET ori_ck_ot = MY_RE_CKOSD_DETAIL;
						ELSEIF MY_CKOSD_DETAIL IS NOT NULL AND MY_RE_CKOSD_DETAIL IS NOT NULL THEN 
							SET ori_ck_ot = CONCAT(MY_CKOSD_DETAIL,',',MY_RE_CKOSD_DETAIL);
						END IF;
						#外勤备注
						SELECT GROUP_CONCAT(IFNULL(A.remark,'')) INTO MY_CKOSD_RMK FROM att_emp_log A WHERE A.check_time between concat(date(chk_time),' 05:00:00') and concat(DATE_ADD(date(chk_time),INTERVAL 1 DAY),' 04:59:59') and A.emp_id=i_emp and  A.check_type =3;
						SELECT GROUP_CONCAT(IFNULL(A.remark,'')) INTO MY_RE_CKOSD_RMK FROM att_check_apply A WHERE A.check_time between concat(date(chk_time),' 05:00:00') and concat(DATE_ADD(date(chk_time),INTERVAL 1 DAY),' 04:59:59') and A.emp_id=i_emp and  A.check_type =3 AND state=1;
						IF MY_CKOSD_RMK IS NULL AND MY_RE_CKOSD_RMK IS NULL THEN
							SET Olsn = NULL;
						ELSEIF MY_CKOSD_RMK IS NOT NULL AND MY_RE_CKOSD_RMK IS NULL THEN 
							SET Olsn = MY_CKOSD_RMK;
						ELSEIF MY_CKOSD_RMK IS NULL AND MY_RE_CKOSD_RMK IS NOT NULL THEN 
							SET Olsn = MY_RE_CKOSD_RMK;
						ELSEIF MY_CKOSD_RMK IS NOT NULL AND MY_RE_CKOSD_RMK IS NOT NULL THEN 
							SET Olsn = CONCAT(MY_CKOSD_RMK,',',MY_RE_CKOSD_RMK);
						END IF;
						
	
						SET MY_WCBZCS = FN_ATT_GET_DINNER_SUBSIDY_COUNT(THIS_DATE,i_emp);
						SET i_ck_workhours = FN_ATT_GET_CHECK_WORK_HOURS(ci,co,i_att_id,i_emp);
						
						update att_emp_detail A
						set A.check_work_interval=i_ck_workhours,A.check_osd_times=ck_osdtms,check_osd=chk_time,A.check_osd_detail=ori_ck_ot,A.check_osd_remark=Olsn,late_mins=lm,early_mins=em,work_interval=wki,is_dayoff=is_off,WCBZCS=MY_WCBZCS
						where emp_id=i_emp and dt=THIS_DATE;	
			
					END IF;	
				END IF;
				CALL SP_ATT_DAILY_OVER(bgdt,bgdt,NULL,NULL,i_emp,NULL);
				CALL SP_ATT_DAILY_OVER_WITH_REST(bgdt,bgdt,NULL,i_emp);
#select bgdt,i_emp;
				DELETE FROM tmp_att_check_list WHERE ID=ct;
			END IF;
			
			set ct=ct+1;
		end while;													#loop2
		
		set bgdt=date_add(bgdt,INTERVAL 1 day);
	end while;														#loop1
	
	
	#delete from  tmp_att_check_list where version_code = i_version_code;
	
END;

