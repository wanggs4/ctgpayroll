create procedure SP_ICSS_ST_WEEKEND_WORK_DETAIL(IN MONTH_VERSION int)
  comment '月周末出勤时长超N小时人员明细报表'
  BEGIN
DECLARE IS_ARCH INT;
DECLARE MY_STID,CT,MXCT,MY_EMPID BIGINT UNSIGNED;
DECLARE ARCH_DAY,LAST_ARCH_DAY,LAST2_ARCH_DAY,THIS_BGDT,THIS_EDDT,LAST_BGDT,LAST_EDDT,LAST2_BGDT,LAST2_EDDT DATE;
DECLARE THIS_WKD_WKMS,LAST_WKD_WKMS,LAST2_WKD_WKMS DECIMAL(12,2);

	IF MONTH_VERSION IS NOT NULL THEN
		SELECT A.archive_state,A.st_id,A.comp_start_time,A.comp_start_time,A.comp_end_time INTO IS_ARCH,MY_STID,ARCH_DAY,THIS_BGDT,THIS_EDDT
		FROM att_st_month A 
		WHERE A.`version` = MONTH_VERSION AND A.cust_id=2162554862743552;
	ELSE
		SET ARCH_DAY = DATE_ADD(DATE(NOW()),INTERVAL -1 MONTH);
		SELECT A.archive_state,A.st_id,A.comp_start_time,A.comp_end_time INTO IS_ARCH,MY_STID,THIS_BGDT,THIS_EDDT
		FROM att_st_month A 
		WHERE A.comp_start_time <= ARCH_DAY AND A.comp_end_time >= ARCH_DAY AND A.cust_id=2162554862743552;
	END IF;	
	
	
	IF IS_ARCH = 1 AND IS_ARCH IS NOT NULL THEN		
		REPLACE INTO icss_st_3months_weekend_work_detail (emp_id,year_mon,emp_code,emp_name,ownership_place,dept_full_name,dept_id,admin_place_id)
			SELECT A.emp_id,MONTH_VERSION,A.emp_code,A.emp_name,A.ownership_place,A.dept_full_name,A.dept_id,A.dms_id5
			FROM att_st_month_quick_view_icss A
			WHERE A.st_id=MY_STID;	
		
		TRUNCATE TABLE tmp_icss_st_extra_emplist ;
		INSERT INTO tmp_icss_st_extra_emplist (emp_id)
			SELECT DISTINCT A.emp_id FROM icss_st_3months_weekend_work_detail A WHERE A.year_mon=MONTH_VERSION;
		
		SET CT = 0, MXCT = 0;
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_icss_st_extra_emplist;
		WHILE CT <= MXCT AND CT > 0 DO
			SET MY_EMPID = NULL, THIS_WKD_WKMS = 0;
			SELECT EMP_ID INTO MY_EMPID FROM tmp_icss_st_extra_emplist A WHERE A.ID = CT;
			
			SELECT SUM(FN_ATT_GET_RESTDAY_WORK_MINUTE(A.emp_id,A.dt)) INTO THIS_WKD_WKMS
			FROM att_emp_detail A
			WHERE A.emp_id=MY_EMPID AND A.dt BETWEEN LAST_BGDT AND LAST_EDDT AND A.date_type NOT IN (1,6);
			
			UPDATE icss_st_3months_weekend_work_detail A 
			SET A.this_weekend_work_mins = IFNULL(THIS_WKD_WKMS,0)
			WHERE A.emp_id=MY_EMPID AND A.year_mon=MONTH_VERSION;
			
			SET CT = CT + 1;
		END WHILE;
		
		
		SET LAST_ARCH_DAY = DATE_ADD(ARCH_DAY,INTERVAL -1 MONTH);
		SELECT A.comp_start_time,A.comp_end_time INTO LAST_BGDT,LAST_EDDT
		FROM att_st_month A 
		WHERE A.comp_start_time <= LAST_ARCH_DAY AND A.comp_end_time >= LAST_ARCH_DAY AND A.cust_id=2162554862743552;
		
		SET CT = 0, MXCT = 0;
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_icss_st_extra_emplist;
		WHILE CT <= MXCT AND CT > 0 DO
			SET MY_EMPID = NULL, LAST_WKD_WKMS = 0;
			SELECT EMP_ID INTO MY_EMPID FROM tmp_icss_st_extra_emplist A WHERE A.ID = CT;
			
			SELECT SUM(FN_ATT_GET_RESTDAY_WORK_MINUTE(A.emp_id,A.dt)) INTO LAST_WKD_WKMS
			FROM att_emp_detail A
			WHERE A.emp_id=MY_EMPID AND A.dt BETWEEN LAST_BGDT AND LAST_EDDT AND A.date_type NOT IN (1,6);
			
			UPDATE icss_st_3months_weekend_work_detail A 
			SET A.last_weekend_work_mins = IFNULL(LAST_WKD_WKMS,0)
			WHERE A.emp_id=MY_EMPID AND A.year_mon=MONTH_VERSION;
			
			SET CT = CT + 1;
		END WHILE;
		
		
		SET LAST2_ARCH_DAY = DATE_ADD(LAST_ARCH_DAY,INTERVAL -1 MONTH);
		SELECT A.comp_start_time,A.comp_end_time INTO LAST2_BGDT,LAST2_EDDT
		FROM att_st_month A 
		WHERE A.comp_start_time <= LAST2_ARCH_DAY AND A.comp_end_time >= LAST2_ARCH_DAY AND A.cust_id=2162554862743552;
		
		SET CT = 0, MXCT = 0;
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_icss_st_extra_emplist;
		WHILE CT <= MXCT AND CT > 0 DO
			SET MY_EMPID = NULL, LAST2_WKD_WKMS = 0;
			SELECT EMP_ID INTO MY_EMPID FROM tmp_icss_st_extra_emplist A WHERE A.ID = CT;
			
			SELECT SUM(FN_ATT_GET_RESTDAY_WORK_MINUTE(A.emp_id,A.dt)) INTO THIS_WKD_WKMS
			FROM att_emp_detail A
			WHERE A.emp_id=MY_EMPID AND A.dt BETWEEN LAST2_BGDT AND LAST2_EDDT AND A.date_type NOT IN (1,6);
			
			UPDATE icss_st_3months_weekend_work_detail A 
			SET A.last_2_weekend_work_mins = IFNULL(LAST2_WKD_WKMS,0)
			WHERE A.emp_id=MY_EMPID AND A.year_mon=MONTH_VERSION;
			
			SET CT = CT + 1;
		END WHILE;
		
		DELETE A.* FROM icss_st_3months_weekend_work_detail A WHERE A.this_weekend_work_mins = 0 OR A.this_weekend_work_mins IS NULL;
	END IF;
END;

