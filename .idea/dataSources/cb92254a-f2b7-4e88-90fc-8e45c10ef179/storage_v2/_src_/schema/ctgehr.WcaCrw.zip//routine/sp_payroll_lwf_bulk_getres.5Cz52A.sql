create procedure SP_PAYROLL_LWF_BULK_GETRES(IN custid bigint unsigned, IN ym int, IN setid bigint unsigned)
  comment '批量计算劳务费结果'
  BEGIN

DECLARE AFT_TOL_NUM,LWF_SC,BTA,BTS,ATA,ATS,TIA,TIS,AT2BTP,AT2BTNP,TMA,TMS,H_LWF_YNSE, H_LWF_S,H_LWF_ZS,N_LWF_ZS,N_LWF_KCS,N_LWF_BL,N_LWF_SSKCS,N_LWF_YNSE,N_LWF_S,N_LWF_TAX_CPAY_SUM_NOPAY,N_LWF_TAX_CPAY_SUM_PAY,N_LWF_TAX_CPAY_SUM,N_LWF_TAX_EPAY_SUM,N_LWF_AFT_TAX_NOPAY_SUM,N_LWF_AFT_TAX_PAY_SUM,N_LWF_SF DECIMAL(13,3);
DECLARE ct,mxct,sumb_rescnt,TOLCNT int;
DECLARE prid,i_custid,i_deptid,i_emp bigint;
DECLARE i_deptname,i_empname varchar(50);
DECLARE S_GZ_SF,S_LWF_SF,S_LZF_SF,S_NZJ_SF DECIMAL(13,3);
 DECLARE i_version_code VARCHAR(50);
 SET i_version_code = UUID();
	set sumb_rescnt=0;
	

		
		select count(*) into sumb_rescnt from payroll_lwf_base where cust_id=custid and MONTH_STEP=ym and set_id=setid and is_publish=0 ;

	
	if sumb_rescnt>0 then
	
		INSERT INTO tmp_payroll_lwf_sum (version_code,payroll_id,cust_id,dept_id,dept_name,emp_id,emp_name,month_step,LWF_BTA,LWF_BTS,LWF_ATA,LWF_ATS,LWF_TIA,LWF_TIS,LWF_AT2BTP,LWF_AT2BTNP,LWF_TMA,LWF_TMS) 
			select i_version_code,id,cust_id,dept_id,dept_name,emp_id,emp_name,month_step,
			sum(BTA1+BTA2+BTA3+BTA4+BTA5+BTA6+BTA7+BTA8+BTA9+BTA10+BTA11+BTA12+BTA13+BTA14+BTA15+BTA16+BTA17+BTA18+BTA19+BTA20+BTA21+BTA22+BTA23+BTA24+BTA25+BTA26+BTA27+BTA28+BTA29+BTA30) BTA,
			sum(BTS1+BTS2+BTS3+BTS4+BTS5+BTS6+BTS7+BTS8+BTS9+BTS10+BTS11+BTS12+BTS13+BTS14+BTS15+BTS16+BTS17+BTS18+BTS19+BTS20+BTS21+BTS22+BTS23+BTS24+BTS25+BTS26+BTS27+BTS28+BTS29+BTS30) BTS,
			sum(ATA1+ATA2+ATA3+ATA4+ATA5+ATA6+ATA7+ATA8+ATA9+ATA10+ATA11+ATA12+ATA13+ATA14+ATA15+ATA16+ATA17+ATA18+ATA19+ATA20+ATA21+ATA22+ATA23+ATA24+ATA25+ATA26+ATA27+ATA28+ATA29+ATA30+ATA31+ATA32+ATA33+ATA34+ATA35+ATA36+ATA37+ATA38+ATA39+ATA40+ATA41+ATA42+ATA43+ATA44+ATA45+ATA46+ATA47+ATA48+ATA49+ATA50) ATA,
			sum(ATS1+ATS2+ATS3+ATS4+ATS5+ATS6+ATS7+ATS8+ATS9+ATS10+ATS11+ATS12+ATS13+ATS14+ATS15+ATS16+ATS17+ATS18+ATS19+ATS20+ATS21+ATS22+ATS23+ATS24+ATS25+ATS26+ATS27+ATS28+ATS29+ATS30+ATS31+ATS32+ATS33+ATS34+ATS35+ATS36+ATS37+ATS38+ATS39+ATS40+ATS41+ATS42+ATS43+ATS44+ATS45+ATS46+ATS47+ATS48+ATS49+ATS50) ATS,
			sum(tia1+tia2+tia3+tia4+tia5) tia,
			sum(TIS1+TIS2+TIS3+TIS4+TIS5) TIS,
			sum(AT2BTP1+AT2BTP2+AT2BTP3+AT2BTP4+AT2BTP5+AT2BTP6+AT2BTP7+AT2BTP8+AT2BTP9+AT2BTP10) AT2BTP,
			sum(AT2BTNP1+AT2BTNP2+AT2BTNP3+AT2BTNP4+AT2BTNP5+AT2BTNP6+AT2BTNP7+AT2BTNP8+AT2BTNP9+AT2BTNP10) AT2BTNP,
			sum(TMA1+TMA2+TMA3+TMA4+TMA5) TMA,
			sum(TMS1+TMS2+TMS3+TMS4+TMS5) TMS
			from payroll_lwf_base where cust_id=custid and MONTH_STEP=ym and set_id=setid and is_publish=0 
			group by emp_id;
			
		
		select count(*) into sumb_rescnt from tmp_payroll_lwf_sum  where version_code = i_version_code;
		if sumb_rescnt>0 then
			select min(id),max(id) into ct,mxct from tmp_payroll_lwf_sum  where version_code = i_version_code;
			while (ct<=mxct) do
				SET prid=NULL;
				SET i_custid=NULL;
				SET i_deptid=NULL;
				SET i_deptname=NULL;
				SET i_emp=NULL;
				SET i_empname=NULL;
				SET BTA=NULL;
				SET BTS=NULL;
				SET ATA=NULL;
				SET ATS=NULL;
				SET TIA=NULL;
				SET TIS=NULL;
				SET AT2BTP=NULL;
				SET AT2BTNP=NULL;
				SET TMA=NULL;
				SET TMS=NULL;
				
				select payroll_id,cust_id,dept_id,dept_name,emp_id,emp_name,LWF_BTA,LWF_BTS,LWF_ATA,LWF_ATS,LWF_TIA,LWF_TIS,LWF_AT2BTP,LWF_AT2BTNP,LWF_TMA,LWF_TMS
					into prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,BTA,BTS,ATA,ATS,TIA,TIS,AT2BTP,AT2BTNP,TMA,TMS
				from tmp_payroll_lwf_sum where id=ct and version_code = i_version_code;
				
				IF prid IS NOT NULL THEN
				
					select SUM(IF(LWF_YNSE IS NULL,0,LWF_YNSE)),
							 SUM(IF(LWF_S IS NULL,0,LWF_S)), 
							 SUM(IF(LWF_ZS IS NULL,0,LWF_ZS))
					  into H_LWF_YNSE, H_LWF_S,H_LWF_ZS
					from payroll_lwf where EMP_ID = i_emp and month_step=ym and IS_PUBLISH = 1 and set_id <> setid;
					IF H_LWF_YNSE IS NULL THEN SET H_LWF_YNSE = 0; END IF;
					IF H_LWF_S IS NULL THEN SET H_LWF_S = 0; END IF;
					IF H_LWF_ZS IS NULL THEN SET H_LWF_ZS = 0; END IF;
					
	
					
					
					SET N_LWF_ZS = BTA -BTS; 
					CALL SP_PAYROLL_LWF_TAX(N_LWF_ZS + H_LWF_ZS,N_LWF_BL,N_LWF_SSKCS,N_LWF_YNSE);
	
					
					SET N_LWF_YNSE = N_LWF_YNSE + TIA - TIS; 
					SET N_LWF_S = N_LWF_YNSE * N_LWF_BL - N_LWF_SSKCS;
					
					
					SET N_LWF_AFT_TAX_PAY_SUM = AT2BTP; 
					
					SET N_LWF_AFT_TAX_NOPAY_SUM = AT2BTNP;
					SET N_LWF_TAX_EPAY_SUM = N_LWF_S;
					
					if (AT2BTP + AT2BTNP) > 0 then
						CALL SP_PAYROLL_LWF_TAX_BACK(N_LWF_ZS - N_LWF_S + AT2BTP,   	
					                        			N_LWF_BL,   							
					                        			N_LWF_SSKCS,  							
					                        			N_LWF_YNSE);
	
					  	SET LWF_SC = N_LWF_YNSE * N_LWF_BL - N_LWF_SSKCS;
					  	SET N_LWF_TAX_CPAY_SUM = LWF_SC - N_LWF_S; 
					
					  	CALL SP_PAYROLL_LWF_TAX_BACK(AFT_TOL_NUM,   
					                             	  N_LWF_BL,   
					                                N_LWF_SSKCS,  
					                                N_LWF_YNSE);
	
					
					   SET LWF_SC = N_LWF_YNSE * N_LWF_BL - N_LWF_SSKCS;
					   SET N_LWF_TAX_CPAY_SUM_NOPAY = LWF_SC - N_LWF_S - N_LWF_TAX_CPAY_SUM; 
					   SET N_LWF_S = LWF_SC;
					
					else
					   SET N_LWF_TAX_CPAY_SUM = 0 ;
					   SET N_LWF_TAX_CPAY_SUM_NOPAY = 0 ;	
					end if;
	
					SET N_LWF_S = N_LWF_S - H_LWF_S;
					
					SET N_LWF_SF = N_LWF_ZS - N_LWF_S + N_LWF_TAX_CPAY_SUM + N_LWF_TAX_CPAY_SUM_NOPAY + AT2BTP + ATA - ATS; 
	         	SET N_LWF_YNSE = N_LWF_YNSE - H_LWF_YNSE;
					
						
					IF N_LWF_ZS IS NULL THEN SET N_LWF_ZS=0; END IF;
					IF N_LWF_S IS NULL THEN SET N_LWF_S=0; END IF;
					IF N_LWF_SF  IS NULL THEN SET N_LWF_SF=0; END IF;
		
					SET N_LWF_KCS = 0;
					SET N_LWF_TAX_CPAY_SUM_PAY = 0;
					
					DELETE FROM payroll_lwf WHERE ID = prid;
					INSERT INTO payroll_lwf (`ID`,`CUST_ID`,`DEPT_ID`,`DEPT_NAME`,`EMP_ID`,`EMP_NAME`,`set_id`,`MONTH_STEP`,`IS_PUBLISH`,
														LWF_ZS,LWF_KCS,LWF_BL,LWF_SSKCS,LWF_YNSE,LWF_S,LWF_TAX_CPAY_SUM_NOPAY,
														LWF_TAX_CPAY_SUM_PAY,LWF_TAX_CPAY_SUM,LWF_TAX_EPAY_SUM,
														LWF_AFT_TAX_NOPAY_SUM,LWF_AFT_TAX_PAY_SUM,LWF_SF)
										  VALUES (prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,setid,ym,0,
														N_LWF_ZS,N_LWF_KCS,N_LWF_BL,N_LWF_SSKCS,N_LWF_YNSE,N_LWF_S,N_LWF_TAX_CPAY_SUM_NOPAY,
														N_LWF_TAX_CPAY_SUM_PAY,N_LWF_TAX_CPAY_SUM,N_LWF_TAX_EPAY_SUM,
														N_LWF_AFT_TAX_NOPAY_SUM,N_LWF_AFT_TAX_PAY_SUM,N_LWF_SF);
					
					UPDATE payroll_lwf_base set is_calc=1 where id = prid;
					
					UPDATE payroll_tol 
					SET TAX_BEF_PLUSMIN_TOL=TAX_BEF_PLUSMIN_TOL+N_LWF_ZS,
						TAX_VALUE=TAX_VALUE+N_LWF_S,
						SALARY_PAY=SALARY_PAY+N_LWF_SF 
					WHERE ID=prid;
				END IF;
			SET ct = ct + 1;
	      end while;
		end if;

		
	end if;	
	
	delete from tmp_payroll_lwf_sum where version_code = i_version_code;
	
END;

