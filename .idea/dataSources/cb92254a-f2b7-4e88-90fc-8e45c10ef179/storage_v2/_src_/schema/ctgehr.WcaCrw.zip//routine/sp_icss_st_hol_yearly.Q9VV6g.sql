create procedure SP_ICSS_ST_HOL_YEARLY(IN MY_BGDT date, IN MY_EMP bigint unsigned)
  comment '各类假期年度汇总明细'
  BEGIN
DECLARE CT,MXCT,MY_EMP_ID,MY_DEPT_ID BIGINT UNSIGNED;
DECLARE MY_DEPT_FULL_NAME,MY_EMP_CODE,MY_EMP_NAME,I_VERSION_CODE VARCHAR(500);
DECLARE MY_ENTRY_DATE,MY_LEAVE_DATE,MY_EDDT DATE;
DECLARE MY_THIS_YEAR INT;
/*
入参说明：
MY_BGDT 入组人员在职时间范围和计算的时间范围的开始日期，NULL时取前天这一年的一月一日
MY_EMP 人员id，只为重跑某个人时使用，平时给NULL既跑所有
所有时间范围结束日期均为前天
*/
	
	SET I_VERSION_CODE = UUID();
	#结束日期只能为上月最后一天
	SET MY_EDDT = DATE_ADD(CONCAT(LEFT(DATE(NOW()),8),'01'),INTERVAL -1 DAY);
	SET MY_THIS_YEAR = YEAR(MY_EDDT);
	
	#入参MY_BGDT 校验
	#1.如果为空，设为前天的同年一月一日
	IF MY_BGDT IS NULL THEN
		SET MY_BGDT = CONCAT(MY_THIS_YEAR,'-01-01');
	ELSE
		IF YEAR(MY_BGDT) <> MY_THIS_YEAR THEN
			SET MY_BGDT = CONCAT(MY_THIS_YEAR,'-01-01');
		END IF;
	END IF;
	
	IF MY_EMP IS NULL THEN
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT);			
	
		REPLACE INTO icss_st_hol_yearly (emp_id,this_year,hol_id,hol_name)
			SELECT DISTINCT A.emp_id,MY_THIS_YEAR,A.hol_id,IFNULL(B.hol_name,'')
 			FROM icss_st_hol_detail A 
				LEFT JOIN att_set_holiday_main B ON A.hol_id=B.hol_id
			WHERE A.this_year_mon BETWEEN CONCAT(MY_THIS_YEAR,'01') AND CONCAT(MY_THIS_YEAR,'01') AND A.hol_id<>1;
	ELSE
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT)
				AND A.EMP_ID=MY_EMP;			
	
		REPLACE INTO icss_st_hol_yearly (emp_id,this_year,hol_id,hol_name)
			SELECT DISTINCT A.emp_id,MY_THIS_YEAR,A.hol_id,IFNULL(B.hol_name,'')
			FROM icss_st_hol_detail A 
				LEFT JOIN att_set_holiday_main B ON A.hol_id=B.hol_id
			WHERE A.this_year_mon BETWEEN CONCAT(MY_THIS_YEAR,'01') AND CONCAT(MY_THIS_YEAR,'01') AND A.hol_id<>1 AND A.EMP_ID=MY_EMP;	
	END IF;
	SET CT = 0, MXCT = 0;
	
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_icss_st_emp_list A WHERE A.version_code = I_VERSION_CODE;
	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_EMP_ID=NULL,MY_DEPT_ID=NULL,MY_DEPT_FULL_NAME=NULL,MY_EMP_CODE=NULL,MY_EMP_NAME=NULL,MY_ENTRY_DATE=NULL,MY_LEAVE_DATE=NULL;

		SELECT A.emp_id,A.emp_code,A.emp_name,A.entry_date,A.leave_date,A.dept_id,A.dept_full_name
			INTO MY_EMP_ID,MY_EMP_CODE,MY_EMP_NAME,MY_ENTRY_DATE,MY_LEAVE_DATE,MY_DEPT_ID,MY_DEPT_FULL_NAME
		FROM tmp_icss_st_emp_list A 
		WHERE A.version_code = I_VERSION_CODE AND A.id=CT; 

		IF MY_EMP_ID IS NOT NULL THEN
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.jan=B.hol_hours,A.emp_code=MY_EMP_CODE,A.emp_name=MY_EMP_NAME,A.entry_date=MY_ENTRY_DATE,A.leave_date=MY_LEAVE_DATE,A.dept_id=MY_DEPT_ID,A.dept_full_name=MY_DEPT_FULL_NAME
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'01') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.feb=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'02') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.mar=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'03') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.apr=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'04') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.may=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'05') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.jun=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'06') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.july=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'07') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.aug=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'08') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.sep=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'09') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.oct=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'10') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.nov=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'11') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
			
			UPDATE icss_st_hol_yearly A,icss_st_hol_detail B
			SET A.`dec`=B.hol_hours
			WHERE A.emp_id=MY_EMP_ID AND B.this_year_mon = CONCAT(MY_THIS_YEAR,'12') 
				AND A.emp_id=B.emp_id AND A.hol_id=B.hol_id ;
		END IF;
		SET CT = CT + 1;
	END WHILE;
	
	UPDATE icss_st_hol_yearly A
	SET A.all_hours = A.jan + A.feb + A.mar + A.apr + A.may + A.jun + A.july + A.aug + A.sep + A.`oct` + A.nov + A.`dec` 
	WHERE A.this_year=MY_THIS_YEAR;
	
END;

