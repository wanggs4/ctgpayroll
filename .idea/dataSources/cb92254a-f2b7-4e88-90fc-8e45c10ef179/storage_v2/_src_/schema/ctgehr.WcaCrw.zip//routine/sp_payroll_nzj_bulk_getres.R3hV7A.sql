create procedure SP_PAYROLL_NZJ_BULK_GETRES(IN custid bigint unsigned, IN ym int, IN setid bigint unsigned)
  comment '批量计算年终奖结果'
  BEGIN

	
	DECLARE calc_rescnt,sumb_rescnt,TAX_VERSION,ct,mxct,i_emp,i_deptid,i_custid,sala,prid,TOLCNT bigint;
	DECLARE i_empname,i_deptname varchar(50);
	DECLARE N_AFT_TAX_TOL,N_NZJ_ZS,N_NZJ_YNSE,N_NZJ_YNSE_DK,N_NZJ_SL,N_NZJ_SSKCE,N_NZJ_S,N_NZJ_AFT_TAX_pay_SUM,N_NZJ_AFT_TAX_NOpay_SUM,N_NZJ_TAX_Cpay_SUM_NOPAY,N_NZJ_TAX_Cpay_SUM_PAY,N_NZJ_TAX_Cpay_SUM,N_NZJ_TAX_AFT_SUM,N_NZJ_SF,N_NZJ_TAX_Epay_SUM DECIMAL(13,3);
	DECLARE N_BTA,N_BTS,N_ATA,N_ATS,N_TIA,N_TIS,N_TMA,N_TMS,N_AT2BTP,N_AT2BTNP DECIMAL(13,3);
	DECLARE N_TAX_C_TOL,N_AFT_TAX_TOL_SUM,N_TAX_BEF_TOL,H_AFT_TAX_TOL_SUM,H_TAX_BEF_TOL DECIMAL(13,3);
	DECLARE n_tax_stand DECIMAL(13,3);
	DECLARE S_GZ_SF,S_LWF_SF,S_LZF_SF,S_NZJ_SF,NZJ_TAX_CPAY_SUM_PAY_TEMP DECIMAL(13,3);
 DECLARE i_version_code VARCHAR(50);
 SET i_version_code = UUID();

	
	set sumb_rescnt=0;
	select count(*) into sumb_rescnt from payroll_nzj_base where cust_id=custid and MONTH_STEP=ym and set_id=setid and is_publish=0 ;
	
	if sumb_rescnt>0 then		
		INSERT INTO tmp_payroll_nzj_sum (version_code,payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,MONTH_STEP,TAX_STAND,BTA,BTS,ATA,ATS,TIA,TIS,TMA,TMS,AT2BTP,AT2BTNP) 
			select i_version_code,id,CUST_ID,DEPT_ID,DEPT_NAME,emp_id,EMP_NAME,month_step,AVG(TAX_STAND),
				sum(BTA1+BTA2+BTA3+BTA4+BTA5+BTA6+BTA7+BTA8+BTA9+BTA10+BTA11+BTA12+BTA13+BTA14+BTA15+BTA16+BTA17+BTA18+BTA19+BTA20+BTA21+BTA22+BTA23+BTA24+BTA25+BTA26+BTA27+BTA28+BTA29+BTA30) BTA,
				sum(BTS1+BTS2+BTS3+BTS4+BTS5+BTS6+BTS7+BTS8+BTS9+BTS10+BTS11+BTS12+BTS13+BTS14+BTS15+BTS16+BTS17+BTS18+BTS19+BTS20+BTS21+BTS22+BTS23+BTS24+BTS25+BTS26+BTS27+BTS28+BTS29+BTS30) BTS,
				sum(ATA1+ATA2+ATA3+ATA4+ATA5) ATA,
				sum(ATS1+ATS2+ATS3+ATS4+ATS5) ATS,
				sum(TIA1+TIA2+TIA3+TIA4+TIA5) TIA,
				sum(TIS1+TIS2+TIS3+TIS4+TIS5) TIS,
				sum(TMA1+TMA2+TMA3+TMA4+TMA5) TMA,
				sum(TMS1+TMS2+TMS3+TMS4+TMS5) TMS,
				sum(AT2BTP1+AT2BTP2+AT2BTP3+AT2BTP4+AT2BTP5) AT2BTP,
				sum(AT2BTNP1+AT2BTNP2+AT2BTNP3+AT2BTNP4+AT2BTNP5) AT2BTNP
			from payroll_nzj_base where  cust_id=custid and MONTH_STEP=ym and set_id=setid and is_publish=0 
			group by emp_id;
		
		select count(*) into calc_rescnt from tmp_payroll_nzj_sum where version_code = i_version_code;
	
		
		set TAX_VERSION=left(ym,4);
		
		
		
		set calc_rescnt=0;
		select count(*),min(id),max(id) into calc_rescnt,ct,mxct from tmp_payroll_nzj_sum where version_code = i_version_code;
		if calc_rescnt>0 then 			
			while (ct<=mxct) do			
				SET N_NZJ_ZS = 0;
				SET N_NZJ_YNSE = 0;
				SET N_NZJ_YNSE_DK = 0;
				SET N_NZJ_SL = 0;
				SET N_NZJ_SSKCE = 0;
				SET N_NZJ_S = 0;
				SET N_NZJ_AFT_TAX_pay_SUM = 0;
				SET N_NZJ_AFT_TAX_NOpay_SUM = 0;
				SET N_NZJ_TAX_Cpay_SUM_NOPAY = 0;
				SET N_NZJ_TAX_Cpay_SUM_PAY = 0;
				SET N_NZJ_TAX_Cpay_SUM = 0;
				SET N_NZJ_TAX_AFT_SUM = 0;
				SET N_NZJ_SF = 0;
				SET N_NZJ_TAX_Epay_SUM = 0;
				SET prid = NULL;
				
				select payroll_id,cust_id,dept_id,dept_name,emp_id,emp_name,tax_stand,BTA,BTS,ATA,ATS,TIA,TIS,TMA,TMS,AT2BTP,AT2BTNP
					into prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,n_tax_stand,N_BTA,N_BTS,N_ATA,N_ATS,N_TIA,N_TIS,N_TMA,N_TMS,N_AT2BTP,N_AT2BTNP
				from tmp_payroll_nzj_sum where id=ct and version_code = i_version_code;
				
				IF prid IS NOT NULL THEN
					select count(*) into calc_rescnt from payroll_gz where emp_id=i_emp and MONTH_STEP = ym and set_id=setid;
					if calc_rescnt>0 then														
						select if(sum(TAX_BEF_TOL) is null,0,sum(TAX_BEF_TOL)),
									if(sum(AFT_TAX_TOL_SUM) is null,0,sum(AFT_TAX_TOL_SUM)),
									if(sum(TAX_C_TOL) is null,0,sum(TAX_C_TOL))
			      		into N_TAX_BEF_TOL,						
									N_AFT_TAX_TOL_SUM,				
									N_TAX_C_TOL							
			      	from payroll_gz g
			 			where emp_id=i_emp and month_step=ym and set_id=setid;
					else																				
						set N_TAX_BEF_TOL=0;
						set N_AFT_TAX_TOL_SUM=0;
						set N_TAX_C_TOL=0;
					end if;																			
			
					
					select count(*) into calc_rescnt from payroll_gz where emp_id = i_emp and MONTH_STEP=ym and is_publish = 1;
					if calc_rescnt >0 then														
						select SUM(IF(TAX_BEF_TOL IS NULL,0,TAX_BEF_TOL)),
									SUM(IF(AFT_TAX_TOL_SUM IS NULL,0,AFT_TAX_TOL_SUM))
				      	into H_TAX_BEF_TOL,
									H_AFT_TAX_TOL_SUM
				      from payroll_gz a
						where a.emp_id = i_emp and a.is_publish = 1 and a.MONTH_STEP=ym and a.SET_ID <> setid
						group by a.emp_id;
					else																				
						set H_TAX_BEF_TOL=0;
						set H_AFT_TAX_TOL_SUM=0;
					end if;																			
					
		    		set N_NZJ_YNSE_DK = N_TAX_BEF_TOL + 
					 												H_TAX_BEF_TOL + 
																	N_AFT_TAX_TOL_SUM + 
																	H_AFT_TAX_TOL_SUM;
																	
					set N_NZJ_ZS = N_BTA -
		                              	N_BTS; 
		                              	
				   if N_NZJ_YNSE_DK > 0 and N_NZJ_YNSE_DK < n_tax_stand then				
				
				       set N_NZJ_YNSE_DK = n_tax_stand - N_NZJ_YNSE_DK ;
				   else																					
						if N_TAX_C_TOL >0  and N_NZJ_YNSE_DK < n_tax_stand then			
				            set N_NZJ_YNSE_DK = n_tax_stand  ;
				        else																			
				            set N_NZJ_YNSE_DK = 0 ;
				        end if;																		
				   end if;																				
		
		    		set N_NZJ_YNSE = N_NZJ_ZS +
		                                      N_TIA -
		                                      N_TIS -
		                                      N_NZJ_YNSE_DK; 
		
		    		CALL SP_PAYROLL_NZJ_TAX(N_NZJ_YNSE,TAX_VERSION,N_NZJ_SL,N_NZJ_SSKCE,N_NZJ_S);
		
				   set N_NZJ_TAX_Epay_SUM = N_NZJ_S;
				   set N_NZJ_AFT_TAX_pay_SUM   = N_AT2BTP; 
				   set N_NZJ_AFT_TAX_NOpay_SUM = N_AT2BTNP; 
		
				   if (N_NZJ_AFT_TAX_PAY_SUM + N_NZJ_AFT_TAX_NOPAY_SUM ) > 0 then
						set N_AFT_TAX_TOL = N_NZJ_YNSE- N_NZJ_S+ 
			                                          N_AT2BTP ; 
						call SP_PAYROLL_NZJ_TAX_BACK(N_AFT_TAX_TOL,N_NZJ_SL,N_NZJ_SSKCE,TAX_VERSION,N_NZJ_SL,N_NZJ_SSKCE,NZJ_TAX_CPAY_SUM_PAY_TEMP);
						call SP_PAYROLL_NZJ_TAX(NZJ_TAX_CPAY_SUM_PAY_TEMP,TAX_VERSION,N_NZJ_SL,N_NZJ_SSKCE,N_NZJ_TAX_CPAY_SUM_PAY);
						set N_NZJ_TAX_CPAY_SUM_PAY = N_NZJ_TAX_CPAY_SUM_PAY - N_NZJ_S;  
			            set N_AFT_TAX_TOL = N_NZJ_YNSE - N_NZJ_S+ 
			                                          N_AT2BTP +
			                                          N_AT2BTNP; 
						call SP_PAYROLL_NZJ_TAX_BACK(N_AFT_TAX_TOL,N_NZJ_SL,N_NZJ_SSKCE,TAX_VERSION,N_NZJ_SL,N_NZJ_SSKCE,N_NZJ_YNSE); 
						call SP_PAYROLL_NZJ_TAX(N_NZJ_YNSE,TAX_VERSION,N_NZJ_SL,N_NZJ_SSKCE,N_NZJ_TAX_CPAY_SUM_NOPAY);
						set N_NZJ_TAX_CPAY_SUM_NOPAY = N_NZJ_TAX_CPAY_SUM_NOPAY - N_NZJ_S; 
						set N_NZJ_TAX_CPAY_SUM_NOPAY = N_NZJ_TAX_CPAY_SUM_NOPAY - N_NZJ_TAX_CPAY_SUM_PAY;
			      else
			       	set N_NZJ_TAX_CPAY_SUM_PAY = 0;
			       	set N_NZJ_TAX_CPAY_SUM_NOPAY = 0;
			      end if;
		
		
		    		SET N_NZJ_S = N_NZJ_S + N_NZJ_TAX_CPAY_SUM+N_NZJ_TAX_CPAY_SUM_NOPAY; 
		
		
		
			    	SET N_NZJ_TAX_AFT_SUM = N_ATA - N_ATS;
			    	SET N_NZJ_SF  =  N_NZJ_ZS  -
			                                    N_NZJ_S  +
			                                     N_NZJ_TAX_CPAY_SUM +
			                                     N_NZJ_TAX_CPAY_SUM_NOPAY+
			                                    N_NZJ_AFT_TAX_PAY_SUM +
			                                    N_NZJ_TAX_AFT_SUM ;
		
		
			      
			      
			      IF N_NZJ_ZS IS NULL THEN SET N_NZJ_ZS=0; END IF;
				  	IF N_NZJ_S IS NULL THEN SET N_NZJ_S=0; END IF;
				  	IF N_NZJ_SF  IS NULL THEN SET N_NZJ_SF=0; END IF;
		
			      
			      delete from payroll_nzj WHERE id=prid;
			      insert into payroll_nzj (`ID`,`CUST_ID`,`DEPT_ID`,`DEPT_NAME`,`EMP_ID`,`EMP_NAME`,`set_id`,`MONTH_STEP`,`IS_PUBLISH`,
				  							NZJ_ZS,NZJ_YNSE,NZJ_YNSE_DK,NZJ_SL,NZJ_SSKCE,NZJ_S,NZJ_AFT_TAX_PAY_SUM,NZJ_TAX_CPAY_SUM,
											  NZJ_TAX_EPAY_SUM,NZJ_TAX_CPAY_SUM_NOPAY,NZJ_TAX_AFT_SUM,NZJ_SF,NZJ_AFT_TAX_NOPAY_SUM,
											  NZJ_TAX_CPAY_SUM_PAY) 
										values	(prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,setid,ym,0,
											N_NZJ_ZS,N_NZJ_YNSE,N_NZJ_YNSE_DK,N_NZJ_SL,N_NZJ_SSKCE,N_NZJ_S,N_NZJ_AFT_TAX_PAY_SUM,N_NZJ_TAX_CPAY_SUM,
											N_NZJ_TAX_EPAY_SUM,N_NZJ_TAX_CPAY_SUM_NOPAY,N_NZJ_TAX_AFT_SUM,N_NZJ_SF,N_NZJ_AFT_TAX_NOPAY_SUM,
											N_NZJ_TAX_CPAY_SUM_PAY);
		
					UPDATE payroll_nzj_base set is_calc=1 where id = prid;
					
					
					UPDATE payroll_tol 
					SET TAX_BEF_PLUSMIN_TOL=TAX_BEF_PLUSMIN_TOL+N_NZJ_ZS,TAX_VALUE=TAX_VALUE+N_NZJ_S,SALARY_PAY=SALARY_PAY+N_NZJ_SF 
					WHERE ID=prid;
		
				END IF;
				set ct=ct+1;
			end while;																			
		end if;																					
	end if;
	delete from  tmp_payroll_nzj_sum where version_code = i_version_code;
	
END;

