create function FN_DPT_GET_SONHOLID(EMPID bigint unsigned, DT date, HOLTYPE int)
  returns bigint unsigned
  comment '给emp和dt从而得到你想要的假期的子表主键id'
  BEGIN
DECLARE HOLIDAYID, CT, MXCT BIGINT UNSIGNED;
	IF HOLTYPE > 0 THEN 
	
		
		SET CT=10,MXCT=1;
		WHILE CT>=MXCT AND HOLIDAYID IS NULL DO
			SELECT  D.id INTO HOLIDAYID
			FROM att_rel_holiday_depts A 
				LEFT JOIN emp_base_info B ON (A.dept_id=B.dept_id  or A.dept_id = B.prgm_id or A.dept_id = B.jrdc_id or A.dept_id = B.dms_id4 or A.dept_id = B.dms_id5 or A.dept_id = B.dms_id6 or A.dept_id = B.dms_id7 or A.dept_id = B.dms_id8 or A.dept_id = B.dms_id9 or A.dept_id = B.dms_id10)
				LEFT JOIN att_set_holiday D ON A.hol_id=D.hol_id AND A.son_ver=D.son_ver
			WHERE B.emp_id=EMPID AND A.dept_type=CT AND D.is_year_hol = HOLTYPE and D.`status` = 1 and D.is_delete = 0
			LIMIT 1;
			
			SET CT = CT - 1;
		END WHILE;
	END IF;
RETURN HOLIDAYID;
END;

