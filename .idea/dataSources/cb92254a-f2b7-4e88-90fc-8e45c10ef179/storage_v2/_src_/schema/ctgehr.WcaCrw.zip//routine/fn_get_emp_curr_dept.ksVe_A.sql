create function FN_GET_EMP_CURR_DEPT(i_emp bigint, dt date)
  returns bigint
  comment '根据给出的员工id和时间，来得到该员工目前所属的部门id'
  BEGIN


DECLARE my_ori_dept_id,my_loan_dept_id,i_deptid,IS_HAVE_EMP bigint;


SET my_ori_dept_id = NULL;
SET my_loan_dept_id = NULL;
SET i_deptid = NULL;

	IF i_emp IS NOT NULL AND dt IS NOT NULL THEN
		SELECT COUNT(*) INTO IS_HAVE_EMP FROM emp_base_info WHERE emp_id = i_emp;
		IF IS_HAVE_EMP>0 THEN
		
			
			SELECT dept_id INTO my_ori_dept_id FROM emp_base_info WHERE emp_id = i_emp;
			
			IF my_ori_dept_id IS NOT NULL THEN
				
				SELECT to_dept_id INTO my_loan_dept_id FROM att_emp_loan
				WHERE emp_id=i_emp AND loan_begin_time <= dt AND loan_end_time>= dt;
				
				
				IF my_loan_dept_id IS NULL THEN
					SET i_deptid = my_ori_dept_id;
				ELSE
					SET i_deptid = my_loan_dept_id;
				END IF;
			ELSE
				SET i_deptid = -3; 	
			END IF;
		ELSE			
			SET i_deptid = -2;		
		END IF;
	ELSE
		SET i_deptid = -1; 			
	END IF;

RETURN i_deptid;
END;

