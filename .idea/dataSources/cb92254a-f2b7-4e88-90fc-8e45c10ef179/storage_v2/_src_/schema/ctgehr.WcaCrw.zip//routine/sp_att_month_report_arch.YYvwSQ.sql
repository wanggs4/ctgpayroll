create procedure SP_ATT_MONTH_REPORT_ARCH(IN ARCHID bigint unsigned, IN STID bigint unsigned, IN DEPTID bigint unsigned,
                                          IN EMPID  bigint unsigned, IN DEPTTYPE int, INOUT STATE int)
  comment '将月报结果归档到指定的归档信息里'
  BEGIN
DECLARE IS_HAVE_ARCH,IS_HAVE_ST,PAR_STAT INT;
	SET STATE = 0;
	IF ARCHID IS NOT NULL AND STID IS NOT NULL THEN
		SELECT COUNT(*) INTO IS_HAVE_ARCH FROM ATT_ST_MONTH_ARCH WHERE ARCH_ID=ARCHID;
		SELECT COUNT(*) INTO IS_HAVE_ST FROM ATT_ST_MONTH WHERE ST_ID=STID;
		IF EMPID IS NOT NULL THEN 
			SET PAR_STAT=1;
		ELSEIF EMPID IS NULL AND DEPTID IS NOT NULL AND DEPTTYPE IS NOT NULL THEN
			SET PAR_STAT=2;
		ELSEIF EMPID IS NULL AND DEPTID IS NULL THEN
			SET PAR_STAT=3;
		END IF;
		
		IF IS_HAVE_ARCH > 0 AND IS_HAVE_ST > 0 AND PAR_STAT=1 THEN
			DELETE FROM att_st_month_arch_items WHERE arch_id=ARCHID AND emp_id=EMPID;
			DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND emp_id=EMPID;
			#归档
			INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
				SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
				FROM att_st_month_item a
				WHERE a.st_id=STID AND a.EMP_ID=EMPID;
			#归档横表
			CALL SP_ATT_MONTH_REPORT_ARCH_SZH(ARCHID,NULL,EMPID,NULL);
			
		ELSEIF IS_HAVE_ARCH > 0 AND IS_HAVE_ST > 0 AND PAR_STAT=2 THEN
			CASE DEPTTYPE 
			WHEN 1 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.dept_id=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND dept_id=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.dept_id=DEPTID;
			WHEN 1 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.prgm_id=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND prgm_id=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.prgm_id=DEPTID;
			WHEN 3 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.jrdc_id=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND jrdc_id=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.jrdc_id=DEPTID;
			WHEN 4 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.dms_id4=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND dms_id4=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.dms_id4=DEPTID;
			WHEN 5 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.dms_id5=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND dms_id5=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.dms_id5=DEPTID;
			WHEN 6 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.dms_id6=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND dms_id6=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.dms_id6=DEPTID;
			WHEN 7 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.dms_id7=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND dms_id7=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.dms_id7=DEPTID;
			WHEN 8 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.dms_id8=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND dms_id8=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.dms_id8=DEPTID;
			WHEN 9 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.dms_id9=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND dms_id9=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.dms_id9=DEPTID;
			WHEN 10 THEN
				DELETE a.* FROM att_st_month_arch_items a ,emp_base_info b WHERE b.dms_id10=DEPTID and a.emp_id=b.emp_id and a.arch_id=ARCHID;
				DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID AND dms_id10=DEPTID;
				#归档
				INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
					SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
					FROM att_st_month_item a LEFT JOIN emp_base_info b ON a.emp_id=b.emp_id
					WHERE a.st_id=STID AND b.dms_id10=DEPTID;
			END CASE;
			#归档横表
			CALL SP_ATT_MONTH_REPORT_ARCH_SZH(ARCHID,DEPTID,NULL,DEPTTYPE);
			
		ELSEIF IS_HAVE_ARCH > 0 AND IS_HAVE_ST > 0 AND PAR_STAT=3 THEN
			DELETE FROM att_st_month_arch_items WHERE arch_id=ARCHID;
			DELETE FROM att_st_month_arch_quick_view WHERE arch_id=ARCHID;
			#归档
			INSERT INTO att_st_month_arch_items (arch_id,emp_id,emp_name,dept_id,dept_name,st_type,st_key,st_name,st_value,st_money,seq_num)
				SELECT ARCHID,a.emp_id,a.emp_name,a.dept_id,a.dept_name,a.st_type,a.st_key,a.st_name,a.st_value,a.st_money,a.seq_num
				FROM att_st_month_item a
				WHERE a.st_id=STID;
			#归档横表
			CALL SP_ATT_MONTH_REPORT_ARCH_SZH(ARCHID,NULL,NULL,NULL);
		END IF;
	END IF;
	SET STATE = 1;
END;

