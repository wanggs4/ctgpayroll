create procedure SP_ICSS_AUDIT_POOL_YEAR(IN MY_STID bigint unsigned)
  comment '年假池审核'
  BEGIN
DECLARE IS_HAVE_INCREMENT INT;
DECLARE CT,MXCT,THIS_EMPID,MY_LAST_STID,MY_NEXT_STID BIGINT UNSIGNED;
DECLARE VRBS_THIS_MON_YEAR_HPD,VRBS_THIS_MON_TO_FUTURE_POOL_YEAR_USD,VRBS_LAST_YEAR_HAVE,VRBS_LAST_YEAR_LEFT,VRBS_LAST2_YEAR_HAVE DECIMAL(12,5);
DECLARE VRBS_LAST2_YEAR_LEFT,VRBS_THIS_YEAR_ALL_NEW_RLS,VRBS_THIS_YEAR_LEFT,VRBS_THIS_YEAR_NEXT_MON_NEW_RLS,VRBS_ALL_YEAR_LEFT DECIMAL(12,5);
DECLARE VRBS_STD_ALL_YEAR_LEFT,VRBS_DIFF_ALL_YEAR_LEFT,VRBS_ST_LAST_YEAR_LEFT,VRBS_STD_ST_LAST_YEAR_LEFT,VRBS_DIFF_ST_LAST_YEAR_LEFT DECIMAL(12,5);
DECLARE VRBS_ST_ALL_YEAR_LEFT,VRBS_STD_ST_ALL_YEAR_LEFT,VRBS_DIFF_ST_ALL_YEAR_LEFT,VRBS_BEGIN,TMP_VRB1,TMP_VRB2,VRBS_THIS_YEAR_HAVE,VRBS_ARCH_LAST_YEAR_LEFT,VRBS_ARCH_LAST_YEAR_USE DECIMAL(12,5);
DECLARE VRBS_DIFF_ALL_YEAR_LEFT_REASON VARCHAR(100);
DECLARE BGDT,EDDT DATE;

	IF MY_STID IS NOT NULL THEN
		#得到计算周期
		SELECT A.comp_start_time,A.comp_end_time INTO BGDT,EDDT FROM att_st_month A WHERE A.st_id = MY_STID;
		
		SELECT A.st_id INTO MY_LAST_STID 
		FROM att_st_month A 
		WHERE A.comp_start_time <= DATE_ADD(BGDT,INTERVAL -1 MONTH) AND A.comp_end_time >= DATE_ADD(BGDT,INTERVAL -1 MONTH) AND A.cust_id=2162554862743552;
		
		SELECT A.st_id INTO MY_NEXT_STID 
		FROM att_st_month A 
		WHERE A.comp_start_time <= DATE_ADD(BGDT,INTERVAL 1 MONTH) AND A.comp_end_time >= DATE_ADD(BGDT,INTERVAL 1 MONTH) AND A.cust_id=2162554862743552;
		
		#如果增量列表有数据，就跑增量，否则就跑所有
		SELECT COUNT(*) INTO IS_HAVE_INCREMENT FROM icss_audit_pool_year_emplist;
		IF IS_HAVE_INCREMENT IS NULL OR IS_HAVE_INCREMENT = 0 THEN
			INSERT INTO icss_audit_pool_year_emplist (emp_id,st_id) 
				SELECT EMP_ID,ST_ID FROM icss_audit_pool_year A WHERE A.st_id=MY_STID;
		END IF;
		
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM icss_audit_pool_year_emplist;
		
		WHILE CT <= MXCT DO
			SET THIS_EMPID = NULL,VRBS_THIS_MON_YEAR_HPD = 0, VRBS_THIS_MON_TO_FUTURE_POOL_YEAR_USD = 0, VRBS_LAST_YEAR_HAVE = 0,
				VRBS_LAST_YEAR_LEFT = 0, VRBS_LAST2_YEAR_HAVE = 0, VRBS_LAST2_YEAR_LEFT = 0, VRBS_THIS_YEAR_ALL_NEW_RLS = 0, 
				VRBS_THIS_YEAR_LEFT = 0, VRBS_THIS_YEAR_NEXT_MON_NEW_RLS = 0, VRBS_ALL_YEAR_LEFT = 0, VRBS_STD_ALL_YEAR_LEFT = 0, 
				VRBS_DIFF_ALL_YEAR_LEFT = 0, VRBS_DIFF_ALL_YEAR_LEFT_REASON = NULL, VRBS_ST_LAST_YEAR_LEFT = 0, VRBS_STD_ST_LAST_YEAR_LEFT = 0, 
				VRBS_DIFF_ST_LAST_YEAR_LEFT = 0, VRBS_ST_ALL_YEAR_LEFT = 0, VRBS_STD_ST_ALL_YEAR_LEFT = 0, VRBS_DIFF_ST_ALL_YEAR_LEFT=0,
				VRBS_ARCH_LAST_YEAR_LEFT = 0, VRBS_ARCH_LAST_YEAR_USE = 0;

			SELECT EMP_ID INTO THIS_EMPID FROM icss_audit_pool_year_emplist A WHERE A.id=CT;
			IF THIS_EMPID IS NOT NULL THEN
				#得到起点
				SELECT IFNULL(A.`begin`,0)/8,IFNULL(A.arch_last_year_left,0)/8,IFNULL(A.arch_last_year_use,0)/8 
					INTO VRBS_BEGIN,VRBS_ARCH_LAST_YEAR_LEFT,VRBS_ARCH_LAST_YEAR_USE 
				FROM icss_audit_pool_year A WHERE A.emp_id=THIS_EMPID AND A.st_id=MY_STID;
				
				#this_mon_year_hpd	本月已通过已休年假(天):取本月已审批通过的所有的请年假实际时长
				SELECT IFNULL(A.TYPE0002,0) INTO VRBS_THIS_MON_YEAR_HPD
				FROM att_st_month_quick_view_icss A
				WHERE A.emp_id = THIS_EMPID AND A.st_id = MY_STID;
				
				#this_mon_to_future_pool_year_usd	截至上月已占用年假(天):取当月及往后所有的请年假（审批中，待选审批，审批通过）状态的实际时长
				SET TMP_VRB1 = 0,TMP_VRB2 = 0;
					#未来的已通过
				SELECT IFNULL(SUM(A.hol_days),0) INTO VRBS_THIS_MON_TO_FUTURE_POOL_YEAR_USD 
				FROM att_hol_apply_day A 
				WHERE A.emp_id = THIS_EMPID AND A.hol_date > EDDT AND A.hol_days > 0 AND A.is_year_hol = 1 AND A.hol_days IS NOT NULL;
					#有扣减顺序
				SELECT IFNULL(SUM(IFNULL(MID(A.credit_detail,LOCATE('年假',A.credit_detail)+3,4),0)),0)/8  
					INTO TMP_VRB1
				FROM att_hol_apply A
				WHERE A.credit_detail IS NOT NULL AND A.credit_detail LIKE '%年假%'
					AND A.state IN (2,5) AND A.end_time >= CONCAT(BGDT,' 05:00:00') AND A.emp_id = THIS_EMPID;
					#无扣减顺序
				SELECT IFNULL(SUM(IFNULL(A.hol_min_num,0)/60),0)/8  
					INTO TMP_VRB2
				FROM att_hol_apply A
				WHERE A.credit_detail IS NULL AND A.hol_name='年假'
					AND A.state IN (2,5) AND A.end_time >= CONCAT(BGDT,' 05:00:00') AND A.emp_id = THIS_EMPID;
					
				SET VRBS_THIS_MON_TO_FUTURE_POOL_YEAR_USD = VRBS_THIS_MON_YEAR_HPD + TMP_VRB1 + TMP_VRB2 + VRBS_THIS_MON_TO_FUTURE_POOL_YEAR_USD;

				#last_year_have	去年可用年假：取往年年假have
				#last_year_left	去年剩余年假：取往年年假池left
				SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_left,0) INTO VRBS_LAST_YEAR_HAVE,VRBS_LAST_YEAR_LEFT 
				FROM att_hol_year A 
				WHERE A.emp_id = THIS_EMPID AND A.this_year = YEAR(BGDT)-1 AND A.is_delete = 0;
				
				#last2_year_have	前年可用年假：取前年年假have
				#last2_year_left	前年剩余年假：取前年年假池left
				SELECT IFNULL(A.this_year_have,0),IFNULL(A.this_year_left,0) INTO VRBS_LAST2_YEAR_HAVE,VRBS_LAST2_YEAR_LEFT 
				FROM att_hol_year A 
				WHERE A.emp_id = THIS_EMPID AND A.this_year = YEAR(BGDT)-2 AND A.is_delete = 0;

				#this_year_all_new_rls	当年截至到当前新释放年假：取当年截至到当月新释放年假天数，（截至到当月可休年假 - 上月可休年假） 
				SET TMP_VRB1 = 0,TMP_VRB2 = 0;
					#截至到当月可休年假（取当月系统中生成假期池报表的截至当月可休年假）
				SELECT IFNULL(A.this_year_have,0)/8 INTO TMP_VRB1
				FROM att_st_month_quick_view_st_pool A 
				WHERE A.emp_id = THIS_EMPID AND A.st_id = MY_STID;
					#上月可休年假（取定稿数据中的截至到当月可休年假，也就是上月的的截至当月可休年假字段）
				SELECT IFNULL(A.this_year_have,0)/8 INTO TMP_VRB2
				FROM att_st_month_quick_view_st_pool A 
				WHERE A.emp_id = THIS_EMPID AND A.st_id = MY_LAST_STID;

				SET VRBS_THIS_YEAR_ALL_NEW_RLS = TMP_VRB1 - TMP_VRB2;

				#this_year_next_mon_new_rls	下月新释放年假：如果核对月份为2月，则取3月报表中的当月可用年假 减去 2月报表中的当月可用年假。
				SET TMP_VRB2 = 0;
					#上月可休年假（取定稿数据中的截至到当月可休年假，也就是上月的的截至当月可休年假字段）
				SELECT IFNULL(A.this_year_have,0)/8 INTO TMP_VRB2
				FROM att_st_month_quick_view_st_pool A 
				WHERE A.emp_id = THIS_EMPID AND A.st_id = MY_NEXT_STID;
					
				SET VRBS_THIS_YEAR_NEXT_MON_NEW_RLS = IF(TMP_VRB2 - TMP_VRB1 > 0 ,TMP_VRB2 - TMP_VRB1 , 0);

				#this_year_left	系统当年年假剩余：取当年年假池剩余
				SELECT IFNULL(A.this_year_left,0),IFNULL(A.this_year_have,0) INTO VRBS_THIS_YEAR_LEFT,VRBS_THIS_YEAR_HAVE
				FROM att_hol_year A 
				WHERE A.emp_id = THIS_EMPID AND A.this_year = YEAR(BGDT) AND A.is_delete = 0;


				#all_year_left	年假池剩余合计：取当前系统中所有剩余年假的合计
				SELECT IFNULL(SUM(IFNULL(A.this_year_left,0)),0) INTO VRBS_ALL_YEAR_LEFT 
				FROM att_hol_year A 
				WHERE A.emp_id = THIS_EMPID AND A.is_delete = 0;
				
				#std_all_year_left	年假池正确剩余：上月定稿结余+截至到当前新释放年假+下月新释放年假-已占用年假
				SET VRBS_STD_ALL_YEAR_LEFT = VRBS_BEGIN + VRBS_THIS_YEAR_ALL_NEW_RLS + VRBS_THIS_YEAR_NEXT_MON_NEW_RLS - VRBS_THIS_MON_TO_FUTURE_POOL_YEAR_USD;
				
				#diff_all_year_left	年假池差额：std_all_year_left - all_year_left
				SET VRBS_DIFF_ALL_YEAR_LEFT = VRBS_STD_ALL_YEAR_LEFT - VRBS_ALL_YEAR_LEFT;
				
				#st_last_year_left	截至上月非当年未休年假（现结果）：取当前系统中最新的假期池报表中的截至上月非当年未休年假
				SELECT IFNULL(A.last_year_left,0)/8 INTO VRBS_ST_LAST_YEAR_LEFT
				FROM att_st_month_quick_view_st_pool A 
				WHERE A.emp_id = THIS_EMPID AND A.st_id = MY_STID;
				
				#std_st_last_year_left	截至上月非当年未休年假（正确）：取上月定稿数据中的 （截至上月非当年未休年假 -上月已休年假，如果截至上月非当年未休年假=0，则为0） 
				
				IF VRBS_ARCH_LAST_YEAR_LEFT = 0 THEN
					SET VRBS_STD_ST_LAST_YEAR_LEFT = 0;
				ELSE
					SET VRBS_STD_ST_LAST_YEAR_LEFT = VRBS_ARCH_LAST_YEAR_LEFT - VRBS_ARCH_LAST_YEAR_USE;
				END IF;
				
				#diff_st_last_year_left	非当年未休年假差额：std_st_last_year_left - st_last_year_left
				SET VRBS_DIFF_ST_LAST_YEAR_LEFT = VRBS_STD_ST_LAST_YEAR_LEFT - VRBS_ST_LAST_YEAR_LEFT;
				
				#st_all_year_left	本月年假结余（现系统）：取系统假期池报表截至当月年假结余
				SELECT IFNULL(A.all_year_left,0)/8 INTO VRBS_ST_ALL_YEAR_LEFT
				FROM att_st_month_quick_view_st_pool A 
				WHERE A.emp_id = THIS_EMPID AND A.st_id = MY_STID;
				
				
				#std_st_all_year_left	本月年假结余（正确）：年假上月定稿结余  +  2021截至当月新释放年假 - 本月已通过已休年假
				SET VRBS_STD_ST_ALL_YEAR_LEFT = VRBS_BEGIN + VRBS_THIS_YEAR_ALL_NEW_RLS + VRBS_THIS_MON_YEAR_HPD;
				
				#diff_st_all_year_left	假期池报表差额：std_st_all_year_left - st_all_year_left
				SET VRBS_DIFF_ST_ALL_YEAR_LEFT = VRBS_STD_ST_ALL_YEAR_LEFT - VRBS_ST_ALL_YEAR_LEFT;
				
				#diff_all_year_left_reason	年假池差异原因分析
				IF VRBS_DIFF_ALL_YEAR_LEFT <> 0 THEN
						#1.VRBS_ALL_YEAR_LEFT 为负数，返回“年假超休”
					IF VRBS_ALL_YEAR_LEFT < 0 THEN
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '年假超休';
						
						#2.如果 VRBS_THIS_YEAR_HAVE=0，VRBS_THIS_YEAR_LEFT 不等于 VRBS_THIS_YEAR_HAVE，返回“当年错误转往年处理”
					ELSEIF VRBS_THIS_YEAR_HAVE=0 AND VRBS_THIS_YEAR_LEFT <> VRBS_THIS_YEAR_HAVE THEN
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '当年错误转往年处理';
						
						#3.如果 VRBS_ALL_YEAR_LEFT + VRBS_LAST_YEAR_LEFT > VRBS_LAST_YEAR_HAVE，并且 VRBS_THIS_YEAR_HAVE=VRBS_THIS_YEAR_LEFT，返回‘去年前年底数错误’。
					ELSEIF VRBS_ALL_YEAR_LEFT + VRBS_LAST_YEAR_LEFT > VRBS_LAST_YEAR_HAVE AND VRBS_THIS_YEAR_HAVE=VRBS_THIS_YEAR_LEFT THEN
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '去年前年底数错误';
						
						#4.如果 VRBS_LAST2_YEAR_LEFT=0 并且 VRBS_ALL_YEAR_LEFT + VRBS_LAST_YEAR_LEFT > VRBS_LAST_YEAR_HAVE，并且VRBS_THIS_YEAR_HAVE>0 AND VRBS_THIS_YEAR_LEFT < VRBS_THIS_YEAR_HAVE，返回‘去年当年底数错误’
					ELSEIF VRBS_LAST2_YEAR_LEFT=0 AND VRBS_ALL_YEAR_LEFT + VRBS_LAST_YEAR_LEFT > VRBS_LAST_YEAR_HAVE AND VRBS_THIS_YEAR_HAVE>0 AND VRBS_THIS_YEAR_LEFT < VRBS_THIS_YEAR_HAVE THEN
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '去年当年底数错误';
						
						#5.如果 VRBS_THIS_YEAR_HAVE = VRBS_THIS_YEAR_LEFT AND VRBS_LAST2_YEAR_LEFT=0 AND VRBS_ALL_YEAR_LEFT + VRBS_LAST_YEAR_LEFT <= VRBS_LAST_YEAR_HAVE AND VRBS_ALL_YEAR_LEFT + VRBS_LAST_YEAR_LEFT>0 返回‘去年错误’
					ELSEIF VRBS_THIS_YEAR_HAVE = VRBS_THIS_YEAR_LEFT AND VRBS_LAST2_YEAR_LEFT=0 AND VRBS_ALL_YEAR_LEFT + VRBS_LAST_YEAR_LEFT <= VRBS_LAST_YEAR_HAVE AND VRBS_ALL_YEAR_LEFT + VRBS_LAST_YEAR_LEFT>0 THEN
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '去年错误';
						
						#6.如果 VRBS_THIS_YEAR_HAVE = VRBS_THIS_YEAR_LEFT AND VRBS_LAST2_YEAR_LEFT>0 AND VRBS_LAST2_YEAR_LEFT + VRBS_ALL_YEAR_LEFT <= VRBS_LAST2_YEAR_HAVE AND VRBS_LAST2_YEAR_LEFT + VRBS_ALL_YEAR_LEFT>0 返回‘前年错误’
					ELSEIF VRBS_THIS_YEAR_HAVE = VRBS_THIS_YEAR_LEFT AND VRBS_LAST2_YEAR_LEFT>0 AND VRBS_LAST2_YEAR_LEFT + VRBS_ALL_YEAR_LEFT <= VRBS_LAST2_YEAR_HAVE AND VRBS_LAST2_YEAR_LEFT + VRBS_ALL_YEAR_LEFT > 0 THEN
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '前年错误';
						
						#7.如果 VRBS_THIS_YEAR_HAVE = VRBS_THIS_YEAR_LEFT AND VRBS_LAST2_YEAR_LEFT>0 AND VRBS_LAST2_YEAR_LEFT + VRBS_ALL_YEAR_LEFT > VRBS_LAST2_YEAR_HAVE  返回‘前年去年错误’
					ELSEIF VRBS_THIS_YEAR_HAVE = VRBS_THIS_YEAR_LEFT AND VRBS_LAST2_YEAR_LEFT>0 AND VRBS_LAST2_YEAR_LEFT + VRBS_ALL_YEAR_LEFT > VRBS_LAST2_YEAR_HAVE THEN
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '前年去年错误';
						
						#8.如果 VRBS_THIS_YEAR_LEFT <> VRBS_THIS_YEAR_HAVE AND VRBS_THIS_YEAR_HAVE>0 AND VRBS_LAST2_YEAR_LEFT>0 AND VRBS_LAST_YEAR_LEFT<>VRBS_LAST_YEAR_HAVE   返回‘前年去年当年错误’ 					
					ELSEIF VRBS_THIS_YEAR_LEFT <> VRBS_THIS_YEAR_HAVE AND VRBS_THIS_YEAR_HAVE>0 AND VRBS_LAST2_YEAR_LEFT>0 AND VRBS_LAST_YEAR_LEFT<>VRBS_LAST_YEAR_HAVE THEN
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '前年去年当年错误';
						
						#以上条件都不满足，返回 其他原因
					ELSE
						SET VRBS_DIFF_ALL_YEAR_LEFT_REASON = '其他原因';
					END IF;
				END IF;
				#更数据
				UPDATE icss_audit_pool_year
				SET this_mon_year_hpd = VRBS_THIS_MON_YEAR_HPD, this_mon_to_future_pool_year_usd = VRBS_THIS_MON_TO_FUTURE_POOL_YEAR_USD, 
					last_year_have = VRBS_LAST_YEAR_HAVE, last_year_left = VRBS_LAST_YEAR_LEFT, last2_year_have = VRBS_LAST2_YEAR_HAVE, 
					last2_year_left = VRBS_LAST2_YEAR_LEFT, this_year_all_new_rls = VRBS_THIS_YEAR_ALL_NEW_RLS, this_year_left = VRBS_THIS_YEAR_LEFT, 
					this_year_next_mon_new_rls = VRBS_THIS_YEAR_NEXT_MON_NEW_RLS, all_year_left = VRBS_ALL_YEAR_LEFT, std_all_year_left = VRBS_STD_ALL_YEAR_LEFT, 
					diff_all_year_left = VRBS_DIFF_ALL_YEAR_LEFT, diff_all_year_left_reason = VRBS_DIFF_ALL_YEAR_LEFT_REASON, st_last_year_left = VRBS_ST_LAST_YEAR_LEFT, 
					std_st_last_year_left = VRBS_STD_ST_LAST_YEAR_LEFT, diff_st_last_year_left = VRBS_DIFF_ST_LAST_YEAR_LEFT, st_all_year_left = VRBS_ST_ALL_YEAR_LEFT, 
					std_st_all_year_left = VRBS_STD_ST_ALL_YEAR_LEFT, diff_st_all_year_left = VRBS_DIFF_ST_ALL_YEAR_LEFT
				WHERE emp_id=THIS_EMPID AND st_id=MY_STID;
			END IF;
			SET CT = CT + 1;
		END WHILE;
		TRUNCATE TABLE icss_audit_pool_year_emplist;
	END IF;
END;

