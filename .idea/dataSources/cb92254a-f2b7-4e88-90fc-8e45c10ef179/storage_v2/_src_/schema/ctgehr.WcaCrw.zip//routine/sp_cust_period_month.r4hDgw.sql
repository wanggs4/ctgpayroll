create procedure SP_CUST_PERIOD_MONTH(IN bgdt date, IN custid bigint, IN scale int)
  comment '公司周期事务调度--月报'
  BEGIN
DECLARE i_version_code VARCHAR(50);
DECLARE MON_BGDT,MON_EDDT DATE;
DECLARE IS_HAVE_MONTH,MY_CUSTID,MY_STID,CT,MXCT,MY_p_item_id,MY_YEAR_MON BIGINT;

SET i_version_code = UUID();


	#判断输入参数，如果为null，计算所有
	#按优先级跑
	IF custid IS NULL AND scale BETWEEN 1 AND 10 THEN
		INSERT INTO tmp_cpm_cust_list (version_code,p_item_id,cust_id,year_mon,begin_date,end_date)
			SELECT distinct i_version_code,A.p_item_id,A.cust_id,A.year_mon,A.begin_date,A.end_date
			FROM cust_period_schedule A 
				LEFT JOIN cust_info B ON A.cust_id=B.cust_id
				LEFT JOIN att_st_month_cust_priority_level C ON B.cust_id=C.cust_id
			WHERE A.begin_date <= bgdt AND A.end_date >= bgdt AND A.period_type=1 AND B.is_enable=1 AND A.is_compute=0
				AND C.`type`= scale;
	#跑没有优先级的
	ELSEIF custid IS NULL AND scale=99 THEN
		INSERT INTO tmp_cpm_cust_list (version_code,p_item_id,cust_id,year_mon,begin_date,end_date)
			SELECT distinct i_version_code,A.p_item_id,A.cust_id,A.year_mon,A.begin_date,A.end_date
			FROM cust_period_schedule A 
				LEFT JOIN cust_info B ON A.cust_id=B.cust_id
			WHERE A.begin_date <= bgdt AND A.end_date >= bgdt AND A.period_type=1 AND B.is_enable=1 AND A.is_compute=0
				AND B.cust_id NOT IN (SELECT CUST_ID FROM att_st_month_cust_priority_level);
	#跑所有的
	ELSEIF custid IS NULL AND scale IS NULL THEN
		INSERT INTO tmp_cpm_cust_list (version_code,p_item_id,cust_id,year_mon,begin_date,end_date)
			SELECT distinct i_version_code,A.p_item_id,A.cust_id,A.year_mon,A.begin_date,A.end_date
			FROM cust_period_schedule A 
				LEFT JOIN cust_info B ON A.cust_id=B.cust_id
			WHERE A.begin_date <= bgdt AND A.end_date >= bgdt AND A.period_type=1 AND B.is_enable=1 AND A.is_compute=0
				AND B.cust_id NOT IN (SELECT CUST_ID FROM att_st_month_cust_priority_level WHERE `TYPE`=0);
	#按照给定的custid进行计算
	ELSEIF custid IS NOT NULL THEN
		INSERT INTO tmp_cpm_cust_list (version_code,p_item_id,cust_id,year_mon,begin_date,end_date)
			SELECT distinct i_version_code,p_item_id,cust_id,A.year_mon,begin_date,end_date
			FROM cust_period_schedule A
			WHERE CUST_ID=custid AND A.begin_date <= bgdt AND A.end_date >= bgdt AND A.period_type=1;
	END IF;


	
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_cpm_cust_list WHERE VERSION_CODE = i_version_code;

	WHILE (CT <= MXCT AND CT > 0) DO
		SET MY_CUSTID = NULL;
		SET MON_BGDT = NULL;
		SET MON_EDDT = NULL;
		SET IS_HAVE_MONTH =NULL;
		
		#依次读出企业在给出的时间所属的周期起止点
		SELECT cust_id,begin_date,end_date,p_item_id,year_mon
			INTO MY_CUSTID,MON_BGDT,MON_EDDT,MY_p_item_id,MY_YEAR_MON
		FROM tmp_cpm_cust_list
		WHERE VERSION_CODE = i_version_code AND ID = CT;
		
		#只有找到数据时才进行计算
		IF MY_CUSTID IS NOT NULL THEN
			SELECT COUNT(*) INTO IS_HAVE_MONTH FROM att_st_month A WHERE A.cust_id=MY_CUSTID AND A.comp_start_time =MON_BGDT AND A.comp_end_time = MON_EDDT;
			IF IS_HAVE_MONTH = 0 THEN
				SELECT IF(MAX(A.st_id) IS NULL,0,MAX(A.st_id)) + 1 INTO MY_STID FROM att_st_month A WHERE A.st_id < 10000000000;
				INSERT INTO att_st_month (`version`,ST_ID,cust_id,comp_start_time,comp_end_time,creator_id,create_time) VALUES
					(MY_YEAR_MON,MY_STID,MY_CUSTID,MON_BGDT,MON_EDDT,1,NOW());
			ELSEIF IS_HAVE_MONTH = 1 THEN
				SELECT A.st_id INTO MY_STID FROM att_st_month A WHERE A.cust_id=MY_CUSTID AND A.comp_start_time =MON_BGDT AND A.comp_end_time = MON_EDDT;
			ELSEIF IS_HAVE_MONTH > 1 THEN
				SELECT MIN(A.st_id) INTO MY_STID FROM att_st_month A WHERE A.cust_id=MY_CUSTID AND A.comp_start_time =MON_BGDT AND A.comp_end_time = MON_EDDT;
			END IF;
			
			SET @ST = 0;
			CALL SP_ATT_MONTH_REPORT(MON_BGDT,bgdt,MY_CUSTID,NULL,NULL,MY_STID,@ST,NULL);
#			CALL SP_ATT_MONTH_REPORT_ST_POOL(MY_STID,NULL);
#			CALL SP_CUST_PERIOD_EMP(bgdt,MY_CUSTID);
			DELETE FROM tmp_cpm_cust_list WHERE VERSION_CODE = i_version_code AND ID = CT;
			#UPDATE cust_period_schedule SET IS_COMPUTE=1 WHERE p_item_id=MY_p_item_id;
		END IF;
		SET CT = CT + 1 ;
	END WHILE;


END;

