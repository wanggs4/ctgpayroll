create procedure SP_PAYROLL_FH_TAX(IN FHAMO decimal(13, 3), OUT RES decimal(13, 3))
  comment '分红税计算方式'
  BEGIN
  
	SET RES = FHAMO * 0.2;

END;

