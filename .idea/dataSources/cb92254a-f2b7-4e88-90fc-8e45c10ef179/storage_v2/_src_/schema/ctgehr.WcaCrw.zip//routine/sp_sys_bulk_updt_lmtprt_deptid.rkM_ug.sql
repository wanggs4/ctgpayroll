create procedure SP_SYS_BULK_UPDT_LMTPRT_DEPTID(IN CUSTID bigint unsigned, IN DEPTID bigint unsigned)
  comment '批量为所有或某个公司更新各个部门的有人数限制的父级节点id'
  BEGIN
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE THIS_DEPTID BIGINT UNSIGNED;
DECLARE CT,MXCT BIGINT;
	SET I_VERSION_CODE = UUID();
	#参数全空，所有
	IF CUSTID IS NULL AND DEPTID IS NULL THEN
		INSERT INTO tmp_sys_uplmtprt_deptid_list (version_code,dept_id)
			SELECT I_VERSION_CODE,A.dept_id 
			FROM dept_info A 
			WHERE A.is_enable=1 AND A.dept_type=1
			ORDER BY A.cust_id,A.dept_lv_code,A.dept_id;
	#公司不为空部门为空，跑公司
	ELSEIF CUSTID IS NOT NULL AND DEPTID IS NULL THEN
		INSERT INTO tmp_sys_uplmtprt_deptid_list (version_code,dept_id)
			SELECT I_VERSION_CODE,A.dept_id 
			FROM dept_info A 
			WHERE A.is_enable=1 AND A.cust_id=CUSTID AND A.dept_type=1
			ORDER BY A.cust_id,A.dept_lv_code,A.dept_id;
	#部门不为空，跑部门
	ELSEIF DEPTID IS NOT NULL THEN
		INSERT INTO tmp_sys_uplmtprt_deptid_list (version_code,dept_id)
			SELECT I_VERSION_CODE,A.dept_id 
			FROM dept_info A 
			WHERE A.is_enable=1 AND A.dept_id=DEPTID AND A.dept_type=1
			ORDER BY A.cust_id,A.dept_lv_code,A.dept_id;
	END IF;
	
	SET CT=0,MXCT=0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_sys_uplmtprt_deptid_list WHERE VERSION_CODE = I_VERSION_CODE;
	
	WHILE CT <= MXCT AND CT > 0 DO
		SET THIS_DEPTID = NULL;
		SELECT DEPT_ID INTO THIS_DEPTID FROM tmp_sys_uplmtprt_deptid_list WHERE VERSION_CODE = I_VERSION_CODE AND ID = CT;
		IF THIS_DEPTID IS NOT NULL THEN
			CALL SP_SYS_UPDATE_LIMITED_PARENTDEPTID(THIS_DEPTID);
		END IF;
		SET CT = CT + 1 ;
	END WHILE;
END;

