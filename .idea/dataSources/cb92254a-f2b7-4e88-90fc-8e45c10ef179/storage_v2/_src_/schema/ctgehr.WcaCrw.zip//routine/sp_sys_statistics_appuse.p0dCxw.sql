create procedure SP_SYS_STATISTICS_APPUSE(IN MY_BGTM datetime, IN MY_EDTM datetime, IN MY_APPTYPE tinyint unsigned,
  INOUT                                      ST      int)
  comment '统计各种程序来源的以公司为对象的使用情况'
  BEGIN

DECLARE CUST_CT,CUST_MXCT,MY_CUSTID BIGINT UNSIGNED;
DECLARE MY_MNG_PCUSE,MY_AGTTYPE,MY_MNG_NUM,MY_MNG_APPUSE,MY_EMP_NUM,MY_EMP_APPUSE,MY_MNG_APPUSE_EMP,MY_MNG_APPUSE_USER INT;
DECLARE I_VERSION_CODE,MY_CUSTNAME VARCHAR(50);

	SET I_VERSION_CODE = UUID();
	
	IF ST = 0 AND MY_APPTYPE IS NOT NULL AND MY_BGTM IS NOT NULL AND MY_EDTM IS NOT NULL AND MY_BGTM<=MY_EDTM THEN
		INSERT INTO tmp_sys_statistics_appuser_custlist (version_code,cust_id,cust_name) 
			SELECT DISTINCT I_VERSION_CODE,A.ehr_cust_id,A.corp_name
			FROM qywx_cust_info A
			WHERE A.is_delete=0 AND A.create_time <= MY_EDTM;
		
		delete from sys_statistics_appuse  where bgtm=MY_BGTM and edtm = MY_EDTM and app_type=MY_APPTYPE;
		SET CUST_CT=0,CUST_MXCT=0;
		SELECT MIN(ID),MAX(ID) INTO CUST_CT,CUST_MXCT FROM tmp_sys_statistics_appuser_custlist WHERE version_code = I_VERSION_CODE;
		WHILE CUST_CT <= CUST_MXCT AND CUST_CT > 0 DO
			SET MY_CUSTID=NULL,MY_CUSTNAME=NULL;
			SELECT A.CUST_ID,A.CUST_NAME INTO MY_CUSTID,MY_CUSTNAME FROM tmp_sys_statistics_appuser_custlist A WHERE A.ID=CUST_CT AND A.version_code=I_VERSION_CODE;
			IF MY_CUSTID IS NOT NULL THEN
				SET MY_MNG_NUM=0,MY_MNG_APPUSE=0,MY_EMP_NUM=0,MY_EMP_APPUSE=0,MY_AGTTYPE=NULL;
				SELECT MAX(A.ehr_agent_type) INTO MY_AGTTYPE FROM qywx_cust_info A WHERE A.ehr_cust_id=MY_CUSTID AND A.is_delete=0;
				#管理员人数
				SELECT COUNT(*) INTO MY_MNG_NUM FROM au_users A WHERE A.cust_id=MY_CUSTID AND A.is_enable=1 AND A.emp_id>0 AND A.emp_id IS NOT NULL;
				#管理员使用人数-小程序
					#有emp的管理员
				SELECT COUNT(*) INTO MY_MNG_APPUSE 
				FROM au_users A LEFT JOIN sys_log_appuse B ON A.emp_id =B.emp_id 
				WHERE A.cust_id=MY_CUSTID AND A.is_enable=1 AND A.emp_id IS NOT NULL AND A.emp_id>0 
					AND B.app_type=MY_APPTYPE AND B.use_time BETWEEN MY_BGTM AND MY_EDTM;
				#管理员使用人数-PC
				SELECT COUNt(*) INTO MY_MNG_PCUSE
				FROM login_log  A 
				WHERE A.user_type=1 AND A.mobile='' AND A.login_time BETWEEN MY_BGTM AND MY_EDTM AND A.cust_id = MY_CUSTID;
  
				
				#员工数量
				SELECT COUNT(*) INTO MY_EMP_NUM
				FROM emp_base_info A LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				WHERE A.cust_id=MY_CUSTID AND A.is_delete=0 AND A.emp_state IN (1,3) 
					AND B.entry_date IS NOT NULL AND B.entry_date <= DATE(MY_EDTM) AND (B.leave_date IS NULL OR B.leave_date >= DATE(MY_BGTM));
				#员工使用程序数量
				SELECT COUNT(*) INTO MY_EMP_APPUSE
				FROM emp_base_info A 
					LEFT JOIN emp_post B ON A.emp_id=B.emp_id
					LEFT JOIN sys_log_appuse C ON A.emp_id=C.emp_id
				WHERE A.cust_id=MY_CUSTID AND A.is_delete=0 AND A.emp_state IN (1,3) 
					AND B.entry_date IS NOT NULL AND B.entry_date <= DATE(MY_EDTM) AND (B.leave_date IS NULL OR B.leave_date >= DATE(MY_BGTM))
					AND C.app_type=MY_APPTYPE AND C.use_time BETWEEN MY_BGTM AND MY_EDTM;
					
				REPLACE INTO sys_statistics_appuse 
					(cust_id,bgtm,edtm,app_type,cust_name,ehr_agent_type,manager_number,manager_appuse,manager_pcuse,employee_number,employee_appuse) VALUES
					(MY_CUSTID,MY_BGTM,MY_EDTM,MY_APPTYPE,MY_CUSTNAME,MY_AGTTYPE,IFNULL(MY_MNG_NUM,0),IFNULL(MY_MNG_APPUSE,0),IFNULL(MY_MNG_PCUSE,0),IFNULL(MY_EMP_NUM,0),IFNULL(MY_EMP_APPUSE,0));
					
				DELETE FROM tmp_sys_statistics_appuser_custlist WHERE ID = CUST_CT AND VERSION_CODE = I_VERSION_CODE;
			END IF;
			SET CUST_CT = CUST_CT + 1;
		END WHILE;
	END IF;
	SET ST = 1;
END;

