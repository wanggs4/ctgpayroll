create procedure SP_ATT_GET_SALA_PROG(IN i_emp     bigint, IN eddt date, IN prog_type int, IN prog_id bigint,
                                      IN MY_SONVER int, OUT my_sala_prog_value decimal(13, 3))
  comment '得到某员工（emp）某段时间内(bgdt->eddt)的某个薪酬项目(prog_type:prog_id)的值(my_sala_'
  BEGIN
DECLARE IS_NEED_FIND_PROG,i_custid,i_deptid,my_max_enabletime BIGINT;
DECLARE my_sala_prog VARCHAR(500);
DECLARE my_adj_id BIGINT;
DECLARE i_version_code VARCHAR(50);
SET i_version_code = UUID();
SET @i_version_code = i_version_code;
/*
	变量说明：
	prog_type
		1	考勤设置中的排班薪酬项目
		2	考勤设置中迟到早退薪酬项目
		3	考勤设置中旷工薪酬项目
		4	加班设置中的薪酬项目
		5 	假期设置中的薪酬项目

	DROP TABLE IF EXISTS  `TMP_PROG_VALUE`;
	CREATE TEMPORARY TABLE IF NOT EXISTS `TMP_PROG_VALUE` (
		COL_VALUE DECIMAL(13,3) NOT NULL DEFAULT 0
	)ENGINE = MEMORY;
*/
#	delete from  TMP_PROG_VALUE where version_code = i_version_code;
	
	#初始化
	SET my_sala_prog_value = 0;
	
	SELECT DISTINCT CUST_ID,DEPT_ID INTO i_custid,i_deptid FROM EMP_BASE_INFO WHERE EMP_ID = i_emp;
	
	CASE prog_type
	WHEN 1 THEN	#考勤设置中的排班薪酬项目
		SELECT 2,a.arrange_sala_prog 
			INTO IS_NEED_FIND_PROG,my_sala_prog 
		FROM att_set_schema_new a
		WHERE att_id = prog_id;		
	WHEN 2 THEN	#考勤设置中缺勤薪酬项目
		SELECT a.le_fine_single_com,a.arrange_sala_prog,a.le_fine_single_money 
			INTO IS_NEED_FIND_PROG,my_sala_prog ,my_sala_prog_value
		FROM att_set_schema_new a
		WHERE att_id = prog_id;		
	WHEN 3 THEN	#考勤设置中旷工薪酬项目
		SELECT a.dayoff_fine_single_com,a.arrange_sala_prog,a.dayoff_fine_single_money 
			INTO IS_NEED_FIND_PROG,my_sala_prog,my_sala_prog_value
		FROM att_set_schema_new a
		WHERE att_id = prog_id;		
	WHEN 4 THEN	#加班
		SELECT 2,sala_prog 
			INTO IS_NEED_FIND_PROG,my_sala_prog 
		FROM att_set_overtime_new a
		WHERE ot_id=prog_id;
	WHEN 5 THEN	#假期
		SELECT 2,sala_prog 
			INTO IS_NEED_FIND_PROG,my_sala_prog 
		FROM att_set_holiday 
		WHERE hol_id=prog_id AND SON_VER = MY_SONVER;
	ELSE
		SET my_sala_prog_value = 0;
	END CASE;
	
	IF IS_NEED_FIND_PROG = 2 AND my_sala_prog IS NOT NULL AND my_sala_prog <> '' THEN
		#得到期间的生效薪酬的操作时间
		SELECT MAX(enable_time) INTO my_max_enabletime FROM emp_salary_adj a where emp_id =i_emp and enable_time <= cast(replace(eddt,'-','') as unsigned) and a.is_delete=0 and a.is_enable=1;
		SELECT MAX(adj_id) INTO my_adj_id FROM emp_salary_adj WHERE emp_id =i_emp and enable_time = my_max_enabletime and is_delete=0 and is_enable=1;
		
		#取得薪酬项目值
		SET @my_sala_prog = my_sala_prog; 
		SET @my_adj_id = my_adj_id;
		SET @i_emp = i_emp;
		SET @SQL1 = CONCAT('INSERT INTO TMP_PROG_VALUE SELECT ''',@i_version_code,''',',@my_sala_prog,' FROM emp_salary_adj WHERE adj_id=',@my_adj_id,';');
		IF @my_sala_prog IS NOT NULL AND @my_adj_id IS NOT NULL THEN
			PREPARE stmt1 FROM @SQL1;
			EXECUTE stmt1 ;
			DEALLOCATE PREPARE stmt1;
		END IF;
		SELECT COL_VALUE INTO my_sala_prog_value FROM TMP_PROG_VALUE where version_code = i_version_code limit 1;
	END IF;
	delete from  TMP_PROG_VALUE where version_code = i_version_code;
	IF my_sala_prog_value IS NULL THEN SET my_sala_prog_value = 0 ; END IF;
	
END;

