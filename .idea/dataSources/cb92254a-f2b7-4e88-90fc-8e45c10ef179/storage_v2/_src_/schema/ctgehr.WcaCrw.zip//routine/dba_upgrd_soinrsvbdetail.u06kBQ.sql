create procedure DBA_UPGRD_SOINRSVBDETAIL()
  comment '转换数据专用，用后删除：用于将soin_receivable_detail表里的跨月数据拆分成多条'
  BEGIN
DECLARE CT,MXCT,MON_CT BIGINT;
DECLARE THIS_DETAILID BIGINT UNSIGNED;
DECLARE THIS_MONTH_STR VARCHAR(50);
DECLARE THIS_PAMT_ALL,THIS_EAMT_ALL,SINGLE_PAMT,SINGLE_EAMT DECIMAL(12,2);
DECLARE BGYM,EDYM DATE;
	DROP TABLE IF EXISTS tmp_soin_rsvb_detail;
	CREATE TABLE IF NOT EXISTS tmp_soin_rsvb_detail as
		SELECT * FROM `soin_receivable_detail` WHERE `receivable_ym` LIKE '%-%';
	ALTER TABLE `tmp_soin_rsvb_detail`
		ADD COLUMN `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT FIRST,
		ADD PRIMARY KEY (`id`);
	SET CT=0,MXCT=0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_soin_rsvb_detail;
	WHILE CT <= MXCT AND CT > 0 DO
		SET THIS_MONTH_STR=NULL,THIS_DETAILID=NULL,THIS_PAMT_ALL=NULL,THIS_EAMT_ALL=NULL;
		SELECT A.receivable_ym,A.detail_id,A.p_amt,A.e_amt 
			INTO THIS_MONTH_STR,THIS_DETAILID,THIS_PAMT_ALL,THIS_EAMT_ALL
		FROM tmp_soin_rsvb_detail A WHERE A.id = CT;
		IF THIS_DETAILID IS NOT NULL THEN
			SET BGYM=NULL,EDYM=NULL;
			SET BGYM = CONCAT(LEFT(THIS_MONTH_STR,4),'-',MID(THIS_MONTH_STR,5,2),'-01');
			SET EDYM = CONCAT(MID(THIS_MONTH_STR,8,4),'-',RIGHT(THIS_MONTH_STR,2),'-01');
			SET MON_CT = 0;
			WHILE BGYM <= EDYM DO
				SET MON_CT = MON_CT + 1;
				SET BGYM = DATE_ADD(BGYM,INTERVAL 1 MONTH);
			END WHILE;
			
			SET BGYM = CONCAT(LEFT(THIS_MONTH_STR,4),'-',MID(THIS_MONTH_STR,5,2),'-01');
			SET SINGLE_PAMT = ROUND(THIS_PAMT_ALL / MON_CT,2);
			SET SINGLE_EAMT = ROUND(THIS_EAMT_ALL / MON_CT,2);
			WHILE BGYM <= EDYM DO
				INSERT INTO soin_receivable_detail (su_ym,su_months,rule_id,category,product_id,product_name,ehr_cust_id,ehr_emp_id,id_card_num,hro_cust_id,receivable_ym,service_mon,soin_city,p_amt,p_base,p_ratio,p_additional_amt,e_amt,e_base,e_ratio,e_additional_amt,is_receivable,su_ym,su_months,pro_base_type,creator_id,creator,creat_time,remark)
					SELECT THIS_MONTH_STR,MON_CT,rule_id,category,product_id,product_name,ehr_cust_id,ehr_emp_id,id_card_num,hro_cust_id,CONCAT(LEFT(REPLACE(BGYM,'-',''),6)),service_mon,soin_city,SINGLE_PAMT,p_base,p_ratio,p_additional_amt,SINGLE_EAMT,e_base,e_ratio,e_additional_amt,is_receivable,su_ym,su_months,pro_base_type,creator_id,creator,creat_time,remark
					FROM soin_receivable_detail
					WHERE detail_id=THIS_DETAILID;
				SET BGYM = DATE_ADD(BGYM,INTERVAL 1 MONTH);
			END WHILE;
			
			DELETE FROM soin_receivable_detail WHERE detail_id = THIS_DETAILID;
		END IF;
		SET CT = CT + 1 ;
	END WHILE;
END;

