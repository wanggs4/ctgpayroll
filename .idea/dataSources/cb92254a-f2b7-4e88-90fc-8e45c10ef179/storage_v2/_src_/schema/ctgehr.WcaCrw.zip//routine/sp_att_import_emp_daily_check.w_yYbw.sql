create procedure SP_ATT_IMPORT_EMP_DAILY_CHECK(IN MY_VERSION_CODE bigint unsigned)
  comment '导入员工时用于调用执行日报'
  BEGIN
DECLARE CT,MXCT,MY_EMPID,MY_CUSTID,MY_YM,MY_STID BIGINT UNSIGNED;
DECLARE BGDT,EDDT,MY_CHECKTIME,MON_BGDT,MON_EDDT DATE;
DECLARE MY_STATE INT;

		truncate table tmp_att_import_emp_daily_check;
		#日报
		INSERT INTO tmp_att_import_emp_daily_check (EMP_ID,DT)
			SELECT DISTINCT A.EMP_ID,A.DR_BGDT
			FROM att_import_emp_daily_check A
			WHERE A.STATE=0
			ORDER BY A.ID
			LIMIT 300000;
			
#		TRUNCATE TABLE	tmp_log_test;
		
		SET CT=0,MXCT=0;
		SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_att_import_emp_daily_check A ;
		
		WHILE CT <= MXCT AND CT > 0 DO
			SET MY_EMPID = NULL, BGDT = NULL, EDDT = NULL;
			SELECT A.EMP_ID,A.DT,A.DT INTO MY_EMPID,BGDT,EDDT
			FROM tmp_att_import_emp_daily_check A 
			WHERE A.ID=CT  ;
			
			IF MY_EMPID IS NOT NULL THEN 
				#CALL SP_ATT_DAILY_ARRANGE(BGDT,EDDT,NULL,NULL,MY_EMPID,NULL);
				CALL SP_ATT_DAILY_CHECK(BGDT,EDDT,NULL,NULL,MY_EMPID,NULL);
				CALL SP_ATT_DAILY_OVER(BGDT,EDDT,NULL,NULL,MY_EMPID,NULL);
				CALL SP_ATT_DAILY_OVER_WITH_REST(BGDT,EDDT,NULL,MY_EMPID);
				
#				INSERT INTO tmp_log_test (`EMP_ID`,`BGDT`,`STATE`) VALUES (MY_EMPID,BGDT,1);
				
				UPDATE att_emp_detail A 
					LEFT JOIN att_over_apply_day B on A.emp_id=B.emp_id and A.dt=B.work_day
					LEFT JOIN att_over_apply C ON B.apply_id=C.apply_id
				SET A.is_have_over=1
				WHERE A.emp_id = MY_EMPID AND A.dt BETWEEN BGDT AND EDDT	AND B.work_hour > 0 AND C.state=1;
				
				UPDATE att_emp_detail A 
					LEFT JOIN att_hol_apply_day B on A.emp_id=B.emp_id and A.dt=B.hol_date
					LEFT JOIN att_hol_apply C ON B.apply_id=C.apply_id
				SET A.is_have_hol=1
				WHERE A.emp_id = MY_EMPID AND A.dt BETWEEN BGDT AND EDDT	AND B.hol_hours > 0 AND C.state=1;
				
				UPDATE att_import_emp_daily_check A 
				SET A.STATE=1,A.EXECUTE_TIME=NOW()
				WHERE A.EMP_ID=MY_EMPID AND A.DR_BGDT=BGDT;
				
				#DELETE FROM tmp_att_import_emp_daily_check WHERE ID=CT;
			END IF;
			SET CT = CT + 1 ;
		END WHILE;

END;

