create function FN_ATT_GET_REAL_DAY_HOURS_WITH_ATTID(bgtm time, edtm time, ATTID bigint unsigned)
  returns decimal(12, 2)
  comment '通过给出的两个时间和部门id得到实际一天内的发生时间'
  LABEL:BEGIN
DECLARE supper_mins,real_day_hours,i_flex_hour,DINNER_DEDUCTION DECIMAL(12,2);	
DECLARE is_have_supper,is_have_emp,bgst,edst,minunit,i_att_rule,IS_DINNER_COVERD INT;
DECLARE this_bgtm,this_edtm,supper_start_time,supper_end_time,i_na_start_time_1,i_na_end_time_1,i_na_start_time_2,i_na_end_time_2,mst,met,ast,aet DATETIME;
DECLARE TODAY,TOMORROW DATE;
set real_day_hours = 0;

	SET bgtm = FN_SYS_TMFMT_PURGE_SECOND(bgtm);
	SET edtm = FN_SYS_TMFMT_PURGE_SECOND(edtm);
	SET TODAY=DATE(NOW());
	SET TOMORROW = DATE_ADD(TODAY,INTERVAL 1 DAY);
	
	IF edtm < bgtm THEN
		SET this_bgtm = CONCAT(TODAY,' ',bgtm);
		SET this_edtm = CONCAT(TOMORROW,' ',edtm);
	ELSE
		SET this_bgtm = CONCAT(TODAY,' ',bgtm);
		SET this_edtm = CONCAT(TODAY,' ',edtm);
	END IF;
	
	IF (ATTID IS NOT NULL and this_bgtm<=this_edtm) THEN		
	#如果有部门且有出勤方案且初试时间小于等于结束时间时才开始计算
		#1 得到四个时间
		SELECT att_rule,flex_hour,
				CONCAT(TODAY,' ',b.na_start_time_1),CONCAT(TODAY,' ',b.na_end_time_1),
				CONCAT(TODAY,' ',b.na_start_time_2),CONCAT(TODAY,' ',b.na_end_time_2),
				CONCAT(TODAY,' ',morn_start_time),CONCAT(TODAY,' ',morn_end_time),
				CONCAT(TODAY,' ',aftn_start_time),CONCAT(TODAY,' ',aftn_end_time),b.le_fine_compute_unit
			INTO i_att_rule,i_flex_hour,
				i_na_start_time_1,i_na_end_time_1,
				i_na_start_time_2,i_na_end_time_2,
				mst,met,
				ast,aet,minunit
		FROM att_set_schema_new b 
		WHERE b.att_id=ATTID;
		
		#判断晚餐时段，如果第一个不可用时段晚于下班时间，那就是晚餐时段
		#如果如果第一个不可用时段不晚于下班时间，且第二个不可用时间晚于下班时间，那就是晚餐时段
		SET supper_start_time = NULL,i_na_start_time_2 = NULL;
		IF i_na_start_time_1 IS NOT NULL AND i_na_start_time_1 > aet THEN
			SET supper_start_time = i_na_start_time_1;
			SET supper_end_time = i_na_end_time_1;
		ELSEIF i_na_start_time_2 IS NOT NULL AND i_na_start_time_2 > aet THEN
			SET supper_start_time = i_na_start_time_2;
			SET supper_end_time = i_na_end_time_2;
		END IF;
		

		#晚餐时长,如果油晚餐时间那么就计算，否则为0
		IF supper_start_time IS NOT NULL THEN 
			SET supper_mins = ROUND(TIME_TO_SEC(TIMEDIFF(supper_end_time,supper_start_time)),0);
		ELSE
			SET supper_mins = 0;
		END IF;
		
		#如果i_flex_hour为空，也设为0
		if i_flex_hour is null then
			set i_flex_hour = 0;
		end if;
		
		#如果i_flex_hour大于0时，需要把aet追加上i_flex_hour的时间
		IF i_flex_hour>0 THEN
			SET aet = DATE_ADD(aet,INTERVAL i_flex_hour MINUTE);
		END IF;

		#弹性时间是否超过了晚餐时间
		#1.弹性结束后时间处于晚餐时间之间，那么时间从晚餐结束时间顺延晚餐开始时间到弹性后下班时间的时间
		#2.弹性结束后时间超出晚餐时间，那么时间从弹性后下班时间顺延晚晚餐时段时间
		IF supper_start_time IS NOT NULL AND aet > supper_start_time AND aet < supper_end_time THEN
			SET aet = DATE_ADD(supper_end_time,INTERVAL TIME_TO_SEC(TIMEDIFF(aet,supper_start_time)) SECOND);
		ELSEIF supper_start_time IS NOT NULL AND aet >= supper_end_time THEN
			SET aet = DATE_ADD(aet,INTERVAL TIME_TO_SEC(TIMEDIFF(supper_end_time,supper_start_time)) SECOND);
		END IF;

		#要计算晚餐时长扣减值
		IF this_edtm > supper_end_time THEN
			SET DINNER_DEDUCTION = ROUND(TIME_TO_SEC(TIMEDIFF(supper_end_time,supper_start_time))/60,0);
			SET IS_DINNER_COVERD = 1;
		ELSEIF this_edtm >= supper_start_time AND this_edtm <= supper_end_time THEN
			SET DINNER_DEDUCTION = ROUND(TIME_TO_SEC(TIMEDIFF(this_edtm,supper_start_time))/60,0);
			SET IS_DINNER_COVERD = 1;
		ELSE
			SET DINNER_DEDUCTION = 0;
			SET IS_DINNER_COVERD = 0;
		END IF;
		
		#晚餐标记
		SET is_have_supper = 0;

		#当坐班考勤时，考虑四个时间
		IF i_att_rule = 1 THEN
			#2 判断起止时间的情况 
				#this_bgtm
					#条件						目标值		目标所在时段
					#this_bgtm < mst					mst			bgst=1(上午)
					#mst <= this_bgtm <= met		this_bgtm			bgst=1	
					#met < this_bgtm < ast			ast			bgst=2（下午）
					#ast <= this_bgtm <= aet		this_bgtm			bgst=2
					#this_bgtm > aet					null			bgst=3(不在考勤时间内，返回0)
			IF (this_bgtm < mst) THEN
				SET this_bgtm = mst;
				SET bgst = 1;
			END IF;
			
			IF (mst <= this_bgtm and this_bgtm <= met) THEN
				SET bgst = 1;			
			END IF;
			
			IF (met < this_bgtm and this_bgtm < ast) THEN
				SET this_bgtm = ast;
				SET bgst = 2;			
			END IF;
			
			IF (ast <= this_bgtm and this_bgtm <= aet) THEN
				SET bgst = 2;
			END IF;
			
			IF (this_bgtm > aet) THEN
				SET bgst = 3;
				
			END IF;
				#this_edtm
					#this_edtm < mst					0				edst=3
					#mst <= this_edtm <= met		this_edtm			edst=1(上午)
					#met < this_edtm < ast			met			edst=1
					#ast <= this_edtm <= aet		this_edtm			edst=2（下午）
					#this_edtm > aet					aet			edst=2
			IF (this_edtm < mst) THEN
				SET edst = 3;
			END IF;
			
			IF (mst <= this_edtm and this_edtm <= met) THEN
				SET edst = 1;			
			END IF;
			
			IF (met < this_edtm and this_edtm < ast) THEN
				SET this_edtm = met;
				SET edst = 1;			
			END IF;
			
			IF (ast <= this_edtm and this_edtm <= aet) THEN
				SET edst = 2;
				#晚餐标记
				IF supper_start_time IS NOT NULL AND this_edtm >= supper_start_time THEN
					SET is_have_supper = 1;
				END IF;
			END IF;
			
			IF (this_edtm > aet) THEN
				SET this_edtm = aet;
				SET edst = 2;
			END IF;
#SELECT bgst,edst;
			IF (bgst=3 or edst=3) or (bgst=2 and edst=1) THEN		#给出的时间不在考勤范围内
				SET real_day_hours = 0 ;
			ELSEIF (bgst=edst and bgst<>3 and edst<>3) AND this_bgtm < aet THEN			#都在上午或都在下午
				SET real_day_hours = TIME_TO_SEC(timediff(this_edtm,this_bgtm))/60;
			ELSEIF (bgst<edst and bgst<>3 and edst<>3) THEN			#一个上午一个下午
				SET real_day_hours = TIME_TO_SEC(timediff(met,this_bgtm))/60 + TIME_TO_SEC(timediff(this_edtm,ast))/60 ;
			ELSE
				SET real_day_hours = 0;
			END IF;
			
#select 		real_day_hours;	
			#当发生时间超出了当天的理论工作时长，则替换为理论时长
			IF (real_day_hours > FN_ATT_GET_WORKHOURS(ATTID)*60) THEN
				SET real_day_hours = FN_ATT_GET_WORKHOURS(ATTID)*60;
			END IF;
		END IF;
	ELSE	#没有考勤或排班
		SET real_day_hours=TIME_TO_SEC(TIMEDIFF(this_edtm,this_bgtm))/60;
	END IF;
	
	IF IS_DINNER_COVERD = 1 AND this_edtm < aet THEN
		SET real_day_hours = real_day_hours - DINNER_DEDUCTION;
	END IF;
	
	IF real_day_hours < 0 OR real_day_hours IS NULL THEN
		SET real_day_hours = 0;
	END IF;
	
	RETURN real_day_hours;
END;

