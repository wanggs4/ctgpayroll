create procedure SP_ATT_DAILY_PAY(IN bgdt date, IN eddt date, IN custid bigint, IN deptid bigint, IN emp bigint)
  comment '日报钱数计算'
  BEGIN
#PART 1  初始化	
DECLARE MY_SONVER,h_is_sala_compute,is_have_hol,stat,ct,mxct,dttype,i_dttype,t_dttype,i_isdoff,is_have_att,app_cnt,app_mxcnt int;
DECLARE a_att_id,i_emp,i_deptid,i_custid,i_hol_id, i_applyid bigint;
DECLARE init_bgdt,i_lvdate,i_entry_date date;
DECLARE i_lm,i_em,MY_SALA_PROG,h_hol_sala,i_hol_hours,hpay,i_daily_hour,i_days DECIMAL(12,2);
DECLARE i_version_code VARCHAR(50);
DECLARE i_att_rule,a_le_fine,a_le_fine_single_com,a_dayoff_fine,a_dayoff_fine_single_com INT;
DECLARE MY_DAYOFF_FINE,MY_LATE_FINE,MY_EARLY_FINE,a_le_fine_single_money,a_le_fine_compute_factor,a_dayoff_half_fine_single_money,a_dayoff_fine_single_money,a_dayoff_fine_compute_factor	DECIMAL(12,2);

	SET i_version_code = UUID();
	SET @i_version_code = i_version_code;
	set sql_mode='';
	SET init_bgdt = bgdt;
	#创建用于存放人名单的临时表
/*	DROP TABLE IF EXISTS TMP_VALUE_DP_DP_DP;
	CREATE TEMPORARY TABLE TMP_VALUE_DP_DP (
		COL_VALUE varchar(50) 
	)engine=memory;
	
	DROP TABLE IF EXISTS TMP_APPLY_ID_DP_DP;
	CREATE TEMPORARY TABLE TMP_APPLY_ID_DP_DP (
		id bigint unsigned not null AUTO_INCREMENT,
		apply_id bigint unsigned ,
  		primary key (id)
	)engine=memory;
	
	DROP TABLE IF EXISTS tmp_att_emp_list_DP_DP;
	CREATE TEMPORARY TABLE tmp_att_emp_list_DP_DP (
		id bigint unsigned not null AUTO_INCREMENT,
		emp_id bigint unsigned ,
		dept_id bigint unsigned ,
		cust_id bigint unsigned ,
  		primary key (ID),
  		INDEX `idx_cust_id` (`cust_id`),
  		INDEX `idx_dept_id` (`dept_id`)
	)engine=memory;
*/	
	/*
	stat 1 emp		emp is not null 按员工查						
	stat 2 detp		deptid is not null and emp is null 按部门查
	stat 3 custid  custid is not null and deptid is null and emp is null; 按公司查
	stat 4 all		custid is null and deptid is null and emp is null  全局查
	*/
	if (custid is null and deptid is null and emp is null) then
		set stat=4;
	elseif (custid is not null and deptid is null and emp is null) then
		set stat=3;
	elseif (deptid is not null and emp is null) then
		set stat=2;
	elseif (emp is not null) then
		set stat=1;
	end if;
	#根据不同的参数输入情况初始化要遍历的员工列表	
	delete from  tmp_att_emp_list_DP WHERE version_code=i_version_code;
	case stat
	when 1 then
		insert into tmp_att_emp_list_DP (version_code,emp_id,dept_id,cust_id)  
		select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
		from emp_base_info a
		where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null and a.is_delete=0 
		and a.emp_id=emp and a.dept_id is not null;
	when 2 then
		insert into tmp_att_emp_list_DP (version_code,emp_id,dept_id,cust_id)  
		select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
		from emp_base_info a
		where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null and a.is_delete=0 
		and a.dept_id=deptid and a.dept_id is not null;
	when 3 then
		insert into tmp_att_emp_list_DP (version_code,emp_id,dept_id,cust_id)  
		select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
		from emp_base_info a
		where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null and a.is_delete=0 
		and a.cust_id=custid and a.dept_id is not null;	
	when 4 then
		insert into tmp_att_emp_list_DP (version_code,emp_id,dept_id,cust_id)  
		select distinct i_version_code,a.emp_id,a.dept_id,a.cust_id 
		from emp_base_info a
		where (a.boss_level<>1 or a.boss_level is null) and a.emp_state is not null and a.is_delete=0  and a.dept_id is not null;	
	end case;	
#select * from tmp_att_emp_list_DP;
#PART 2 计算日报相关的钱数	
	#开始遍历员工
	SET ct = 0;
	SET mxct = 0;
	select min(if(id is null,0,id)),max(if(id is null,0,id)) into ct,mxct from tmp_att_emp_list_DP where version_code = i_version_code;
	WHILE (ct <= mxct and ct>0) DO															#LOOP1 ct
		#初始化循环变量
		SET i_emp = NULL ;
		SET i_deptid = NULL ;
		SET i_custid = NULL ;
		SET i_lvdate = NULL ;
		SET bgdt = init_bgdt ;
		#得到员工和相关的部门、企业id
		select emp_id,dept_id,cust_id into i_emp,i_deptid,i_custid from tmp_att_emp_list_DP where id=ct and version_code = i_version_code;
		IF i_emp IS NOT NULL THEN
			#得到离职日期
			select entry_date,leave_date into i_entry_date,i_lvdate from emp_post where emp_id=i_emp;
			#开始循环日期
			WHILE (bgdt<=eddt) DO														#LOOP2 bgdt
				if i_entry_date<= bgdt AND i_entry_date IS NOT NULL and (i_lvdate is null or i_lvdate >=bgdt) then
					#初始化循环变量
					SET is_have_att = NULL;
					SET is_have_hol = NULL;
					#有没有考勤信息
					select count(*) into is_have_att from att_emp_detail where emp_id=i_emp and dt=bgdt;
					#有没有请假信息
					select count(*) into is_have_hol from att_hol_apply_day where emp_id=i_emp and hol_date=bgdt;
		#select is_have_att,is_have_over,is_have_hol;
		
					if is_have_att>0 then		#r如果有考勤记录，那么开始计算
								
		#********1 计算考勤
						#初始化变量;
						SET i_dttype = NULL;
						SET i_isdoff = NULL;
						SET i_lm = NULL;
						SET i_em = NULL;
						SET i_days = NULL;
						
						SET a_le_fine = NULL;
						SET a_le_fine_single_com = NULL;
						SET a_le_fine_single_money = NULL;
						SET a_le_fine_compute_factor = NULL;
						SET a_dayoff_fine = NULL;
						SET a_dayoff_fine_single_com = NULL;
						SET a_dayoff_half_fine_single_money = NULL;
						SET a_dayoff_fine_single_money = NULL;
						SET a_dayoff_fine_compute_factor = NULL;
						SET a_att_id = NULL;
		
						#得到员工当天的考勤信息
						select date_type,is_dayoff,late_mins,early_mins,att_rule
							into i_dttype,i_isdoff,i_lm,i_em,i_att_rule
						from att_emp_detail a where emp_id=i_emp and dt=bgdt;
						
						#读出考勤设置
						IF i_att_rule = 1 THEN
							SELECT A.att_id INTO a_att_id
							FROM att_rel_schema_dept B
								LEFT JOIN att_set_schema_new A ON B.schema_id=A.att_id
							WHERE A.is_delete=0 AND A.`status`=1 AND B.dept_id=i_deptid;
						ELSEIF i_att_rule = 3 THEN
							SELECT A.att_id INTO a_att_id
							FROM att_arrange_schedual A
							WHERE A.emp_id = i_emp AND A.dt = bgdt LIMIT 1;						
						END IF;
						
						IF a_att_id IS NOT NULL THEN
							#读出考勤设置
							select b.le_fine,b.le_fine_single_com,b.le_fine_single_money,
										b.le_fine_compute_factor,
									 b.dayoff_fine,b.dayoff_fine_single_com,b.dayoff_half_fine_single_money,
										b.dayoff_fine_single_money,b.dayoff_fine_compute_factor
								into a_le_fine,a_le_fine_single_com,a_le_fine_single_money,
									  #迟到早退扣薪（0关 1开） #1迟到早退单次扣减 2迟到早退计算扣薪 #迟到早退单次扣薪x元
										a_le_fine_compute_factor,
										#迟到早退扣减几倍的薪酬项目
									 a_dayoff_fine,a_dayoff_fine_single_com,a_dayoff_half_fine_single_money,
									 #旷工扣薪（0关 1开） #1旷工单次扣减 2旷工计算扣薪 #旷工半天单次扣薪x元
										a_dayoff_fine_single_money,a_dayoff_fine_compute_factor
										#旷工单次扣薪x元 #旷工扣减几倍的薪酬项目
							from att_set_schema_new b
							where b.att_id = a_att_id and b.is_delete=0 and b.`status`=1;
								
							#计算应工作天数
							SET i_days = FN_ATT_GET_WORKDAYS(init_bgdt,eddt,i_deptid,1);
							IF i_att_rule = 1 THEN
								#计算一天工作时长
								SET i_daily_hour = FN_ATT_GET_WORKHOURS(i_deptid);
							ELSEIF i_att_rule = 3 THEN
								SET i_daily_hour = FN_ATT_GET_ARR_WORKHOURS(i_emp,bgdt);
							END IF;
							
							#矿工扣款
							IF i_isdoff > 0 THEN
								#开启扣款
								IF a_dayoff_fine = 1 THEN
									#1旷工单次扣减 
									IF a_dayoff_fine_single_com = 1 THEN
										#整天
										IF i_isdoff = 1 THEN
											SET MY_DAYOFF_FINE = a_dayoff_fine_single_money;
										#半天
										ELSEIF i_isdoff = 2 THEN
											SET MY_DAYOFF_FINE = a_dayoff_half_fine_single_money;
										END IF;	
										SET MY_LATE_FINE = 0;
										SET MY_EARLY_FINE = 0;
									#2旷工计算扣薪
									ELSEIF a_dayoff_fine_single_com = 2 THEN
										CALL SP_ATT_GET_SALA_PROG(i_emp,bgdt,3,a_att_id,MY_SALA_PROG);
										IF i_isdoff = 1 THEN
											SET MY_DAYOFF_FINE = ROUND(MY_SALA_PROG * a_dayoff_fine_compute_factor / i_days,2);
										ELSEIF i_isdoff = 2 THEN
											SET MY_DAYOFF_FINE = ROUND(MY_SALA_PROG * a_dayoff_fine_compute_factor / i_days /2,2);
										END IF;
										SET MY_LATE_FINE = 0;
										SET MY_EARLY_FINE = 0;
									END IF;
								ELSE
									SET MY_DAYOFF_FINE = 0;
									SET MY_LATE_FINE = 0;
									SET MY_EARLY_FINE = 0;
								END IF;
							#迟到早退扣款
							ELSEIF i_isdoff = 0 AND (i_lm > 0 OR i_em > 0) THEN
								#迟到
								IF i_lm > 0 THEN
									#开启了迟到早退扣款
									IF a_le_fine = 1 THEN
										#1迟到早退单次扣减 
										IF a_le_fine_single_com = 1 THEN
											SET MY_LATE_FINE = a_le_fine_single_money;
										#2迟到早退计算扣薪
										ELSEIF a_le_fine_single_com = 2 THEN
											CALL SP_ATT_GET_SALA_PROG(i_emp,bgdt,2,a_att_id,MY_SALA_PROG);
											SET MY_LATE_FINE = ROUND(MY_SALA_PROG * a_le_fine_compute_factor / i_days / i_daily_hour / 60 * i_lm,2);	
										END IF;
									ELSE
										SET MY_LATE_FINE = 0;
									END IF;
								ELSE
									SET MY_LATE_FINE = 0;
								END IF;
								
								#早退
								IF i_em > 0 THEN
									#开启了迟到早退扣款
									IF a_le_fine = 1 THEN
										#1迟到早退单次扣减 
										IF a_le_fine_single_com = 1 THEN
											SET MY_EARLY_FINE = a_le_fine_single_money;
										#2迟到早退计算扣薪
										ELSEIF a_le_fine_single_com = 2 THEN
											CALL SP_ATT_GET_SALA_PROG(i_emp,bgdt,2,a_att_id,MY_SALA_PROG);
											SET MY_EARLY_FINE = ROUND(MY_SALA_PROG * a_le_fine_compute_factor / i_days / i_daily_hour / 60 * i_em,2);	
										END IF;
									ELSE
										SET MY_EARLY_FINE = 0;
									END IF;
								ELSE
									SET MY_EARLY_FINE = 0;
								END IF;
								
								SET MY_DAYOFF_FINE = 0;
								
							#没有迟到早退和矿工
							ELSE
								SET MY_DAYOFF_FINE = 0;
								SET MY_LATE_FINE = 0;
								SET MY_EARLY_FINE = 0;
							END IF;
							
							IF MY_DAYOFF_FINE IS NULL THEN SET MY_DAYOFF_FINE = 0 ; END IF;
							IF MY_LATE_FINE IS NULL THEN SET MY_LATE_FINE = 0 ; END IF;
							IF MY_EARLY_FINE IS NULL THEN SET MY_EARLY_FINE = 0 ; END IF;
							
							UPDATE att_emp_detail A 
							SET A.dock_pay=MY_DAYOFF_FINE, A.dock_pay_late=MY_LATE_FINE, A.dock_pay_early=MY_EARLY_FINE
							WHERE EMP_ID=i_emp AND DT = bgdt;
						END IF;
					end if;
		#********1 考勤 end
		
		#********3 计算请假
					IF is_have_hol>0 THEN
						#把当天所有的apply_id写入临时表
						INSERT INTO TMP_APPLY_ID_DP (version_code,APPLY_ID) SELECT DISTINCT i_version_code,APPLY_ID FROM att_hol_apply_day WHERE emp_id = i_emp and hol_date = bgdt;
						SET app_cnt = 0;
						SET app_mxcnt = 0;
						SELECT MIN(ID),MAX(ID) INTO app_cnt,app_mxcnt FROM TMP_APPLY_ID_DP  where version_code = i_version_code;
						WHILE (app_cnt<=app_mxcnt) DO	#遍历每个apply_id
							#初始化循环变量
							SET i_applyid = NULL;
							SET i_hol_hours = NULL;
							SET i_hol_id = NULL;
							SET h_is_sala_compute = NULL;
							SET h_hol_sala = NULL;
							SET MY_SALA_PROG = NULL;
							SET i_days = NULL;
							SET i_daily_hour = NULL;
							SET i_hol_hours = NULL;
							SET h_hol_sala = NULL;
							#得到apply_id
							SELECT APPLY_ID INTO i_applyid FROM TMP_APPLY_ID_DP WHERE ID = app_cnt and version_code = i_version_code;
			
							#1	得到当天请假信息
							SELECT hol_hours,hol_id,A.son_ver,date_type INTO i_hol_hours,i_hol_id,MY_SONVER,i_dttype
							FROM att_hol_apply_day A
							WHERE emp_id = i_emp and hol_date = bgdt AND apply_id=i_applyid;
														
							#型取得 h_is_sala_compute，hol_sala_rate，h_sala_prog
							SELECT is_sala_compute,
									hol_sala
							INTO	h_is_sala_compute,				#是否计算薪酬（0否 1是）
									h_hol_sala
							FROM att_set_holiday A
							WHERE hol_id= i_hol_id AND A.son_ver=MY_SONVER;				
						
						
							IF h_is_sala_compute=1 THEN     #如果计算薪酬
								/*
								请假扣薪金额计算方法：
									扣薪金额 = 薪酬项目/该月工作日/每日工作时数*请假时数*工资比例
									hpay = MY_SALA_PROG/i_days/i_daily_hour*i_hol_hours*h_hol_sala
								*/
								#1 得到薪酬项目值MY_SALA_PROG
								CALL SP_ATT_GET_SALA_PROG(i_emp,bgdt,5,i_hol_id,MY_SALA_PROG);
								#2 得到本月工作天数 i_days
								SET i_days = FN_ATT_GET_HOL_WORKDAYS(init_bgdt,eddt,i_deptid,i_hol_id);
								#3 得到一天工作时长 
								SELECT ATT_RULE INTO i_att_rule FROM att_emp_detail A WHERE A.emp_id = i_emp AND dt = bgdt;
								IF i_att_rule > 0 AND i_att_rule IS NOT NULL THEN
									IF i_att_rule = 1 THEN
										#计算一天工作时长
										SET i_daily_hour = FN_ATT_GET_WORKHOURS(i_deptid);
									ELSEIF i_att_rule = 3 THEN
										SET i_daily_hour = FN_ATT_GET_ARR_WORKHOURS(i_emp,bgdt);
									END IF;
									#计算出结果
									SET hpay = MY_SALA_PROG/i_days/i_daily_hour*i_hol_hours*h_hol_sala/100;
								ELSE
									SET hpay=0;
								END IF;
							ELSE
								SET hpay=0;
							END IF;
		#SELECT 	i_emp,init_bgdt,eddt,i_deptid,i_hol_id,MY_SALA_PROG,i_days,i_daily_hour,i_hol_hours,h_hol_sala;				
							UPDATE att_hol_apply_day SET pay_money= hpay WHERE emp_id = i_emp and hol_date = bgdt AND apply_id=i_applyid and is_delete=0;
							
							DELETE FROM TMP_APPLY_ID_DP WHERE ID = app_cnt and version_code = i_version_code;

							SET app_cnt = app_cnt + 1;
						END WHILE;
					END IF;
	#********3 end
				end if;
				#如果有离职时间，并且当天是离职日期的话，那么循环到此结束；如果没有离职时间或者当天不是离职那天，bgdt继续递增。
				IF (i_lvdate = bgdt) THEN
					SET bgdt = date_add(eddt,interval 1 day);
				ELSE
					SET bgdt = date_add(bgdt,interval 1 day);
				END IF;	
			END WHILE;																		#LOOP2 bgdt
			delete from  tmp_att_emp_list_DP where version_code = i_version_code and id = ct;
		END IF;
		SET ct = ct + 1;
	END WHILE;																				#loop1
END;

