create procedure DBA_TMP_INIT_ROLEMENUREL()
  comment '初始化角色菜单关系表，将原有的单点关联，变为级联关联'
  BEGIN

END;

