create procedure SP_ICSS_ST_EMP_GONGCHU(IN MY_BGDT date, IN MY_EMP bigint unsigned)
  comment '员工公出情况表'
  BEGIN
DECLARE I_VERSION_CODE VARCHAR(50);
DECLARE CT,MXCT,MY_EMP_ID,MY_DEPT_ID BIGINT UNSIGNED;
DECLARE MY_DEPT_FULL_NAME,MY_EMP_CODE,MY_EMP_NAME VARCHAR(500);
DECLARE MY_ENTRY_DATE,MY_LEAVE_DATE,MY_EDDT DATE;
DECLARE MY_THIS_YEAR,THIS_YEAR_MON,MY_YEAR_MON_BG INT;

/*
入参说明：
MY_BGDT 入组人员在职时间范围和计算的时间范围的开始日期，NULL时取前天这一年的一月一日
MY_EMP 人员id，只为重跑某个人时使用，平时给NULL既跑所有
所有时间范围结束日期均为前天
*/

	SET I_VERSION_CODE = UUID();
	SET MY_EDDT = DATE(DATE_ADD(NOW(),INTERVAL -2 DAY));
	SET MY_THIS_YEAR = YEAR(MY_EDDT);
	
	#入参MY_BGDT 校验
	#1.如果为空，设为前天的同年一月一日
	IF MY_BGDT IS NULL THEN
		SET MY_BGDT = CONCAT(YEAR(MY_EDDT),'-01-01');
	ELSE
		#2.如果不为空，但是年分和前天的年份不一致，改为前天同年的一月一日
		IF YEAR(MY_BGDT) <> MY_THIS_YEAR THEN
			SET MY_BGDT = CONCAT(YEAR(MY_EDDT),'-01-01');
		END IF;
	END IF;
	
	SET MY_YEAR_MON_BG = CAST(LEFT(REPLACE(MY_BGDT,'-',''),6) AS UNSIGNED);
	SET THIS_YEAR_MON = CAST(LEFT(REPLACE(MY_EDDT,'-',''),6) AS UNSIGNED);

	IF MY_EMP IS NULL THEN
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
				LEFT JOIN att_hol_apply_day D ON A.emp_id=D.emp_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT)
				AND D.is_year_hol=10 AND D.hol_date LIKE CONCAT(MY_THIS_YEAR,'-%')
			GROUP BY A.emp_id;			
	ELSE
		TRUNCATE TABLE tmp_icss_st_emp_list;
		INSERT INTO tmp_icss_st_emp_list (version_code,emp_id,emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
			SELECT I_VERSION_CODE,A.emp_id,B.emp_code,A.emp_name,B.entry_date,B.leave_date,A.dept_id,C.dept_full_name
			FROM emp_base_info A
				LEFT JOIN emp_post B ON A.emp_id=B.emp_id
				LEFT JOIN dept_info C ON A.dept_id=C.dept_id
				LEFT JOIN att_hol_apply_day D ON A.emp_id=D.emp_id
			WHERE A.cust_id=2162554862743552 AND A.is_delete=0 AND A.emp_state IS NOT NULL
				AND B.emp_code IS NOT NULL AND B.entry_date IS NOT NULL 
				AND B.entry_date <= MY_EDDT AND (B.leave_date IS NULL OR B.leave_date >= MY_BGDT)
				AND D.is_year_hol=10 AND D.hol_date LIKE CONCAT(MY_THIS_YEAR,'-%')
				AND A.emp_id=MY_EMP
			GROUP BY A.emp_id;			
	END IF;
	
	SET CT = 0, MXCT = 0;

	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_icss_st_emp_list A WHERE A.version_code = I_VERSION_CODE;
	WHILE CT <= MXCT AND CT > 0 DO
		SET MY_EMP_ID=NULL,MY_DEPT_ID=NULL,MY_DEPT_FULL_NAME=NULL,MY_EMP_CODE=NULL,MY_EMP_NAME=NULL,MY_ENTRY_DATE=NULL,MY_LEAVE_DATE=NULL;

		SELECT A.emp_id,A.emp_code,A.emp_name,A.entry_date,A.leave_date,A.dept_id,A.dept_full_name
			INTO MY_EMP_ID,MY_EMP_CODE,MY_EMP_NAME,MY_ENTRY_DATE,MY_LEAVE_DATE,MY_DEPT_ID,MY_DEPT_FULL_NAME
		FROM tmp_icss_st_emp_list A 
		WHERE A.version_code = I_VERSION_CODE AND A.id=CT; 

		IF MY_EMP_ID IS NOT NULL THEN
			DELETE A.* 
			FROM icss_st_emp_gongchu A 
			WHERE A.emp_id=MY_EMP_ID AND A.this_yearmon BETWEEN MY_YEAR_MON_BG AND THIS_YEAR_MON;
			
			REPLACE INTO icss_st_emp_gongchu 
				(emp_id,this_yearmon,all_hours,all_days,detail,
					emp_code,emp_name,entry_date,leave_date,dept_id,dept_full_name)
				SELECT A.emp_id,LEFT(REPLACE(A.hol_date,'-',''),6),SUM(A.hol_hours),SUM(A.hol_days),GROUP_CONCAT(DISTINCT B.start_time,'~',B.end_time,' 公出',B.hol_hours),
					MY_EMP_CODE,MY_EMP_NAME,MY_ENTRY_DATE,MY_LEAVE_DATE,MY_DEPT_ID,MY_DEPT_FULL_NAME
				FROM att_hol_apply_day A
					LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
				WHERE A.hol_date BETWEEN MY_BGDT AND MY_EDDT
					AND A.is_year_hol=10 AND A.hol_hours>0 AND A.emp_id=MY_EMP_ID
				GROUP BY A.EMP_ID,LEFT(REPLACE(A.hol_date,'-',''),6);
		END IF;
		SET CT = CT + 1;
	END WHILE;
END;

