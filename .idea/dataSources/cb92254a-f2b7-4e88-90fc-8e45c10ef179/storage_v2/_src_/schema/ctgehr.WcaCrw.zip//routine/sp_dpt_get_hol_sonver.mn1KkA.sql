create procedure SP_DPT_GET_HOL_SONVER(IN  MY_EMPID  bigint unsigned, IN THIS_DATE date, IN MY_HOLID bigint unsigned,
                                       OUT MY_SONVER int)
  comment '通过emp_id，日期和假期holid来定位某个人对于某个假期的sonver'
  BEGIN
DECLARE MY_DEPTTYPE,IS_HAVE_EMP,IS_HAVE_HOL INT;

	SET MY_SONVER = NULL;
	IF MY_EMPID IS NOT NULL AND THIS_DATE IS NOT NULL AND MY_HOLID IS NOT NULL THEN
		SELECT COUNT(*) INTO IS_HAVE_EMP FROM emp_base_info WHERE EMP_ID=MY_EMPID;
		SELECT COUNT(*) INTO IS_HAVE_HOL FROM att_set_holiday_main WHERE HOL_ID=MY_HOLID;
		IF IS_HAVE_HOL > 0 AND IS_HAVE_EMP > 0 THEN

			SET MY_DEPTTYPE=10;			
			WHILE MY_SONVER IS NULL AND MY_DEPTTYPE > 0 DO
				SELECT A.son_ver INTO MY_SONVER
				FROM log_attsetting_change A 
					LEFT JOIN att_rel_holiday_depts B ON A.setting_id=B.hol_id AND A.son_ver=B.son_ver
					LEFT JOIN log_emp_dept_change C ON B.dept_id=C.dept_id 
				WHERE A.setting_id=MY_HOLID AND A.on_time <= THIS_DATE AND (A.off_time IS NULL OR A.off_time>=THIS_DATE)
					AND C.emp_id=MY_EMPID AND C.entry_date <= THIS_DATE AND (C.leave_date IS NULL OR C.leave_date>=THIS_DATE)
					AND C.dept_type=MY_DEPTTYPE 
				LIMIT 1;
#SELECT MY_SONVER,MY_DEPTTYPE;
				IF MY_SONVER IS NOT NULL THEN
					SET MY_DEPTTYPE = 0;
				ELSE
					SET MY_DEPTTYPE = MY_DEPTTYPE - 1;
				END IF;
				
			END WHILE;
		END IF;
	END IF;
END;

