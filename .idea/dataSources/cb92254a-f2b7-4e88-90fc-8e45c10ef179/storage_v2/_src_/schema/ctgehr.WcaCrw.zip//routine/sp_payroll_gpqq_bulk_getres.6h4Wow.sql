create procedure SP_PAYROLL_GPQQ_BULK_GETRES(IN custid bigint unsigned, IN ym int, IN setid bigint unsigned)
  comment '股票期权计算'
  BEGIN
	DECLARE N_GPQQ_ZS,N_GPQQ_SL,N_GPQQ_KCS,N_GPQQ_S,N_GPQQ_SF,N_GPQQ_QZS,N_GPQQ_TL_ZS,N_GPQQ_TL_GS,N_GPQQ_QGS,N_GPQQ_CE,N_GPQQ_MRJ,N_GPQQ_XQJ,N_GPQQ_XQDATE,N_GPQQ_YSSK,N_GPQQ_HL,N_GPQQ_GFS,N_GPQQ_NF,N_GPQQ_YS,N_GPQQ_ZS_THIS,A_GPQQ_ZS,H_GPQQ_QZS,A_GPQQ_S,H_GPQQ_QS DECIMAL(13,3);
	DECLARE ct,mxct,sumb_rescnt,N_TAX_VERSION,TOLCNT int;
	DECLARE prid,i_custid,i_deptid,i_emp BIGINT;
	DECLARE i_deptname,i_empname varchar(50);
 DECLARE i_version_code VARCHAR(50);
 SET i_version_code = UUID();
 SET @i_version_code = i_version_code;
	
	
	set N_TAX_VERSION=left(ym,4);

	
	select count(*) into sumb_rescnt from payroll_GPQQ_base where cust_id=custid and MONTH_STEP=ym AND set_id = setid and is_publish=0 ;

	
	if sumb_rescnt>0 then
		
		INSERT INTO tmp_payroll_GPQQ_sum (version_code,payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,MONTH_STEP,GPQQ_MRJ,GPQQ_XQJ,GPQQ_XQDATE,GPQQ_YSSK,GPQQ_HL,GPQQ_GFS,GPQQ_NF,GPQQ_YS,GPQQ_B_ZS) 
			SELECT i_version_code,ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,MONTH_STEP,
				SUM(IF(GPQQ_MRJ IS NULL,0,GPQQ_MRJ)),
				SUM(IF(GPQQ_XQJ IS NULL,0,GPQQ_MRJ)),
				SUM(IF(GPQQ_XQDATE IS NULL,0,GPQQ_MRJ)),
				SUM(IF(GPQQ_YSSK IS NULL,0,GPQQ_MRJ)),
				SUM(IF(GPQQ_HL IS NULL,0,GPQQ_MRJ)),
				SUM(IF(GPQQ_GFS IS NULL,0,GPQQ_MRJ)),
				SUM(IF(GPQQ_NF IS NULL,0,GPQQ_MRJ)),
				SUM(IF(GPQQ_YS IS NULL,0,GPQQ_MRJ)),
				SUM(IF(GPQQ_B_ZS IS NULL,0,GPQQ_MRJ))
			FROM payroll_GPQQ_base
			WHERE is_publish=0 and cust_id=custid and MONTH_STEP=ym AND SET_ID=setid
			group by emp_id;
		
		
		select min(id),max(id) into ct,mxct from tmp_payroll_GPQQ_sum where version_code = i_version_code;
		WHILE (ct<=mxct) DO
			SET prid=NULL;
			SET i_custid=NULL;
			SET i_deptid=NULL;
			SET i_deptname=NULL;
			SET i_emp=NULL;
			SET i_empname=NULL;
			SET N_GPQQ_MRJ=NULL;
			SET N_GPQQ_XQJ=NULL;
			SET N_GPQQ_XQDATE=NULL;
			SET N_GPQQ_YSSK=NULL;
			SET N_GPQQ_HL=NULL;
			SET N_GPQQ_GFS=NULL;
			SET N_GPQQ_NF=NULL;
			SET N_GPQQ_YS=NULL;
			SET N_GPQQ_ZS_THIS=NULL;
			
			SELECT payroll_id,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,
					IF(GPQQ_MRJ IS NULL,0,GPQQ_MRJ),
					IF(GPQQ_XQJ IS NULL,0,GPQQ_XQJ),
					IF(GPQQ_XQDATE IS NULL,0,GPQQ_XQDATE),
					IF(GPQQ_YSSK IS NULL,0,GPQQ_YSSK),
					IF(GPQQ_HL IS NULL,0,GPQQ_HL),
					IF(GPQQ_GFS IS NULL,0,GPQQ_GFS),
					IF(GPQQ_NF IS NULL,0,GPQQ_NF),
					IF(GPQQ_YS IS NULL,0,GPQQ_YS),
					IF(GPQQ_B_ZS IS NULL,0,GPQQ_B_ZS)
				INTO prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,
 					N_GPQQ_MRJ,
					N_GPQQ_XQJ,
					N_GPQQ_XQDATE,
					N_GPQQ_YSSK,
					N_GPQQ_HL,
					N_GPQQ_GFS,
					N_GPQQ_NF,
					N_GPQQ_YS,
					N_GPQQ_ZS_THIS			
			FROM tmp_payroll_GPQQ_sum WHERE ID = ct and version_code = i_version_code;
			
			IF prid IS NOT NULL THEN
			
				SELECT sum(IF(GPQQ_ZS IS NULL,0,GPQQ_ZS)), sum(IF(GPQQ_S IS NULL,0,GPQQ_S))
	      		INTO  H_GPQQ_QZS, H_GPQQ_QS
	      	FROM payroll_GPQQ 
	     		WHERE IS_PUBLISH = 1 and GPQQ_NF = N_GPQQ_NF AND EMP_ID = i_emp;
	
				
				select sum(IF(GPQQ_ZS IS NULL,0,GPQQ_ZS)), sum(IF(GPQQ_S IS NULL,0,GPQQ_S))
				into A_GPQQ_ZS, A_GPQQ_S
				from payroll_GPQQ
				where p.IS_PUBLISH = 0 and GPQQ_NF = N_GPQQ_NF and EMP_ID = i_emp AND id <> prid;
				
				
				SET A_GPQQ_ZS = A_GPQQ_ZS +   H_GPQQ_QZS;  
				SET A_GPQQ_S  = A_GPQQ_S  +   H_GPQQ_QS;   
				
				SET N_GPQQ_QGS = A_GPQQ_S ;					
				SET N_GPQQ_QZS = A_GPQQ_ZS ;					
				SET N_GPQQ_TL_GS = A_GPQQ_S;					
				SET N_GPQQ_TL_ZS = A_GPQQ_ZS;					
				    
				If N_GPQQ_YS = 0 Then
				    SET N_GPQQ_YS = 0;			
				Else
				     if(N_GPQQ_XQJ = 0 or N_GPQQ_XQJ is null ) then
				        SET N_GPQQ_ZS= N_GPQQ_ZS_THIS;
				     else
				        SET N_GPQQ_ZS= (N_GPQQ_XQJ-N_GPQQ_MRJ)*N_GPQQ_GFS*N_GPQQ_HL;
				     end if;
					  
					  CALL SP_PAYROLL_GZ_TAX((N_GPQQ_ZS+A_GPQQ_ZS)/N_GPQQ_YS,
															N_TAX_VERSION,
															N_GPQQ_SL,
															N_GPQQ_KCS,
															N_GPQQ_S);
						
						SET N_GPQQ_S = (N_GPQQ_Zs+A_GPQQ_ZS)*N_GPQQ_SL-N_GPQQ_KCS*N_GPQQ_YS ;
						
						SET N_GPQQ_TL_GS = N_GPQQ_S ; 
						SET N_GPQQ_TL_ZS = N_GPQQ_ZS + A_GPQQ_ZS; 
						SET N_GPQQ_S =N_GPQQ_S - A_GPQQ_S;
						
						if(N_GPQQ_YSSK = 0) then
							SET N_GPQQ_SF = N_GPQQ_ZS - N_GPQQ_S;
							SET N_GPQQ_YSSK = 0;
						ELSE
							SET N_GPQQ_SF = N_GPQQ_YSSK - N_GPQQ_S;
							SET N_GPQQ_YSSK = N_GPQQ_YSSK;
						END IF;
					END IF;
					
					SET N_GPQQ_CE = GPQQ_MRJ - GPQQ_XQJ;
					
					DELETE FROM payroll_gpqq WHERE ID = prid;
					INSERT INTO payroll_gpqq (ID,CUST_ID,DEPT_ID,DEPT_NAME,EMP_ID,EMP_NAME,set_id,MONTH_STEP,IS_PUBLISH,
														GPQQ_NF,GPQQ_ZS,GPQQ_SL,GPQQ_KCS,GPQQ_S,GPQQ_SF,GPQQ_QZS,GPQQ_TL_ZS,GPQQ_TL_GS,GPQQ_QGS,GPQQ_CE)
											 VALUES(prid,i_custid,i_deptid,i_deptname,i_emp,i_empname,setid,ym,0,
											 			N_GPQQ_NF,N_GPQQ_ZS,N_GPQQ_SL,N_GPQQ_KCS,N_GPQQ_S,N_GPQQ_SF,N_GPQQ_QZS,N_GPQQ_TL_ZS,N_GPQQ_TL_GS,N_GPQQ_QGS,N_GPQQ_CE);
					UPDATE payroll_gpqq_base SET IS_CALC = 1 WHERE ID = prid;
					
					
					UPDATE payroll_tol 
					SET TAX_BEF_PLUSMIN_TOL=TAX_BEF_PLUSMIN_TOL+N_GPQQ_ZS,TAX_VALUE=TAX_VALUE+N_GPQQ_S,SALARY_PAY=SALARY_PAY+N_GPQQ_SF 
					WHERE ID=prid;
				
			END IF;
			SET ct = ct + 1;
		END WHILE;
	end if;
	delete from  tmp_payroll_GPQQ_sum where version_code = i_version_code;
END;

