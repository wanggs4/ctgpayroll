create procedure SP_PAYROLL_FML_VIP_HX(IN key_word varchar(50), IN i_emp bigint unsigned, IN prid bigint unsigned,
                                       IN setid    bigint unsigned, OUT res decimal(12, 2))
  comment '海翔工资计算'
  BEGIN

DECLARE my_sala_ymd_begin,my_sala_ymd_end DATE;
DECLARE MY_TAX_VERSION,MY_DAILY_WORKHOUR,MY_DEPT_ID,my_arch_id,MY_ADJ_ID,ATTID BIGINT UNSIGNED;
DECLARE MY_WORKDAY_ATT,MY_WORKDAY_OVER,MY_WEEKEND_OVER,MY_YSGZ DECIMAL(12,2);
DECLARE MY_EMP_STATE INT;
DECLARE IS_BOSS VARCHAR(50);
DECLARE ATTID_STR TEXT;

	IF key_word IS NOT NULL AND i_emp IS NOT NULL AND prid IS NOT NULL AND setid IS NOT NULL THEN 

		SELECT DEPT_ID INTO MY_DEPT_ID FROM EMP_BASE_INFO WHERE EMP_ID = i_emp;
		
		#根据setid找到月报归档id和年份
		SELECT a.arch_id,left(a.sala_ym,4) 
			into my_arch_id,MY_TAX_VERSION
		FROM payroll_sala_settings a 
		WHERE a.set_id=setid;
		
		#再根据归档id找到周期
		SELECT a.comp_start_time,a.comp_end_time
			into my_sala_ymd_begin,my_sala_ymd_end	
		FROM att_st_month_arch a
		where a.arch_id = my_arch_id;
#SELECT 		my_arch_id,my_sala_ymd_begin,my_sala_ymd_end	;
		IF  my_sala_ymd_begin IS NOT NULL AND my_sala_ymd_end IS NOT NULL THEN
			CALL SP_DPT_GET_SETTINGID(i_emp,my_sala_ymd_begin,1,ATTID_STR);
			SET ATTID = CAST(ATTID_STR AS UNSIGNED);

			CASE key_word
			#餐费补助
			WHEN 'HX_CFBZ' THEN
				#1、每天45元补贴；
				#2、无论上午下午只要半天出勤就享有45元；
				#3、工作日加班超过1.5小时给予20元的餐费补助；
				#4、周末加班超过4小时有补贴45元
				SELECT other_03 INTO IS_BOSS FROM emp_post WHERE EMP_ID=i_emp;
				SELECT DEPT_ID INTO MY_DEPT_ID FROM EMP_BASE_INFO WHERE EMP_ID=i_emp;
				#计算应该出勤分钟数
				SET MY_DAILY_WORKHOUR = FN_ATT_GET_WORKHOURS(ATTID) * 60;
								
				IF IS_BOSS = '是' THEN
					SET MY_WORKDAY_ATT = FN_ATT_GET_WORKDAYS(my_sala_ymd_begin,my_sala_ymd_end,i_emp,2);
					
					SELECT MY_WORKDAY_ATT - IF(COUNT(*) IS NULL,0,COUNT(*)) INTO MY_WORKDAY_ATT 
					FROM att_hol_apply_day A 
					WHERE A.emp_id= i_emp AND HOL_DATE BETWEEN my_sala_ymd_begin AND my_sala_ymd_end AND A.hol_hours >= FN_ATT_GET_WORKHOURS(ATTID);
					
				ELSE
					#计算时间区间内工作时长超过半天的出勤次数
					SELECT COUNT(*) INTO MY_WORKDAY_ATT 
					FROM att_emp_detail A 
					WHERE A.emp_id = i_emp AND A.dt BETWEEN my_sala_ymd_begin AND my_sala_ymd_end
						AND A.work_interval >= MY_DAILY_WORKHOUR/2 and A.date_type=1;
					IF MY_WORKDAY_ATT IS NULL THEN SET MY_WORKDAY_ATT = 0 ; END IF;
				END IF;	
				
				#计算超过1.5小时的工作日加班次数
				SELECT COUNT(*) INTO MY_WORKDAY_OVER
				FROM att_over_apply_day A
				WHERE A.emp_id = i_emp AND A.work_day BETWEEN my_sala_ymd_begin AND my_sala_ymd_end
					AND A.date_type = 1 AND A.work_hour >= 1.5;
				IF MY_WORKDAY_OVER IS NULL THEN SET MY_WORKDAY_OVER = 0 ; END IF;
				
				
				#计算超过4小时的周末加班次数
				SELECT COUNT(*) INTO MY_WEEKEND_OVER
				FROM att_over_apply_day A
				WHERE A.emp_id = i_emp AND A.work_day BETWEEN my_sala_ymd_begin AND my_sala_ymd_end
					AND A.date_type IN (2,3,4) AND A.work_hour >= 4;
				IF MY_WEEKEND_OVER IS NULL THEN SET MY_WEEKEND_OVER = 0 ; END IF;

				set res = (MY_WORKDAY_ATT * 45) + (MY_WORKDAY_OVER * 20) + (MY_WEEKEND_OVER * 45);
			#个税
			WHEN 'HX_GS' THEN
				#应税工资*税率-速算扣除数
				SELECT bz36 INTO MY_YSGZ FROM payroll_bz_gz WHERE ID = prid;
				IF MY_YSGZ IS NULL THEN SET MY_YSGZ = 0 ; END IF;
				CALL SP_PAYROLL_GZ_TAX(MY_YSGZ,MY_TAX_VERSION,@MY_RATE,@MY_D,res);

			
			#工作日加班小时
			WHEN 'HX_WORKDAY_OVER' THEN
#				SELECT SUM(IF(A.work_hour IS NULL,0,A.work_hour)) INTO res 
#				FROM att_over_apply_day A 
#					LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
#				WHERE A.emp_id = i_emp AND A.date_type IN (1,6) AND A.work_day BETWEEN my_sala_ymd_begin AND my_sala_ymd_end
#					AND B.state=1 AND B.is_clear=0 AND B.repay_type=1;
				SELECT ST_VALUE INTO res 
				FROM att_st_month_arch_items 
				WHERE emp_id = i_emp AND arch_id = my_arch_id AND st_key='prjbsc';
			#周末加班小时
			WHEN 'HX_WEEKEND_OVER' THEN
#				SELECT SUM(IF(A.work_hour IS NULL,0,A.work_hour)) INTO res 
#				FROM att_over_apply_day A 
#					LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
#				WHERE A.emp_id = i_emp AND A.date_type IN (2,4) AND A.work_day BETWEEN my_sala_ymd_begin AND my_sala_ymd_end
#					AND B.state=1 AND B.is_clear=0 AND B.repay_type=1;
				SELECT ST_VALUE INTO res 
				FROM att_st_month_arch_items 
				WHERE emp_id = i_emp AND arch_id = my_arch_id AND st_key='gxjbsc';
			#法定假日加班小时
			WHEN 'HX_HOLIDAY_OVER' THEN
#				SELECT SUM(IF(A.work_hour IS NULL,0,A.work_hour)) INTO res 
#				FROM att_over_apply_day A 
#					LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id
#					LEFT JOIN att_rel_schema_dept C ON A.dept_id = C.dept_id
#					LEFT JOIN att_set_schema_new D ON C.schema_id=D.att_id
#				WHERE A.emp_id = i_emp AND A.date_type IN (3) AND A.work_day BETWEEN my_sala_ymd_begin AND my_sala_ymd_end
#					AND B.state=1 AND B.is_clear=0 AND B.repay_type=1 AND D.is_delete=0 AND D.is_exp_hol=1 AND D.`status`=1;
				SELECT ST_VALUE INTO res 
				FROM att_st_month_arch_items 
				WHERE emp_id = i_emp AND arch_id = my_arch_id AND st_key='jrjbsc';
			#病假天数	352031190216708
			WHEN 'HX_BJTS' THEN
#				SELECT ROUND((SUM(IF(A.hol_hours IS NULL,0,A.hol_hours)) - SUM(IF(A.free_hours IS NULL,0,A.free_hours)))/FN_ATT_GET_WORKHOURS(MY_DEPT_ID),2) INTO res FROM att_hol_apply_day A WHERE A.emp_id = i_emp AND A.hol_id = 352031190216708 AND A.hol_date BETWEEN my_sala_ymd_begin AND my_sala_ymd_end;
				SELECT ST_VALUE INTO res 
				FROM att_st_month_arch_items 
				WHERE emp_id = i_emp AND arch_id = my_arch_id AND st_key='kxbj';
			#事假天数	462763770961920
			WHEN 'HX_SJTS' THEN
#				SELECT ROUND(SUM(IF(A.hol_hours IS NULL,0,A.hol_hours))/FN_ATT_GET_WORKHOURS(MY_DEPT_ID),2) INTO res FROM att_hol_apply_day A WHERE A.emp_id = i_emp AND A.hol_id = 462763770961920 AND A.hol_date BETWEEN my_sala_ymd_begin AND my_sala_ymd_end;
				SELECT ST_VALUE INTO res 
				FROM att_st_month_arch_items 
				WHERE emp_id = i_emp AND arch_id = my_arch_id AND st_key='type0008';
			#旷工天数
			WHEN 'HX_KGTS' THEN
#				SELECT COUNT(*) * 0.5 INTO res FROM att_emp_detail A WHERE A.emp_id=i_emp AND A.is_dayoff = 2 AND A.dt BETWEEN my_sala_ymd_begin AND my_sala_ymd_end;
#				IF res IS NULL THEN SET res = 0; END IF;
#				SELECT COUNT(*) + res INTO res FROM att_emp_detail A WHERE A.emp_id=i_emp AND A.is_dayoff = 1 AND A.dt BETWEEN my_sala_ymd_begin AND my_sala_ymd_end;
#				IF res IS NULL THEN SET res = 0; END IF;
				SELECT ST_VALUE INTO res 
				FROM att_st_month_arch_items 
				WHERE emp_id = i_emp AND arch_id = my_arch_id AND st_key='kg';
			#迟到早退次数
			WHEN 'HX_CDZTCS' THEN
#				SELECT COUNT(*) INTO res FROM att_emp_detail A WHERE A.emp_id=i_emp AND A.late_mins > 0 AND A.is_dayoff = 0 AND A.date_type=1 AND A.dt BETWEEN my_sala_ymd_begin AND my_sala_ymd_end;
#				IF res IS NULL THEN SET res = 0; END IF;
#				SELECT COUNT(*) + res INTO res FROM att_emp_detail A WHERE A.emp_id=i_emp AND A.early_mins > 0 AND A.is_dayoff = 0 AND A.date_type=1 AND A.dt BETWEEN my_sala_ymd_begin AND my_sala_ymd_end;
#				IF res IS NULL THEN SET res = 0; END IF;
				SELECT ST_VALUE INTO res 
				FROM att_st_month_arch_items 
				WHERE emp_id = i_emp AND arch_id = my_arch_id AND st_key='cdcs';
				SELECT ST_VALUE+res INTO res 
				FROM att_st_month_arch_items 
				WHERE emp_id = i_emp AND arch_id = my_arch_id AND st_key='ztcs';

			WHEN 'HX_JBGZ' THEN
				SELECT EMP_STATE INTO MY_EMP_STATE FROM emp_base_info WHERE EMP_ID=i_emp AND IS_DELETE=0;
				
				IF MY_EMP_STATE = 1 THEN
					SELECT MAX(A.adj_id) INTO MY_ADJ_ID
					FROM emp_salary_adj A
					WHERE A.emp_id=i_emp AND A.enable_time <= REPLACE(my_sala_ymd_end,'-','') AND A.is_delete=0 AND A.is_enable=1;
					
					SELECT A.base_sala INTO res
					FROM emp_salary_adj A
					WHERE A.emp_id=i_emp AND A.adj_id = MY_ADJ_ID;
				ELSEIF MY_EMP_STATE = 3 THEN
					SELECT test_sala INTO res FROM emp_salary WHERE EMP_ID=i_emp;
					
				END IF;
				
				IF res IS NULL THEN SET res = 0 ; END IF;
				
			WHEN 'HX_GWGZ' THEN
				SELECT MAX(A.adj_id) INTO MY_ADJ_ID
				FROM emp_salary_adj A
				WHERE A.emp_id=i_emp AND A.enable_time <= REPLACE(my_sala_ymd_end,'-','') AND A.is_delete=0 AND A.is_enable=1;
				
				SELECT A.pos_sala INTO res
				FROM emp_salary_adj A
				WHERE A.emp_id=i_emp AND A.adj_id = MY_ADJ_ID;
				
				IF res IS NULL THEN SET res = 0 ; END IF;
				
			WHEN 'HX_JXGZ' THEN
				SELECT MAX(A.adj_id) INTO MY_ADJ_ID
				FROM emp_salary_adj A
				WHERE A.emp_id=i_emp AND A.enable_time <= REPLACE(my_sala_ymd_end,'-','') AND A.is_delete=0 AND A.is_enable=1;
				
				SELECT A.kpi_sala INTO res
				FROM emp_salary_adj A
				WHERE A.emp_id=i_emp AND A.adj_id = MY_ADJ_ID;
				
				IF res IS NULL THEN SET res = 0 ; END IF;
				
			END CASE;
		END IF;
	END IF;
	set res = round(res,2);
END;

