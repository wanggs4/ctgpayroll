create procedure FN_ATT_GET_DAILY_REAL_CHECKTIME(IN  MY_EMPID         bigint unsigned, IN THIS_DAY_BG_TIME datetime,
                                                 IN  THIS_DAY_ED_TIME datetime, IN SOURCE_PRIORITY int, IN OP_TYPE int,
                                                 OUT MY_CHECKIN       datetime, OUT MY_CHECKOUT datetime,
                                                 OUT MY_CHECKOSD      datetime)
  comment '得到时间段内的签到签退和外签时间'
  BEGIN
/*
	参数说明：
	OP_TYPE	1 不考虑补签
				2 考虑补签
*/
DECLARE IS_HAVE_EMP INT;
DECLARE MY_RECHECKIN,MY_RECHECKOUT DATETIME;

	IF MY_EMPID IS NOT NULL AND OP_TYPE IN (1,2) AND THIS_DAY_ED_TIME IS NOT NULL AND THIS_DAY_ED_TIME IS NOT NULL THEN
		SET IS_HAVE_EMP = 0;
		SELECT COUNT(*) INTO IS_HAVE_EMP FROM EMP_BASE_INFO WHERE EMP_ID=MY_EMPID;
		IF IS_HAVE_EMP > 0 AND IS_HAVE_EMP IS NOT NULL AND THIS_DAY_BG_TIME < THIS_DAY_ED_TIME THEN
			#不考虑补签的情况
			IF OP_TYPE = 1 THEN
				#取来源优先级高的上下班打卡时间
				SELECT MIN(A.check_time),MAX(A.check_time)
					INTO MY_CHECKIN,MY_CHECKOUT
				FROM att_emp_log A
				WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
					AND A.data_source >= SOURCE_PRIORITY AND A.check_type<>3;
				#如果都没有，取没有来源优先级的打卡数据
				IF MY_CHECKIN IS NULL AND MY_CHECKOUT IS NULL THEN
					SELECT MIN(A.check_time),MAX(A.check_time)
						INTO MY_CHECKIN,MY_CHECKOUT
					FROM att_emp_log A
					WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
						AND (A.data_source < SOURCE_PRIORITY OR A.data_source IS NULL) AND A.check_type<>3;
				END IF;
				
				#取来源优先级高的外勤打卡时间
				SELECT MIN(A.check_time)
					INTO MY_CHECKOSD
				FROM att_emp_log A
				WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
					AND A.data_source >= SOURCE_PRIORITY AND A.check_type=3;
					
				#如果都没有，取没有来源优先级的外勤打卡数据
				IF MY_CHECKOSD IS NULL THEN
					SELECT MIN(A.check_time)
						INTO MY_CHECKOSD
					FROM att_emp_log A
					WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
						AND (A.data_source < SOURCE_PRIORITY OR A.data_source IS NULL) AND A.check_type=3;
				END IF;
			#考虑补签
			ELSEIF OP_TYPE = 2 THEN
				#取来源优先级高的上下班打卡时间
				SELECT MIN(A.check_time),MAX(A.check_time)
					INTO MY_CHECKIN,MY_CHECKOUT
				FROM att_emp_log A
				WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
					AND A.data_source >= SOURCE_PRIORITY AND A.check_type<>3;
				#取补签数据	
				SELECT MIN(A.check_time),MAX(A.check_time)
					INTO MY_RECHECKIN,MY_RECHECKOUT
				FROM att_check_apply A
				WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
					AND A.state=1 AND A.check_type<>3;
				#如果都没有，取没有来源优先级的打卡数据
				IF MY_CHECKIN IS NULL AND MY_CHECKOUT IS NULL THEN
					SELECT MIN(A.check_time),MAX(A.check_time)
						INTO MY_CHECKIN,MY_CHECKOUT
					FROM att_emp_log A
					WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
						AND (A.data_source < SOURCE_PRIORITY OR A.data_source IS NULL) AND A.check_type<>3;
				END IF;
				
				IF (MY_CHECKIN IS NULL AND MY_RECHECKIN IS NOT NULL) OR MY_CHECKIN > MY_RECHECKIN THEN
					SET MY_CHECKIN = MY_RECHECKIN;
				END IF;
				
				IF (MY_CHECKOUT IS NULL AND MY_RECHECKOUT IS NOT NULL) OR MY_CHECKOUT < MY_RECHECKOUT THEN
					SET MY_CHECKOUT = MY_RECHECKOUT;
				END IF;
				
				#取来源优先级高的外勤打卡时间
				SELECT MIN(A.check_time)
					INTO MY_CHECKOSD
				FROM att_emp_log A
				WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
					AND A.data_source >= SOURCE_PRIORITY AND A.check_type=3;
					
				#如果都没有，取没有来源优先级的外勤打卡数据
				IF MY_CHECKOSD IS NULL THEN
					SELECT MIN(A.check_time)
						INTO MY_CHECKOSD
					FROM att_emp_log A
					WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
						AND (A.data_source < SOURCE_PRIORITY OR A.data_source IS NULL) AND A.check_type=3;
				END IF;
				
				IF MY_CHECKOSD IS NULL THEN
					#取补签数据
					SELECT MIN(A.check_time)
						INTO MY_CHECKOSD
					FROM att_check_apply A
					WHERE A.emp_id=MY_EMPID AND A.check_time BETWEEN THIS_DAY_BG_TIME AND THIS_DAY_ED_TIME
						AND A.state=1 AND A.check_type=3;
				END IF;
			END IF;
		END IF;
	END IF;
#	SET MY_CHECKIN = FN_SYS_DTTMFMT_PURGE_SECOND(MY_CHECKIN);
#	SET MY_CHECKOUT = FN_SYS_DTTMFMT_PURGE_SECOND(MY_CHECKOUT);
#	SET MY_CHECKOSD = FN_SYS_DTTMFMT_PURGE_SECOND(MY_CHECKOSD);
	
END;

