create procedure SP_CUST_EMPPERIOD_SCHEDULE_INIT(IN MY_CUSTID bigint, IN MY_YEAR int)
  comment '人事周期初始化,只初始化当年里人事周期没有的，与考勤周期同步'
  BEGIN
DECLARE IS_HAVE_SCHEDUAL,MY_ID_START_POINT BIGINT;
DECLARE I_VERSION_CODE VARCHAR(50);
	
	SET I_VERSION_CODE = UUID();

	SELECT COUNT(*) INTO IS_HAVE_SCHEDUAL
	FROM cust_period_schedule A
	WHERE A.cust_id=MY_CUSTID AND A.year_mon BETWEEN MY_YEAR*100 AND (MY_YEAR+1)*100-1 AND A.period_type=3;
	
	IF IS_HAVE_SCHEDUAL <= 0 THEN
		SELECT MAX(p_item_id) INTO MY_ID_START_POINT FROM cust_period_schedule WHERE p_item_id <= 15000000000000;
		
		IF MY_ID_START_POINT IS NULL THEN SET MY_ID_START_POINT = 0; END IF;
		
		TRUNCATE TABLE tmp_empperiod_init;
		INSERT INTO tmp_empperiod_init (version_code,cust_id,period_type,year_mon,begin_date,end_date)
			SELECT I_VERSION_CODE,A.cust_id,3,A.year_mon,A.begin_date,A.end_date
				FROM cust_period_schedule A
				WHERE A.cust_id=MY_CUSTID AND A.year_mon BETWEEN MY_YEAR*100 AND (MY_YEAR+1)*100-1  AND A.period_type=1;
				
		INSERT INTO cust_period_schedule (p_item_id,cust_id,period_type,year_mon,begin_date,end_date)
			SELECT A.ID+MY_ID_START_POINT,A.cust_id,A.period_type,A.year_mon,A.begin_date,A.end_date
			FROM tmp_empperiod_init A
			WHERE A.VERSION_CODE=I_VERSION_CODE;
	END IF;
END;

