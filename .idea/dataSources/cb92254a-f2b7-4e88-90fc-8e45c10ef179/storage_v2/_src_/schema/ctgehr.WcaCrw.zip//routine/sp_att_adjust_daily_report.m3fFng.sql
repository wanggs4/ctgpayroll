create procedure SP_ATT_ADJUST_DAILY_REPORT(IN BGDT date, IN EDDT date, IN MY_CUST bigint)
  comment '根据给出的时间范围和公司id，找出符合全勤条件但没有全勤的记录'
  BEGIN
DECLARE i_version_code VARCHAR(50);
DECLARE ACT_LATE_MINS,ACT_EARLY_MINS,ACT_IS_DAYOFF,MY_ATT_ID,DR_IS_DAYOFF,MY_EMP,MY_DEPT,CT,MXCT BIGINT;
DECLARE DTCT DATE;
DECLARE SET_MST,SET_MET,SET_AST,SET_AET TIME;
DECLARE DR_CHECK_IN,DR_CHECK_OUT,THIS_MST,THIS_MET,THIS_AST,THIS_AET DATETIME;
DECLARE DR_LATE_MINS,DR_EARLY_MINS,SET_FREE_HOUR_LATE,SET_FREE_HOUR_EARLY,SET_FLEX_HOUR DECIMAL(12,2);

TRUNCATE TABLE att_emp_detail_adjust;
SET i_version_code = UUID();

	insert into tmp_att_adjust_list (version_code,emp_id,dept_id) 
		select distinct i_version_code,a.emp_id,a.dept_id  
		from emp_base_info a 
			left join att_rel_schema_dept b on a.dept_id=b.dept_id 
			left join att_set_schema_new c on b.schema_id=c.att_id 
			left join emp_post d on a.emp_id=d.emp_id 
		where (d.entry_date is not null and d.entry_date <= EDDT and (d.leave_date is null or d.leave_date>=BGDT)) 
			and c.is_delete=0 and c.att_rule in (1,2) and (a.boss_level<>1 or a.boss_level is null) 
			and a.emp_state is not null and a.cust_id=MY_CUST and a.dept_id is not null AND a.is_delete=0 
			and (c.is_app_checkin=1 or c.is_import_att=1);	

	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_att_adjust_list WHERE VERSION_CODE = i_version_code;
	WHILE CT <= MXCT AND CT > 0 DO
		SELECT A.emp_id,A.dept_id
			INTO MY_EMP,MY_DEPT
		FROM tmp_att_adjust_list A
		WHERE A.version_code = i_version_code AND A.ID=CT;
		
		SELECT B.morn_start_time,B.morn_end_time,B.aftn_start_time,B.aftn_end_time,
				B.free_hour_late,B.free_hour_early,B.flex_hour,B.att_id
			INTO SET_MST,SET_MET,SET_AST,SET_AET,
				SET_FREE_HOUR_LATE,SET_FREE_HOUR_EARLY,SET_FLEX_HOUR,MY_ATT_ID
		FROM att_rel_schema_dept A LEFT JOIN att_set_schema_new B ON A.schema_id=B.att_id
		WHERE A.dept_id = MY_DEPT AND B.is_delete=0 AND B.`status`=1;
		
		IF MY_EMP IS NOT NULL THEN
			SET DTCT = BGDT;
			WHILE DTCT <= EDDT DO
				SET THIS_MST = CONCAT(DTCT,' ',SET_MST);
				SET THIS_MET = CONCAT(DTCT,' ',SET_MET);
				SET THIS_AST = CONCAT(DTCT,' ',SET_AST);
				SET THIS_AET = CONCAT(DTCT,' ',SET_AET);
				
				IF SET_FLEX_HOUR IS NULL OR SET_FLEX_HOUR = 0 THEN
					SET THIS_MST = DATE_ADD(THIS_MST,INTERVAL SET_FREE_HOUR_LATE MINUTE);
					SET THIS_AET = DATE_ADD(THIS_AET,INTERVAL -SET_FREE_HOUR_EARLY MINUTE);
				END IF;
				
				SELECT A.check_in,A.check_out,A.late_mins,A.early_mins,A.is_dayoff
					INTO DR_CHECK_IN,DR_CHECK_OUT,DR_LATE_MINS,DR_EARLY_MINS,DR_IS_DAYOFF
				FROM att_emp_detail A
				WHERE A.emp_id = MY_EMP AND DT = DTCT;
				
				CALL FN_ATT_GET_MINS_FIXED_NA(DR_CHECK_IN,DR_CHECK_OUT,MY_DEPT,ACT_LATE_MINS,ACT_EARLY_MINS);
				
				SET ACT_IS_DAYOFF = FN_ATT_GET_DAYOFF_STATUS(ACT_LATE_MINS,ACT_EARLY_MINS,MY_ATT_ID);
				
				IF DR_CHECK_IN IS NOT NULL AND DR_CHECK_OUT IS NOT NULL AND ((DR_LATE_MINS > ACT_LATE_MINS) OR (DR_EARLY_MINS > ACT_EARLY_MINS) OR (DR_IS_DAYOFF>ACT_IS_DAYOFF) OR (DR_CHECK_IN < THIS_MST AND DR_LATE_MINS > 0) OR (DR_CHECK_OUT > THIS_AET AND DR_EARLY_MINS > 0)) THEN
					REPLACE INTO att_emp_detail_adjust
						SELECT * FROM att_emp_detail WHERE EMP_ID=MY_EMP AND DT=DTCT;
				END IF;
				SET DTCT = DATE_ADD(DTCT,INTERVAL 1 DAY);
			END WHILE;
		END IF;
		DELETE FROM tmp_att_adjust_list WHERE version_code = i_version_code AND ID=CT;
		SET CT= CT + 1;
	END WHILE;
END;

