create procedure SP_ATT_DAILY_OVER(IN bgdt date, IN eddt date, IN custid bigint unsigned, IN deptid bigint unsigned,
                                   IN emp  bigint unsigned, IN depttype int)
  comment '加班日报汇总计算'
  BEGIN
#声明变量
DECLARE MY_ATTID,i_custid,i_deptid,i_emp,i_applyid,i_otid BIGINT UNSIGNED;
DECLARE IS_HAVE_LOG,ct,mxct,ctn,mxctn BIGINT;
DECLARE i_is_outside_over,THIS_CT,THIS_MXCT,i_date_repay_type,i_how_repay,i_workday_repay,i_weekend_repay,i_holiday_repay,IS_TODAY_HAVE_OVER,THIS_DO_YEAR,i_repay_type,stat,is_wksala,is_lft2rest,dttype,dttype_next,this_dttype,this_dttype_next,is_att,do_recycle,is_have_rest_log,i_seed,i_data_source,i_over_range_bg_day,i_over_range_ed_day,i_over_rule,MY_ATT_RULE,MY_IEH INT;
DECLARE i_version_code,workday,i_deptn,i_empn VARCHAR(200);
DECLARE LOG_DO_VALUE,today_ohour,i_permit_over_hours,MY_OVER_HOUR_1,MY_OVER_HOUR_2,MY_OVER_HOUR_3,o_hour,r_hour,s_hour,max_wksala,his_shour,this_ohour,i_ori_value,i_mod_value,last_mod_value,onday_ori_value,onday_do_value,this_do_value decimal(12,2);
DECLARE MY_CHECK_ED_TIME_1,MY_CHECK_BG_TIME_1,MY_CHECK_ED_TIME_2,MY_CHECK_BG_TIME_2,MY_CHECK_ED_TIME_3,MY_CHECK_BG_TIME_3,sdt,edt,this_sdt,this_edt,MAX_LOG_TIME,MY_ENABLE_BG_DATE_1,MY_ENABLE_ED_DATE_1,MY_ENABLE_BG_DATE_2,MY_ENABLE_ED_DATE_2,MY_ENABLE_BG_DATE_3,MY_ENABLE_ED_DATE_3,MY_ARR_BG_TIME,MY_ARR_ED_TIME datetime;
DECLARE OVER_BGDT,OVER_EDDT,i_bgdt,i_eddt,init_i_bgdt date;
DECLARE stm,etm,i_over_range_bg_time_1,i_over_range_ed_time_1,i_over_range_bg_time_2,i_over_range_ed_time_2,i_over_range_bg_time_3,i_over_range_ed_time_3 time;
DECLARE ATTID_STR TEXT;
DECLARE this_check_in,this_check_out,this_check_osd datetime;
	
	set i_version_code = uuid();
	set sql_mode='';

	/*判断输入的参数
		stat 1 emp		emp is not null 按员工查
		stat 2 detp		deptid is not null and emp is null 按部门查
		stat 3 custid  custid is not null and deptid is null and emp is null; 按公司查
		stat 4 all		custid is null and deptid is null and emp is null  全局查
	*/
	if (custid is null and deptid is null and depttype is null and emp is null) then
		set stat=4;
	elseif (custid is not null and deptid is null and depttype is null  and emp is null) then
		set stat=3;
	elseif (deptid is not null and depttype between 1 and 10 and emp is null) then
		set stat=2;
	elseif (emp is not null) then
		set stat=1;
	end if;

	#第一层循环 按日期
	while (bgdt<=eddt) do 										#loop1
		#初始化循环变量
		SET ct=NULL;
		SET mxct=NULL;
		#因为程序调用时，需要审批的给的时间时审批通过时间；不需要审批的给的是请假开始时间，所以不需要审批的时间字段，应该是start_time
		#得到当天通过的加班                        
		case stat
		when 1 then
			#申请 从申请捋
			insert into tmp_att_over_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_over_apply a
				where a.emp_id=emp and a.dept_id is not null and a.state=1 and a.state is not null
					and a.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') #and a.is_delete=0
				order by start_time;
			#申请 驳回 撤销
			insert into tmp_att_over_list_no (version_code,apply_id) 
				select distinct i_version_code,b.apply_id 
				from att_over_apply b
				where b.emp_id=emp and b.state in (3,4) and b.state is not null and b.dept_id is not null and (b.rest_hours = 0 or b.rest_hours is null) 
					and b.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') #and a.is_delete=0
				order by b.start_time;
			#批量申请 从申请捋
			insert into tmp_att_over_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_over_apply a 
					left join att_over_group_apply b on a.group_over_apply_id=b.group_apply_id
				where a.emp_id=emp and a.group_over_apply_id is not null and a.dept_id is not null and a.state=1 and a.state is not null
					and a.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') 
					and a.apply_id not in (select distinct apply_id from tmp_att_over_list where version_code=i_version_code)  #and a.is_delete=0
				order by a.start_time;
			#批量申请 驳回 撤销
			insert into tmp_att_over_list_no (version_code,apply_id) 
				select distinct i_version_code,b.apply_id 
				from att_over_group_apply a left join att_over_apply b on a.group_apply_id=b.group_over_apply_id
				where b.emp_id=emp and b.group_over_apply_id is not null and b.state in (3,4) and a.state is not null and b.dept_id is not null and (b.rest_hours = 0 or b.rest_hours is null) 
					and b.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') 
					and b.apply_id not in (select distinct apply_id from tmp_att_over_list_no where version_code=i_version_code)  #and a.is_delete=0
				order by a.start_time;


		when 2 then
			CASE depttype 
			WHEN 1 THEN
				#申请 从申请捋
				insert into tmp_att_over_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_over_apply a
					where b.dept_id=deptid and a.dept_id is not null and a.state=1 and a.state is not null
						and a.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') #and a.is_delete=0
					order by start_time;
				#申请 驳回 撤销
				insert into tmp_att_over_list_no (version_code,apply_id) 
					select distinct i_version_code,b.apply_id 
					from att_over_apply b
					where b.dept_id=deptid and b.state in (3,4) and b.state is not null and b.dept_id is not null and (b.rest_hours = 0 or b.rest_hours is null) 
						and b.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') #and a.is_delete=0
					order by b.start_time;
				#批量申请 从申请捋
				insert into tmp_att_over_list (version_code,apply_id) 
					select distinct i_version_code,a.apply_id 
					from att_over_apply a 
						left join att_over_group_apply b on a.group_over_apply_id=b.group_apply_id
					where b.dept_id=deptid and a.group_over_apply_id is not null and a.dept_id is not null and a.state=1 and a.state is not null 
						and a.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') 
						and a.apply_id not in (select distinct apply_id from tmp_att_over_list where version_code=i_version_code)  #and a.is_delete=0
					order by a.start_time;
				#批量申请 驳回 撤销
				insert into tmp_att_over_list_no (version_code,apply_id) 
					select distinct i_version_code,b.apply_id 
					from att_over_group_apply a left join att_over_apply b on a.group_apply_id=b.group_over_apply_id
					where b.dept_id=deptid and b.group_over_apply_id is not null and b.state in (3,4) and a.state is not null and b.dept_id is not null and (b.rest_hours = 0 or b.rest_hours is null) 
						and b.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') 
						and b.apply_id not in (select distinct apply_id from tmp_att_over_list_no where version_code=i_version_code)  #and a.is_delete=0
					order by a.start_time;

			END CASE;
		when 3 then
			#申请 从申请捋
			insert into tmp_att_over_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_over_apply a
				where a.cust_id=custid and a.dept_id is not null and a.state=1 and a.state is not null 
					and a.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') #and a.is_delete=0
				order by start_time;
			#申请 驳回 撤销
			insert into tmp_att_over_list_no (version_code,apply_id) 
				select distinct i_version_code,b.apply_id 
				from att_over_apply b
				where b.cust_id=custid and b.state in (3,4) and b.state is not null and b.dept_id is not null and (b.rest_hours = 0 or b.rest_hours is null) 
					and b.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') #and a.is_delete=0
				order by b.start_time;
			#批量申请 从申请捋
			insert into tmp_att_over_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_over_apply a 
					left join att_over_group_apply b on a.group_over_apply_id=b.group_apply_id
				where a.cust_id=custid and a.group_over_apply_id is not null and a.dept_id is not null and a.state=1 and a.state is not null 
					and a.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') 
					and a.apply_id not in (select distinct apply_id from tmp_att_over_list where version_code=i_version_code)  #and a.is_delete=0
				order by a.start_time;
			#批量申请 驳回 撤销
			insert into tmp_att_over_list_no (version_code,apply_id) 
				select distinct i_version_code,b.apply_id 
				from att_over_group_apply a left join att_over_apply b on a.group_apply_id=b.group_over_apply_id
				where b.cust_id=custid and b.group_over_apply_id is not null and b.state in (3,4) and a.state is not null and b.dept_id is not null and (b.rest_hours = 0 or b.rest_hours is null) 
					and b.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') 
					and b.apply_id not in (select distinct apply_id from tmp_att_over_list_no where version_code=i_version_code)  #and a.is_delete=0
				order by a.start_time;
		when 4 then
			#申请 从申请捋
			insert into tmp_att_over_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_over_apply a
				where a.dept_id is not null and a.state=1 and a.state is not null 
					and a.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') #and a.is_delete=0
				order by start_time;
			#申请 驳回 撤销
			insert into tmp_att_over_list_no (version_code,apply_id) 
				select distinct i_version_code,b.apply_id 
				from att_over_apply b
				where b.state in (3,4) and b.state is not null and b.dept_id is not null and (b.rest_hours = 0 or b.rest_hours is null) 
					and b.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') #and a.is_delete=0
				order by b.start_time;
			#批量申请 从申请捋
			insert into tmp_att_over_list (version_code,apply_id) 
				select distinct i_version_code,a.apply_id 
				from att_over_apply a 
					left join att_over_group_apply b on a.group_over_apply_id=b.group_apply_id
				where a.group_over_apply_id is not null and a.dept_id is not null and a.state=1 and a.state is not null 
					and a.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') 
					and a.apply_id not in (select distinct apply_id from tmp_att_over_list where version_code=i_version_code)  #and a.is_delete=0
				order by a.start_time;
			#批量申请 驳回 撤销
			insert into tmp_att_over_list_no (version_code,apply_id) 
				select distinct i_version_code,b.apply_id 
				from att_over_group_apply a left join att_over_apply b on a.group_apply_id=b.group_over_apply_id
				where b.group_over_apply_id is not null and b.state in (3,4) and a.state is not null and b.dept_id is not null and (b.rest_hours = 0 or b.rest_hours is null) 
					and b.start_time between concat(bgdt,' 05:00:00') and concat(date_add(bgdt,interval 1 day),' 04:59:59') 
					and b.apply_id not in (select distinct apply_id from tmp_att_over_list_no where version_code=i_version_code)  ##and a.is_delete=0
				order by a.start_time;
		end case;													#part 1

		#虚拟角色,免核算人员不计算
		DELETE A.* FROM tmp_att_over_list A 
			LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id 
			LEFT JOIN emp_base_info C ON B.emp_id=C.emp_id
		WHERE A.VERSION_CODE=i_version_code AND C.boss_level IN (1,3);
			
		DELETE A.* FROM tmp_att_over_list_no A 
			LEFT JOIN att_over_apply B ON A.apply_id=B.apply_id 
			LEFT JOIN emp_base_info C ON B.emp_id=C.emp_id
		WHERE A.VERSION_CODE=i_version_code AND C.boss_level IN (1,3);
	
#select * from  tmp_att_over_list a where version_code = i_version_code;
	
		##################           PART 1          ##########################
		#													
												 #
		#			对审核通过和不需要审核的神情进行计算和日报归档					  #
		#																							 #
		#######################################################################
		select min(id),max(id) into ct,mxct from tmp_att_over_list where version_code = i_version_code;
		#第二重循环 遍历当天通过的加班					    loop2
		while (ct<=mxct and ct>0) do
			#初始化本次循环的变量
			SET i_permit_over_hours=NULL,i_applyid=NULL,i_custid=NULL,i_deptid=NULL,i_deptn=NULL,i_emp=NULL,i_empn=NULL,o_hour=NULL,this_ohour =NULL,sdt=NULL,edt=NULL,is_wksala=NULL,max_wksala=NULL,is_lft2rest=NULL,i_bgdt=NULL,i_eddt=NULL,stm=NULL,etm=NULL,MY_ENABLE_BG_DATE_1=NULL,MY_ENABLE_ED_DATE_1=NULL,MY_ENABLE_BG_DATE_2=NULL,MY_ENABLE_ED_DATE_2=NULL,MY_ENABLE_BG_DATE_3=NULL,MY_ENABLE_ED_DATE_3=NULL,r_hour = NULL,this_sdt = NULL,this_sdt = NULL,MY_ATTID = NULL,i_how_repay=NULL,i_workday_repay=NULL,i_weekend_repay=NULL,i_holiday_repay=NULL;
			#读出申请id
			select apply_id into i_applyid from tmp_att_over_list where id=ct and version_code = i_version_code;
			IF i_applyid IS NOT NULL THEN
#select i_applyid;
				#清空该申请的数据
				delete from att_over_apply_day where apply_id=i_applyid;
				#2读出本次申请的相应信息
				select `cust_id`,`dept_id`,`dept_name`,`emp_id`,`emp_name`,
						`over_hours`,start_time,end_time,
						data_source,ot_id,repay_type,permit_over_hours,is_outside_over
					into i_custid,i_deptid,i_deptn,i_emp,i_empn,	#申请id,公司id，部门id、名称，员工id、名称
						o_hour,sdt,edt,
						i_data_source,i_otid,i_repay_type,i_permit_over_hours,i_is_outside_over			#加班时数
				from att_over_apply a where apply_id=i_applyid ;
				
				select a.how_repay,a.workday_repay,a.weekend_repay,a.holiday_repay
					into i_how_repay,i_workday_repay,i_weekend_repay,i_holiday_repay
				from att_set_overtime_new a
				where a.ot_id=i_otid;
				
				#读出考勤设置
				CALL SP_DPT_GET_SETTINGID(i_emp,DATE(sdt),1,ATTID_STR);
				SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);

				SELECT A.att_rule INTO MY_ATT_RULE FROM att_set_schema_new A WHERE ATT_ID=MY_ATTID;
				
				#分解每个申请中的起始和截止日期，拆分每天进行计算和记录
				SET stm	= TIME(sdt);
				SET etm = TIME(edt);
				
				IF stm < '05:00:00' THEN
					SET i_bgdt = DATE_ADD(date(sdt),INTERVAL -1 DAY);
				ELSE
					SET i_bgdt = date(sdt);
				END IF;
				IF etm < '05:00:00' THEN
					SET i_eddt = DATE_ADD(date(edt),INTERVAL -1 DAY);
				ELSE
					SET i_eddt = date(edt);
				END IF;
 
				SELECT COUNT(*) INTO IS_HAVE_LOG FROM att_hol_rest_log A WHERE A.apply_id=i_applyid AND A.do_value<>0;
				IF IS_HAVE_LOG > 0 THEN
					SET THIS_DO_YEAR = YEAR(i_bgdt);
					SELECT A.do_value INTO LOG_DO_VALUE FROM att_hol_rest_log A WHERE A.apply_id=i_applyid AND A.col_name='this_year_have' AND A.which_year=THIS_DO_YEAR; 
					IF LOG_DO_VALUE <> 0 AND LOG_DO_VALUE IS NOT NULL THEN
						CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,2,1,0);
					END IF;
				END IF;
	#----------------- 逻辑架构开始------------------------	
	
				#出勤规则为坐班的，按照正常的逻辑去分析每天的时长
				IF MY_ATT_RULE IN (1,3) THEN		
					set init_i_bgdt = i_bgdt;
					
					WHILE (i_bgdt<=i_eddt) DO
						set this_check_in=null,this_check_out=null,this_check_osd=null;
						SET this_dttype = FN_ATT_GET_DTTYPE(i_bgdt,i_emp);
						SET i_date_repay_type = 1;
						#i_how_repay,i_workday_repay,i_weekend_repay,i_holiday_repay,i_repay_type
						IF (i_how_repay=1 AND i_workday_repay=2 AND this_dttype IN (1,6))
							OR (i_how_repay=1 AND i_weekend_repay=2 AND this_dttype IN (2,4))
							OR (i_how_repay=1 AND i_holiday_repay=2 AND this_dttype=3)
							OR (i_how_repay=2 AND i_repay_type=2) 
						THEN
							SET i_date_repay_type=2;
						END IF;
						
						
						
#select i_emp,i_bgdt,i_eddt,init_i_bgdt;
						#单天的申请:
						#申请的开始结束时间在同一天
						#当申请的结束时间在下一天(当天为工作日或者不计算节假日情况下的节假日)的有效开始时间之前
						IF init_i_bgdt = i_eddt AND TIME(sdt) >= '05:00:00' THEN
							SET this_sdt = sdt;
							SET this_edt = edt;
							CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,i_bgdt,2,this_check_in,this_check_out,this_check_osd);
							IF i_is_outside_over = 0 THEN
								IF this_check_in IS NOT NULL AND this_check_out IS NOT NULL THEN
									#取交集
									IF this_check_in > this_edt OR this_check_out < this_sdt THEN
										SET this_ohour = 0;
									ELSE
										IF this_sdt < this_check_in THEN
											SET this_sdt = this_check_in;
										END IF;
										IF this_edt > this_check_out THEN
											SET this_edt = this_check_out;
										END IF;
										SET this_ohour = FN_ATT_GET_OVER_HOURS(this_sdt,this_edt,i_otid,i_deptid,i_emp);
									END IF;
								ELSE
									SET this_ohour = 0;
								END IF;
							ELSEIF i_is_outside_over = 1 THEN
								SET this_ohour = FN_ATT_GET_OVER_HOURS(this_sdt,this_edt,i_otid,i_deptid,i_emp);
							END IF;
						#日期相同，且都在5点前，算前一天
						ELSEIF init_i_bgdt = i_eddt AND TIME(sdt) < '05:00:00' AND TIME(edt) < '05:00:00' THEN
							SET this_sdt = sdt;
							SET this_edt = edt;
							#需要考虑打卡
							IF i_is_outside_over = 0 THEN
								CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,DATE_ADD(i_bgdt,INTERVAL -1 DAY),2,this_check_in,this_check_out,this_check_osd);
								IF this_check_in IS NOT NULL AND this_check_out IS NOT NULL THEN
									#取交集
									IF this_check_in > this_edt OR this_check_out < this_sdt THEN
										SET this_ohour = 0;
									ELSE
										IF this_sdt < this_check_in THEN
											SET this_sdt = this_check_in;
										END IF;
										IF this_edt > this_check_out THEN
											SET this_edt = this_check_out;
										END IF;
		
										#得到当天的加班时数
										SET this_ohour = FN_ATT_GET_OVER_HOURS(this_sdt,this_edt,i_otid,i_deptid,i_emp);
									END IF;
								ELSE
									SET this_ohour = 0;
								END IF;
							#不需要考虑打卡
							ELSEIF i_is_outside_over = 1 THEN
								SET this_ohour = FN_ATT_GET_OVER_HOURS(this_sdt,this_edt,i_otid,i_deptid,i_emp);
							END IF;
						#日期相同，一个在5点钱，一个在5点后，要按两天来计算
						ELSEIF init_i_bgdt = i_eddt AND TIME(sdt) < '05:00:00' AND TIME(edt) >= '05:00:00' THEN
							SET THIS_CT = 1,THIS_MXCT = 2,this_ohour=0;
							WHILE THIS_CT <= THIS_MXCT DO
								SET today_ohour = 0,this_sdt=NULL,this_edt=NULL;
								SET this_check_in=NULL,this_check_out=NULL,this_check_osd=NULL;
								IF THIS_CT = 1 THEN
									SET this_sdt = sdt;
									SET this_edt = CONCAT(DATE(this_sdt),' 04:59:59');
									CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,DATE_ADD(i_bgdt,INTERVAL -1 DAY),2,this_check_in,this_check_out,this_check_osd);
								ELSE
									SET this_edt = edt;
									SET this_sdt = CONCAT(DATE(this_edt),' 05:00:00');
									CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,i_bgdt,2,this_check_in,this_check_out,this_check_osd);
								END IF;
								
								#需要考虑打卡
								IF i_is_outside_over = 0 THEN
									IF this_check_in IS NOT NULL AND this_check_out IS NOT NULL THEN
										#取交集
										IF this_check_in > this_edt OR this_check_out < this_sdt THEN
											SET today_ohour = 0;
										ELSE
											IF this_sdt < this_check_in THEN
												SET this_sdt = this_check_in;
											END IF;
											IF this_edt > this_check_out THEN
												SET this_edt = this_check_out;
											END IF;
			
											#得到当天的加班时数
											SET today_ohour = FN_ATT_GET_OVER_HOURS(this_sdt,this_edt,i_otid,i_deptid,i_emp);
										END IF;
									ELSE
										SET today_ohour = 0;
									END IF;						
								#不需要考虑打卡
								ELSEIF i_is_outside_over = 1 THEN
									SET today_ohour = FN_ATT_GET_OVER_HOURS(this_sdt,this_edt,i_otid,i_deptid,i_emp);
								END IF;

								SET this_ohour = this_ohour + today_ohour;
								SET THIS_CT = THIS_CT + 1;
							END WHILE;
						#多天申请当是第一天,且时间超过5点
						ELSEIF init_i_bgdt<>i_eddt AND i_bgdt = init_i_bgdt AND TIME(sdt) >= '05:00:00' THEN
							SET this_sdt = sdt;
							SET this_edt = CONCAT(DATE_ADD(i_bgdt,INTERVAL 1 DAY),' 04:59:59');
							
							#需要考虑打卡
							IF i_is_outside_over = 0 THEN
								CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,i_bgdt,2,this_check_in,this_check_out,this_check_osd);
								IF this_check_in IS NOT NULL AND this_check_out IS NOT NULL THEN
									#取交集
	
									IF this_check_in > this_edt OR this_check_out < this_sdt THEN
										SET this_ohour = 0;
									ELSE
										IF this_sdt < this_check_in THEN
											SET this_sdt = this_check_in;
										END IF;
										IF this_edt > this_check_out THEN
											SET this_edt = this_check_out;
										END IF;
										#得到当天的加班时数
										SET this_ohour = FN_ATT_GET_REAL_OVER_HOURS(time(this_sdt),time(this_edt),MY_ATTID,i_otid,i_emp,i_bgdt);
									END IF;
								ELSE
									SET this_ohour = 0;
								END IF;
							#不需要考虑打卡
							ELSEIF i_is_outside_over = 1 THEN
								SET this_ohour = FN_ATT_GET_REAL_OVER_HOURS(time(this_sdt),time(this_edt),MY_ATTID,i_otid,i_emp,i_bgdt);
							END IF;
						#多天申请当是第一天,且时间没超过5点
						ELSEIF init_i_bgdt<>i_eddt AND i_bgdt = init_i_bgdt AND TIME(sdt) < '05:00:00' THEN
							SET THIS_CT = 1,THIS_MXCT = 2,this_ohour=0;
							WHILE THIS_CT <= THIS_MXCT DO
								SET today_ohour = 0,this_sdt=NULL,this_edt=NULL;
								SET this_check_in=NULL,this_check_out=NULL,this_check_osd=NULL;
								IF THIS_CT = 1 THEN
									SET this_sdt = sdt;
									SET this_edt = CONCAT(DATE(this_sdt),' 04:59:59');
									CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,DATE_ADD(i_bgdt,INTERVAL -1 DAY),2,this_check_in,this_check_out,this_check_osd);
								ELSE
									SET this_edt = edt;
									SET this_sdt = CONCAT(DATE(this_edt),' 05:00:00');
									CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,i_bgdt,2,this_check_in,this_check_out,this_check_osd);
								END IF;
	
								#需要考虑打卡
								IF i_is_outside_over = 0 THEN
									IF this_check_in IS NOT NULL AND this_check_out IS NOT NULL THEN
										#取交集
										IF this_check_in > this_edt OR this_check_out < this_sdt THEN
											SET today_ohour = 0;
										ELSE
											IF this_sdt < this_check_in THEN
												SET this_sdt = this_check_in;
											END IF;
											IF this_edt > this_check_out THEN
												SET this_edt = this_check_out;
											END IF;
		
											#得到当天的加班时数
											SET today_ohour = FN_ATT_GET_OVER_HOURS(this_sdt,this_edt,i_otid,i_deptid,i_emp);
										END IF;
									ELSE
										SET today_ohour = 0;
									END IF;
								#不需要考虑打卡
								ELSEIF i_is_outside_over = 1 THEN
									SET today_ohour = FN_ATT_GET_OVER_HOURS(this_sdt,this_edt,i_otid,i_deptid,i_emp);
								END IF;
								
								SET this_ohour = this_ohour + today_ohour;
								SET THIS_CT = THIS_CT + 1;
							END WHILE;
						#多天申请最后一天
						ELSEIF init_i_bgdt<>i_eddt AND i_bgdt = i_eddt THEN
							SET this_sdt = CONCAT(i_bgdt,' 05:00:00');
							SET this_edt = edt;
							#需要考虑打卡
							IF i_is_outside_over = 0 THEN
								CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,i_bgdt,2,this_check_in,this_check_out,this_check_osd);

								IF this_check_in IS NOT NULL AND this_check_out IS NOT NULL THEN
									#取交集
									IF this_check_in > this_edt OR this_check_out < this_sdt THEN
										SET this_ohour = 0;
									ELSE
										IF this_sdt < this_check_in THEN
											SET this_sdt = this_check_in;
										END IF;
										IF this_edt > this_check_out THEN
											SET this_edt = this_check_out;
										END IF;
										#得到当天的加班时数
										SET this_ohour = FN_ATT_GET_REAL_OVER_HOURS(time(this_sdt),time(this_edt),MY_ATTID,i_otid,i_emp,i_bgdt);
									END IF;
								ELSE
									SET this_ohour = 0;
								END IF;
							#不需要考虑打卡
							ELSEIF i_is_outside_over = 1 THEN
								SET this_ohour = FN_ATT_GET_REAL_OVER_HOURS(time(this_sdt),time(this_edt),MY_ATTID,i_otid,i_emp,i_bgdt);
							END IF;
						#多天申请其余天数
						ELSE 
							SET this_sdt = CONCAT(i_bgdt,' 05:00:00');
							SET this_edt = CONCAT(DATE_ADD(i_bgdt,INTERVAL 1 DAY),' 04:59:59');
							#需要考虑打卡
							IF i_is_outside_over = 0 THEN
								CALL FN_ATT_GET_DAILY_FIXED_CHECKTIME(i_emp,i_bgdt,2,this_check_in,this_check_out,this_check_osd);

								IF this_check_in IS NOT NULL AND this_check_out IS NOT NULL THEN
									#取交集
									IF this_check_in > this_edt OR this_check_out < this_sdt THEN
										SET this_ohour = 0;
									ELSE
										IF this_sdt < this_check_in THEN
											SET this_sdt = this_check_in;
										END IF;
										IF this_edt > this_check_out THEN
											SET this_edt = this_check_out;
										END IF;
										#得到当天的加班时数
										SET this_ohour = FN_ATT_GET_REAL_OVER_HOURS(time(this_sdt),time(this_edt),MY_ATTID,i_otid,i_emp,i_bgdt);
									END IF;
								ELSE
									SET this_ohour = 0;
								END IF;
							#不需要考虑打卡
							ELSEIF i_is_outside_over = 1 THEN
								SET this_ohour = FN_ATT_GET_REAL_OVER_HOURS(time(this_sdt),time(this_edt),MY_ATTID,i_otid,i_emp,i_bgdt);
							END IF;
						END IF;
						
						IF this_ohour IS NULL OR this_ohour < 0 THEN
							SET this_ohour = 0;
						END IF;
						
						IF i_permit_over_hours >= 0 AND i_permit_over_hours IS NOT NULL AND this_ohour > i_permit_over_hours THEN
							SET this_ohour = i_permit_over_hours;
						END IF;
						
						
						IF this_dttype in (2,3,4) AND this_ohour > 8 THEN
							SET this_ohour = 8;
						END IF;
#select this_ohour,i_permit_over_hours;
						#写入day表
						replace into att_over_apply_day 
							(att_id,ot_id,date_repay_type,apply_id,cust_id,dept_id,dept_name,emp_id,emp_name,work_day,date_type,work_hour,partition_code) 
						values
							(MY_ATTID,i_otid,i_date_repay_type,i_applyid,i_custid,i_deptid,i_deptn,i_emp,i_empn,i_bgdt,this_dttype,this_ohour,md5(concat(i_emp,i_bgdt,i_applyid)));
						
						#更新考勤日报是否加班						
						SET IS_TODAY_HAVE_OVER=NULL;
						
						SELECT SUM(A.work_hour) INTO IS_TODAY_HAVE_OVER
						FROM att_over_apply_day A
						WHERE A.emp_id=i_emp AND A.work_day = i_bgdt;
						
						IF IS_TODAY_HAVE_OVER IS NULL OR IS_TODAY_HAVE_OVER < 0 THEN
							SET IS_TODAY_HAVE_OVER = 0;
						ELSEIF IS_TODAY_HAVE_OVER > 0 THEN
							SET IS_TODAY_HAVE_OVER = 1;
						END IF;
						
						IF this_ohour > 0 THEN
							UPDATE att_emp_detail A
							SET A.is_have_over = IS_TODAY_HAVE_OVER
							WHERE A.emp_id=i_emp AND A.dt=i_bgdt;
						END IF;
						SET i_bgdt = DATE_ADD(i_bgdt,INTERVAL 1 DAY);
					END WHILE;							
	
				
				#将本次的修改记录到池子表的修改记录中
				
					#最后更新的日期  last_update_date
					#最后修改值      last_mod_value
					#本次执行日期    this_date   
					#本次执行次数    this_do_times
					#本次发生值      this_do_value
					#池中数          pool_value
					#当前条目初始值  onday_ori_valueX
					#当前条目的发生值（上次发生值）
					#                onday_do_value
					SET THIS_DO_YEAR = NULL;
					SET this_do_value = NULL; 
					SELECT SUM(IF(work_hour IS NULL,0,work_hour)),YEAR(MIN(work_day)) INTO this_do_value,THIS_DO_YEAR 
					FROM att_over_apply_day A WHERE apply_id=i_applyid AND A.date_repay_type=2;
					IF this_do_value > 0 THEN
#select i_emp,i_applyid,2,1,this_do_value;
						CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,2,1,this_do_value); 
					END IF;
				END IF;
	#----------------- 逻辑架构结束 ------------------------		
			END IF;
			set ct=ct+1;
		end while;													#loop2






		##################           PART 2          ##########################
		#																							 #
		#			对审核驳回和撤销的申请进行计算和日报归档							  #
		#																							 #
		#######################################################################

		#根据列表依次计算
		select min(id),max(id) into ctn,mxctn from tmp_att_over_list_no  where version_code = i_version_code;
#SELECT * FROM tmp_att_over_list_no;
		WHILE (ctn <= mxctn and ctn>0) DO
			set i_repay_type = null;
			SET i_applyid = NULL;
			set i_emp = null;
			SET THIS_DO_YEAR = NULL;
			#得到apply_id
			select apply_id into i_applyid from tmp_att_over_list_no where id = ctn and version_code = i_version_code;
			select YEAR(start_time) INTO THIS_DO_YEAR from att_over_apply where apply_id = i_applyid;
			IF i_applyid IS NOT NULL THEN
				#先看看日表中有没有这条申请的记录，如果有，做回滚操作，如果没有，不用做任何事情
				select count(*) into do_recycle from att_over_apply_day where apply_id = i_applyid;
				if ( do_recycle > 0 ) then						#if99		
					select emp_id into i_emp from att_over_apply_day where apply_id = i_applyid limit 1;
					select count(*) into i_repay_type from att_over_apply_day a where a.apply_id = i_applyid and a.date_repay_type=2;
					if i_repay_type > 0 then
						#将本次的修改记录到池子表的修改记录中
						CALL SP_ATT_ICSS_POOL_MODIFY_LOG(i_emp,i_applyid,2,1,0);
					end if;
					
					SELECT MIN(A.work_day),MAX(A.work_day) 
						INTO OVER_BGDT,OVER_EDDT
					FROM att_over_apply_day A WHERE A.apply_id = i_applyid;
					
					#删除日表数据
					delete from att_over_apply_day where apply_id = i_applyid;
					
					WHILE OVER_BGDT <= OVER_EDDT DO
						SET IS_TODAY_HAVE_OVER=NULL;
						
						SELECT SUM(A.work_hour) INTO IS_TODAY_HAVE_OVER
						FROM att_over_apply_day A
						WHERE A.emp_id=i_emp AND A.work_day = OVER_BGDT;
						
						IF IS_TODAY_HAVE_OVER IS NULL OR IS_TODAY_HAVE_OVER <= 0 THEN
							SET IS_TODAY_HAVE_OVER = 0;
						ELSEIF IS_TODAY_HAVE_OVER > 0 THEN
							SET IS_TODAY_HAVE_OVER = 1;
						END IF;
						
						UPDATE att_emp_detail A
						SET A.is_have_over = IS_TODAY_HAVE_OVER
						WHERE A.emp_id=i_emp AND A.dt=OVER_BGDT;
						
						SET OVER_BGDT = DATE_ADD(OVER_BGDT,INTERVAL 1 DAY);
					END WHILE;
				end if;												#if99

			END IF;
			SET ctn = ctn + 1;
		END WHILE;

		set bgdt=date_add(bgdt,interval 1 day);
	end while;														#loop1


END;

