create function FN_ATT_GET_DAYOFF_STATUS(LATE_MINS decimal, EARLY_MINS decimal, ATTID bigint unsigned)
  returns int
  comment '根据给出的迟到早退时间来判断当天的旷工类型（该方法不考虑日期类型，取得值之后需要和日期类型总和考虑）'
  BEGIN
DECLARE i_is_dayoff,QQ_MINS,i_att_rule,i_half_dayoff_late_mins,i_all_dayoff_late_mins,i_half_dayoff_early_mins,i_all_dayoff_early_mins,i_half_dayoff_qq_mins,i_all_dayoff_qq_mins	BIGINT;
DECLARE SHOULD_WORK_MIN,my_qq_kg ,my_early_kg ,my_late_kg DECIMAL(12,1);
	#查看考勤类型，只有坐班和排班涉及到
	SELECT att_rule INTO i_att_rule FROM att_set_schema_new WHERE att_id = ATTID ; 


	IF i_att_rule IN (1,3) THEN
		#读出旷工相关的数据
		SELECT half_dayoff_late_mins,all_dayoff_late_mins,
			#迟到x分钟等于矿工半天,迟到x分钟等于矿工1天
			half_dayoff_early_mins,all_dayoff_early_mins,
			#早退x分钟等于矿工半天,早退x分钟等于矿工1天
			half_dayoff_qq_mins,all_dayoff_qq_mins
			#缺勤x分钟等于矿工半天，缺勤x分钟等于矿工1天
			INTO i_half_dayoff_late_mins,i_all_dayoff_late_mins,
			i_half_dayoff_early_mins,i_all_dayoff_early_mins,
			i_half_dayoff_qq_mins,i_all_dayoff_qq_mins	
		FROM att_set_schema_new WHERE att_id = ATTID;
#SELECT i_half_dayoff_late_mins,i_all_dayoff_late_mins,i_half_dayoff_early_mins,i_all_dayoff_early_mins,i_half_dayoff_qq_mins,i_all_dayoff_qq_mins	;
		#迟到早退分钟数和缺勤计算
		IF LATE_MINS IS NULL OR LATE_MINS<0 THEN SET LATE_MINS = 0; END IF;
		IF EARLY_MINS IS NULL OR EARLY_MINS<0 THEN SET EARLY_MINS = 0; END IF;
		SET QQ_MINS = LATE_MINS+EARLY_MINS;
		#如果没有设置，那么视为最大值
		IF i_half_dayoff_late_mins IS NULL OR i_half_dayoff_late_mins = 0 THEN SET i_half_dayoff_late_mins = 899999999; END IF;
		IF i_all_dayoff_late_mins IS NULL OR i_all_dayoff_late_mins = 0 THEN SET i_all_dayoff_late_mins = 99999999; END IF;
		IF i_half_dayoff_early_mins IS NULL OR i_half_dayoff_early_mins = 0 THEN SET i_half_dayoff_early_mins = 89999999; END IF;
		IF i_all_dayoff_early_mins IS NULL OR i_all_dayoff_early_mins = 0 THEN SET i_all_dayoff_early_mins = 99999999; END IF;
		#处理迟到的旷工情况
		IF i_half_dayoff_late_mins > 0 AND i_all_dayoff_late_mins > 0 AND LATE_MINS >= i_half_dayoff_late_mins AND LATE_MINS < i_all_dayoff_late_mins THEN
			SET my_late_kg = 0.5;
		ELSEIF i_all_dayoff_late_mins > 0 AND LATE_MINS >= i_all_dayoff_late_mins THEN
			SET my_late_kg = 1;
		ELSE
			SET my_late_kg = 0;
		END IF;
		
		#处理早退的旷工情况
		IF i_half_dayoff_early_mins > 0 AND i_all_dayoff_early_mins > 0 AND EARLY_MINS >= i_half_dayoff_early_mins AND EARLY_MINS < i_all_dayoff_early_mins THEN
			SET my_early_kg = 0.5;
		ELSEIF i_all_dayoff_early_mins > 0 AND EARLY_MINS >= i_all_dayoff_early_mins THEN
			SET my_early_kg = 1;
		ELSE
			SET my_early_kg = 0;
		END IF;
		
		#处理缺勤的旷工情况
		IF i_half_dayoff_qq_mins > 0 AND i_all_dayoff_qq_mins > 0 AND QQ_MINS >= i_half_dayoff_qq_mins AND QQ_MINS < i_all_dayoff_qq_mins THEN
			SET my_qq_kg = 0.5;
		ELSEIF i_all_dayoff_qq_mins > 0 AND QQ_MINS >= i_all_dayoff_qq_mins THEN
			SET my_qq_kg = 1;
		ELSE
			SET my_qq_kg = 0;
		END IF;
	
		#计算旷工
		IF my_qq_kg = 1 OR my_early_kg = 1 OR my_late_kg = 1 THEN
			SET i_is_dayoff = 1;
		ELSEIF my_qq_kg = 0.5 OR my_early_kg = 0.5 OR my_late_kg = 0.5 THEN
			SET i_is_dayoff = 2;
		ELSE
			SET i_is_dayoff = 0;
		END IF;
		
		SET SHOULD_WORK_MIN = FN_ATT_GET_WORKHOURS(ATTID)*60;
		
		#当前出勤未满6小时	
		IF i_is_dayoff = 0 AND SHOULD_WORK_MIN - LATE_MINS - EARLY_MINS < 360 THEN
			SET i_is_dayoff = 1;
		END IF;
		
	ELSE
		SET i_is_dayoff = 0;
	END IF;
	RETURN i_is_dayoff;

END;

