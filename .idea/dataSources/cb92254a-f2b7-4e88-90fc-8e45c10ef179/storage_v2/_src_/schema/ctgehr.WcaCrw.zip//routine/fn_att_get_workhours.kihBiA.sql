create function FN_ATT_GET_WORKHOURS(ATTID bigint unsigned)
  returns decimal(12, 2)
  comment '根据输入的出勤方案id得到每天的工作时长'
  LABEL:BEGIN
	DECLARE a_attrule,a_flexratio,is_have_dept INT;
	DECLARE mst,met,ast,aet TIME;
	DECLARE a_flexhour,i_daily_hour DECIMAL(12,2);

#****** 规则性默认值 ：
#****** 坐班：按照实际小时数
#****** 综合工时-天：按照设置的小时数来走
#****** 综合工时-月：按照设置的小时/21.75来走
#****** 排班：每天8小时


	
	IF ATTID IS NOT NULL THEN		#如果有部门时才开始计算

		select b.att_rule
			into a_attrule
		from att_set_schema_new b 
		where b.att_id=ATTID;
		
		#1	得到考勤设置
		select 	b.att_rule,morn_start_time,morn_end_time,aftn_start_time,aftn_end_time,
					zh_ratio,zh_hour
			into	a_attrule,mst,met,ast,aet,	#出勤规则（1准时考勤 2弹性考勤）、四个时间
					a_flexratio,a_flexhour		#弹性工作时间频率（1每天 2每月），弹性工作时间（小时）
		from att_set_schema_new b 
		where  b.att_id=ATTID;
		
		IF a_attrule = 1 THEN
			#计算 一天工作时长 涉及参数：a_attrule,mst,met,ast,aet，a_flexratio,a_flexhour
			SET i_daily_hour = ROUND(TIME_TO_SEC(timediff(met,mst))/3600,2) + ROUND(TIME_TO_SEC(timediff(aet,ast))/3600,2) ;
		ELSEIF a_attrule = 2 THEN
			IF a_flexratio = 1 THEN
				SET i_daily_hour = a_flexhour;
			ELSE
				SET i_daily_hour = ROUND(a_flexhour/21.75,2);
			END IF;
		ELSE
			SET i_daily_hour = 8;
		END IF;
		
	END IF;
	
	IF i_daily_hour IS NULL THEN
		SET i_daily_hour = 8;
	END IF;
	RETURN i_daily_hour;
END;

