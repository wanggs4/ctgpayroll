create procedure DBA_DUPLICATE_ROLES(IN CUSTID bigint unsigned, IN TARGET_CUSTID bigint unsigned)
  comment '以给到的公司为模板，更新所有au_roles里cust_id=0的角色的关系表'
  BEGIN
DECLARE CT,MXCT BIGINT;
DECLARE THIS_ROLENAME VARCHAR(50);
	DROP TABLE IF EXISTS tmp_sample_role;
	CREATE TABLE IF NOT EXISTS `tmp_sample_role` (
		`id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		`role_name` VARCHAR(50) NOT NULL COMMENT '角色名称',
		PRIMARY KEY (`id`)
	)
	COLLATE='utf8mb4_general_ci'
	ENGINE=MEMORY;
	
	DROP TABLE IF EXISTS tmp_mubiao_role;
	CREATE TABLE IF NOT EXISTS `tmp_mubiao_role` (
		`role_id` BIGINT(20) UNSIGNED NOT NULL ,
		PRIMARY KEY (`role_id`)
	)
	COLLATE='utf8mb4_general_ci'
	ENGINE=MEMORY;
	
	INSERT INTO tmp_sample_role (role_name) SELECT a.role_name from au_roles a where a.cust_id=0;
	SET CT=0,MXCT=0;
	SELECT MIN(ID),MAX(ID) INTO CT,MXCT FROM tmp_sample_role ;
	
	WHILE CT <= MXCT AND CT > 0 DO
		SET THIS_ROLENAME = NULL;
		SELECT A.role_name INTO THIS_ROLENAME FROM tmp_sample_role A WHERE A.id=CT;
		IF THIS_ROLENAME IS NOT NULL THEN
			TRUNCATE TABLE tmp_mubiao_role ;
			IF TARGET_CUSTID IS NULL THEN
				INSERT INTO tmp_mubiao_role (ROLE_ID)
					SELECT A.role_id FROM au_roles A WHERE A.role_name=THIS_ROLENAME AND A.cust_id<>CUSTID;
			ELSE
				INSERT INTO tmp_mubiao_role (ROLE_ID)
					SELECT A.role_id FROM au_roles A WHERE A.role_name=THIS_ROLENAME AND A.cust_id=TARGET_CUSTID AND A.cust_id<>CUSTID;
			END IF;
			
			DELETE A.* FROM au_rel_role_menu A,tmp_mubiao_role B where A.role_id=B.ROLE_ID;
			
			INSERT INTO au_rel_role_menu 
				SELECT C.ROLE_ID,B.menu_id
				FROM tmp_mubiao_role C, au_roles A ,au_rel_role_menu B
				WHERE A.cust_id=CUSTID AND A.role_name=THIS_ROLENAME AND A.is_enable=1
					AND A.role_id=B.role_id;
		END IF;
		SET CT = CT + 1;
	END WHILE;
	
	DROP TABLE IF EXISTS tmp_sample_role;
	DROP TABLE IF EXISTS tmp_mubiao_role;
	
END;

