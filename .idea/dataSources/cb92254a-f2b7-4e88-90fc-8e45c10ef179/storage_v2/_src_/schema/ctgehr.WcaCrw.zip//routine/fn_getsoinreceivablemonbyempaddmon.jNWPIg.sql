create function FN_getSoinReceivableMonByEmpAddMon(serviceMon       varchar(50), empStartMon varchar(50),
                                                   empRemittanceMon varchar(50))
  returns varchar(50)
  BEGIN
	DECLARE FINAL_DATE VARCHAR(50);
	DECLARE BGDT,EDDT,FINALDATE DATE;
	DECLARE DIFF_MON INT;
	SET FINAL_DATE=NULL;
	SET BGDT = CONCAT(LEFT(empStartMon,4),'-',RIGHT(empStartMon,2),'-01');
	SET EDDT = CONCAT(LEFT(empRemittanceMon,4),'-',RIGHT(empRemittanceMon,2),'-01');

	SET DIFF_MON = 0;
	WHILE (BGDT<EDDT) DO
		SET DIFF_MON = DIFF_MON + 1;
		SET BGDT = DATE_ADD(BGDT,INTERVAL 1 MONTH);
	END WHILE;
	
	SET FINALDATE = CONCAT(LEFT(serviceMon,4),'-',RIGHT(serviceMon,2),'-01');
	SET FINALDATE = DATE_ADD(FINALDATE,INTERVAL DIFF_MON MONTH);
	SET FINAL_DATE = REPLACE(LEFT(FINALDATE,7),'-','');
	
	RETURN FINAL_DATE;
END;

