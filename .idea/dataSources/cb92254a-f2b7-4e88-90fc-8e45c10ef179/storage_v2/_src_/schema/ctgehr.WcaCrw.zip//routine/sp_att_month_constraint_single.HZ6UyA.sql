create procedure SP_ATT_MONTH_CONSTRAINT_SINGLE(IN bgdt date, IN eddt date, IN emp bigint unsigned)
  comment '针对周期内的日报进行检查和纠错,例如：请假对于考勤的影响'
  BEGIN
DECLARE MY_DTTYPE,MY_BOSS_LEVEL,ARR_BGDAY1,ARR_EDDAY1,ARR_BGDAY2,ARR_EDDAY2,ARR_BGDAY3,ARR_EDDAY3,MY_HOLRULE,MY_ATTRULE,THIS_WEEKDAY,MY_ATTGROUPNUMBER,i_have_out,sp_day_half_flag,this_half_day_flag,i_half_day_flag,i_have_half_day_hols,THIS_DAYOFF,ieh,stat,ct,mxct,i_date_type,is_have_att_daily,i_have_hols,h_is_dayoff,app_cnt,app_mxcnt,i_att_rule INT;
DECLARE I_HAVE_SPDAYS,i_act_do_num,i_should_do_num BIGINT;
DECLARE MY_HOLID,i_prgm_id,i_jrdc_id,i_dms_id4,i_dms_id5,i_dms_id6,i_dms_id7,i_dms_id8,i_dms_id9,i_dms_id10,i_position_level_id,i_emp,i_deptid,i_custid,i_holid,i_applyid,MY_ATTID BIGINT UNSIGNED;
DECLARE MONTH_FLEX,MY_MONTH_FLEX_LATE,MY_MONTH_FLEX,ERROR_MINS,THIS_QQ_MINS,i_flex_hour,MY_HOL_DIFF,MY_CK_DIFF,MY_FLEX_DIFF,THIS_WORK_MINS,MY_CNT_HOL_HOUR,MY_ACT_HOUR,i_month_period_hour,MY_WORKMINS,MY_ORI_LATEMINS,MY_ORI_EARLYMINS,MY_ORI_WORKMINS,MY_SPDAY_HOURS,MY_HOLIDAY_HOURS,MY_NA_MINS,THIS_HOL_MINS,THIS_LM,THIS_EM,THIS_MHM,h_work_interval,nl_hour,ne_hour,h_late_mins,h_early_mins,h_hol_hours,i_daily_work_hour,i_hol_hours,MY_MIKLHOL_HOURS DECIMAL(12,2);
DECLARE THIS_HOL_BGTM,THIS_HOL_EDTM,MY_CPT_MST,THIS_ARR_BGTM1,THIS_ARR_EDTM1,THIS_ARR_BGTM2,THIS_ARR_EDTM2,THIS_ARR_BGTM3,THIS_ARR_EDTM3,i_check_in,i_check_out,i_check_osd,THIS_MST,THIS_MET,THIS_AST,THIS_AET,THIS_NA1_BGTM,THIS_NA1_EDTM,THIS_NA2_BGTM,THIS_NA2_EDTM,MY_MONTH_CKIN DATETIME;
DECLARE MY_APPLY_END_TIME,ARR_BGTM1,ARR_EDTM1,ARR_BGTM2,ARR_EDTM2,ARR_BGTM3,ARR_EDTM3,SP_START_TIME,SP_END_TIME,min_start_time,max_end_time,start_time,end_time,MST,MET,AST,AET,i_na_start_time_1,i_na_end_time_1,i_na_start_time_2,i_na_end_time_2 TIME;
DECLARE i_eddt,i_bgdt,i_entry_date,i_leave_date,I_HOL_BGDT,I_HOL_EDDT date;
DECLARE ATTID_STR,MY_HOL_STR,THIS_HOL_STR TEXT;
DECLARE THIS_UID,i_partition_code,i_emp_code,i_emp_name VARCHAR(50);
DECLARE THIS_MAX_MST,THIS_MAX_AET,MY_FST_CHECK,MY_LAST_CHECK,THIS_BGTM,THIS_EDTM DATETIME;

	set sql_mode='';
	SET h_hol_hours = 0,i_hol_hours=0;
	#得到该员工的各项id
	SELECT a.emp_id,a.cust_id,a.dept_id,a.prgm_id,a.jrdc_id,a.dms_id4,a.dms_id5,a.dms_id6,a.dms_id7,a.dms_id8,a.dms_id9,a.dms_id10,
			b.position_level_id,b.emp_code,a.emp_name,a.boss_level
		INTO 	i_emp,i_custid,i_deptid,i_prgm_id,i_jrdc_id,i_dms_id4,i_dms_id5,i_dms_id6,i_dms_id7,i_dms_id8,i_dms_id9,i_dms_id10,
				i_position_level_id,i_emp_code,i_emp_name,MY_BOSS_LEVEL
	FROM emp_base_info a LEFT JOIN emp_post b ON a.emp_id=b.emp_id 
	WHERE a.emp_id = emp ;
	
	IF i_emp IS NOT NULL THEN

		select entry_date,leave_date into i_entry_date,i_leave_date from emp_post where emp_id = i_emp;
		#循环2 按给定的日期范围循环
		
		IF i_entry_date > bgdt AND i_entry_date IS NOT NULL THEN 
			SET bgdt = i_entry_date; 
		END IF;
		
		IF i_leave_date < eddt AND i_leave_date IS NOT NULL THEN
			SET eddt = i_leave_date;
		END IF;
		
		SELECT MIN(A.hol_date),MAX(A.hol_date)
			INTO I_HOL_BGDT,I_HOL_EDDT
		FROM att_hol_apply_day A
		WHERE A.emp_id=i_emp AND A.hol_date BETWEEN bgdt AND eddt ;
		
		IF I_HOL_BGDT > bgdt AND I_HOL_BGDT IS NOT NULL THEN 
			SET bgdt = I_HOL_BGDT; 
		END IF;
		
		IF I_HOL_EDDT < eddt AND I_HOL_EDDT IS NOT NULL THEN
			SET eddt = I_HOL_EDDT;
		END IF;

		#按天循环
		WHILE(bgdt <= eddt) DO
			SET h_hol_hours = 0,i_hol_hours=0;
			SET i_date_type=NULL,i_check_in=NULL,i_check_out=NULL,i_check_osd=NULL,is_have_att_daily=0;
			SET i_have_hols=NULL,i_have_half_day_hols=NULL,min_start_time=NULL,max_end_time=NULL,MY_APPLY_END_TIME=NULL;
			SET MY_HOLIDAY_HOURS=0,MY_SPDAY_HOURS=0,MY_MIKLHOL_HOURS=0;
			SET ATTID_STR = NULL,MY_ATTID=NULL;
			#初始化变量
			SET MY_ATTID=NULL,MY_ATTRULE=NULL,MY_ORI_WORKMINS=NULL,MY_ORI_LATEMINS=NULL,MY_ORI_EARLYMINS=NULL;
			#得到日报的信息
			SELECT A.late_mins,A.early_mins,A.work_interval,A.att_id,date_type,
				check_in,check_out,check_osd,count(*)
				INTO MY_ORI_LATEMINS,MY_ORI_EARLYMINS,MY_ORI_WORKMINS,MY_ATTID,i_date_type,i_check_in,i_check_out,i_check_osd,is_have_att_daily
			FROM att_emp_detail A
			WHERE emp_id = i_emp AND dt = bgdt;
			
			IF MY_ATTID IS NULL THEN
				CALL SP_DPT_GET_SETTINGID(i_emp,bgdt,1,ATTID_STR);
				SET MY_ATTID = CAST(ATTID_STR AS UNSIGNED);
			END IF;
			#第一步：获得和计算设定值
			IF MY_ATTID IS NOT NULL THEN
				SET MY_DTTYPE = FN_ATT_GET_DTTYPE(bgdt,i_emp);
				
				#得到该员工的出勤设置
				SELECT b.att_rule,b.is_exp_hol,
						b.morn_start_time,b.morn_end_time,b.aftn_start_time,b.aftn_end_time,b.month_period_hour,b.flex_hour,
						b.na_start_time_1,b.na_end_time_1,b.na_start_time_2,b.na_end_time_2
					INTO i_att_rule,ieh,
						MST,MET,AST,AET,i_month_period_hour,i_flex_hour,
						i_na_start_time_1,i_na_end_time_1,i_na_start_time_2,i_na_end_time_2
				FROM att_set_schema_new b
				WHERE b.att_id=MY_ATTID;
				
				#考勤有效时间点转化为datetime
				#坐班
				SET THIS_MST = CONCAT(bgdt,' ',MST);
				SET THIS_MET = CONCAT(bgdt,' ',MET);
				SET THIS_AST = CONCAT(bgdt,' ',AST);
				SET THIS_AET = CONCAT(bgdt,' ',AET);
				SET THIS_NA1_BGTM = CONCAT(bgdt,' ',i_na_start_time_1);
				SET THIS_NA1_EDTM = CONCAT(bgdt,' ',i_na_end_time_1);
				SET THIS_NA2_BGTM = CONCAT(bgdt,' ',i_na_start_time_2);
				SET THIS_NA2_EDTM = CONCAT(bgdt,' ',i_na_end_time_2);			
				
				IF ieh IS NULL OR ieh NOT IN (0,1) THEN SET ieh = 0 ; END IF;
				IF i_month_period_hour IS NULL THEN SET i_month_period_hour=0; END IF;
				
				IF i_flex_hour IS NULL THEN 
					SET i_flex_hour = 0;
				END IF;
				
				
				SET THIS_MAX_MST=NULL,THIS_MAX_AET=NULL;
				#日弹最晚上班时间和最晚下班时间
				IF i_flex_hour > 0 THEN
					SET THIS_MAX_MST = DATE_ADD(THIS_MST,INTERVAL i_flex_hour MINUTE);
					SET THIS_MAX_AET = DATE_ADD(THIS_AET,INTERVAL i_flex_hour MINUTE);
				END IF;
				
				#月弹最晚上班时间和最晚下班时间
				IF i_month_period_hour > 0 THEN
					SET THIS_MAX_MST = DATE_ADD(THIS_MST,INTERVAL (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60 MINUTE);
					SET THIS_MAX_AET = THIS_AET;
				END IF;
				
				#把弹后的最晚下班时间做校验是否覆盖晚餐时间的处理
				CALL FN_ATT_PASS_DINNER_TIME(THIS_MAX_AET,MY_ATTID,THIS_MAX_AET);
				
			END IF;
			
			
#1 >>>>>>>>>>>>>>>>>>>		请假校正开始
#1.1 ----------> 	除了每天一小时的哺乳假以外，所有的假期
			#得到请假的信息
			#首先看看当天有几个休假
			SET i_have_hols = 0;
			SELECT count(*) INTO i_have_hols
			FROM att_hol_apply_day A 
				LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
				AND (A.is_year_hol NOT IN (4,9) OR (A.is_year_hol=4 AND B.hol_duration=2)) 
				AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL) and A.hol_hours>0;
				
			SELECT COUNT(*) INTO i_have_out
			FROM att_hol_apply_day A 
				LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			WHERE A.emp_id = i_emp AND A.hol_date = bgdt  AND A.hol_hours > 0
				AND A.is_year_hol = 10 AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL);

			SELECT count(*) INTO i_have_half_day_hols
			FROM att_hol_apply_day A 
				LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			WHERE A.emp_id = i_emp AND A.hol_date = bgdt AND A.min_unit=4
				AND (A.is_year_hol NOT IN (4,9,10) OR (A.is_year_hol=4 AND B.hol_duration=2))
				AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL) and A.hol_hours>0;
				
			SELECT COUNT(*) INTO I_HAVE_SPDAYS
			FROM att_hol_apply_day A 
				LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
			WHERE A.emp_id=i_emp AND A.hol_date = bgdt 
				AND A.sp_day_id IS NOT NULL AND A.sp_day_id<>0 AND B.sp_type=2 and A.hol_hours>0;
			
			SET i_have_half_day_hols = IFNULL(i_have_half_day_hols,0) + IFNULL(I_HAVE_SPDAYS,0);
			SET i_have_hols = IFNULL(i_have_hols,0) + IFNULL(I_HAVE_SPDAYS,0);
			
			SET h_hol_hours = 0;

			#当天有休假且有日报时
			IF i_have_hols > 0 and is_have_att_daily>0 AND MY_DTTYPE IN (1,6) THEN
				#读出当天休假的最早和最晚时间
				SELECT min(A.start_time),max(A.end_time),MAX(APPLY_END_TIME)
					INTO min_start_time,max_end_time,MY_APPLY_END_TIME
				FROM att_hol_apply_day A 
					LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
				AND (A.is_year_hol NOT IN (4,9) OR (A.is_year_hol=4 AND B.hol_duration=2)) and A.hol_hours>0;
				
				IF max_end_time <= min_start_time THEN
					SET max_end_time = MY_APPLY_END_TIME;
				END IF;	
				
				SELECT min(A.start_time),max(A.end_time)
					INTO SP_START_TIME,SP_END_TIME
				FROM att_hol_apply_day A 
					LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt
					AND A.sp_day_id IS NOT NULL AND A.sp_day_id<>0 AND B.sp_type=2 and A.hol_hours>0;

				IF min_start_time > SP_START_TIME AND SP_START_TIME IS NOT NULL THEN
				 SET min_start_time = SP_START_TIME;
				END IF;
				IF max_end_time < SP_END_TIME AND SP_END_TIME IS NOT NULL THEN
				 SET max_end_time = SP_END_TIME;
				END IF;
				IF MY_APPLY_END_TIME < SP_END_TIME AND SP_END_TIME IS NOT NULL THEN
				 SET MY_APPLY_END_TIME = SP_END_TIME;
				END IF;
				
				IF max_end_time > TIME(THIS_MAX_AET) THEN
					SET max_end_time = TIME(THIS_MAX_AET);
				END IF;
				#取得一天最早的考勤时间
				IF i_check_out <> i_check_in AND i_check_out IS NOT NULL AND i_check_in IS NOT NULL THEN
					IF min_start_time IS NOT NULL THEN
						IF i_check_in < CONCAT(bgdt,' ',min_start_time) THEN
							SET MY_FST_CHECK = i_check_in;
						ELSE
							SET MY_FST_CHECK = CONCAT(bgdt,' ',min_start_time);
						END IF;
					#打卡有，请假无
					ELSEIF min_start_time IS NULL THEN
						SET MY_FST_CHECK = i_check_in;
					END IF;
				
					#取得一天最晚的考勤时间
					IF max_end_time IS NOT NULL THEN
						IF i_check_out < CONCAT(bgdt,' ',max_end_time) THEN
							SET MY_LAST_CHECK = CONCAT(bgdt,' ',max_end_time);
						ELSE
							SET MY_LAST_CHECK = i_check_out;
						END IF;
					#打卡有，请假无
					ELSEIF  max_end_time IS NULL THEN
						SET MY_LAST_CHECK = i_check_out;
					END IF;
				ELSEIF i_check_out = i_check_in OR i_check_in IS NULL OR i_check_out IS NULL THEN
					IF min_start_time IS NOT NULL AND max_end_time IS NOT NULL THEN
						SET MY_FST_CHECK = CONCAT(bgdt,' ',min_start_time);
						SET MY_LAST_CHECK = CONCAT(bgdt,' ',max_end_time);
					ELSE 
						SET MY_FST_CHECK = NULL;
						SET MY_LAST_CHECK = NULL;
					END IF;
				END IF;	
#select MY_FST_CHECK,MY_LAST_CHECK,i_check_in,i_check_out,min_start_time,max_end_time;
				IF MY_LAST_CHECK = MY_FST_CHECK THEN
					SET MY_FST_CHECK = NULL, MY_LAST_CHECK = NULL;
				END IF;
				
				#计算请假时长 
				SELECT SUM(A.hol_hours) INTO MY_HOLIDAY_HOURS
				FROM att_hol_apply_day A 
					LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
					AND (A.is_year_hol NOT IN (4,9) OR (A.is_year_hol=4 AND B.hol_duration=2))
					AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL) and A.hol_hours>0;
				#计算哺乳假时长 
				SELECT SUM(A.hol_hours) INTO MY_MIKLHOL_HOURS
				FROM att_hol_apply_day A 
					LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
					AND A.is_year_hol IN (4,9)
					AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL) and A.hol_hours>0;
				#计算特殊假期时长
				SELECT SUM(A.hol_hours) INTO MY_SPDAY_HOURS
				FROM att_hol_apply_day A 
					LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
				WHERE A.emp_id = i_emp and A.hol_hours>0 AND A.hol_date = bgdt AND A.sp_day_id <> 0 AND A.sp_day_id IS NOT NULL AND B.sp_type=2;
				#计算总时长
				SET h_hol_hours = IFNULL(MY_HOLIDAY_HOURS,0) + IFNULL(MY_SPDAY_HOURS,0) + IFNULL(MY_MIKLHOL_HOURS,0);
				#计算工作时长
				SET i_daily_work_hour = FN_ATT_GET_WORKHOURS(MY_ATTID);
				
				#如果当天的请假时长已经超过了当天的应工作时长，那么就应该将当天的旷工、迟到、早退和工作时长归零。
				IF i_daily_work_hour <= h_hol_hours  THEN
					SET h_is_dayoff = 0 ;
					SET h_work_interval = 0 ;
					SET h_late_mins = 0;
					set h_early_mins = 0;
					
#select 1,bgdt,i_daily_work_hour,h_hol_hours,bgdt;

					IF i_have_out > 0 AND i_have_out IS NOT NULL THEN
						IF i_att_rule = 1 THEN
							UPDATE att_emp_detail A
							SET  late_mins = h_late_mins ,
								  early_mins = h_early_mins ,
								  is_dayoff = h_is_dayoff,
								  A.is_have_out = 1,
								  work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID)*60,
						  			milk_hol_mins=null
							WHERE emp_id = i_emp and dt = bgdt;
						ELSEIF i_att_rule = 3 THEN
							UPDATE att_emp_detail A
							SET  late_mins = h_late_mins ,
								  early_mins = h_early_mins ,
								  is_dayoff = h_is_dayoff,
								  A.is_have_out = 1,
								  work_interval = FN_ATT_GET_ARR_WORKHOURS(i_emp,bgdt),
								  milk_hol_mins=null
							WHERE emp_id = i_emp and dt = bgdt;
						END IF;
					ELSE
						IF i_att_rule = 1 THEN
							UPDATE att_emp_detail
							SET work_interval = h_work_interval ,
								  late_mins = h_late_mins ,
								  early_mins = h_early_mins ,
								  is_dayoff = h_is_dayoff,
								  is_have_hol = 1,
								  hol_mins = FN_ATT_GET_WORKHOURS(MY_ATTID)*60,
								  milk_hol_mins=null
							WHERE emp_id = i_emp and dt = bgdt;
						ELSEIF i_att_rule = 3 THEN
							UPDATE att_emp_detail
							SET work_interval = h_work_interval ,
								  late_mins = h_late_mins ,
								  early_mins = h_early_mins ,
								  is_dayoff = h_is_dayoff,
								  is_have_hol = 1,
								  hol_mins = FN_ATT_GET_ARR_WORKHOURS(i_emp,bgdt),
								  milk_hol_mins=null
							WHERE emp_id = i_emp and dt = bgdt;
						END IF;
					END IF;
				#坐班考勤，请假时长小于应工作时长，并且有半天假
				ELSEIF i_daily_work_hour > h_hol_hours AND i_have_half_day_hols >= 1 AND i_att_rule = 1 THEN
					SET h_is_dayoff = 0 ;
					SET h_work_interval = 0 ;
					SET h_late_mins = 0;
					set h_early_mins = 0;
					
					SELECT SUM(IFNULL(A.half_day_flag,0)) INTO i_half_day_flag
					FROM att_hol_apply_day A 
						LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
					WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
						AND (A.is_year_hol NOT IN (4,9) OR (A.is_year_hol=4 AND B.hol_duration=2))
						AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL) and A.hol_hours>0;

					SELECT SUM(IFNULL(A.half_day_flag,0)) INTO sp_day_half_flag
					FROM att_hol_apply_day A
						LEFT JOIN att_set_special_day B ON A.sp_day_id=B.sp_day_id
					WHERE A.emp_id = i_emp AND A.hol_date = bgdt AND A.sp_day_id <> 0 and A.sp_day_id IS NOT NULL AND B.sp_type=2;
					set i_half_day_flag = ifnull(i_half_day_flag,0) + ifnull(sp_day_half_flag,0) and A.hol_hours>0;
					
					IF i_half_day_flag IS NULL THEN SET i_half_day_flag = 0; END IF;
					#请了上午半天
					IF i_half_day_flag = 1 THEN
						#无外签，有打卡
						IF i_check_osd IS NULL AND i_check_in IS NOT NULL AND i_check_out IS NOT NULL THEN
							SET MY_NA_MINS = (i_daily_work_hour - h_hol_hours) * 60 - FN_ATT_GET_REAL_DAY_HOURS(time(i_check_in),time(i_check_out),i_emp,bgdt);

							IF MY_NA_MINS < 0 OR MY_NA_MINS IS NULL THEN
								SET MY_NA_MINS = 0;
							END IF;

							#最早打卡时间晚于下午开始时间，算为迟到
							IF i_check_in > THIS_AST THEN
								SET h_late_mins = MY_NA_MINS;
								SET h_early_mins = 0;
							#最晚打卡时间小于下午结束时间，算早退
							ELSEIF i_check_out < THIS_AET THEN			
								SET h_late_mins = 0;
								SET h_early_mins = MY_NA_MINS;
							ELSE
								SET h_late_mins = 0;
								SET h_early_mins = 0;
							END IF;
						#无外签，无打卡，算迟到
						ELSEIF i_check_osd IS NULL AND i_check_in IS NULL AND i_check_out IS NULL THEN
							SET MY_NA_MINS = (i_daily_work_hour - h_hol_hours) * 60 ;
							IF MY_NA_MINS < 0 OR MY_NA_MINS IS NULL THEN
								SET MY_NA_MINS = 0;
							END IF;
							SET h_late_mins = MY_NA_MINS;
							SET h_early_mins = 0;
						#有外签，啥都不算
						ELSEIF i_check_osd IS NOT NULL THEN
							SET h_late_mins = 0;
							SET h_early_mins = 0;
						END IF;
					#请了下午半天
					ELSEIF i_half_day_flag = 2 THEN
						#无外签，有打卡
						IF i_check_osd IS NULL AND i_check_in IS NOT NULL AND i_check_out IS NOT NULL THEN
							SET MY_NA_MINS = (i_daily_work_hour - h_hol_hours) * 60 - FN_ATT_GET_REAL_DAY_HOURS(time(i_check_in),time(i_check_out),i_emp,bgdt);
							
							IF MY_NA_MINS < 0 OR MY_NA_MINS IS NULL THEN
								SET MY_NA_MINS = 0;
							END IF;
							
							#最早打卡时间晚于上午开始时间，算为迟到
							IF i_check_in > THIS_MST THEN
								SET h_late_mins = MY_NA_MINS;
								SET h_early_mins = 0;
							#最晚打卡时间小于上午结束时间，算早退
							ELSEIF i_check_out < THIS_MET THEN			
								SET h_late_mins = 0;
								SET h_early_mins = MY_NA_MINS;
							ELSE
								SET h_late_mins = 0;
								SET h_early_mins = 0;
							END IF;
						#无外签，无打卡，算迟到
						ELSEIF i_check_osd IS NULL AND i_check_in IS NULL AND i_check_out IS NULL THEN
							SET MY_NA_MINS = (i_daily_work_hour - h_hol_hours) * 60;
							IF MY_NA_MINS < 0 OR MY_NA_MINS IS NULL THEN
								SET MY_NA_MINS = 0;
							END IF;
							SET h_late_mins = MY_NA_MINS;
							SET h_early_mins = 0;
						#有外签，啥都不算
						ELSEIF i_check_osd IS NOT NULL THEN
							SET h_late_mins = 0;
							SET h_early_mins = 0;
						END IF;
					#请了全天
					ELSEIF i_half_day_flag =3 THEN
						SET h_late_mins = 0;
						SET h_early_mins = 0;
					END IF;

					#计算工作时长
					SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60 - h_late_mins - h_early_mins - h_hol_hours*60;
					#计算旷工

					SET h_is_dayoff = FN_ATT_GET_DAYOFF_STATUS(h_late_mins,h_early_mins,MY_ATTID);
					
					IF MY_BOSS_LEVEL IN (2,3) THEN
						SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60;
						SET h_late_mins = 0,h_early_mins = 0,h_is_dayoff=0,h_hol_hours=0;
					END IF;
#select 2,bgdt,h_work_interval,h_late_mins,h_early_mins,h_is_dayoff, h_hol_hours*60;
					#更新数据
					UPDATE att_emp_detail 
					SET work_interval = h_work_interval ,
					  late_mins = FN_ATT_GET_MINUNIT_MINS(h_late_mins,MY_ATTID) ,
					  early_mins = FN_ATT_GET_MINUNIT_MINS(h_early_mins,MY_ATTID) ,
					  is_dayoff = h_is_dayoff,
					  hol_mins = h_hol_hours*60,
					  milk_hol_mins=null
					WHERE emp_id = i_emp and dt = bgdt;	

				#如果当天请假时长没有超过应工作时长，那么针对请假的两个时间点进行判断和处理。
				ELSE
					SET h_is_dayoff = 0 ;
					SET h_work_interval = 0 ;
					SET h_late_mins = 0;
					set h_early_mins = 0;
					#case1 有外勤打卡
					IF i_check_osd IS NOT NULL THEN
						SET h_work_interval=0;
						SET h_late_mins = 0;
						SET h_early_mins = 0;
						SET h_is_dayoff = 0 ;

						IF MY_BOSS_LEVEL IN (2,3) THEN
							SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60;
							SET h_late_mins = 0,h_early_mins = 0,h_is_dayoff=0,h_hol_hours=0;
						END IF;
#select 3,bgdt,h_work_interval,h_late_mins,h_early_mins,h_is_dayoff, h_hol_hours*60; 
						#更新数据
						UPDATE att_emp_detail
						SET #work_interval = h_work_interval ,
						  late_mins = FN_ATT_GET_MINUNIT_MINS(h_late_mins,MY_ATTID) ,
						  early_mins = FN_ATT_GET_MINUNIT_MINS(h_early_mins,MY_ATTID) ,
						  is_dayoff = h_is_dayoff,
						  hol_mins = h_hol_hours*60,
						  milk_hol_mins=null
						WHERE emp_id = i_emp and dt = bgdt;	
					#无外勤
					ELSE
						SET THIS_UID = NULL;
						SET THIS_UID = UUID();
						
						IF i_att_rule = 1 THEN
							SET MY_FLEX_DIFF=0;
							
							IF MY_FST_CHECK IS NOT NULL THEN
								SET MY_FLEX_DIFF = ROUND(TIME_TO_SEC(TIMEDIFF(MY_FST_CHECK,THIS_MST))/60,0);

							END IF;
							

							IF MY_FLEX_DIFF IS NULL OR MY_FLEX_DIFF < 0 THEN
								SET MY_FLEX_DIFF = 0;
							END IF;

						
							#比较时间：写入规则时间
							#月弹：上班弹，下班不弹
							IF i_month_period_hour > 0 AND i_month_period_hour IS NOT NULL THEN

								IF MY_FLEX_DIFF > (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60 THEN
									SET MY_FLEX_DIFF = (FN_ATT_GET_WORKHOURS(MY_ATTID)-i_month_period_hour)*60;
								END IF;
								INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
									(THIS_UID,DATE_ADD(THIS_MST,INTERVAL MY_FLEX_DIFF MINUTE),1,1),
									(THIS_UID,THIS_MET,1,2),
									(THIS_UID,THIS_AST,2,1),
									(THIS_UID,THIS_AET,2,2),
									(THIS_UID,THIS_NA1_BGTM,6,1),
									(THIS_UID,THIS_NA1_EDTM,6,2),
									(THIS_UID,THIS_NA2_BGTM,6,1),
									(THIS_UID,THIS_NA2_EDTM,6,2);
							#日弹：上班弹，下班弹
							ELSEIF i_flex_hour > 0 AND i_flex_hour IS NOT NULL THEN 
#select 'rt',MY_FLEX_DIFF,i_flex_hour,THIS_AET,DATE_ADD(THIS_AET,INTERVAL MY_FLEX_DIFF MINUTE);
								IF MY_FLEX_DIFF > i_flex_hour THEN
									SET MY_FLEX_DIFF = i_flex_hour;
								END IF;
	
								INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
									(THIS_UID,DATE_ADD(THIS_MST,INTERVAL MY_FLEX_DIFF MINUTE),1,1),
									(THIS_UID,THIS_MET,1,2),
									(THIS_UID,THIS_AST,2,1),
									(THIS_UID,DATE_ADD(THIS_AET,INTERVAL MY_FLEX_DIFF MINUTE),2,2),
									(THIS_UID,THIS_NA1_BGTM,6,1),
									(THIS_UID,THIS_NA1_EDTM,6,2),
									(THIS_UID,THIS_NA2_BGTM,6,1),
									(THIS_UID,THIS_NA2_EDTM,6,2);
							#不弹
							ELSE
#select 'bt';
								SET MY_FLEX_DIFF = 0;
								INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
									(THIS_UID,THIS_MST,1,1),
									(THIS_UID,THIS_MET,1,2),
									(THIS_UID,THIS_AST,2,1),
									(THIS_UID,THIS_AET,2,2),
									(THIS_UID,THIS_NA1_BGTM,6,1),
									(THIS_UID,THIS_NA1_EDTM,6,2),
									(THIS_UID,THIS_NA2_BGTM,6,1),
									(THIS_UID,THIS_NA2_EDTM,6,2);
							END IF;
						ELSEIF i_att_rule = 3 THEN
							INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
								(THIS_UID,THIS_ARR_BGTM1,1,1),
								(THIS_UID,THIS_ARR_EDTM1,1,2),
								(THIS_UID,THIS_ARR_BGTM2,2,1),
								(THIS_UID,THIS_ARR_EDTM2,2,2),
								(THIS_UID,THIS_ARR_BGTM3,3,1),
								(THIS_UID,THIS_ARR_EDTM3,3,2);
						END IF;
						
						#比较时间：写入请假时间
						SELECT GROUP_CONCAT(A.start_time,'|',IF(A.apply_end_time IS NULL,A.end_time,A.apply_end_time))
							INTO MY_HOL_STR
						FROM att_hol_apply_day A 
							LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
						WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
							AND (A.is_year_hol NOT IN (4,9) OR (A.is_year_hol=4 AND B.hol_duration=2))
							AND (A.sp_day_id = 0 OR A.sp_day_id IS NULL) and A.hol_hours>0;
	
						SET MY_HOL_STR = CONCAT(MY_HOL_STR,',');

						WHILE LOCATE(',',MY_HOL_STR) <= LENGTH(MY_HOL_STR) AND MY_HOL_STR IS NOT NULL AND LOCATE(',',MY_HOL_STR) > 2 DO
							SET THIS_BGTM=NULL,THIS_EDTM=NULL,THIS_HOL_STR=NULL;
							SET THIS_HOL_STR = LEFT(MY_HOL_STR,LOCATE(',',MY_HOL_STR)-1);
							SET THIS_BGTM = CONCAT(bgdt,' ', LEFT(THIS_HOL_STR,LOCATE('|',THIS_HOL_STR)-1));
							SET THIS_EDTM = CONCAT(bgdt,' ',RIGHT(THIS_HOL_STR,LENGTH(THIS_HOL_STR)-LOCATE('|',THIS_HOL_STR)));
							
							IF THIS_BGTM = MY_FST_CHECK THEN
								SET THIS_BGTM = FN_SYS_DTTMFMT_PURGE_SECOND(THIS_BGTM);							
							END IF;
							
							IF THIS_EDTM = MY_LAST_CHECK THEN
								SET THIS_EDTM = FN_SYS_DTTMFMT_PURGE_SECOND(THIS_EDTM);							
							END IF;
							
							INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
								(THIS_UID,THIS_BGTM,5,1),
								(THIS_UID,THIS_EDTM,5,2);						
							
							SET MY_HOL_STR = RIGHT(MY_HOL_STR,LENGTH(MY_HOL_STR)-LOCATE(',',MY_HOL_STR));
						END WHILE;
						
						#比较时间：写入打卡时间,只有两个打卡不一样的时候才写，否则视为没打卡
						IF i_check_in IS NOT NULL AND i_check_out IS NOT NULL AND i_check_in < i_check_out THEN
							INSERT INTO tmp_att_timeframe_compare_random (version_code,time_point,tp_type,which_pt) VALUES
								(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(i_check_in),4,1),
								(THIS_UID,FN_SYS_DTTMFMT_PURGE_SECOND(i_check_out),4,2);	
						END IF;	
										
						#把所有时间排序写入比较表
						INSERT INTO tmp_att_timeframe_compare (version_code,time_point,tp_type,which_pt)
							SELECT A.version_code,A.time_point,A.tp_type,A.which_pt
							FROM tmp_att_timeframe_compare_random A
							WHERE A.version_code=THIS_UID AND A.time_point IS NOT NULL
							ORDER BY A.time_point,A.tp_type,A.which_pt;
							
#SELECT * FROM tmp_att_timeframe_compare WHERE version_code = THIS_UID;

						#进行比较
						SET h_late_mins=0,h_early_mins=0,THIS_HOL_MINS=0,THIS_WORK_MINS=0,h_work_interval=0;
						CALL FN_ATT_GET_TIMEFRAME_COMPARE(THIS_UID,h_late_mins,h_early_mins,THIS_HOL_MINS,THIS_WORK_MINS);
						

						SET h_work_interval = THIS_WORK_MINS;
						
#sELECT h_late_mins,h_early_mins,THIS_HOL_MINS,THIS_WORK_MINS,MY_FST_CHECK,THIS_MST,THIS_MAX_MST;
						#处理具体结果
						#处理最早考勤时间比最晚上班时间早，迟到时间大于0的情况
						IF (MY_FST_CHECK IS NOT NULL AND MY_FST_CHECK > THIS_MST AND MY_FST_CHECK <= THIS_MAX_MST AND h_late_mins > 0) THEN
							IF h_late_mins >= ROUND(TIME_TO_SEC(TIMEDIFF(THIS_MAX_MST,MY_FST_CHECK))/60,0) THEN
								SET h_late_mins = h_late_mins - ROUND(TIME_TO_SEC(TIMEDIFF(THIS_MAX_MST,MY_FST_CHECK))/60,0);
							ELSE
								SET h_early_mins = h_early_mins + h_late_mins;
								SET h_late_mins = 0;
							END IF;
							IF i_flex_hour > 0 AND h_late_mins + h_early_mins + THIS_HOL_MINS + THIS_WORK_MINS < FN_ATT_GET_WORKHOURS(MY_ATTID) * 60 THEN
#select 1,h_late_mins,THIS_MAX_MST,MY_FST_CHECK;
								SET h_early_mins = h_early_mins + ROUND(TIME_TO_SEC(TIMEDIFF(THIS_MAX_MST,MY_FST_CHECK))/60,0);
							END IF;
							#当最晚考勤时间比最晚下班时间晚，差异值算在工时里
							IF h_late_mins > 0 THEN
								IF MY_LAST_CHECK >= THIS_MAX_AET THEN
#select 3;
									SET h_work_interval = h_work_interval + h_late_mins;
								#否则算在早退里
								ELSE
									SET h_early_mins = h_early_mins + h_late_mins;
#select 4;
								END IF;
								SET h_late_mins=0;
							END IF;
						#晚于最晚上班时间 且 无打卡或一次打卡
						ELSEIF MY_FST_CHECK IS NOT NULL AND MY_FST_CHECK > THIS_MAX_MST AND h_late_mins > 0 
							AND (i_check_in IS NULL OR i_check_out IS NULL OR i_check_in = i_check_out)
						THEN
#SELECT 5;
							SET h_late_mins = h_late_mins - ROUND(TIME_TO_SEC(TIMEDIFF(THIS_MAX_MST,THIS_MST))/60,0);
							SET h_early_mins = h_early_mins + ROUND(TIME_TO_SEC(TIMEDIFF(THIS_MAX_MST,THIS_MST))/60,0);
						ELSEIF MY_FST_CHECK IS NOT NULL AND MY_FST_CHECK <= THIS_MST AND h_late_mins > 0 THEN

							IF MY_LAST_CHECK < THIS_MAX_AET OR THIS_MAX_AET IS NULL THEN
#select 6;
								SET h_early_mins = h_early_mins + h_late_mins;
							ELSE
#select 7,MY_LAST_CHECK,THIS_MAX_AET,MY_FST_CHECK,THIS_MST,h_late_mins;
								SET h_work_interval = h_work_interval + h_late_mins;
							END IF;
							SET h_late_mins = 0;
						END IF;

#select MY_LAST_CHECK,THIS_MAX_AET;
						#处理最晚考勤时间比下班时间晚，还有早退的情况
						IF MY_LAST_CHECK IS NOT NULL AND MY_LAST_CHECK > THIS_MAX_AET AND h_early_mins > 0 THEN
							SET h_work_interval = h_work_interval + h_early_mins;
							SET h_early_mins = 0;
						END IF;
						
						SET ERROR_MINS =  MY_HOLIDAY_HOURS*60 - THIS_HOL_MINS ;
						IF ERROR_MINS > 0 THEN

							IF h_early_mins - ERROR_MINS >= 0 THEN
							 	SET h_early_mins = h_early_mins - ERROR_MINS ;
							 	SET ERROR_MINS = 0;
							ELSE
								SET ERROR_MINS = ERROR_MINS - h_early_mins;
								SET h_early_mins = 0;
							END IF;

							IF h_late_mins - ERROR_MINS >= 0 THEN
							 	SET h_late_mins = h_late_mins - ERROR_MINS ;
							 	SET ERROR_MINS = 0;
							ELSE
								SET ERROR_MINS = ERROR_MINS - h_late_mins;
								SET h_late_mins = 0;
							END IF;

						END IF;
						

						#计算旷工
						SET h_is_dayoff = FN_ATT_GET_DAYOFF_STATUS(h_late_mins,h_early_mins,MY_ATTID);
						IF MY_BOSS_LEVEL IN (2,3) THEN
							SET h_work_interval = FN_ATT_GET_WORKHOURS(MY_ATTID) * 60;
							SET h_late_mins = 0,h_early_mins = 0,h_is_dayoff=0,h_hol_hours=0;
						END IF;
						
						IF h_work_interval < 0 THEN SET h_work_interval = 0 ; END IF;
						IF h_late_mins < 0 THEN SET h_late_mins = 0 ; END IF;
						
#select 4,bgdt,h_work_interval,h_late_mins,h_early_mins,h_is_dayoff, h_hol_hours*60,ERROR_MINS; 
						#更新数据
						UPDATE att_emp_detail 
						SET work_interval = h_work_interval ,
						  late_mins = FN_ATT_GET_MINUNIT_MINS(h_late_mins,MY_ATTID) ,
						  early_mins = FN_ATT_GET_MINUNIT_MINS(h_early_mins,MY_ATTID) ,
						  is_dayoff = h_is_dayoff,
						  hol_mins = h_hol_hours*60,
						  milk_hol_mins=null
						WHERE emp_id = i_emp and dt = bgdt;	 
					END IF;		
				END IF;
			END IF;
					
#1.2 ----------> 	每天N小时的哺乳假
			#首先看看当天有几个休假
			SET i_have_hols = 0;
			SET i_applyid = NULL,i_deptid=null;
			select dept_id into i_deptid from emp_base_info a where a.emp_id=i_emp;
			SELECT count(*),MAX(A.APPLY_ID) INTO i_have_hols,i_applyid
			FROM att_hol_apply_day A 
				LEFT JOIN att_hol_apply B ON A.apply_id=B.apply_id
			WHERE A.emp_id = i_emp AND A.hol_date = bgdt 
				AND ((A.is_year_hol=4 AND B.hol_duration=1) OR A.is_year_hol=9)
				AND (A.sp_day_id=0 OR A.sp_day_id IS NULL) and A.hol_hours>0;
			#如果当天有减N小时的哺乳假
			IF i_have_hols > 0 AND i_applyid IS NOT NULL AND MY_DTTYPE IN (1,6) THEN
				#读出当天日报内容
				SELECT A.late_mins,A.early_mins,A.milk_hol_mins
					INTO THIS_LM,THIS_EM,THIS_MHM
				FROM att_emp_detail A
				WHERE A.emp_id = i_emp AND A.dt =  bgdt;
				
				SET THIS_HOL_MINS = 0;
				
				SELECT ROUND(IF(A.hol_hours IS NULL,0,A.hol_hours) * 60,2) INTO THIS_HOL_MINS
				FROM att_hol_apply_day A
				WHERE A.emp_id = i_emp AND A.hol_date = bgdt AND A.apply_id = i_applyid and A.hol_hours>0;

#select 9,bgdt,THIS_LM,THIS_EM,THIS_MHM, THIS_HOL_MINS;
				#只有当哺乳假小时未被扣除时才进行计算，否则直接跳过
				IF THIS_MHM = 0 OR THIS_MHM IS NULL THEN
					SET THIS_MHM = THIS_HOL_MINS ;
					IF THIS_MHM <= THIS_LM THEN
						SET THIS_LM = THIS_LM - THIS_MHM;
					ELSEIF THIS_MHM > THIS_LM THEN
						SET THIS_EM = THIS_EM - (THIS_MHM - THIS_LM);
						IF THIS_EM < 0 THEN
							SET THIS_MHM = THIS_HOL_MINS + THIS_EM;
						END IF;
						SET THIS_LM = 0;
					END IF;
					IF THIS_LM IS NULL OR THIS_LM < 0 THEN SET THIS_LM = 0; END IF;
					IF THIS_EM IS NULL OR THIS_EM < 0 THEN SET THIS_EM = 0; END IF;

					SET THIS_DAYOFF = FN_ATT_GET_DAYOFF_STATUS(THIS_LM,THIS_EM,MY_ATTID);
					IF MY_BOSS_LEVEL IN (2,3) THEN
						SET THIS_LM = 0,THIS_EM = 0,THIS_DAYOFF=0,THIS_HOL_MINS=0;
					END IF;
					
					IF THIS_LM < 0 THEN SET THIS_LM = 0 ;END IF;
					UPDATE att_emp_detail A
					SET 
						late_mins = FN_ATT_GET_MINUNIT_MINS(THIS_LM,MY_ATTID) ,
						early_mins = FN_ATT_GET_MINUNIT_MINS(THIS_EM,MY_ATTID) ,
						A.milk_hol_mins = THIS_HOL_MINS,
						A.is_dayoff = THIS_DAYOFF
					WHERE A.emp_id = i_emp AND A.dt =  bgdt;
				END IF;
			END IF;
#<<<<<<<<<<<<<<<<<<<		请假校正结束
			#是否请假
			update att_emp_detail a left join att_hol_apply_day b on a.emp_id=b.emp_id and a.dt=b.hol_date
			set a.is_have_hol=1
			where b.hol_hours > 0 AND b.apply_id <> 0 and b.apply_id is not null and a.emp_id=emp and a.dt=bgdt and b.is_year_hol<>10;
			#是否加班
			update att_emp_detail a left join att_over_apply_day b on a.emp_id=b.emp_id and a.dt=b.work_day
			set a.is_have_over=1
			where b.work_hour > 0 and a.emp_id=emp and a.dt=bgdt;
					
			SET bgdt = DATE_ADD(bgdt,INTERVAL 1 DAY);
		END WHILE;
	END IF;
	
	
END;

